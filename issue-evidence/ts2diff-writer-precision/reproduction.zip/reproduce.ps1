# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements. See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership. The ASF licenses this file
# to you under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
param(
    [Parameter(Mandatory = $true)] [string] $TsFileSource,
    [string] $BuildRoot = (Join-Path $PSScriptRoot 'build'),
    [string] $JavaClasspath = '',
    [string] $StaticLibrary = ''
)
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
function Invoke-Checked($Program, [string[]] $Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program exited with $LASTEXITCODE" }
}
function Get-Value($Program, [string[]] $Arguments) {
    $captured = & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program exited with $LASTEXITCODE" }
    $captured | ForEach-Object { Write-Host $_ }
    $values = @($captured | Select-String 'output.value=([0-9.]+)')
    if ($values.Count -ne 1) { throw 'Expected exactly one output value' }
    return $values[0].Matches[0].Groups[1].Value
}
$sourcePath = (Resolve-Path -LiteralPath $TsFileSource).Path
New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
$BuildRoot = (Resolve-Path -LiteralPath $BuildRoot).Path
$java = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME 'bin\java.exe' } else { 'java' }
$javac = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME 'bin\javac.exe' } else { 'javac' }
if (-not $StaticLibrary) {
    $libraryBuild = Join-Path $BuildRoot 'library'
    Invoke-Checked cmake @('-S', "$sourcePath/cpp", '-B', $libraryBuild,
        '-DTSFILE_BUILD_SHARED=OFF', '-DBUILD_TEST=OFF', '-DBUILD_TOOLS=OFF',
        '-DENABLE_ANTLR4=OFF', '-DENABLE_SNAPPY=OFF', '-DENABLE_LZ4=OFF',
        '-DENABLE_LZOKAY=OFF', '-DENABLE_ZLIB=OFF', '-DENABLE_ZSTD=OFF',
        '-DENABLE_LZMA2=OFF', '-DENABLE_SIMD=OFF', '-DENABLE_THREADS=ON')
    Invoke-Checked cmake @('--build', $libraryBuild, '--config', 'Release', '--target', 'tsfile', '--parallel', '6')
    $StaticLibrary = Join-Path $libraryBuild 'lib\Release\tsfile.lib'
}
$programBuild = Join-Path $BuildRoot 'program'
Invoke-Checked cmake @('-S', $PSScriptRoot, '-B', $programBuild, "-DTSFILE_SOURCE=$sourcePath", "-DTSFILE_LIBRARY=$StaticLibrary")
Invoke-Checked cmake @('--build', $programBuild, '--config', 'Release', '--target', 'precision_repro')
if (-not $JavaClasspath) {
    Invoke-Checked mvn @('-f', "$sourcePath/pom.xml", '-P', 'with-java', '-pl', 'java/tsfile', '-am',
        '-Dtest=CompatibilityTest', '-Dsurefire.failIfNoSpecifiedTests=false', '-Dspotless.skip=true', 'test')
    [xml] $report = Get-Content -LiteralPath "$sourcePath/java/tsfile/target/surefire-reports/TEST-org.apache.tsfile.compatibility.CompatibilityTest.xml" -Raw
    $JavaClasspath = ($report.testsuite.properties.property | Where-Object { $_.name -eq 'java.class.path' }).value
    if (-not $JavaClasspath) { throw 'Missing Java classpath' }
}
$classes = Join-Path $BuildRoot 'classes'
New-Item -ItemType Directory -Force -Path $classes | Out-Null
Invoke-Checked $javac @('-cp', $JavaClasspath, '-d', $classes, "$PSScriptRoot/PrecisionRepro.java")
$classpath = $JavaClasspath + ';' + $classes
$cpp = Join-Path $programBuild 'Release\precision_repro.exe'
$mismatches = 0
$controls = 0
foreach ($type in @('FLOAT', 'DOUBLE')) {
    foreach ($alignment in @('nonaligned', 'aligned')) {
        foreach ($precision in @('0', '2', '4', 'default')) {
            $id = "$type-$alignment-$precision"
            $javaFile = Join-Path $BuildRoot "$id-java.tsfile"
            $cppFile = Join-Path $BuildRoot "$id-cpp.tsfile"
            if ((Test-Path -LiteralPath $javaFile) -or (Test-Path -LiteralPath $cppFile)) { throw 'Use a fresh BuildRoot for each run' }
            Write-Host "CASE=$id"
            $javaValue = Get-Value $java @('-cp', $classpath, 'PrecisionRepro', 'write', $javaFile, $type, $precision, $alignment)
            $cppValue = Get-Value $cpp @('write', $cppFile, $type, $precision, $alignment)
            $javaReadsCpp = Get-Value $java @('-cp', $classpath, 'PrecisionRepro', 'read', $cppFile, $type, $precision, $alignment)
            $cppReadsJava = Get-Value $cpp @('read', $javaFile, $type, $precision, $alignment)
            $expected = switch ($precision) { '0' { '1.000000' }; '4' { '1.234600' }; default { '1.230000' } }
            if ($javaValue -ne $expected -or $cppValue -ne '1.230000') { throw "Unexpected writer value: $id" }
            if ($javaReadsCpp -ne $cppValue -or $cppReadsJava -ne $javaValue) { throw "Cross-read changed the stored value: $id" }
            if ($javaValue -eq $cppValue) { $controls++ } else { $mismatches++ }
            Write-Host "comparison.java=$javaValue comparison.cpp=$cppValue cross_read=PRESERVES_STORED_VALUE"
        }
    }
}
Write-Host "configurations=16 reproduced_mismatches=$mismatches matching_controls=$controls cross_reads=32"
if ($mismatches -ne 8 -or $controls -ne 8) { throw 'Unexpected reproduction summary' }
Write-Host 'reproduction=CONFIRMED'

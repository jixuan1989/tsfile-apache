from pathlib import Path
import hashlib,json,re,struct
def pe(p):
    data=p.read_bytes();o=struct.unpack_from('<I',data,0x3c)[0];assert data[o:o+4]==b'PE\0\0'
    count=struct.unpack_from('<H',data,o+6)[0];opt=o+24;start=opt+struct.unpack_from('<H',data,o+20)[0]
    result={}
    for i in range(count):
        at=start+40*i;n=data[at:at+8].rstrip(b'\0').decode();virtual,rva,size,raw=struct.unpack_from('<IIII',data,at+8)
        result[n]={'rva':rva,'data':data[raw:raw+size],'virtual_bytes':virtual}
    dr,ds=struct.unpack_from('<II',data,opt+112+6*8)
    result['debug_timestamps']={dr+i+4+j for i in range(0,ds,28) for j in range(4)}
    return result
def coff(p):
    d=p.read_bytes();big=d[:4]==b'\0\0\xff\xff'
    n,ptr,count=struct.unpack_from('<III',d,44) if big else (struct.unpack_from('<H',d,2)[0],*struct.unpack_from('<II',d,8))
    size=20 if big else 18;start=56 if big else 20;strings=ptr+count*size
    def name(raw):
        if raw[:4]==b'\0'*4:
            at=strings+struct.unpack_from('<I',raw,4)[0];return d[at:d.index(b'\0',at)].decode()
        return raw.rstrip(b'\0').decode()
    sections=[]
    for i in range(n):
        at=start+40*i;nm=d[at:at+8].rstrip(b'\0').decode()
        if nm.startswith('/'):
            a=strings+int(nm[1:]);nm=d[a:d.index(b'\0',a)].decode()
        length,raw,relptr=struct.unpack_from('<III',d,at+16);rels=struct.unpack_from('<H',d,at+32)[0];chars=struct.unpack_from('<I',d,at+36)[0]
        sections.append({'name':nm,'bytes':length,'characteristics':chars,'comdat':bool(chars&0x1000),
            'sha256':hashlib.sha256(d[raw:raw+length]).hexdigest(),'relocations':[struct.unpack_from('<IIH',d,relptr+j*10) for j in range(rels)]})
    symbols={};at=0
    while at<count:
        off=ptr+at*size;nm=name(d[off:off+8]);value=struct.unpack_from('<I',d,off+8)[0]
        sec=struct.unpack_from('<i' if big else '<h',d,off+12)[0];storage=d[off+(18 if big else 16)];aux=d[off+(19 if big else 17)]
        symbols[at]={'name':nm,'value':value,'section':sec,'storage':storage};at+=1+aux
    return {'sections':sections,'symbols':symbols}
def symbols(p):
    result={}
    for line in p.read_text(encoding='utf-8').splitlines():
        m=re.match(r'\s+([0-9a-fA-F]{4}):[0-9a-fA-F]+\s+(\S+)\s+([0-9a-fA-F]{16})\s+(.*?)\s+([^ ]+)$',line)
        if m:result[m[2]]={'rva':int(m[3],16)-0x140000000,'owner':m[5],'segment':m[1]}
    return result

"""Account for all original reader PE section differences; never patch images."""
from pathlib import Path
from collections import Counter
import hashlib,json,struct
from binary_helpers import pe
here=Path(__file__).resolve().parent;root=here.parent
a=json.loads((here/'analysis.json').read_text());imports=json.loads((root/'dependency-audit/imports.json').read_text())
old=json.loads((root/'diagnosis/normalized-instruction-differences.json').read_text());crt=json.loads((here/'crt-arrays.json').read_text())
pools=json.loads((here/'constant-pools.json').read_text())
versions={};labels={};relocs={};known_relocs={};native_inputs={}
for v in ['baseline','fixed']:
    p=root/f'reader-only/build/Release/read_only_02_{v}.exe';d=p.read_bytes();image=pe(p);versions[v]=image
    assert hashlib.sha256(d).hexdigest()==imports['original_image_imports']['reader_only']['versions'][v]['image_sha256']
    native_inputs[v]={'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d)}
    labels[v]={};known_relocs[v]=set()
    def label(start,size,kind):
        for n in range(size):labels[v].setdefault(start+n,set()).add(kind)
    for name,node in a['nodes'].items():
        if node.get('boundary'):continue
        n=node['variants'][v];label(n['section_rva'],n['section_bytes'],'audited_vtable_RTTI')
        known_relocs[v].update(n['section_rva']+r['offset'] for r in n['relocations'] if r['kind']==1)
    for pool in pools['variants'][v]:
        for rva in pool['rvas']:label(rva,pool['bytes'],'COFF_verified_literal_pool')
    for rva in image['debug_timestamps']:label(rva,1,'PE_debug_timestamp')
    def offset(rva,size=1):
        start=struct.unpack_from('<I',d,0x3c)[0];count=struct.unpack_from('<H',d,start+6)[0];pos=start+24+struct.unpack_from('<H',d,start+20)[0]
        results=[]
        for i in range(count):
            at=pos+40*i;virt,srva,rawsize,raw=struct.unpack_from('<IIII',d,at+8)
            if srva<=rva and rva+size<=srva+rawsize:results.append(raw+rva-srva)
        assert len(results)==1;return results[0]
    def string(rva):
        at=offset(rva);return d[at:d.index(b'\0',at)].decode()
    pe_at=struct.unpack_from('<I',d,0x3c)[0];opt=pe_at+24;irva,ibytes=struct.unpack_from('<II',d,opt+112+8)
    imported={}
    for k in range(ibytes//20):
        original,stamp,fwd,name,first=struct.unpack_from('<IIIII',d,offset(irva+k*20,20))
        if not any([original,stamp,fwd,name,first]):break
        dll=string(name).lower()
        for i in range(len(d)//8):
            value=struct.unpack_from('<Q',d,offset((original or first)+i*8,8))[0]
            if not value:break
            function='#'+str(value&0xffff) if value>>63 else string(value+2)
            key=dll+'!'+function;imported[key]={'iat':first+i*8,'ilt':(original or first)+i*8,'name_rva':value}
    assert set(imported)==set(imports['original_image_imports']['reader_only']['versions'][v]['imports'])
    for key,x in imported.items():
        label(x['iat'],8,'same_import_binding_IAT');label(x['ilt'],8,'same_import_binding_ILT')
        if not x['name_rva']>>63:
            name_size=len(key.split('!',1)[1].encode())+1
            label(x['name_rva'],2+name_size,'same_import_function_name_storage')
    rrva,rbytes=struct.unpack_from('<II',d,opt+112+5*8);at=0;entries=set();padding=0
    while at<rbytes:
        page,size=struct.unpack_from('<II',d,offset(rrva+at,8));assert size>=8 and size%2==0
        for j in range((size-8)//2):
            word=struct.unpack_from('<H',d,offset(rrva+at+8+2*j,2))[0];kind=word>>12;low=word&4095
            if kind==0:padding+=1;continue
            assert kind==10
            assert page+low not in entries
            entries.add(page+low)
        at+=size
    assert at==rbytes
    relocs[v]={'entries':sorted(entries),'padding_entries':padding,'bytes':rbytes}
    assert known_relocs[v]<=entries
differences={};uncovered=[]
for section,ls in versions['baseline'].items():
    if not isinstance(ls,dict):continue
    rs=versions['fixed'][section];assert ls['rva']==rs['rva'] and len(ls['data'])==len(rs['data'])
    positions=[ls['rva']+i for i,(x,y) in enumerate(zip(ls['data'],rs['data'])) if x!=y]
    groups=Counter();unknown=[]
    if section=='.rdata':
        for rva in positions:
            kinds=labels['baseline'].get(rva,set())|labels['fixed'].get(rva,set())
            if not kinds:unknown.append(rva)
            else:groups['|'.join(sorted(kinds))]+=1
        uncovered.extend(unknown)
    differences[section]={'different_bytes':len(positions),'classifications':dict(groups),'unclassified_rvas':unknown}
left,right=set(relocs['baseline']['entries']),set(relocs['fixed']['entries'])
removed,added=left-right,right-left
known_removed=known_relocs['baseline']-known_relocs['fixed'];known_added=known_relocs['fixed']-known_relocs['baseline']
relocation_explained=removed==known_removed and added==known_added
result={'original_images':native_inputs,'section_differences':differences,
    'base_relocations':relocs,'removed_base_relocation_locations':sorted(removed),'added_base_relocation_locations':sorted(added),
    'relocation_location_changes_exactly_match_audited_data_nodes':relocation_explained,
    'all_rdata_differences_accounted':not uncovered,'unclassified_rdata_bytes':len(uncovered),
    'CRT_initialization_arrays_equal':all(x['equal_sequence'] for x in crt['comparisons'].values()),
    'CRT_XCU_pointer_count':crt['comparisons']['.CRT$XCU']['bytes']//8,
    'literal_pool_limits':pools['limit'],
    'existing_code_reference_analysis':{'different_text_bytes':old['differing_text_bytes'],'changed_instructions':old['changed_instructions'],
        'same_operations_and_named_targets':old['all_changed_instructions_are_same_operations_addressing_common_symbols']},
    'query_timings':0,'query_gate_cleared':False,'necessary_cost_proven':False,
    'limit':'Static difference accounting only: same bindings/data structure and initial CRT function-pointer sequence do not prove same runtime allocation/cache state, absolute addresses, behavior under all address-sensitive APIs, or performance.'}
(here/'image-differences.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'section_differing_bytes':{k:v['different_bytes'] for k,v in differences.items()},'rdata_classifications':differences['.rdata']['classifications'],
    'unclassified_rdata_bytes':len(uncovered),'first_unclassified_rvas':uncovered[:15],
    'removed_relocations':len(removed),'added_relocations':len(added),'relocation_changes_match_audited_nodes':relocation_explained,
    'CRT_initialization_arrays_equal':result['CRT_initialization_arrays_equal'],'CRT_XCU_pointers':result['CRT_XCU_pointer_count'],'new_query_timings':0}))

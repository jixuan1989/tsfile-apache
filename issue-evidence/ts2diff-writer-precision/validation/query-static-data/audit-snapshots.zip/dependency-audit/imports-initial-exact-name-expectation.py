"""Resolve original-image import slots; no execution or binary patching."""
from pathlib import Path
import hashlib,json,re,struct
root=Path(__file__).resolve().parent;here=root/'dependency-audit'
def imports(path):
    d=path.read_bytes();pe=struct.unpack_from('<I',d,0x3c)[0];opt=pe+24
    assert d[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',d,opt)[0]==0x20b
    ns=struct.unpack_from('<H',d,pe+6)[0];secoff=opt+struct.unpack_from('<H',d,pe+20)[0];sections=[]
    for i in range(ns):
        p=secoff+i*40;virtual,rva,size,raw=struct.unpack_from('<IIII',d,p+8);sections.append((rva,raw,size))
    def offset(rva):
        found=[raw+rva-start for start,raw,size in sections if start<=rva<start+size];assert len(found)==1;return found[0]
    def string(rva):
        p=offset(rva);return d[p:d.index(b'\0',p)].decode('ascii')
    irva,ibytes=struct.unpack_from('<II',d,opt+112+8);table={};pos=offset(irva)
    for descriptor in range(ibytes//20):
        original,timestamp,forwarder,name,first=struct.unpack_from('<IIIII',d,pos+descriptor*20)
        if not any([original,timestamp,forwarder,name,first]):break
        dll=string(name).lower();thunk=offset(original or first)
        for i in range(len(d)//8):
            value=struct.unpack_from('<Q',d,thunk+i*8)[0]
            if not value:break
            function='#'+str(value&0xffff) if value>>63 else string(value+2)
            key=dll+'!'+function;assert key not in table
            table[key]={'dll':dll,'function':function,'iat_slot_rva':first+i*8}
    assert table
    return table
def map_imports(p):
    found={}
    for line in p.read_text(encoding='utf-8').splitlines():
        m=re.match(r'\s+[0-9a-fA-F]{4}:[0-9a-fA-F]+\s+(__imp_\S+)\s+([0-9a-fA-F]{16})\s',line)
        if m:found[m[1]]=int(m[2],16)-0x140000000
    return found
records={};tables={}
for caller in ['mixed','reader_only']:
    versions={}
    for v in ['baseline','fixed']:
        path=root/(f'build/Release/query_02_{v}.exe' if caller=='mixed' else f'reader-only/build/Release/read_only_02_{v}.exe')
        table=imports(path);maps=map_imports(here/f'build/{caller}_{v}.map');slots={x['iat_slot_rva']:x for x in table.values()}
        matched={}
        for name,rva in maps.items():
            if rva not in slots:continue
            value=slots[rva]
            assert name=='__imp_'+value['function'],(name,value)
            matched[name]={'dll':value['dll'],'function':value['function'],'rva':rva}
        assert matched and all(x['iat_slot_rva'] in set(maps.values()) for x in table.values())
        versions[v]={'image_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'imports':table,'map_imports':matched}
        tables[caller,v]=matched
    left,right=versions['baseline']['imports'],versions['fixed']['imports']
    records[caller]={'versions':versions,'baseline_only':sorted(set(left)-set(right)),'fixed_only':sorted(set(right)-set(left)),
        'shifted_slots':[{'import':name,'baseline_rva':left[name]['iat_slot_rva'],'fixed_rva':right[name]['iat_slot_rva'],
            'slot_difference_bytes':right[name]['iat_slot_rva']-left[name]['iat_slot_rva'],
            'same_64byte_rva_line':left[name]['iat_slot_rva']//64==right[name]['iat_slot_rva']//64} for name in sorted(set(left)&set(right)) if left[name]['iat_slot_rva']!=right[name]['iat_slot_rva']]}
old=json.loads((root/'diagnosis/normalized-instruction-differences.json').read_text())
referenced={}
for ins in old['instructions']:
    for name in ins['common_map_target_symbols']:
        if name.startswith('__imp_'):
            assert tables['reader_only','baseline'][name]['function']==tables['reader_only','fixed'][name]['function']
            item=referenced.setdefault(name,{'changed_instructions':0,'baseline':tables['reader_only','baseline'][name],
                'fixed':tables['reader_only','fixed'][name]})
            item['changed_instructions']+=1
result={'original_image_imports':records,'reader_only_changed_instruction_import_targets':referenced,
    'query_timings':0,'source_changed':False,'binary_patched':False,'query_gate_cleared':False,'necessary_cost_proven':False,
    'limits':['RVA slot layout is not a measurement of cache misses, cache set ownership or latency.',
              'Same DLL and symbol names do not prove identical runtime absolute addresses or surrounding memory behavior.',
              'Public MAP function absence is not a dynamic call trace; combined with the retained instruction analysis it rejects an asserted new precision call path, not the original performance signal.']}
(here/'imports.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'scope':{c:{'imports_baseline':len(r['versions']['baseline']['imports']),'imports_fixed':len(r['versions']['fixed']['imports']),'baseline_only':r['baseline_only'],'fixed_only':r['fixed_only'],'shifted_slots':len(r['shifted_slots'])} for c,r in records.items()},'changed_instruction_import_targets':referenced,'new_query_timings':0}))

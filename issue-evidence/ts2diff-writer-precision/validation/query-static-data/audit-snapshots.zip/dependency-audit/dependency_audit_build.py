"""Relink exact original objects/libraries with dependency logging only."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess

root=Path(__file__).resolve().parent;here=root/'dependency-audit';here.mkdir(exist_ok=True)
base=root.parents[1];cmake='C:/Program Files/CMake/bin/cmake.exe'
inputs=[root/'reader-only/build/reader_object.dir/Release/reader_only.obj']
for v in ['baseline','fixed']:
    inputs.extend([base/f'work/issue-02/validation/msvc-{v}/lib/Release/tsfile.lib',root/f'build/query_02_{v}.dir/Release/query_benchmark.obj',
                   root/f'build/Release/query_02_{v}.exe',root/f'reader-only/build/Release/read_only_02_{v}.exe'])
def snapshot():return {p.relative_to(base).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs}
frozen=snapshot()
plan={'created_at':datetime.now(timezone.utc).isoformat(),'inputs':frozen,'query_timings':0,'source_edits':0,
      'purpose':'Record which archive members are loaded and which unresolved symbols cause extraction. Relink only with VERBOSE:LIB and MAP diagnostics. Require unchanged .text/.pdata and debug-timestamp-only .rdata differences before applying logs to original images.',
      'stop':'If any exact-image guard fails, keep logs and stop attribution. No variants, source edits, function order or timing runs in this step.'}
(here/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(here/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.20)
project(query_dependency_maps LANGUAGES CXX)
get_filename_component(ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../../.." ABSOLUTE)
foreach(caller mixed reader_only)
  foreach(version baseline fixed)
    if(caller STREQUAL "mixed")
      set(OBJECT "${ROOT}/work/query-backfill/build/query_02_${version}.dir/Release/query_benchmark.obj")
    else()
      set(OBJECT "${ROOT}/work/query-backfill/reader-only/build/reader_object.dir/Release/reader_only.obj")
    endif()
    set(NAME ${caller}_${version})
    add_executable(${NAME} "${OBJECT}")
    set_target_properties(${NAME} PROPERTIES LINKER_LANGUAGE CXX)
    target_link_libraries(${NAME} PRIVATE "${ROOT}/work/issue-02/validation/msvc-${version}/lib/Release/tsfile.lib" psapi)
    target_link_options(${NAME} PRIVATE "/MAP:${CMAKE_CURRENT_BINARY_DIR}/${NAME}.map" "/VERBOSE:LIB")
  endforeach()
endforeach()
''')
commands=[[cmake,'-S',str(here),'-B',str(here/'build'),'-G','Visual Studio 18 2026']]
commands.extend([cmake,'--build',str(here/'build'),'--config','Release','--target',f'{c}_{v}','--','/m:1','/v:normal'] for c in ['mixed','reader_only'] for v in ['baseline','fixed'])
results=[]
for n,args in enumerate(commands):
    log=here/('configure.log' if n==0 else args[args.index('--target')+1]+'.log')
    with log.open('w',encoding='utf-8') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
    results.append({'command':args,'log':log.name,'exit_code':p.returncode})
    (here/'build-results.json').write_text(json.dumps(results,indent=2)+'\n')
    assert p.returncode==0,log
assert snapshot()==frozen,'Original artifact mutated'
print(json.dumps({'links_completed':4,'inputs_unchanged':True,'new_query_timings':0}))

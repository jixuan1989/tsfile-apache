"""Check exact-image sidecars and trace selected archive-member references."""
from pathlib import Path
import hashlib,json,re,struct
root=Path(__file__).resolve().parent;here=root/'dependency-audit';base=root.parents[1]
plan=json.loads((here/'plan.json').read_text())
for p,r in plan['inputs'].items():assert hashlib.sha256((base/p).read_bytes()).hexdigest()==r['sha256']
def pe(p):
    data=p.read_bytes();o=struct.unpack_from('<I',data,0x3c)[0];assert data[o:o+4]==b'PE\0\0'
    count=struct.unpack_from('<H',data,o+6)[0];opt=o+24;start=opt+struct.unpack_from('<H',data,o+20)[0]
    result={}
    for i in range(count):
        at=start+40*i;n=data[at:at+8].rstrip(b'\0').decode();virtual,rva,size,raw=struct.unpack_from('<IIII',data,at+8)
        result[n]={'rva':rva,'data':data[raw:raw+size],'virtual_bytes':virtual}
    dr,ds=struct.unpack_from('<II',data,opt+112+6*8)
    result['debug_timestamps']={dr+i+4+j for i in range(0,ds,28) for j in range(4)}
    return result
def coff(p):
    d=p.read_bytes();big=d[:4]==b'\0\0\xff\xff'
    n,ptr,count=struct.unpack_from('<III',d,44) if big else (struct.unpack_from('<H',d,2)[0],*struct.unpack_from('<II',d,8))
    size=20 if big else 18;start=56 if big else 20;strings=ptr+count*size
    def name(raw):
        if raw[:4]==b'\0'*4:
            at=strings+struct.unpack_from('<I',raw,4)[0];return d[at:d.index(b'\0',at)].decode()
        return raw.rstrip(b'\0').decode()
    sections=[]
    for i in range(n):
        at=start+40*i;nm=d[at:at+8].rstrip(b'\0').decode()
        if nm.startswith('/'):
            a=strings+int(nm[1:]);nm=d[a:d.index(b'\0',a)].decode()
        length,raw,relptr=struct.unpack_from('<III',d,at+16);rels=struct.unpack_from('<H',d,at+32)[0];chars=struct.unpack_from('<I',d,at+36)[0]
        sections.append({'name':nm,'bytes':length,'characteristics':chars,'comdat':bool(chars&0x1000),
            'sha256':hashlib.sha256(d[raw:raw+length]).hexdigest(),'relocations':[struct.unpack_from('<IIH',d,relptr+j*10) for j in range(rels)]})
    symbols={};at=0
    while at<count:
        off=ptr+at*size;nm=name(d[off:off+8]);value=struct.unpack_from('<I',d,off+8)[0]
        sec=struct.unpack_from('<i' if big else '<h',d,off+12)[0];storage=d[off+(18 if big else 16)];aux=d[off+(19 if big else 17)]
        symbols[at]={'name':nm,'value':value,'section':sec,'storage':storage};at+=1+aux
    return {'sections':sections,'symbols':symbols}
def symbols(p):
    result={}
    for line in p.read_text(encoding='utf-8').splitlines():
        m=re.match(r'\s+([0-9a-fA-F]{4}):[0-9a-fA-F]+\s+(\S+)\s+([0-9a-fA-F]{16})\s+(.*?)\s+([^ ]+)$',line)
        if m:result[m[2]]={'rva':int(m[3],16)-0x140000000,'owner':m[5],'segment':m[1]}
    return result
guards=[];scope={}
for caller in ['mixed','reader_only']:
    for v in ['baseline','fixed']:
        original=root/(f'build/Release/query_02_{v}.exe' if caller=='mixed' else f'reader-only/build/Release/read_only_02_{v}.exe')
        linked=here/f'build/Release/{caller}_{v}.exe';a,b=pe(original),pe(linked)
        assert a['.text']==b['.text'] and a['.pdata']==b['.pdata']
        aa,bb=a['.rdata'],b['.rdata'];assert aa['rva']==bb['rva'] and len(aa['data'])==len(bb['data'])
        differences={aa['rva']+i for i,(x,y) in enumerate(zip(aa['data'],bb['data'])) if x!=y}
        assert differences<=a['debug_timestamps']&b['debug_timestamps']
        guards.append({'caller':caller,'version':v,'text_and_pdata_exact':True,'rdata_changed_bytes':len(differences),
            'rdata_changes_only_debug_timestamps':True,'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest()})
        if caller!='reader_only':continue
        maps=symbols(here/f'build/{caller}_{v}.map')
        objbase=base/f'work/issue-02/validation/msvc-{v}'
        objects={}
        for name in ['tsfile_writer','chunk_writer','value_chunk_writer','page_writer','value_page_writer','time_chunk_writer','time_page_writer']:
            paths=list((objbase/'src/writer').rglob(name+'.obj'));assert len(paths)==1
            objects[name+'.obj']=coff(paths[0])
        driver=coff(root/'reader-only/build/reader_object.dir/Release/reader_only.obj')
        api_names=['?libtsfile_init@storage@@YAHXZ','?libtsfile_destroy@storage@@YAXXZ']
        entries=[]
        for nm in api_names:
            found=[s for s in driver['symbols'].values() if s['name']==nm and s['section']==0 and s['storage']==2]
            assert len(found)==1 and maps[nm]['owner']=='tsfile:tsfile_writer.obj'
            definition=next(s for s in objects['tsfile_writer.obj']['symbols'].values() if s['name']==nm and s['section']>0)
            sec=objects['tsfile_writer.obj']['sections'][definition['section']-1]
            assert not sec['comdat'] and sec['name'].startswith('.text')
            entries.append({'symbol':nm,'selected_provider':maps[nm],'section':{k:sec[k] for k in ['name','bytes','comdat','sha256']}})
        nodes={};edges=[]
        for name,obj in objects.items():
            retained=[]
            for idx,sec in enumerate(obj['sections'],1):
                if sec['comdat'] or not sec['name'].startswith('.text') or not sec['bytes']:continue
                definitions=[s for s in obj['symbols'].values() if s['section']==idx and s['storage']==2 and s['name'] in maps and maps[s['name']]['owner']=='tsfile:'+name]
                if not definitions:continue
                bases={maps[s['name']]['rva']-s['value'] for s in definitions};assert len(bases)==1
                retained.append({'name':sec['name'],'bytes':sec['bytes'],'rva':next(iter(bases)),
                    'public_function_definitions':len(definitions),'function_symbols':[s['name'] for s in definitions]})
                for offset,symbol_index,kind in sec['relocations']:
                    target=obj['symbols'][symbol_index]
                    selected=maps.get(target['name'])
                    if target['section']==0 and selected and selected['owner'].startswith('tsfile:'):
                        provider=selected['owner'].split(':',1)[1]
                        if provider!=name:edges.append({'from':name,'to':provider,'symbol':target['name'],'source_section':sec['name'],'relocation_offset':offset,'relocation_type':kind})
            nodes[name]={'retained_non_comdat_sections':retained,'non_comdat_code_bytes':sum(s['bytes'] for s in retained)}
        scope[v]={'root_api_references':entries,'writer_objects':nodes,'selected_external_edges_from_retained_noncomdat_code':edges}
report={'guards':guards,'reader_only_dependencies':scope,'query_timings':0,'source_changed':False,
    'query_gate_cleared':False,'necessary_cost_proven':False,
    'verbose_lib_log_limit':'This linker version prints library search paths but no Found/Referenced-in/Loaded member edges; selected MAP providers plus COFF references are used instead.',
    'interpretation':'Reader-only driver references libtsfile_init/destroy; both are defined in tsfile_writer.obj within a non-COMDAT code section. Retaining this object also retains its writer implementation block and its static dependencies. This is a real library boundary coupling, not proof of runtime writer execution or the original query slowdown cause.'}
(here/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'four_original_image_guards_passed':True,'reader_only_retained_writer_code_bytes':{v:{n:x['non_comdat_code_bytes'] for n,x in z['writer_objects'].items()} for v,z in scope.items()},'root_api_providers':{v:[e['selected_provider'] for e in z['root_api_references']] for v,z in scope.items()},'new_query_timings':0}))

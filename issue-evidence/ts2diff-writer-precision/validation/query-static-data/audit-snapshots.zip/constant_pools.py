"""Locate original non-COMDAT literal pools by owner-qualified MAP anchors."""
from pathlib import Path
from collections import defaultdict,Counter
import hashlib,json,re,struct
from binary_helpers import pe,coff
here=Path(__file__).resolve().parent;root=here.parent;base=root.parents[1]
variants={};provenance={}
for v in ['baseline','fixed']:
    image=pe(root/f'reader-only/build/Release/read_only_02_{v}.exe')
    entries=defaultdict(list)
    for line in (root/f'dependency-audit/build/reader_only_{v}.map').read_text().splitlines():
        m=re.match(r'\s+([0-9a-fA-F]{4}):[0-9a-fA-F]+\s+(\S+)\s+([0-9a-fA-F]{16})\s+(.*?)\s+(tsfile:[^ ]+)$',line)
        if m:entries[m[5]].append({'name':m[2],'rva':int(m[3],16)-0x140000000,'segment':m[1]})
    members={p.name:p for p in (base/f'work/issue-02/validation/msvc-{v}/src').rglob('*.obj')}
    pools=[]
    for owner,records in entries.items():
        path=members[owner.split(':',1)[1]];data=path.read_bytes();obj=coff(path);start=56 if data[:4]==b'\0\0\xff\xff' else 20
        map_names=defaultdict(list)
        for r in records:map_names[r['name']].append(r)
        for section,sec in enumerate(obj['sections'],1):
            if sec['name']!='.rdata' or sec['comdat'] or sec['relocations'] or not sec['bytes']:continue
            definitions=[s for s in obj['symbols'].values() if s['section']==section and s['name']!='.rdata']
            anchors=[(s,m) for s in definitions for m in map_names[s['name']] if m['segment']=='0002']
            at=start+40*(section-1);size,raw=struct.unpack_from('<II',data,at+16);content=data[raw:raw+size]
            rdata=image['.rdata']
            if anchors:
                rvas={m['rva']-s['value'] for s,m in anchors};assert len(rvas)==1
            else:
                if size<32 or sum(x!=0 for x in content)<8:continue
                rvas=set();search=0
                while True:
                    at_match=rdata['data'].find(content,search)
                    if at_match<0:break
                    rvas.add(rdata['rva']+at_match);search=at_match+1
                if not rvas:continue
            for rva in rvas:
                offset=rva-rdata['rva'];assert rdata['data'][offset:offset+size]==content
            defs=sorted(definitions,key=lambda s:(s['value'],s['name']))
            locations=sorted(set(s['value'] for s in defs)|{len(content)})
            constants=[]
            for s in defs:
                end=next(x for x in locations if x>s['value'])
                value=content[s['value']:end];refs=[]
                for source_index,source in enumerate(obj['sections'],1):
                    for ro,index,kind in source['relocations']:
                        target=obj['symbols'][index]
                        if target['section']!=section or target['value']!=s['value']:continue
                        funcs=[x['name'] for x in obj['symbols'].values() if x['section']==source_index and x['storage']==2]
                        refs.append({'source_section':source['name'],'source_symbols':funcs,
                            'selected_symbols_from_this_owner':[n for n in funcs if any(x['name']==n and x['segment']=='0001' for x in records)]})
                constants.append({'name':s['name'],'offset':s['value'],'storage':s['storage'],
                    'span_to_next_symbol_bytes':len(value),'bytes_hex':value.hex(),
                    'payload_without_trailing_NUL_padding_sha256':hashlib.sha256(value.rstrip(b'\0')).hexdigest(),
                    'incoming_references':refs})
            pools.append({'owner':owner,'section':section,'rvas':sorted(rvas),'location_method':'owner-qualified MAP anchor' if anchors else 'all exact full-section byte matches; owner attribution ambiguous',
                'bytes':size,'sha256':hashlib.sha256(content).hexdigest(),
                'content_hex':content.hex(),'constants':constants})
            provenance[path.relative_to(base).as_posix()]=hashlib.sha256(data).hexdigest()
    variants[v]=pools
maps={v:{(p['owner'],c['name']):c for p in ps for c in p['constants']} for v,ps in variants.items()}
shared=sorted(set(maps['baseline'])&set(maps['fixed']))
changed=[{'owner':key[0],'symbol':key[1]} for key in shared if maps['baseline'][key]['payload_without_trailing_NUL_padding_sha256']!=maps['fixed'][key]['payload_without_trailing_NUL_padding_sha256']]
missing={v:[{'owner':key[0],'symbol':key[1],'constant':maps[v][key]} for key in sorted(set(maps[v])-set(maps['fixed' if v=='baseline' else 'baseline']))] for v in variants}
result={'variants':variants,'shared_owner_qualified_constant_symbols':len(shared),'shared_normalized_payload_differences':changed,
    'unpaired_constants':missing,'object_sha256':provenance,
    'normalization':'Span from each COFF definition to next symbol/section end; trailing NUL bytes excluded for this descriptive payload comparison. Full original pool bytes are separately checked against PE/GNU data; this normalization is not general semantic equivalence.',
    'limit':'No code-reference or runtime cache/latency conclusion follows from section placement alone. Owner-qualify duplicate internal MAP names; global name dictionaries can silently select the wrong copy.'}
(here/'constant-pools.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pools':{v:len(ps) for v,ps in variants.items()},'shared_owner_qualified_constants':len(shared),'changed_shared_payloads':changed,
    'unpaired':{v:[{'owner':n['owner'],'symbol':n['symbol'],'incoming_references':len(n['constant']['incoming_references'])} for n in ns] for v,ns in missing.items()}}))

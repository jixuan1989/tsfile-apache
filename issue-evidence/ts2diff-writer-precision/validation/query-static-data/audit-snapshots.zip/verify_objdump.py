"""Cross-check saved relocated data with GNU binutils, not the PE parser."""
from pathlib import Path,PureWindowsPath
import hashlib,json,re,struct,subprocess
here=Path(__file__).resolve().parent;root=here.parent
a=json.loads((here/'analysis.json').read_text());records=[]
pools=json.loads((here/'constant-pools.json').read_text());crt=json.loads((here/'crt-arrays.json').read_text())
version=subprocess.run(['wsl.exe','-d','Ubuntu-22.04','--','/usr/bin/objdump','--version'],capture_output=True,timeout=30)
assert version.returncode==0
(here/'objdump-version.txt').write_bytes(version.stdout)
for v in ['baseline','fixed']:
    p=root/f'reader-only/build/Release/read_only_02_{v}.exe';win=PureWindowsPath(p)
    wsl='/mnt/'+win.drive[0].lower()+'/'+('/'.join(win.parts[1:]))
    proc=subprocess.run(['wsl.exe','-d','Ubuntu-22.04','--','/usr/bin/objdump','-s','-j','.rdata','-j','.data',wsl],capture_output=True,timeout=30)
    assert proc.returncode==0,proc.stderr
    (here/f'original-{v}-objdump.txt').write_bytes(proc.stdout)
    memory={}
    for line in proc.stdout.decode('utf-8').splitlines():
        m=re.match(r'^\s*([0-9a-fA-F]{8,16}) (.{35})  ',line)
        if not m:continue
        raw=bytes.fromhex(m[2].replace(' ',''));address=int(m[1],16)
        assert len(raw)<=16
        for n,b in enumerate(raw):assert address+n not in memory;memory[address+n]=b
    assert memory
    data_nodes=0;verified_bytes=0;overlap=set();relocations=0
    for name,node in a['nodes'].items():
        if node.get('boundary'):continue
        n=node['variants'][v];start=0x140000000+n['section_rva'];expected=bytes.fromhex(n['initial_linked_bytes_hex'])
        actual=bytes(memory[start+i] for i in range(len(expected)))
        assert actual==expected,(v,name)
        overlap.update(range(start,start+len(actual)))
        for r in n['relocations']:
            value=int.from_bytes(actual[r['offset']:r['offset']+r['width']],'little')
            expected_pointer=r['linked_target_rva']+r['addend']+(0x140000000 if r['kind']==1 else 0)
            assert value==expected_pointer
            relocations+=1
        data_nodes+=1;verified_bytes+=len(actual)
    method_slots=0
    for n in a['roots']:
        table=0x140000000+n[v+'_rva']
        for entry in n['slots']:
            ptr=bytes(memory[table+entry['slot']*8+j] for j in range(8))
            assert struct.unpack('<Q',ptr)[0]==0x140000000+entry['rva']
            method_slots+=1
    assert method_slots==57 and data_nodes==72
    literal_pools=0
    for pool in pools['variants'][v]:
        for rva in pool['rvas']:
            actual=bytes(memory[0x140000000+rva+j] for j in range(pool['bytes']))
            assert actual==bytes.fromhex(pool['content_hex'])
        literal_pools+=1
    crt_pointers=0
    for n,arr in crt['original_reader_only_arrays'][v].items():
        values=[]
        for i in range(arr['bytes']//8):
            raw=bytes(memory[0x140000000+arr['rva']+i*8+j] for j in range(8))
            values.append(struct.unpack('<Q',raw)[0])
        assert values==arr['pointers']
        crt_pointers+=len(values)
    records.append({'version':v,'image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
        'data_nodes':data_nodes,'sum_section_bytes':verified_bytes,'unique_PE_data_bytes':len(overlap),
        'relocations_checked':relocations,'root_method_slots':method_slots,
        'literal_pools':literal_pools,'CRT_pointer_entries':crt_pointers,
        'objdump_sha256':hashlib.sha256(proc.stdout).hexdigest(),'all_actual_data_bytes_match':True})
result={'tool':version.stdout.decode('utf-8').splitlines()[0],'records':records,
    'independent_byte_decoder':'GNU objdump on original PE files; all72nodes and57method slots per image match.',
    'new_query_timings':0,'query_gate_cleared':False,'passed':True}
(here/'objdump-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

"""Audit relocated vtables and reachable RTTI in the original reader images."""
from pathlib import Path
from collections import Counter,deque
from datetime import datetime,timezone
import hashlib,json,struct
from binary_helpers import pe,coff,symbols

here=Path(__file__).resolve().parent;root=here.parent;base=root.parents[1]
old=json.loads((root/'diagnosis/normalized-instruction-differences.json').read_text())
dependency=json.loads((root/'dependency-audit/analysis.json').read_text())
plan=json.loads((root/'dependency-audit/plan.json').read_text())
for file,r in plan['inputs'].items():assert hashlib.sha256((base/file).read_bytes()).hexdigest()==r['sha256']
names=Counter(n for x in old['instructions'] for n in x['common_map_target_symbols'] if not n.startswith('__imp_'))
assert len(names)==10 and sum(names.values())==31
images={};maps={};objects={};cache={};provenance={}
for v in ['baseline','fixed']:
    original=root/f'reader-only/build/Release/read_only_02_{v}.exe'
    assert hashlib.sha256(original.read_bytes()).hexdigest()==next(g['original_sha256'] for g in dependency['guards'] if g['caller']=='reader_only' and g['version']==v)
    images[v]=pe(original);maps[v]=symbols(root/f'dependency-audit/build/reader_only_{v}.map')
    paths=list((base/f'work/issue-02/validation/msvc-{v}/src').rglob('*.obj'))
    grouped={}
    for p in paths:grouped.setdefault(p.name,[]).append(p)
    objects[v]=grouped
def raw_section(file,section):
    data=file.read_bytes();start=56 if data[:4]==b'\0\0\xff\xff' else 20
    at=start+40*(section-1);size,raw=struct.unpack_from('<II',data,at+16)
    return data[raw:raw+size]
def read(v,rva,size):
    found=[s for n,s in images[v].items() if isinstance(s,dict) and s['rva']<=rva and rva+size<=s['rva']+len(s['data'])]
    assert len(found)==1,(v,hex(rva),size)
    sec=found[0];start=rva-sec['rva'];return sec['data'][start:start+size]
def info(v,name):
    m=maps[v].get(name)
    if m is None:return {'unresolved':'No public MAP symbol','name':name}
    if not m['owner'].startswith('tsfile:'):return {'external_leaf':True,'name':name,'map':m}
    owner=m['owner'].split(':',1)[1];paths=objects[v].get(owner,[])
    if len(paths)!=1:return {'unresolved':'Archive member not uniquely located','name':name,'map':m}
    path=paths[0];key=v,str(path)
    if key not in cache:
        cache[key]=coff(path);provenance[path.relative_to(base).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
    obj=cache[key];matches=[s for s in obj['symbols'].values() if s['name']==name and s['section']>0]
    if len(matches)!=1:return {'unresolved':'Selected MAP owner does not expose one COFF definition','name':name,'map':m}
    sym=matches[0];sec=obj['sections'][sym['section']-1];raw=raw_section(path,sym['section'])
    assert len(raw)==sec['bytes']
    rva=m['rva']-sym['value'];linked=read(v,rva,len(raw));masked=bytearray(linked);zero=bytearray(raw);rels=[]
    for offset,index,kind in sec['relocations']:
        target=obj['symbols'][index];width=8 if kind==1 else 4 if kind==3 else None
        if width is None:return {'unresolved':'Data node has non-address relocation','name':name,'map':m,'relocation_type':kind}
        assert offset+width<=len(raw)
        addend=int.from_bytes(raw[offset:offset+width],'little',signed=True)
        encoded=int.from_bytes(linked[offset:offset+width],'little')
        trva=encoded-(0x140000000 if kind==1 else 0)-addend
        target_map=maps[v].get(target['name'])
        binding_checked=target_map is not None and target_map['rva']==trva
        assert binding_checked,(v,name,target['name'],hex(trva),target_map)
        masked[offset:offset+width]=b'\0'*width;zero[offset:offset+width]=b'\0'*width
        rels.append({'offset':offset,'kind':kind,'width':width,'target':target['name'],'addend':addend,
            'linked_target_rva':trva,'selected_target_owner':target_map['owner'],'target_segment':target_map['segment'],
            'actual_linked_binding_matches_map':binding_checked})
    assert masked==zero,(v,name,'Non-relocation bytes changed during link')
    return {'name':name,'map':m,'section_name':sec['name'],'section_bytes':len(raw),'symbol_value':sym['value'],
        'section_rva':rva,'comdat':sec['comdat'],'raw_sha256':hashlib.sha256(raw).hexdigest(),
        'linked_sha256':hashlib.sha256(linked).hexdigest(),'non_address_payload_sha256':hashlib.sha256(masked).hexdigest(),
        'relocations':rels,'section_is_code':bool(sec['characteristics']&0x20),
        'initial_linked_bytes_hex':linked.hex()}

queue=deque(sorted(names));visited={};bounds=[];functions={};MAX_DATA_NODES=256
while queue:
    name=queue.popleft()
    if name in visited:continue
    if len(visited)>=MAX_DATA_NODES:
        bounds.append({'name':name,'reason':'Prespecified 256-node data limit reached'});break
    variants={v:info(v,name) for v in ['baseline','fixed']}
    if any('unresolved' in n or 'external_leaf' in n for n in variants.values()):
        bounds.append({'name':name,'variants':variants});visited[name]={'boundary':True};continue
    assert not any(n['section_is_code'] for n in variants.values()),name
    a,b=variants['baseline'],variants['fixed']
    signature=lambda n:[{k:r[k] for k in ['offset','kind','width','target','addend']} for r in n['relocations']]
    assert a['section_bytes']==b['section_bytes'] and a['symbol_value']==b['symbol_value']
    assert a['non_address_payload_sha256']==b['non_address_payload_sha256']
    assert signature(a)==signature(b),(name,'Relocation target/slot change')
    visited[name]={'variants':variants,'same_non_address_bytes_and_named_slots':True,
        'raw_linked_bytes_equal':a['linked_sha256']==b['linked_sha256'],
        'same_section_rva':a['section_rva']==b['section_rva']}
    for index,rel in enumerate(a['relocations']):
        other=b['relocations'][index];target=rel['target']
        assert rel['target_segment']==other['target_segment']
        if rel['target_segment']=='0001':
            entry=functions.setdefault(target,{'baseline_rva':rel['linked_target_rva'],'fixed_rva':other['linked_target_rva'],
                'references':[],'same_target_rva':rel['linked_target_rva']==other['linked_target_rva']})
            entry['references'].append({'data_node':name,'offset':rel['offset']})
        else:queue.append(target)

# Root method slots, including pure-virtual/ICF targets, must have exactly equal
# function RVAs in the two original images. Do not turn a same-name target into
# a statement about unchanged function bodies or runtime state.
root_records=[]
for name in sorted(names):
    n=visited[name];assert not n.get('boundary')
    a,b=(n['variants'][v] for v in ['baseline','fixed'])
    assert a['symbol_value']==8 and all(r['kind']==1 for r in a['relocations'])
    slots=[]
    for ra,rb in zip(a['relocations'],b['relocations']):
        if ra['offset']<a['symbol_value']:continue
        assert ra['target_segment']=='0001' and ra['linked_target_rva']==rb['linked_target_rva']
        slots.append({'slot':(ra['offset']-a['symbol_value'])//8,'target':ra['target'],'rva':ra['linked_target_rva']})
    start=a['symbol_value'];assert bytes.fromhex(a['initial_linked_bytes_hex'])[start:]==bytes.fromhex(b['initial_linked_bytes_hex'])[start:]
    root_records.append({'vtable':name,'changed_instruction_references':names[name],
        'baseline_rva':a['map']['rva'],'fixed_rva':b['map']['rva'],'method_slot_count':len(slots),
        'actual_method_pointer_bytes_equal':True,'slots':slots})
for path,h in provenance.items():assert hashlib.sha256((base/path).read_bytes()).hexdigest()==h
for file,r in plan['inputs'].items():assert hashlib.sha256((base/file).read_bytes()).hexdigest()==r['sha256']
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
item=next(x for x in [state['active'],*state['drafts']] if x['id']=='02')
result={'analyzed_at':datetime.now(timezone.utc).isoformat(),'head':item['head_commit'],
    'method':'Start from all ten non-import targets of the52 changed original reader-only instructions. Resolve exact selected COFF data sections. Compare non-address bytes and ordered relocation names/addends; independently validate every relocated pointer against its original PE bytes and public MAP binding. Traverse reachable non-code RTTI nodes until external/unresolved boundaries or the fixed256-node limit.',
    'roots':root_records,'nodes':visited,'boundaries':bounds,'method_targets':functions,'object_sha256':provenance,
    'root_vtable_method_slots':sum(x['method_slot_count'] for x in root_records),'data_nodes_checked':sum(not n.get('boundary') for n in visited.values()),
    'query_timings':0,'production_source_changed':False,'query_gate_cleared':False,'necessary_cost_proven':False,
    'limits':['On-disk relocated vtable/RTTI structure and named binding equality do not establish equal cache behavior, runtime data/heap layout or latency.',
        'Writable TypeDescriptor fields are initial image values; the runtime may mutate/cache RTTI state.',
        'Public MAP ownership can reflect identical COMDAT folding, not independent dynamic source attribution.',
        'The original mixed-caller performance gate cannot be cleared by a reader-only metadata audit. Earlier Java/coverage/write/sanitizer scope is unchanged.']}
(here/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'root_vtables':len(root_records),'changed_instructions_covered':sum(names.values()),'root_method_slots':result['root_vtable_method_slots'],
    'data_nodes_checked':result['data_nodes_checked'],'boundary_count':len(bounds),'boundary_names':[x['name'] for x in bounds],
    'all_root_actual_method_pointers_equal':True,'method_targets_same_rva':all(x['same_target_rva'] for x in functions.values()),
    'query_gate_cleared':False,'new_query_timings':0}))

"""Verify published audit snapshots offline, without original build artifacts."""
from pathlib import Path
import hashlib,json,re,struct
here=Path(__file__).resolve().parent
manifest=json.loads((here/'manifest.json').read_text())
for name,r in manifest.items():
    d=(here/name).read_bytes();assert len(d)==r['bytes'] and hashlib.sha256(d).hexdigest()==r['sha256'],name
a=json.loads((here/'analysis.json').read_text());pools=json.loads((here/'constant-pools.json').read_text());crt=json.loads((here/'crt-arrays.json').read_text())
summaries=[]
for v in ['baseline','fixed']:
    memory={}
    for line in (here/f'original-{v}-objdump.txt').read_text(encoding='utf-8').splitlines():
        m=re.match(r'^\s*([0-9a-fA-F]{8,16}) (.{35})  ',line)
        if m:
            data=bytes.fromhex(m[2].replace(' ',''));at=int(m[1],16)
            for n,b in enumerate(data):assert at+n not in memory;memory[at+n]=b
    def read(rva,size):return bytes(memory[0x140000000+rva+i] for i in range(size))
    nodes=slots=relocations=0
    for name,node in a['nodes'].items():
        if node.get('boundary'):continue
        r=node['variants'][v];data=read(r['section_rva'],r['section_bytes']);assert data.hex()==r['initial_linked_bytes_hex']
        masked=bytearray(data)
        for rel in r['relocations']:
            actual=int.from_bytes(data[rel['offset']:rel['offset']+rel['width']],'little')
            assert actual==rel['linked_target_rva']+rel['addend']+(0x140000000 if rel['kind']==1 else 0)
            masked[rel['offset']:rel['offset']+rel['width']]=b'\0'*rel['width'];relocations+=1
        assert hashlib.sha256(masked).hexdigest()==r['non_address_payload_sha256'];nodes+=1
    for n in a['roots']:
        for s in n['slots']:
            assert struct.unpack('<Q',read(n[v+'_rva']+s['slot']*8,8))[0]==0x140000000+s['rva'];slots+=1
    for pool in pools['variants'][v]:
        for rva in pool['rvas']:assert read(rva,pool['bytes']).hex()==pool['content_hex']
    for name,arr in crt['original_reader_only_arrays'][v].items():
        assert list(struct.unpack('<'+'Q'*(arr['bytes']//8),read(arr['rva'],arr['bytes'])))==arr['pointers']
    assert nodes==72 and slots==57 and relocations==171
    summaries.append({'version':v,'data_nodes':nodes,'method_slots':slots,'relocations':relocations,'literal_pools':len(pools['variants'][v])})
for n,node in a['nodes'].items():
    if node.get('boundary'):continue
    left,right=(node['variants'][v] for v in ['baseline','fixed'])
    assert left['non_address_payload_sha256']==right['non_address_payload_sha256']
    signature=lambda r:[(x['offset'],x['kind'],x['target'],x['addend']) for x in r['relocations']]
    assert signature(left)==signature(right)
assert all(x['equal_sequence'] for x in crt['comparisons'].values())
assert not pools['shared_normalized_payload_differences'] and pools['shared_owner_qualified_constant_symbols']==100
unpaired=[pools['unpaired_constants'][v] for v in ['baseline','fixed']]
assert len(unpaired[0])==len(unpaired[1])==1
assert unpaired[0][0]['constant']['bytes_hex']==unpaired[1][0]['constant']['bytes_hex']
diff=json.loads((here/'image-differences.json').read_text())
assert diff['all_rdata_differences_accounted'] and diff['relocation_location_changes_exactly_match_audited_data_nodes']
print(json.dumps({'snapshot_verification_passed':True,'images':summaries,'CRT_XCU_pointer_slots':482,
    'query_gate_cleared':False,'scope':'Frozen data/MAP-derived records verified against independent GNU byte snapshots; not a fresh runtime or full-COFF rebuild.'}))

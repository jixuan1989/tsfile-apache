"""Finite unprivileged sampling of the unchanged original query programs."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import shutil
import statistics
import subprocess
import sys

here = Path(__file__).resolve().parent
root = here.parent
sys.path.insert(0, str(root))
import benchmark as core

case = next(c for c in core.plan['cases']['02'] if c['name'] == 'DOUBLE_aligned_p2_null0_props0_all_w4_batch_parallel0')
fixture = core.plan['fixtures'][case['fixture_key']]
original_manifest = json.loads((root/'tested-artifact-hashes.json').read_text())
images = {v: root/f'build/Release/query_02_{v}.exe' for v in ['baseline', 'fixed']}
payloads = {v: p.read_bytes() for v, p in images.items()}
for v, p in images.items():
    assert hashlib.sha256(payloads[v]).hexdigest() == original_manifest['files'][p.relative_to(root.parents[1]).as_posix()]['sha256']
assert Path(fixture['paths']['baseline']).read_bytes() == Path(fixture['paths']['fixed']).read_bytes()
fixture_bytes = Path(fixture['paths']['fixed']).read_bytes()
sampler = here/'build/Release/thread_sampler.exe'
labels = ['baseline_1', 'fixed_1', 'baseline_2', 'fixed_2']
rounds = 8
repeats = 1024
image_dir = here/'neutral-images'
paths = [image_dir/f's{i:03}.exe' for i in range(4)]

def order(r):
    result = labels[r % 4:]+labels[:r % 4]
    return list(reversed(result)) if (r//4) % 2 else result

assert all(Counter(order(r)[i] for r in range(rounds)) == {label: 2 for label in labels} for i in range(4))
assignments = [{label: str(paths[(i+r) % 4]) for i, label in enumerate(labels)} for r in range(rounds)]
for path in paths:
    assert Counter(label.split('_')[0] for a in assignments for label, p in a.items() if p == str(path)) == {'baseline': 4, 'fixed': 4}

plan = {'created_at': datetime.now(timezone.utc).isoformat(), 'case': case, 'rounds': rounds, 'queries_per_process': repeats,
    'stopping_rule': 'Exactly eight balanced rounds of four images (32 children,32768 fully verified queries), no extension or removal of anomalous samples. Two baseline/fixed image copies are internal same-version controls. Retain smoke separately.',
    'hypothesis': 'Unprivileged main-thread wall-time stack sampling can identify where the unchanged original dense DOUBLE batch query spends time, after elevated WPR collection failed. It cannot measure retired instructions/cache misses or establish causality for a1% change.',
    'method': 'Private parent profiler suspends ONLY its own child main thread, captures CONTEXT_FULL and up to32 StackWalk64 frames, then always resumes. High-resolution waitable timer chooses fixed-seed0.5..1.5ms delays; same delay seed for all four labels within round. Parent CPU mask16; child mask12 before resume, pool2, parallelfalse. Same-byte original images rotate through common four paths once per round. Same input identity, warm filesystem cache. No query-source edit or recompilation.',
    'limitations': ['Suspension, stack walking and module inventory perturb scheduling/cache/timing; profiled latency is NOT acceptance evidence.', 'Wall-time samples can include blocked/off-CPU time and startup/output; classify using captured query call frames but do not call them CPU event counts.', '1024 in-process queries differ from original3-query children and can change boost/cache behavior.', 'Main thread only; worker stacks and exact per-query QPC boundaries are unmeasured.', 'Symbols resolve to linker names/PE runtime-function intervals, not source-line PDBs; aliases/inlined frames can be ambiguous.', 'No system-wide trace is captured or uploaded; only these child modules/threads are sampled.'],
    'source_head': original_manifest['sources']['02']['head'],
    'images': {v: {'path': str(p), 'sha256': hashlib.sha256(payloads[v]).hexdigest()} for v, p in images.items()},
    'sampler_sha256': hashlib.sha256(sampler.read_bytes()).hexdigest(),
    'fixture_sha256': hashlib.sha256(fixture_bytes).hexdigest(), 'identity_assignments': assignments,
    'official_API': 'https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getthreadcontext'}

def prepare(r):
    image_dir.mkdir(exist_ok=True)
    for label, path in assignments[r].items():
        p = Path(path)
        assert p.parent.resolve() == image_dir.resolve()
        p.write_bytes(payloads[label.split('_')[0]])
    file = image_dir/'input.tsfile'
    if not file.exists(): file.write_bytes(fixture_bytes)
    assert file.read_bytes() == fixture_bytes
    return file

def run(r, label, count, directory, profile=True):
    version = label.split('_')[0]
    image = Path(assignments[r][label])
    assert image.read_bytes() == payloads[version]
    file = image_dir/'input.tsfile'
    child_log = directory/f'r{r:02}-{label}.child.log'
    profile_log = directory/f'r{r:02}-{label}.profile.json'
    child_args = ['read', str(file), case['layout'], case['kind'], str(case['precision']), str(case['sparse']), str(case['properties']), case['scenario'], str(case['width']), str(case['batch']), '0', str(count)]
    args = [str(sampler), str(image), str(child_log), str(profile_log), str(10249000+r), *child_args]
    if not profile:
        with child_log.open('w', encoding='utf-8') as output:
            result = subprocess.run([str(image), *child_args], stdout=output, stderr=subprocess.STDOUT, timeout=60)
    else:
        result = subprocess.run(args, capture_output=True, text=True, encoding='utf-8', timeout=90)
        (directory/f'r{r:02}-{label}.sampler.log').write_text(result.stdout+result.stderr, encoding='utf-8')
    assert result.returncode == 0, (args, result.stderr if profile else child_log.read_text())
    data = json.loads([x for x in child_log.read_text().splitlines() if x.startswith('{')][-1])
    expected = core.expected(case)
    expected['checksum'] = expected['checksum']//3*count
    expected['NULL_cells'] = expected['NULL_cells']//3*count
    for k, v in expected.items(): assert data[k] == v, (k, data[k], v)
    assert data['repeats'] == count and len(data['full_seconds']) == count
    sampled = json.loads(profile_log.read_text()) if profile else None
    if profile:
        assert sampled['exit_code'] == 0 and not sampled['timed_out'] and len(sampled['samples']) > 20
        assert any(m['name'] == image.name for m in sampled['modules'])
        assert all(s['rip'] and s['suspend_qpc_ticks'] > 0 for s in sampled['samples'])
    return {'round': r, 'label': label, 'version': version, 'image': str(image), 'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
        'checked_queries': count, 'native_output': data, 'profile_path': str(profile_log) if profile else None,
        'samples': len(sampled['samples']) if profile else None,
        'median_suspend_seconds': statistics.median(s['suspend_qpc_ticks']/sampled['qpc_frequency'] for s in sampled['samples']) if profile else None}

def main():
    smoke = '--smoke' in sys.argv
    directory = here/('smoke-v4' if smoke else 'samples')
    directory.mkdir(exist_ok=False)
    (directory/'plan.json').write_text(json.dumps(plan, indent=2)+'\n')
    if smoke:
        prepare(0)
        rows = [run(0, label, 256, directory) for label in ['baseline_1', 'fixed_1']]
    else:
        rows = []
        for r in range(rounds):
            prepare(r)
            # Initial untimed verified preflight for each exact image after copying.
            for label in labels: run(r, label, 3, directory, profile=False)
            for label in order(r):
                row = run(r, label, repeats, directory)
                rows.append(row)
                (directory/'results.json').write_text(json.dumps({'plan': plan, 'children': rows}, indent=2)+'\n')
                print('Profiled round', r+1, label, 'samples', row['samples'], flush=True)
    report = {'plan': plan, 'children': rows, 'completed_at': datetime.now(timezone.utc).isoformat()}
    (directory/'results.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'smoke': smoke, 'children': len(rows), 'checked_queries': sum(x['checked_queries'] for x in rows), 'samples': sum(x['samples'] for x in rows)}))

if __name__ == '__main__': main()

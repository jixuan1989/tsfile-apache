/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
#include <windows.h>
#include <dbghelp.h>
#include <psapi.h>
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

void require(bool ok, const char* name) {
    if (!ok) throw std::runtime_error(std::string(name)+" error="+std::to_string(GetLastError()));
}
struct Handle {
    HANDLE h = nullptr;
    ~Handle() { if (h && h != INVALID_HANDLE_VALUE) CloseHandle(h); }
};
std::wstring quote(const std::wstring& s) {
    std::wstring out = L"\"";
    size_t slashes = 0;
    for (wchar_t c : s) {
        if (c == L'\\') { ++slashes; continue; }
        out.append(slashes * (c == L'"' ? 2 : 1), L'\\');
        if (c == L'"') out += L'\\';
        out += c; slashes = 0;
    }
    out.append(slashes*2, L'\\');
    return out+L'"';
}
uint64_t qpc() { LARGE_INTEGER x{}; QueryPerformanceCounter(&x); return x.QuadPart; }
struct Sample { uint64_t at, duration, rip; std::vector<uint64_t> stack; };
struct Module { uint64_t base, size; std::wstring name; };

int wmain(int argc, wchar_t** argv) {
    PROCESS_INFORMATION pi{};
    bool child_created = false, resumed = false, symbols = false;
    try {
        require(argc >= 7, "sampler target childlog profilejson seed child-args...");
        require(SetProcessAffinityMask(GetCurrentProcess(), 16), "sampler affinity");
        std::wstring command = quote(argv[1]);
        for (int i = 5; i < argc; ++i) command += L" "+quote(argv[i]);
        std::vector<wchar_t> mutable_command(command.begin(), command.end());
        mutable_command.push_back(0);
        SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
        Handle output{CreateFileW(argv[2], GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr)};
        require(output.h != INVALID_HANDLE_VALUE, "CreateFile child log");
        Handle input{CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, &sa, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr)};
        require(input.h != INVALID_HANDLE_VALUE, "CreateFile NUL");
        STARTUPINFOW si{}; si.cb = sizeof(si); si.dwFlags = STARTF_USESTDHANDLES;
        si.hStdOutput = si.hStdError = output.h; si.hStdInput = input.h;
        require(CreateProcessW(argv[1], mutable_command.data(), nullptr, nullptr, TRUE,
                              CREATE_SUSPENDED|CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi), "CreateProcess");
        child_created = true;
        require(SetProcessAffinityMask(pi.hProcess, 12), "SetProcessAffinityMask");
        DWORD_PTR mask{}, system{};
        require(GetProcessAffinityMask(pi.hProcess, &mask, &system) && mask == 12, "affinity check");
        uint64_t initial_cycles{}, final_cycles{};
        require(QueryThreadCycleTime(pi.hThread, &initial_cycles), "cycles before");
        LARGE_INTEGER frequency{}; QueryPerformanceFrequency(&frequency);
        auto start = qpc();
        require(ResumeThread(pi.hThread) == 1, "initial ResumeThread"); resumed = true;
        // Only this private child is inspected. No debug attachment or symbol-server lookup.
        HMODULE handles[256]{}; DWORD count{};
        // A just-resumed process can report an empty module list before Ldr initializes.
        // Wait for its normal CRT dependency, rather than accepting an empty inventory.
        bool loader_ready = false;
        for (int attempt = 0; attempt < 2000; ++attempt) {
            if (EnumProcessModules(pi.hProcess, handles, sizeof(handles), &count) && count <= sizeof(handles)) {
                bool executable = false, crt = false, kernel = false;
                for (size_t i = 0; i < count/sizeof(HMODULE); ++i) {
                    wchar_t name[MAX_PATH]{};
                    if (!GetModuleBaseNameW(pi.hProcess, handles[i], name, MAX_PATH)) continue;
                    std::wstring text(name);
                    executable = executable || text.find(L".exe") != std::wstring::npos;
                    crt = crt || _wcsicmp(name, L"ucrtbase.dll") == 0;
                    kernel = kernel || _wcsicmp(name, L"kernel32.dll") == 0;
                }
                if (executable && crt && kernel) { loader_ready = true; break; }
            }
            if (WaitForSingleObject(pi.hProcess, 0) == WAIT_OBJECT_0) break;
            Sleep(1);
        }
        require(loader_ready, "loader-ready module inventory");
        SymSetOptions(SYMOPT_DEFERRED_LOADS|SYMOPT_NO_PROMPTS|SYMOPT_FAIL_CRITICAL_ERRORS|SYMOPT_IGNORE_NT_SYMPATH);
        require(SymInitializeW(pi.hProcess, L"", TRUE), "SymInitialize"); symbols = true;
        require(count <= sizeof(handles), "module inventory size");
        std::vector<Module> modules;
        for (size_t i = 0; i < count/sizeof(HMODULE); ++i) {
            MODULEINFO info{}; wchar_t name[MAX_PATH]{};
            require(GetModuleInformation(pi.hProcess, handles[i], &info, sizeof(info)), "GetModuleInformation");
            require(GetModuleBaseNameW(pi.hProcess, handles[i], name, MAX_PATH) > 0, "GetModuleBaseName");
            modules.push_back({reinterpret_cast<uint64_t>(info.lpBaseOfDll), info.SizeOfImage, name});
        }
        auto inventory_done = qpc();
        Handle timer{CreateWaitableTimerExW(nullptr, nullptr, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS)};
        require(timer.h != nullptr, "CreateWaitableTimerEx");
        std::mt19937 rng(static_cast<uint32_t>(std::stoul(argv[4])));
        std::uniform_int_distribution<int> jitter(5000, 15000); // 0.5..1.5 ms, 100 ns units.
        std::vector<Sample> samples;
        bool timed_out = false;
        while (WaitForSingleObject(pi.hProcess, 0) == WAIT_TIMEOUT) {
            if (qpc()-start > 60ULL*frequency.QuadPart) { timed_out = true; break; }
            LARGE_INTEGER due{}; due.QuadPart = -jitter(rng);
            require(SetWaitableTimer(timer.h, &due, 0, nullptr, nullptr, FALSE), "SetWaitableTimer");
            require(WaitForSingleObject(timer.h, 1000) == WAIT_OBJECT_0, "sample delay");
            if (WaitForSingleObject(pi.hProcess, 0) != WAIT_TIMEOUT) break;
            auto before = qpc();
            DWORD previous = SuspendThread(pi.hThread);
            if (previous == DWORD(-1)) {
                // The main thread can finish before the process's final teardown.
                if (WaitForSingleObject(pi.hThread, 100) == WAIT_OBJECT_0) {
                    require(WaitForSingleObject(pi.hProcess, 5000) == WAIT_OBJECT_0, "process teardown");
                    break;
                }
                if (WaitForSingleObject(pi.hProcess, 0) == WAIT_OBJECT_0) break;
                require(false, "SuspendThread");
            }
            bool ok = false;
            Sample sample{before, 0, 0, {}};
            // Every successful suspension is paired with a resume, including failure paths.
            try {
                CONTEXT context{}; context.ContextFlags = CONTEXT_FULL;
                ok = GetThreadContext(pi.hThread, &context) != FALSE;
                if (ok) {
                    sample.rip = context.Rip;
                    STACKFRAME64 frame{};
                    frame.AddrPC.Offset = context.Rip; frame.AddrPC.Mode = AddrModeFlat;
                    frame.AddrStack.Offset = context.Rsp; frame.AddrStack.Mode = AddrModeFlat;
                    frame.AddrFrame.Offset = context.Rbp; frame.AddrFrame.Mode = AddrModeFlat;
                    for (int depth = 0; depth < 32; ++depth) {
                        if (!StackWalk64(IMAGE_FILE_MACHINE_AMD64, pi.hProcess, pi.hThread, &frame, &context,
                                         nullptr, SymFunctionTableAccess64, SymGetModuleBase64, nullptr)) break;
                        if (!frame.AddrPC.Offset) break;
                        if (!sample.stack.empty() && sample.stack.back() == frame.AddrPC.Offset) break;
                        sample.stack.push_back(frame.AddrPC.Offset);
                    }
                }
            } catch (...) { ResumeThread(pi.hThread); throw; }
            require(ResumeThread(pi.hThread) == previous+1, "sample ResumeThread");
            require(previous == 0, "unexpected pre-existing child suspension");
            sample.duration = qpc()-before;
            if (ok) samples.push_back(std::move(sample));
            else if (WaitForSingleObject(pi.hProcess, 0) != WAIT_OBJECT_0) require(false, "GetThreadContext");
        }
        if (timed_out) { TerminateProcess(pi.hProcess, 124); WaitForSingleObject(pi.hProcess, 5000); }
        DWORD code{}; require(GetExitCodeProcess(pi.hProcess, &code), "child exit");
        require(QueryThreadCycleTime(pi.hThread, &final_cycles), "cycles after");
        auto end = qpc();
        SymCleanup(pi.hProcess); symbols = false;
        std::ofstream out(argv[3]);
        out << "{\"pid\":" << pi.dwProcessId << ",\"tid\":" << pi.dwThreadId
            << ",\"exit_code\":" << code << ",\"timed_out\":" << (timed_out ? "true" : "false")
            << ",\"qpc_frequency\":" << frequency.QuadPart << ",\"start_qpc\":" << start << ",\"end_qpc\":" << end
            << ",\"inventory_done_qpc\":" << inventory_done << ",\"affinity_mask\":12,\"sampler_affinity_mask\":16,\"main_thread_lifetime_cycles\":" << final_cycles-initial_cycles
            << ",\"modules\":[";
        for (size_t i = 0; i < modules.size(); ++i) {
            if (i) out << ',';
            const auto& m = modules[i];
            int bytes = WideCharToMultiByte(CP_UTF8, 0, m.name.data(), static_cast<int>(m.name.size()), nullptr, 0, nullptr, nullptr);
            require(bytes > 0, "module UTF8 size");
            std::string name(bytes, '\0');
            require(WideCharToMultiByte(CP_UTF8, 0, m.name.data(), static_cast<int>(m.name.size()), &name[0], bytes, nullptr, nullptr) == bytes, "module UTF8 conversion");
            require(name.find_first_of("\\\"") == std::string::npos, "module JSON name");
            out << "{\"base\":" << m.base << ",\"size\":" << m.size << ",\"name\":\"" << name << "\"}";
        }
        out << "],\"samples\":[";
        for (size_t i = 0; i < samples.size(); ++i) {
            if (i) out << ',';
            const auto& s = samples[i];
            out << "{\"qpc\":" << s.at << ",\"suspend_qpc_ticks\":" << s.duration << ",\"rip\":" << s.rip << ",\"stack\":[";
            for (size_t j = 0; j < s.stack.size(); ++j) { if (j) out << ','; out << s.stack[j]; }
            out << "]}";
        }
        out << "]}\n";
        require(out.good(), "profile write");
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess); child_created = false;
        return code ? 1 : 0;
    } catch (const std::exception& e) {
        if (symbols) SymCleanup(pi.hProcess);
        if (child_created) {
            if (!resumed) ResumeThread(pi.hThread);
            TerminateProcess(pi.hProcess, 125); WaitForSingleObject(pi.hProcess, 5000);
            CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
        }
        std::cerr << e.what() << '\n';
        return 1;
    }
}

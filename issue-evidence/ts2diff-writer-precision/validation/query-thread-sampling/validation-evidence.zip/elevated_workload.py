"""Exact original queries for a bounded administrator WPR capture; no self-elevation."""
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path
import _winapi
import ctypes
import hashlib
import json
import msvcrt
import os
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
root = here.parent
base = here.parents[2]
sys.path.insert(0, str(root))
import benchmark as core

k = ctypes.WinDLL('kernel32', use_last_error=True)
k.SetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
k.SetProcessAffinityMask.restype = wintypes.BOOL
k.GetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
k.GetProcessAffinityMask.restype = wintypes.BOOL
k.ResumeThread.argtypes = [wintypes.HANDLE]
k.ResumeThread.restype = wintypes.DWORD
k.QueryPerformanceCounter.argtypes = [ctypes.POINTER(ctypes.c_longlong)]
k.QueryPerformanceFrequency.argtypes = [ctypes.POINTER(ctypes.c_longlong)]

def require(ok):
    if not ok: raise ctypes.WinError(ctypes.get_last_error())

def qpc():
    value = ctypes.c_longlong()
    require(k.QueryPerformanceCounter(ctypes.byref(value)))
    return value.value

def main():
    preflight = '--preflight' in sys.argv
    directory = Path(sys.argv[sys.argv.index('--output')+1]).resolve()
    assert directory.is_relative_to(here.resolve()) and directory.is_dir()
    state = json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
    pending = [x for x in state['performance_validation_backlog'] if x.get('query_gate_cleared') is False]
    assert pending and pending[0]['item_id'] == '02', 'This frozen capture is only for the pending precision query investigation.'
    item = next(x for x in state['drafts'] if x['id'] == pending[0]['item_id'])
    manifest = json.loads((root/'tested-artifact-hashes.json').read_text())
    assert item['head_commit'] == manifest['sources'][item['id']]['head']
    repo = base/item['implementation']['source']
    assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == item['head_commit']
    assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True).strip()
    images = {v: root/f'build/Release/query_{item["id"]}_{v}.exe' for v in ['baseline', 'fixed']}
    payloads = {v: p.read_bytes() for v, p in images.items()}
    for v, p in images.items(): assert hashlib.sha256(payloads[v]).hexdigest() == manifest['files'][p.relative_to(base).as_posix()]['sha256']
    case = next(c for c in core.plan['cases'][item['id']] if c['name'] == 'DOUBLE_aligned_p2_null0_props0_all_w4_batch_parallel0')
    fixture = core.plan['fixtures'][case['fixture_key']]
    data = Path(fixture['paths']['fixed']).read_bytes()
    assert data == Path(fixture['paths']['baseline']).read_bytes()
    frequency = ctypes.c_longlong()
    require(k.QueryPerformanceFrequency(ctypes.byref(frequency)))
    labels = ['baseline_1', 'fixed_1', 'baseline_2', 'fixed_2']
    plan = {'source_head': item['head_commit'], 'pr_number': item['pr_number'], 'created_at': datetime.now(timezone.utc).isoformat(),
            'rounds': 8, 'queries_per_child': 1024, 'expected_measured_children': 32, 'query_gate_cleared': False,
            'scope': 'Elevated WPR diagnosis: whole-process/thread PMCs and query-call-stack sampling. Exact per-query QPC boundaries not instrumented. Elevation and trace overhead differ from original acceptance benchmark. No no-regression claim.',
            'cache': 'Warm filesystem;2 verified preflight/warmup children per image after each round copy, excluded by PID.',
            'affinity_mask_before_resume': 12, 'pool_threads': 2, 'parallel': False, 'qpc_frequency': frequency.value,
            'images': {v: {'path': str(p), 'sha256': hashlib.sha256(payloads[v]).hexdigest()} for v, p in images.items()},
            'fixture_sha256': hashlib.sha256(data).hexdigest(), 'trace_privacy': 'System ETL stays local; publish only target PID/TID filtered aggregates and evidence. No upload performed by this capture.'}
    if preflight:
        (directory/'plan.json').write_text(json.dumps(plan, indent=2)+'\n')
    else:
        frozen = json.loads((directory/'plan.json').read_text())
        assert frozen['source_head'] == plan['source_head'] and frozen['images'] == plan['images'] and frozen['fixture_sha256'] == plan['fixture_sha256']
    image_dir = directory/'images'
    image_dir.mkdir(exist_ok=True)
    input_file = image_dir/'input.tsfile'
    input_file.write_bytes(data)
    report = {'plan': plan, 'measured': [], 'warmups': []}
    deadline = time.monotonic()+600

    def run(r, label, count, phase):
        path = image_dir/f'e{(labels.index(label)+r)%4:03}.exe'
        assert path.read_bytes() == payloads[label.split('_')[0]]
        output = directory/f'{phase}-{r:02}-{label}.log'
        args = [str(path), 'read', str(input_file), case['layout'], case['kind'], str(case['precision']), str(case['sparse']), str(case['properties']), case['scenario'], str(case['width']), str(case['batch']), '0', str(count)]
        with output.open('w+b') as out, open(os.devnull, 'rb') as inp:
            for f in [out, inp]: os.set_handle_inheritable(msvcrt.get_osfhandle(f.fileno()), True)
            si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESTDHANDLES
            si.hStdInput = msvcrt.get_osfhandle(inp.fileno()); si.hStdOutput = si.hStdError = msvcrt.get_osfhandle(out.fileno())
            hp, ht, pid, tid = _winapi.CreateProcess(args[0], subprocess.list2cmdline(args), None, None, True, subprocess.CREATE_NO_WINDOW|4, None, None, si)
            finished = False
            try:
                require(k.SetProcessAffinityMask(hp, 12))
                allowed, system = ctypes.c_size_t(), ctypes.c_size_t()
                require(k.GetProcessAffinityMask(hp, ctypes.byref(allowed), ctypes.byref(system)))
                assert allowed.value == 12
                before = qpc()
                assert k.ResumeThread(ht) == 1
                remaining_ms = int(max(0, min(45, deadline-time.monotonic()))*1000)
                assert _winapi.WaitForSingleObject(hp, remaining_ms) == 0, 'Capture deadline exceeded'
                finished = True
                after = qpc()
                code = _winapi.GetExitCodeProcess(hp)
            finally:
                if not finished:
                    _winapi.TerminateProcess(hp, 124); _winapi.WaitForSingleObject(hp, 5000)
                _winapi.CloseHandle(ht); _winapi.CloseHandle(hp)
        text = output.read_text(encoding='utf-8')
        assert code == 0, text
        result = json.loads([s for s in text.splitlines() if s.startswith('{')][-1])
        expected = core.expected(case)
        for key in ['checksum', 'NULL_cells']: expected[key] = expected[key]//3*count
        for key, value in expected.items(): assert result[key] == value
        assert result['repeats'] == count and len(result['full_seconds']) == count
        return {'round': r, 'label': label, 'phase': phase, 'pid': pid, 'main_tid': tid, 'resume_qpc': before, 'finish_qpc': after, 'queries': count, 'native_output': result}

    for r in range(1 if preflight else 8):
        assert time.monotonic() < deadline
        for i, label in enumerate(labels): (image_dir/f'e{(i+r)%4:03}.exe').write_bytes(payloads[label.split('_')[0]])
        for warmup in range(1 if preflight else 2):
            for label in labels: report['warmups'].append(run(r, label, 3, ('preflight-' if preflight else '')+'warmup'+str(warmup)))
        if not preflight:
            order = labels[r%4:]+labels[:r%4]
            if (r//4)%2: order.reverse()
            for label in order:
                report['measured'].append(run(r, label, 1024, 'measured'))
                (directory/'workload-results.json').write_text(json.dumps(report, indent=2)+'\n')
    report['completed_at'] = datetime.now(timezone.utc).isoformat()
    (directory/('preflight-results.json' if preflight else 'workload-results.json')).write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'preflight': preflight, 'measured_children': len(report['measured']), 'verified_queries': sum(c['queries'] for c in [*report['warmups'], *report['measured']])}))

if __name__ == '__main__': main()

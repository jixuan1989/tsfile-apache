# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements. See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to you under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

$ErrorActionPreference = 'Stop'
$tsfilePrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $tsfilePrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'WPR requires an administrator PowerShell. This script does not elevate itself or change any security policy.'
}
$tsfilePython = 'C:/Users/hxd/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$tsfileWpr = 'C:/Windows/System32/wpr.exe'
$tsfileStatus = & $tsfileWpr -status 2>&1 | Out-String
if ($tsfileStatus -notmatch 'WPR is not recording') { throw 'An existing WPR recording is active. It was left untouched.' }
$tsfileInstanceStatus = & $tsfileWpr -status -instancename TsFileQueryDiag 2>&1 | Out-String
if ($tsfileInstanceStatus -notmatch 'WPR is not recording') { throw 'TsFileQueryDiag is already active. It was left untouched.' }
$tsfileCapture = Join-Path $PSScriptRoot ('capture-' + (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $tsfileCapture -ErrorAction Stop | Out-Null
$tsfileStarted = $false
$tsfileOutcome = @{ state = 'preflight'; directory = $tsfileCapture; source_edits = $false; uploads = $false; query_gate_cleared = $false }
try {
    & $tsfilePython (Join-Path $PSScriptRoot 'elevated_workload.py') --preflight --output $tsfileCapture *> (Join-Path $tsfileCapture 'preflight-console.log')
    if ($LASTEXITCODE -ne 0) { throw 'Verified preflight failed. See preflight-console.log.' }
    & $tsfileWpr -start ((Join-Path $PSScriptRoot 'tsfile.wprp') + '!TsFile') -filemode -instancename TsFileQueryDiag *> (Join-Path $tsfileCapture 'wpr-start.log')
    if ($LASTEXITCODE -ne 0) {
        $tsfileAfterFailure = & $tsfileWpr -status -instancename TsFileQueryDiag 2>&1 | Out-String
        $tsfileAfterFailure | Set-Content -LiteralPath (Join-Path $tsfileCapture 'wpr-start-failure-status.log') -Encoding UTF8
        if ($tsfileAfterFailure -notmatch 'WPR is not recording') { $tsfileStarted = $true }
        throw 'WPR could not start normally. See wpr-start.log; any partial owned recording will be saved.'
    }
    $tsfileStarted = $true
    $tsfileOutcome.state = 'recording'
    $tsfileOutcome | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $tsfileCapture 'status.json') -Encoding UTF8
    & $tsfilePython (Join-Path $PSScriptRoot 'elevated_workload.py') --output $tsfileCapture *> (Join-Path $tsfileCapture 'workload-console.log')
    if ($LASTEXITCODE -ne 0) { throw 'Workload failed; partial raw evidence is retained.' }
    $tsfileOutcome.state = 'workload_complete'
} catch {
    $tsfileOutcome.state = 'failed'
    $tsfileOutcome.error = $_.Exception.Message
    throw
} finally {
    if ($tsfileStarted) {
        & $tsfileWpr -stop (Join-Path $tsfileCapture 'query.etl') -instancename TsFileQueryDiag *> (Join-Path $tsfileCapture 'wpr-stop.log')
        $tsfileOutcome.stop_exit_code = $LASTEXITCODE
        if ($LASTEXITCODE -ne 0) { $tsfileOutcome.state = 'stop_failed' }
        elseif ($tsfileOutcome.state -eq 'workload_complete') { $tsfileOutcome.state = 'captured_pending_validation' }
    }
    $tsfileOutcome | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $tsfileCapture 'status.json') -Encoding UTF8
}
# The ETL is system-wide and must stay local. Only target-process filtered
# statistics may later be published. No source, registry or security-policy
# changes are made. Capture completion is not a performance-gate pass.
Write-Output $tsfileCapture

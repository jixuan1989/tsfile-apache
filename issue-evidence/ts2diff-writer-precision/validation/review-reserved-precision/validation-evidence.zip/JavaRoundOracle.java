/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
import java.io.*;
import java.nio.file.*;
import java.util.Random;

public class JavaRoundOracle {
  static long rows;
  static void emit(DataOutputStream output,long bits) throws IOException {
    double value=Double.longBitsToDouble(bits);
    long rounded=Math.round(value);
    int clipped=(int)Math.max(Integer.MIN_VALUE,Math.min(Integer.MAX_VALUE,rounded));
    output.writeLong(bits);output.writeInt(clipped);output.writeLong(rounded);rows++;
  }
  public static void main(String[] args) throws Exception {
    try(var output=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(Path.of(args[0]))))) {
      Random random=new Random(1024);
      for(int row=0;row<1000000;row++)emit(output,random.nextLong());
      for(int exponent=0;exponent<2048;exponent++)
        for(long sign:new long[]{0,Long.MIN_VALUE})
          for(long fraction:new long[]{0,1,0x8000000000000L,0xfffffffffffffL})
            emit(output,sign|((long)exponent<<52)|fraction);
      for(int integer=-10000;integer<=10000;integer++) {
        double half=integer+0.5;
        for(double value:new double[]{Math.nextDown(half),half,Math.nextUp(half)})
          emit(output,Double.doubleToRawLongBits(value));
      }
      for(int exponent=-1074;exponent<=1023;exponent++)
        for(double sign:new double[]{-1,1}) {
          double value=sign*Math.scalb(1.0,exponent);
          for(double near:new double[]{Math.nextDown(value),value,Math.nextUp(value)})
            emit(output,Double.doubleToRawLongBits(near));
        }
    }
    System.out.println("java_math_round_oracle_rows="+rows+" seed=1024");
    for(double value:new double[]{Math.nextDown(0.5),4503599627370497.0})
      System.out.println("input="+value+" Math.round="+Math.round(value));
  }
}

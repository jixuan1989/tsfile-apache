#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2
validation_root="$task_root/work/issue-02/validation"
task_cmake="$task_root/work/wsl-tools/cmake/data/bin/cmake"
"$task_cmake" -S "$task_root/work/issue-02/fix-repo/cpp" -B "$validation_root/linux-coverage-atomic" \
  -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_FLAGS_DEBUG='-O0 -g --coverage -fprofile-update=atomic' \
  -DCMAKE_C_FLAGS_DEBUG='-O0 -g --coverage -fprofile-update=atomic' -DCMAKE_EXE_LINKER_FLAGS=--coverage \
  -DCMAKE_SHARED_LINKER_FLAGS=--coverage -DCOV_ENABLED=ON \
  -DTSFILE_BUILD_SHARED=OFF -DBUILD_TEST=ON -DBUILD_TOOLS=OFF \
  -DENABLE_ANTLR4=OFF -DENABLE_SIMD=OFF -DENABLE_THREADS=ON \
  -DENABLE_SNAPPY=ON -DENABLE_LZ4=ON -DENABLE_LZOKAY=ON \
  -DENABLE_ZLIB=ON -DENABLE_ZSTD=ON -DENABLE_LZMA2=ON \
  -DTSFILE_DEPENDENCY_CACHE="$task_root/work/issue-01/validation/linux-coverage/dependency-cache" \
  > "$validation_root/linux-configure.log" 2>&1
"$task_cmake" --build "$validation_root/linux-coverage-atomic" --target TsFile_Test --parallel 6 \
  > "$validation_root/linux-build.log" 2>&1
# Reset only generated profiling counters after an incremental rebuild.
profiling_root=$(realpath "$validation_root/linux-coverage-atomic")
test "$profiling_root" = "$task_root/work/issue-02/validation/linux-coverage-atomic"
find "$profiling_root" -type f -name '*.gcda' -delete
cd "$validation_root"
export TSFILE_COMPAT_GENERATE_DIR="$validation_root/native-cpp-fixtures"
export TSFILE_COMPAT_VALIDATE_DIR="$validation_root/native-java-fixtures"
./linux-coverage-atomic/test/lib/TsFile_Test \
  --gtest_output=xml:linux-all-tests.xml > linux-all-tests.log 2>&1
tail -n 12 linux-all-tests.log
PYTHONPATH="$task_root/work/wsl-tools" python3 -m gcovr -j 6 \
  --root /mnt \
  --filter '.*/(encoding/(encoding_props|encoder_factory|ts2diff_encoder)[.]h|writer/(chunk_writer|page_writer|value_chunk_writer|value_page_writer|tsfile_writer)[.]cc)$' \
  --exclude-directory '.*third_party.*' --exclude-directory '.*googletest.*' \
  --merge-mode-functions=merge-use-line-min --json-pretty \
  --output "$validation_root/coverage-raw.json" \
  "$validation_root/linux-coverage-atomic" > "$validation_root/coverage-collection.log" 2>&1

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include "encoding/ts2diff_encoder.h"

uint64_t read_be(const char* bytes,int length) {
    uint64_t result=0;
    for(int i=0;i<length;i++)result=(result<<8)|static_cast<unsigned char>(bytes[i]);
    return result;
}
int main(int argc,char** argv) {
    try {
        std::ifstream input(argv[1],std::ios::binary);
        if(!input.good())throw std::runtime_error("oracle input");
        char row[20];size_t rows=0,old_differences=0;
        while(input.read(row,sizeof(row))) {
            uint64_t bits=read_be(row,8),long_bits=read_be(row+12,8);
            uint32_t int_bits=static_cast<uint32_t>(read_be(row+8,4));
            double value;int32_t expected_int;int64_t expected_long;
            std::memcpy(&value,&bits,8);std::memcpy(&expected_int,&int_bits,4);std::memcpy(&expected_long,&long_bits,8);
            if(storage::java_round<int32_t>(value)!=expected_int || storage::java_round<int64_t>(value)!=expected_long)
                throw std::runtime_error("Java mismatch at row "+std::to_string(rows));
            double rounded=std::floor(value+0.5);
            int64_t old=std::isnan(rounded)?0:rounded>=9223372036854775808.0?std::numeric_limits<int64_t>::max():rounded < -9223372036854775808.0?std::numeric_limits<int64_t>::min():static_cast<int64_t>(rounded);
            old_differences+=old!=expected_long;
            ++rows;
        }
        if(!input.eof() || input.gcount()!=0 || rows!=1088975 || old_differences==0)
            throw std::runtime_error("oracle count "+std::to_string(rows));
        std::cout<<"java_round_inputs="<<rows<<" checked_int32_and_int64=PASS legacy_floor_differences="<<old_differences<<'\n';
    } catch(const std::exception& error) {std::cerr<<error.what()<<'\n';return 1;}
}

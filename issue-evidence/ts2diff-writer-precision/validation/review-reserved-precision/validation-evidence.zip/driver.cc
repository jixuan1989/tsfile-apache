#include <chrono>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
#include <stdexcept>
#include <vector>
#include "encoding/decoder_factory.h"
#include "encoding/encoder_factory.h"
#include "reader/tsfile_reader.h"
#include "writer/tsfile_writer.h"
#include <windows.h>
#include <psapi.h>

using namespace storage;
using namespace common;

void check(bool valid, const std::string& operation) {
    if (!valid) throw std::runtime_error(operation);
}

std::vector<char> read_file(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    check(in.good(), path);
    return std::vector<char>(std::istreambuf_iterator<char>(in), {});
}

uint64_t bits_at(const std::vector<char>& bytes, size_t offset, int size) {
    uint64_t value = 0;
    for (int i = 0; i < size; ++i) value = (value << 8) | static_cast<unsigned char>(bytes.at(offset + i));
    return value;
}

double value_at(const std::vector<char>& bytes, int row, bool is_float) {
    if (is_float) {
        uint32_t bits = static_cast<uint32_t>(bits_at(bytes, row * 4, 4));
        float value;
        std::memcpy(&value, &bits, 4);
        return value;
    }
    uint64_t bits = bits_at(bytes, row * 8, 8);
    double value;
    std::memcpy(&value, &bits, 8);
    return value;
}

#ifdef FIXED_PRECISION_PROPS
void wire(const std::string& directory) {
    std::ifstream manifest(directory + "/manifest.csv");
    check(manifest.good(), "manifest");
    std::string line;
    int cases = 0;
    int total_values = 0;
    while (std::getline(manifest, line)) {
        std::istringstream fields(line);
        std::string id, type_name, props_flag;
        std::getline(fields, id, ','); std::getline(fields, type_name, ','); std::getline(fields, props_flag);
        const bool is_float = type_name == "FLOAT";
        auto type = is_float ? common::FLOAT : common::DOUBLE;
        std::map<std::string, std::string> props;
        if (props_flag == "1") {
            const auto bytes = read_file(directory + "/" + id + ".prop");
            props["max_point_number"] = std::string(bytes.begin(), bytes.end());
        } else if (props_flag == "2") props["unit"] = "celsius";
        auto input = read_file(directory + "/" + id + ".input");
        auto expected = read_file(directory + "/" + id + ".expected");
        const int rows = static_cast<int>(input.size() / (is_float ? 4 : 8));
        Encoder* encoder = EncoderFactory::alloc_value_encoder(TS_2DIFF, type, props);
        check(encoder != nullptr, id + " encoder");
        ByteStream output(128, MOD_DEFAULT);
        for (int row = 0; row < rows; ++row) {
            const double value = value_at(input, row, is_float);
            check((is_float ? encoder->encode(static_cast<float>(value), output) : encoder->encode(value, output)) == E_OK, id + " encode");
        }
        check(encoder->flush(output) == E_OK, id + " flush");
        std::vector<char> bytes(output.total_size());
        copy_bs_to_buf(output, bytes.data(), bytes.size());
        std::ofstream encoded(directory + "/" + id + ".cpp.bin", std::ios::binary);
        encoded.write(bytes.data(), bytes.size());
        check(encoded.good(), id + " write");
        EncoderFactory::free(encoder);
        std::vector<std::vector<char>> pages{bytes};
        if (!std::ifstream(directory + "/" + id + ".java-invalid").good())
            pages.push_back(read_file(directory + "/" + id + ".java.bin"));
        for (const auto& encoded_bytes : pages) {
            ByteStream in;
            in.wrap_from(encoded_bytes.data(), encoded_bytes.size());
            Decoder* decoder = DecoderFactory::alloc_value_decoder(TS_2DIFF, type);
            check(decoder != nullptr, id + " decoder");
            for (int row = 0; row < rows; ++row) {
                double actual;
                if (is_float) {
                    float value;
                    check(decoder->read_float(value, in) == E_OK, id + " read float");
                    actual = value;
                } else check(decoder->read_double(actual, in) == E_OK, id + " read double");
                const double reference = value_at(expected, row, is_float);
                check((std::isnan(actual) && std::isnan(reference)) ||
                      (actual == reference && (actual != 0 || std::signbit(actual) == std::signbit(reference))),
                      id + " row " + std::to_string(row));
            }
            check(!decoder->has_remaining(in), id + " trailing values");
            DecoderFactory::free(decoder);
        }
        ++cases;
        total_values += rows;
    }
    std::cout << "{\"wire_cases\":" << cases << ",\"total_values\":" << total_values << ",\"cpp_read_valid_java_and_all_cpp\":true}\n";
}
#endif

void benchmark(const std::string& path, int rows, bool aligned, bool batch, const std::string& precision, bool is_float) {
    g_config_value_.time_compress_type_ = UNCOMPRESSED;
    const auto type = is_float ? common::FLOAT : common::DOUBLE;
    MeasurementSchema schema("v", type, TS_2DIFF, UNCOMPRESSED);
    if (precision != "default") schema.props_["max_point_number"] = precision;
    auto schemas = std::make_shared<std::vector<MeasurementSchema>>();
    schemas->emplace_back("v", type, TS_2DIFF, UNCOMPRESSED);
    Tablet tablet("root.d", schemas, batch ? rows : 1);
    if (batch) {
        for (int row = 0; row < rows; ++row) {
            check(tablet.add_timestamp(row, row) == E_OK, "timestamp");
            check((is_float ? tablet.add_value(row, "v", 1.23456f)
                            : tablet.add_value(row, "v", 1.23456)) == E_OK, "value");
        }
    }
    const auto start = std::chrono::steady_clock::now();
    {
        TsFileWriter writer;
        check(writer.open(path) == E_OK, "open writer");
        writer.set_generate_table_schema(false);
        check((aligned ? writer.register_aligned_timeseries("root.d", schema) : writer.register_timeseries("root.d", schema)) == E_OK, "register");
        if (batch) check((aligned ? writer.write_tablet_aligned(tablet) : writer.write_tablet(tablet)) == E_OK, "write tablet");
        else {
            for (int row = 0; row < rows; ++row) {
                TsRecord record(row, "root.d");
                if (is_float) record.add_point("v", 1.23456f);
                else record.add_point("v", 1.23456);
                check((aligned ? writer.write_record_aligned(record) : writer.write_record(record)) == E_OK, "write record");
            }
        }
        check(writer.close() == E_OK, "close writer");
    }
    double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    TsFileReader reader;
    check(reader.open(path) == E_OK, "open reader");
    ResultSet* result = nullptr;
    std::vector<std::string> paths{"root.d.v"};
    check(reader.query(paths, 0, rows, result) == E_OK, "query");
    int count = 0;
    for (;;) {
        bool has_next = false;
        check(result->next(has_next) == E_OK, "next");
        if (!has_next) break;
        check(is_float ? result->get_value<float>(2) == 1.23f
                       : result->get_value<double>(2) == 1.23, "read value");
        ++count;
    }
    check(count == rows, "row count");
    reader.destroy_query_data_set(result);
    reader.close();
    PROCESS_MEMORY_COUNTERS info{};
    GetProcessMemoryInfo(GetCurrentProcess(), &info, sizeof(info));
    std::cout << "{\"rows\":" << rows << ",\"seconds\":" << seconds << ",\"peak_working_set_bytes\":" << info.PeakWorkingSetSize << "}\n";
}

int main(int argc, char** argv) {
    try {
        check(libtsfile_init() == E_OK, "init");
#ifdef FIXED_PRECISION_PROPS
        if (std::string(argv[1]) == "wire") wire(argv[2]);
        else
#endif
            benchmark(argv[2], std::stoi(argv[3]), std::stoi(argv[4]), std::stoi(argv[5]), argv[6], std::stoi(argv[7]));
        libtsfile_destroy();
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}

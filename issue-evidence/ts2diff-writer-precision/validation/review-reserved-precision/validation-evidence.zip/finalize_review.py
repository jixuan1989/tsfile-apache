from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root=Path(__file__).resolve().parent
revision=root/'review-reserved-precision'
source=root.parent/'fix-repo'
base=root.parents[2]
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert head!='5f4bc79a6db4d6cf79eb089a9dabe0e1fc4e12bb'
fingerprints=json.loads((revision/'final-source-fingerprints.json').read_text())
for name,digest in fingerprints['source'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
for name,digest in fingerprints['artifacts'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
def tests(path):
    xml=ET.parse(path).getroot()
    skipped=len(xml.findall('.//testcase/skipped'))
    result={k:int(xml.get(k,'0')) for k in ['tests','failures','disabled','errors']}
    result.update(skipped=skipped,passed=result['tests']-result['failures']-result['disabled']-skipped)
    return result
counts={name:tests(root/path) for name,path in {
    'before_marker_fix':'review-reserved-precision/before-tests.xml',
    'focused':'review-reserved-precision/focused.xml',
    'windows':'windows-all-tests.xml','linux':'linux-all-tests.xml'}.items()}
assert counts['before_marker_fix']['failures']==33
assert counts['focused']['passed']==88
assert counts['windows']['passed']==993 and counts['linux']['passed']==1014
for key in ['focused','windows','linux']:assert counts[key]['failures']==counts[key]['errors']==0
assert 'exact_wire_bytes=122 result=PASS' in (root/'java-reads-cpp-wire.log').read_text()
assert 'java_reads_cpp=64 exact_valid_java_pages=36 equivalent_unused_single_value_delta=12 repaired_java_invalid_layouts=16 PASS' in (revision/'java-verify.log').read_text()
assert 'total_reads=64 result=PASS' in (root/'full-file-compatibility.log').read_text()
assert 'exact_wire_bytes=122 result=PASS' in (revision/'java-reads-cpp-wire-rounding.log').read_text()
assert 'java_round_inputs=1088975 checked_int32_and_int64=PASS legacy_floor_differences=251' in (revision/'cpp-round-oracle.log').read_text()
assert 'cpp_own_and_java_cross_reads=16 PASS' in (revision/'zero-full-files.log').read_text()
assert 'keeping 15 files clean' in (revision/'format-check.log').read_text(encoding='utf-8')
linux=ET.parse(root/'linux-all-tests.xml').getroot()
for name in ['GenerateFixtures','ValidateFixtures']:
    cases=[x for x in linux.findall('.//testcase') if x.get('name')==name]
    assert len(cases)==1 and cases[0].find('skipped') is None
cov=json.loads((root/'coverage-summary.json').read_text())
perf=json.loads((root/'performance.json').read_text())
changed=cov['changed_production'];assert changed['line_percent']>=90
assert len(perf['cases'])==4
for name,case in perf['cases'].items():
    assert len(case['measurements'])==(125 if name=='float_nonaligned_record_default' else 25)
    assert case['summary']['bootstrap_95_percent'][0]<=1,'Investigate slowdown before pushing'
old=(revision/'pr-body.md').read_text(encoding='utf-8')
old=old.replace('on the 14 changed files','on the 15 changed files')
old=old.replace('Five additional parser/factory/boundary tests pass: **54 new tests** total.',
    'Seven parser/factory/boundary tests and 32 additional zero-only writer variants pass: **88 new tests** total. The added marker regressions fail 33 tests against the previously published PR head and all pass after the marker fix.')
old=old.replace('**959 passed**','**993 passed**').replace('**980 passed**','**1014 passed**')
old=old.replace('另有 5 项解析、工厂和边界测试，共新增 54 项。Windows 全量 959 项通过，Linux 全量 980 项通过。',
    '另有 7 项解析、工厂和边界测试及 32 项全零 writer 变体，共新增 88 项。新增标记回归在此前 PR 提交有 33 项失败，修复后全部通过。Windows 全量 993 项通过，Linux 全量 1014 项通过。')
old=old.replace('75/75',f"{changed['covered_lines']}/{changed['executable_lines']}").replace('70.00%',f"{changed['branch_percent']:.2f}%")
old=old.replace('coverage: **100.00%**',f"coverage: **{changed['line_percent']:.2f}%**").replace('修改生产可执行行覆盖率 100.00%',f"修改生产可执行行覆盖率 {changed['line_percent']:.2f}%")
ratios=', '.join(f"{x['summary']['paired_median_latency_ratio']:.4f}" for x in perf['cases'].values())
old=old.replace('1.0025, 0.9853, 1.0083, 0.9978',ratios)
old=old.replace('25 alternating pairs per workload','25 alternating pairs per workload, with a predeclared additional 100-pair confirmation for the FLOAT record case (all 125 pairs retained)')
old=old.replace('交错测量 25 轮并固定 CPU','交错测量 25 轮并固定 CPU；FLOAT record 预先固定增加 100 轮确认，保留并合并全部 125 轮')
start=old.index('Very large valid precision makes the scale infinite.')
end=old.index('\n\n### Local validation',start)
rounding='''Very large precision makes the scale infinite; zero times that scale is NaN. Java rounds it to zero, while casting it to a C++ integer is undefined. The old `floor(x + 0.5)` approximation also rounds twice: it returns 1 just below 0.5, and can change already-integral values above 2^52. Those differences remain observable after wiring precision 0, so they must be corrected in this precision-compatibility fix. The helper now rounds the IEEE significand with unsigned integer arithmetic. Values with magnitude below one half return zero; NaN returns zero; out-of-range exponents saturate. For fractional values, compare the discarded bits with half a unit, adding one to the threshold for negative numbers so exact ties round toward positive infinity. Already-integral values use a bounded left shift, and the result is clamped before a signed cast. This follows [Java Math.round semantics](https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/Math.html#round(double)) without a floating-point addition or floor call. The existing `FORCE_INLINE` macro keeps the small rounding/conversion helpers inline; actual NaN input still follows the existing raw-bit path.

An actual Java oracle checks 1,088,975 deterministic random/edge inputs against both 32-bit saturated and 64-bit results; all match. The legacy floor approximation differs on 251 inputs. The original 122-case wire matrix still matches byte-for-byte, and another 122-case matrix including half-neighbors and large odd integers also matches byte-for-byte.'''
old=old[:start]+rounding+old[end:]
start=old.index('极大精度使缩放系数为无穷')
end=old.index('正负半值舍入测试覆盖这些行为。',start)+len('正负半值舍入测试覆盖这些行为。')
old=old[:start]+'''极大精度使缩放系数无穷，零乘它产生 NaN；Java 返回零，C++ 直接转整数则未定义。原有 `floor(x + 0.5)` 还存在二次舍入：略小于 0.5 的数会得到 1，2^52 以上的某些整数也会改变。精度 0 接线后这些输入仍会与 Java 不同，因此本项同时修正舍入路径。现在按 IEEE 有效数进行无符号整数舍入：小于半个单位返回零，NaN 返回零，指数越界饱和；将舍弃位与半个单位比较，负数的阈值再加一，使恰好半值向正无穷方向舍入；已为整数的值只做有界左移，并在有符号转换前截断到范围。遵循 Java Math.round 语义，避免浮点加法及 floor 调用；舍入和转换辅助函数使用现有 `FORCE_INLINE`，实际 NaN 输入仍走原始位路径。Java 实际生成的 1,088,975 个随机/边界输入与 32 位饱和及 64 位结果全部一致，旧 floor 公式有 251 个差异。原有 122 组 wire 矩阵仍逐字节一致，新增包含半值相邻数及大奇数的另一套 122 组矩阵也逐字节一致。'''+old[end:]
en='''### Reserved precision markers and zero-only pages

`2147483646` and `2147483647` are valid parsed precisions but also the two leading bitmap tags. Infinite scaling of zero rounds to integer zero, so every scaled flag is set and `has_overflow()` is false. Writing the precision directly then makes both decoders interpret the following integer block as a bitmap header; the C++ reader rejects its zero count with `E_DECODE_ERR`.

Both floating-point `flush()` paths now also enter the existing bitmap wrapper when the precision is one of these two tags. They write the normal scaled-value marker, count, all-scaled bitmap, actual precision and integer blocks. The precision after the bitmap is read as a value without recursively interpreting it as a marker. This uses the existing Java/C++ wire layout, changes neither decoder, and adds work only when a page is sealed. Empty pages still write nothing.

The record schema-check helpers also borrow `DeviceID` through a const reference to the caller-owned `shared_ptr`, avoiding an unnecessary ownership copy/refcount update on every record. They only look up the ID and never retain the reference; the caller owns it throughout the call, including when a temporary is bound for the full expression. This changes private helper parameters, preserves public APIs and object layouts, and keeps error returns unchanged.

The first wrapper implementation showed a reproducible FLOAT record slowdown (125 pooled pairs, median 1.0172, 95% CI [1.0062, 1.0244]). Bitmap-helper and inlining-only experiments did not resolve every record signal; those were rejected. MSVC disassembly and all source snapshots/measurements are retained. The final source also corrects the rounding approximation as explained above; the four-workload results below use that source.

The regression matrix covers both types, precisions `1000`, `2147483645` and both reserved tags, 1/8/129/260 values, signed zero, reset/repeated pages and every existing writer path. **Important compatibility limit:** current Java itself emits unreadable zero-only pages for the two reserved precisions (16 raw pages and 8 full files reproduced). The fix deliberately emits a valid wrapper rather than copying those invalid bytes. All 64 additional C++ pages are readable by Java; 48 valid Java pages are readable by C++. Of those 48, 36 match byte-for-byte and 12 one-value pages differ only in the pre-existing, unused zero-delta block minimum (`MAX_VALUE` in Java, `0` in C++); the comparison normalizes only that unused field. The remaining 16 Java pages fail Java's own decoder and remain invalid input for C++. Eight additional zero-only C++ files pass own/Java reads (16 successful reads). These limits are retained in the raw evidence.

'''
zh='''两个合法精度值 `2147483646`、`2147483647` 同时也是格式开头的位图标记。全零输入乘无穷并按 Java 规则舍入为零后，所有 scaled flag 都置位，`has_overflow()` 为假；若直接写精度，解码器会把后续整数块当成位图头，C++ 因读到零数量而返回 `E_DECODE_ERR`。现在 FLOAT/DOUBLE 的 `flush()` 遇到这两个精度时，也进入现有位图包装，依次写 scaled-value 标记、数量、全部置位的 scaled 位图、实际精度和整数块。位图之后的精度作为值读取，不再递归当成标记。两边现有 decoder 都支持这个布局，无需修改；只在封页时增加判断，空页仍不输出。

record 的 schema 检查辅助函数改为通过 const 引用借用调用方的 `shared_ptr<DeviceID>`，避免逐条复制所有权及增减引用计数。函数只查找、不保留引用；调用方在整个调用期间拥有对象，临时参数也存活到完整表达式结束。只改私有辅助函数参数，公共 API、对象布局和错误返回保持原样。

新增测试覆盖两种类型、`1000`、`2147483645` 及两个保留值、1/8/129/260 个值、正负零、reset/重复页和全部 writer 路径。兼容性限制：当前 Java 自己也会为两个保留精度产生无法读回的全零页，已复现 16 个原始页及 8 个完整文件；因此修复采用可解码的现有包装，不复制这些无效字节。新增 64 个 C++ 页均能被 Java 读取，48 个有效 Java 页能被 C++ 读取；其中 36 个原始字节相同，12 个单值页只在原有、未使用的零 delta 块最小值字段不同（Java 为 `MAX_VALUE`，C++ 为 `0`），比较时仅规范化该未使用字段。剩余 16 个 Java 页在 Java 自身和 C++ 中都无法读取。新增 8 个全零 C++ 文件自身/Java 读取共 16 次通过；原始证据保留这些边界。

初版包装实现在 FLOAT record 出现可重复变慢（合并全部 125 轮，中位比 1.0172，95% CI [1.0062, 1.0244]）。位图辅助函数及仅强制内联的实验未消除全部 record 信号，均未采用；生成代码、源码快照及所有测量保留。最终版本还修正了上述舍入近似问题，下方四组结果对应最终源码。

'''
old=old.replace('### Local validation\n',en+'### Local validation\n')
old=old.replace('验证结果：相同 49 项',zh+'验证结果：相同 49 项')
old=old.replace('https://github.com/jixuan1989/tsfile-apache/blob/b772f16255c3e45a9c6599235621126d4fa399e2/issue-evidence/ts2diff-writer-precision/validation/validation-report.md','{REPORT_URL}')
old=old.replace('https://raw.githubusercontent.com/jixuan1989/tsfile-apache/b772f16255c3e45a9c6599235621126d4fa399e2/issue-evidence/ts2diff-writer-precision/validation/validation-evidence.zip','{EVIDENCE_URL}')
(revision/'pr-body-ready.md').write_text(old,encoding='utf-8')
rows=[]
for name,item in cov['per_file'].items():
    c=item['whole_file'];rows.append(f"| `{name}` | {c['covered_lines']}/{c['executable_lines']} ({c['line_percent']:.2f}%) | {c['covered_branches']}/{c['branches']} ({c['branch_percent']:.2f}%) |")
perfrows=[]
for name,item in perf['cases'].items():
    c=item['summary'];lo,hi=c['bootstrap_95_percent']
    perfrows.append(f"| {name} | {c['baseline']['median_seconds']:.6f} | {c['fixed']['median_seconds']:.6f} | {c['paired_median_latency_ratio']:.4f} | [{lo:.4f}, {hi:.4f}] | {c['baseline']['median_rows_per_second']:,.0f} / {c['fixed']['median_rows_per_second']:,.0f} | {c['baseline']['median_peak_working_set_bytes']:,} / {c['fixed']['median_peak_working_set_bytes']:,} |")
report=f'''# TsFile PR #1024 审阅修订验证

当前修复提交 `{head}`，基线 `1180b13675e11a0230708af2cc70d037e0e12623`。修订前 PR 提交 `5f4bc79a6db4d6cf79eb089a9dabe0e1fc4e12bb`。

{zh}
新增回归在修订前 33 项失败（32 个 writer 变体及 1 个跨页/边界编码器测试）；修订后全部 88 项专项测试通过。原版基线的既有 49 项 writer 回归仍有 33 项失败，验证属性接线问题。

Windows MSVC 14.50 Release：993 通过、3 跳过、10 原有禁用；Linux GCC 11.4 Debug 原子 gcov：1014 通过、1 跳过、10 原有禁用，无失败。Linux 启用 SNAPPY/LZ4/LZOKAY/ZLIB/ZSTD/LZMA2，原生 GenerateFixtures/ValidateFixtures 均实际执行，覆盖 C++ 读 135 个 Java 文件、Java 读 117 个 C++ 文件；Windows 可选压缩关闭。本地关闭 CLI 工具和 ANTLR/SIMD，线程/内存统计启用。

原有 122 组 × 260 个值的编码页已重跑双向解码和逐字节比较，122 组一致；精度 0/2/4/default、FLOAT/DOUBLE、对齐/非对齐的完整文件重新生成，共 32 个文件、64 次自身/交叉读取通过。新增边界矩阵及 Java 无效输入的实际失败均保留，不将无效 Java 页误计为通过。

舍入的额外 Java 对照包含 1,088,975 个确定性随机/边界输入，同时校验 32 位饱和和 64 位结果，全部一致；旧 floor 近似的 64 位结果有 251 处差异。另生成包含半值相邻数和大奇数的 122 组 × 260 个值的 wire 矩阵，双向读取及原始字节全部一致。舍入实现直接操作 IEEE 有效数，避免 x+0.5 的二次舍入，NaN 返回零，范围外饱和，负数恰好半值向正无穷方向舍入。

## 当前覆盖率

全量 Linux 测试前清理仅构建目录中的旧 gcda，使用 `-O0 -g --coverage -fprofile-update=atomic`；gcovr 未忽略解析错误、未排除分支。逐字节相同的源码/构建复制头文件按物理行及分支标识合并。对最新基线的修改生产可执行行 **{changed['covered_lines']}/{changed['executable_lines']} ({changed['line_percent']:.2f}%)**，相同行分支 **{changed['covered_branches']}/{changed['branches']} ({changed['branch_percent']:.2f}%)**，不是全库覆盖率。

| 受影响模块整个文件 | 行 | 分支 |
|---|---|---|
{chr(10).join(rows)}

## 当前性能

使用原有同一独立 benchmark_driver.cc、同机 MSVC 14.50 Release、相同编译/链接选项、时间/值均 UNCOMPRESSED、固定 CPU 掩码 4；record 500,000 行，Tablet 5,000,000 行。两边各预热 2 次，每组先 25 轮交错运行，FLOAT record 另做预先固定 100 轮确认，合并保留全部 125 轮；配对中位数 bootstrap 10,000 次。计时包含 open/register/write/close，排除 Tablet 构建与读回；每轮仍完整读回核对全部行。峰值工作集包含整个进程/读回。测量期间无本任务构建/覆盖率负载；最终测量后记录源码、库和驱动 SHA，并在后续全量验证后复核；测量期间没有修改源码或重建二进制。

| 工作负载 | 基线秒 | 修复秒 | 配对中位比 | 95% CI | 基线/修复 行每秒 | 基线/修复 峰值工作集 bytes |
|---|---:|---:|---:|---|---|---|
{chr(10).join(perfrows)}

四组等价输出工作负载未观察到可分辨退化；原版非默认精度输出错误，因此只以有效 default/2 为性能基线。这里不声称其他场景绝无退化。原有探索过程和首次验证证据继续保留在 [原始不可变证据](https://raw.githubusercontent.com/jixuan1989/tsfile-apache/b772f16255c3e45a9c6599235621126d4fa399e2/issue-evidence/ts2diff-writer-precision/validation/validation-evidence.zip) 中；当前修订数据以本报告及同目录补充包为准。

clang-format 17.0.6、仓库 Spotless 15 个改动文件检查及 git diff --check 均通过。已按用户授权在原审阅线程回复复现、判断和进度；未主动合并上游 PR。AI 说明继续置于 PR 正文末尾。

{state['workflow']['ai_disclosure']['pr_footer']}
'''
(revision/'validation-report.md').write_text(report,encoding='utf-8')
(base/'outputs/TsFile_PR_02_审阅修订验证报告.md').write_text(report,encoding='utf-8')
summary={'head_commit':head,'tests':counts,'coverage':cov,'performance':{k:v['summary'] for k,v in perf['cases'].items()},
         'original_wire_exact_matches':122,'new_cpp_pages_java_reads':64,'valid_java_pages_cpp_reads':48,
         'new_raw_exact_matches':36,'unused_single_value_delta_differences':12,'known_java_invalid_pages':16,
         'full_file_reads':64,'zero_cpp_file_reads':16,'gates_passed':True}
(revision/'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(revision/'contribution.diff').write_text(subprocess.check_output(['git','-C',str(source),'diff','1180b13675e11a0230708af2cc70d037e0e12623',head],text=True),encoding='utf-8')
package=base/'outputs/TsFile_PR_02_审阅修订验证证据.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
    for path in revision.rglob('*'):
        if path.is_file() and path.suffix not in ['.class'] and path.name not in ['pr-body-ready.md','round-oracle.bin']:z.write(path,str(path.relative_to(root)))
    for name in ['coverage-raw.json','coverage-summary.json','coverage-collection.log','performance.json','performance.log','windows-all-tests.xml','windows-all-tests.log','linux-all-tests.xml','linux-all-tests.log','cpp-wire.log','java-reads-cpp-wire.log','full-file-compatibility.log','full-file-compatibility.json','ReservedPrecisionCompatibility.java','driver.cc','benchmark_driver.cc','benchmark.py','CMakeLists.txt','build-linux.sh','summarize_coverage.py','capture_review_sources.py','finalize_review.py','JavaRoundOracle.java','round_oracle.cc','PrecisionWireCompatibility.java','native-java-validate.log','confirm_performance.py']:
        z.write(root/name,name)
with zipfile.ZipFile(package) as z:assert z.testzip() is None
print(json.dumps({'head':head,'gates_passed':True,'changed_coverage':changed,'evidence_bytes':package.stat().st_size},indent=2))

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * License); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

#include <chrono>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>
#include "reader/tsfile_reader.h"
#include "writer/tsfile_writer.h"
#include <windows.h>
#include <psapi.h>
using namespace storage;
using namespace common;
void check(bool valid, const std::string& operation) {
    if (!valid) throw std::runtime_error(operation);
}

void benchmark(const std::string& path, int rows, bool aligned, bool batch, const std::string& precision, bool is_float) {
    g_config_value_.time_compress_type_ = UNCOMPRESSED;
    const auto type = is_float ? common::FLOAT : common::DOUBLE;
    MeasurementSchema schema("v", type, TS_2DIFF, UNCOMPRESSED);
    if (precision != "default") schema.props_["max_point_number"] = precision;
    auto schemas = std::make_shared<std::vector<MeasurementSchema>>();
    schemas->emplace_back("v", type, TS_2DIFF, UNCOMPRESSED);
    Tablet tablet("root.d", schemas, batch ? rows : 1);
    if (batch) {
        for (int row = 0; row < rows; ++row) {
            check(tablet.add_timestamp(row, row) == E_OK, "timestamp");
            check((is_float ? tablet.add_value(row, "v", 1.23456f)
                            : tablet.add_value(row, "v", 1.23456)) == E_OK, "value");
        }
    }
    const auto start = std::chrono::steady_clock::now();
    {
        TsFileWriter writer;
        check(writer.open(path) == E_OK, "open writer");
        writer.set_generate_table_schema(false);
        check((aligned ? writer.register_aligned_timeseries("root.d", schema) : writer.register_timeseries("root.d", schema)) == E_OK, "register");
        if (batch) check((aligned ? writer.write_tablet_aligned(tablet) : writer.write_tablet(tablet)) == E_OK, "write tablet");
        else {
            for (int row = 0; row < rows; ++row) {
                TsRecord record(row, "root.d");
                if (is_float) record.add_point("v", 1.23456f);
                else record.add_point("v", 1.23456);
                check((aligned ? writer.write_record_aligned(record) : writer.write_record(record)) == E_OK, "write record");
            }
        }
        check(writer.close() == E_OK, "close writer");
    }
    double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    TsFileReader reader;
    check(reader.open(path) == E_OK, "open reader");
    ResultSet* result = nullptr;
    std::vector<std::string> paths{"root.d.v"};
    check(reader.query(paths, 0, rows, result) == E_OK, "query");
    int count = 0;
    for (;;) {
        bool has_next = false;
        check(result->next(has_next) == E_OK, "next");
        if (!has_next) break;
        check(is_float ? result->get_value<float>(2) == 1.23f
                       : result->get_value<double>(2) == 1.23, "read value");
        ++count;
    }
    check(count == rows, "row count");
    reader.destroy_query_data_set(result);
    reader.close();
    PROCESS_MEMORY_COUNTERS info{};
    GetProcessMemoryInfo(GetCurrentProcess(), &info, sizeof(info));
    std::cout << "{\"rows\":" << rows << ",\"seconds\":" << seconds << ",\"peak_working_set_bytes\":" << info.PeakWorkingSetSize << "}\n";
}

int main(int argc, char** argv) {
    try {
        check(argc == 8, "arguments");
        check(libtsfile_init() == E_OK, "init");
        benchmark(argv[2], std::stoi(argv[3]), std::stoi(argv[4]), std::stoi(argv[5]), argv[6], std::stoi(argv[7]));
        libtsfile_destroy();
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}

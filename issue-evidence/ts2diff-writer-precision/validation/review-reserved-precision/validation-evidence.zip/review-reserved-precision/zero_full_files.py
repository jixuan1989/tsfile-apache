from pathlib import Path
import json
import subprocess
import os

root=Path(__file__).resolve().parent
validation=root.parent
cp=(validation/'java-classpath.txt').read_text(encoding='utf-8-sig').strip()+';'+str(root)
java=[r'C:\Program Files\Java\jdk-24\bin\java.exe','-cp',cp,'PrecisionZeroRepro']
cpp=[str(validation/'drivers/Release/precision_zero_repro.exe')]
files=root/os.environ.get('TSFILE_ZERO_FILE_DIRECTORY','zero-full-files')
files.mkdir(exist_ok=True)
records=[]
def run(args,valid):
    result=subprocess.run(list(map(str,args)),capture_output=True,text=True,encoding='utf-8')
    records.append(dict(command=list(map(str,args)),exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
    (root/'zero-full-files.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    assert (result.returncode==0)==valid,records[-1]
    if valid:
        assert 'output.value=0.000000' in result.stdout and 'read=SUCCESS rows=1' in result.stdout
for data_type in ['FLOAT','DOUBLE']:
    for alignment in ['aligned','nonaligned']:
        for precision in ['2147483646','2147483647']:
            key=f'{data_type}-{alignment}-{precision}'
            java_file=files/(key+'-java.tsfile');cpp_file=files/(key+'-cpp.tsfile')
            assert not java_file.exists() and not cpp_file.exists()
            run([*java,'write',java_file,data_type,precision,alignment],False)
            run([*cpp,'read',java_file,data_type,precision,alignment],False)
            run([*cpp,'write',cpp_file,data_type,precision,alignment],True)
            run([*java,'read',cpp_file,data_type,precision,alignment],True)
            print(key+' cpp_self_read=PASS java_reads_cpp=PASS java_self_read=FAIL cpp_reads_invalid_java=FAIL',flush=True)
print('zero_file_configurations=8 cpp_own_and_java_cross_reads=16 PASS java_invalid_file_reads=16 CONFIRMED',flush=True)

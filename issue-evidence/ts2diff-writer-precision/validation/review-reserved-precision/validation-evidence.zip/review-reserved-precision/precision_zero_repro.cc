/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "reader/tsfile_reader.h"
#include "writer/tsfile_writer.h"

void check(int code, const char* operation) {
    if (code != common::E_OK)
        throw std::runtime_error(std::string(operation) + " code=" + std::to_string(code));
}

int run(int argc, char** argv) {
    if (argc != 6) throw std::runtime_error("write|read file FLOAT|DOUBLE default|precision aligned|nonaligned");
    const bool is_float = std::string(argv[3]) == "FLOAT";
    const bool aligned = std::string(argv[5]) == "aligned";
    const auto type = is_float ? common::FLOAT : common::DOUBLE;
    common::g_config_value_.time_compress_type_ = common::UNCOMPRESSED;
    if (std::string(argv[1]) == "write") {
        storage::TsFileWriter writer;
        check(writer.open(argv[2]), "open writer");
        writer.set_generate_table_schema(false);
        auto* schema = new storage::MeasurementSchema("v", type, common::TS_2DIFF, common::UNCOMPRESSED);
        if (std::string(argv[4]) != "default") schema->props_["max_point_number"] = argv[4];
        std::vector<storage::MeasurementSchema*> schemas{schema};
        if (aligned) check(writer.register_aligned_timeseries("root.precision.d", schemas), "register aligned");
        else check(writer.register_timeseries("root.precision.d", schemas), "register nonaligned");
        storage::TsRecord record(1, "root.precision.d");
        if (is_float) check(record.add_point("v", 0.0f), "add float");
        else check(record.add_point("v", 0.0), "add double");
        check(aligned ? writer.write_record_aligned(record) : writer.write_record(record), "write record");
        check(writer.close(), "close writer");
    }
    std::cout << "language=C++ mode=" << argv[1] << " type=" << argv[3]
              << " precision=" << argv[4] << " alignment=" << argv[5] << '\n'
              << "input.timestamp=1 input.value=0.000000 encoding=TS_2DIFF compression=UNCOMPRESSED\n";
    storage::TsFileReader reader;
    check(reader.open(argv[2]), "open reader");
    storage::ResultSet* result = nullptr;
    std::vector<std::string> paths{"root.precision.d.v"};
    check(reader.query(paths, 0, 2, result), "query");
    int rows = 0;
    for (;;) {
        bool has_next = false;
        check(result->next(has_next), "next");
        if (!has_next) break;
        double value = is_float ? result->get_value<float>(2) : result->get_value<double>(2);
        int64_t timestamp = result->get_value<int64_t>(1);
        std::cout << "output.timestamp=" << timestamp << " output.value=" << std::fixed << std::setprecision(6) << value << '\n';
        if (timestamp != 1) throw std::runtime_error("timestamp");
        ++rows;
    }
    reader.destroy_query_data_set(result);
    check(reader.close(), "close reader");
    if (rows != 1) throw std::runtime_error("row count=" + std::to_string(rows));
    std::cout << "read=SUCCESS rows=" << rows << '\n';
    return 0;
}

int main(int argc, char** argv) {
    try {
        check(storage::libtsfile_init(), "initialize");
        int code = run(argc, argv);
        storage::libtsfile_destroy();
        return code;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 2;
    }
}

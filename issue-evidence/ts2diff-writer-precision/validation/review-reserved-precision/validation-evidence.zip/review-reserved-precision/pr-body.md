A `FLOAT`/`DOUBLE` measurement configured with `TS_2DIFF` and `max_point_number` still used the C++ encoder's default precision of 2. With the issue's single input `1.23456`, precision `0` produced `1.23` instead of Java's `1.0`; precision `4` likewise produced `1.23` instead of `1.2346`.

Fixes #1020.

### Why the schema property did not take effect

There were two independent breaks in the writer path:

1. The single-schema registration overloads constructed an owned `MeasurementSchema` from four scalar fields, omitting `props_`. The fix explicitly copies the property map. It does not copy the schema's internal writer pointers, whose ownership must remain independent.
2. Even registrations retaining the map initialized chunk/page encoders using only type, encoding and compression. Pass the map through the nonaligned chunk writer, aligned value chunk writer and table value chunk writer to the value encoder factory. Configure floating-point TS_2DIFF encoders before their first value is encoded.

The existing init overloads delegate using an empty map. The existing two-argument factory implementation stays unchanged; its new overload calls it before applying the property. Class layouts remain unchanged. Property parsing occurs when the encoder is created; it is not added to each row's write path. Precision `2` reuses the encoder's existing default without a redundant `pow` call. Encoder resets preserve the configured precision between pages.

### Matching Java's boundary behavior

The parser follows a fresh Java `TSEncodingBuilder.Ts2Diff` initialized from properties: a missing key uses the existing default `2`; a valid negative value falls back to `2`; malformed or overflowing signed integers leave the fresh builder's precision at `0`. Signs, leading zeroes and BMP decimal digits accepted by `Integer.parseInt` are handled explicitly, without locale-dependent parsing. Supplementary digits, whitespace, trailing text and malformed UTF-8 are rejected.

Very large valid precision makes the scale infinite. For zero, multiplication then produces NaN. Java's `Math.round` returns `0`; casting NaN to a C++ integer is undefined. Include NaN in the existing upper saturation guard: use `!(r <= INT32_MAX)` for the 32-bit conversion and `!(r < 2^63)` for the 64-bit conversion. Ordered comparisons with NaN are false, so the guard's cold branch returns `0` for NaN and the maximum integer for above-range numbers. The lower clamp and actual NaN input/raw-bit handling stay unchanged. Keep this small rounding helper `FORCE_INLINE` to preserve the normal conversion path's performance after adding the boundary handling. Positive/negative zero, NaN, infinities and signed half-rounding regressions cover the behavior.

### Local validation

- The same 49 writer regressions fail **33** cases against unmodified `1180b13675e11a0230708af2cc70d037e0e12623` and pass all 49 with the fix. They cover FLOAT/DOUBLE, aligned/nonaligned, copied/owned schemas, record/Tablet writes, multiple pages/chunks and table value-chunk encoding. Five additional parser/factory/boundary tests pass: **54 new tests** total.
- Windows MSVC Release: **959 passed**, 3 skipped and 10 existing disabled tests. Linux GCC Debug with all six optional compression libraries enabled: **980 passed**, 1 skipped and 10 existing disabled tests.
- Java/C++: **122** floating-point page cases, each with 260 values, decode successfully in both directions and produce **122 exact byte matches**. The matrix includes parsing boundaries, Unicode digits, precision 0/2/4/9/1000/int-max, signed zero, NaN, infinities and extreme finite values. Complete tree files pass **16 configurations, 32 files and 64 own/cross reads**. Native interoperability additionally validates **135 Java-written** and **117 C++-written** files, including actual LZ4/ZSTD/LZMA2 compressed data.
- GCC/gcovr changed production executable-line coverage: **100.00%** (75/75); changed-line branch coverage **70.00%**. New `encoding_props.h`: **100.00% lines**, **96.77% branches**. The detailed report lists every affected module. Byte-identical source/build headers are merged; no branch exclusions or ignored parse errors are used. Unexercised branches include allocation/exception paths.
- Four equivalent-output Release workloads (500,000 rows for record writes; 5,000,000 for Tablet writes), two warmups per variant and 25 alternating pairs per workload, fixed CPU affinity. Both executables compile the same benchmark-only source with identical flags and link their respective libraries. Paired median fixed/baseline write-latency ratios: **1.0025, 0.9853, 1.0083, 0.9978**. Full readback validates every run. **No distinguishable regression was observed in these measured workloads.** Timing includes writer open/registration/write/close; Tablet construction and readback are outside the timer. Peak working set covers the whole process. The original nondefault precision output is wrong, so those workloads cannot serve as equivalent-output performance baselines.
- clang-format **17.0.6**, repository Spotless apply/check on the 14 changed files, and `git diff --check` pass.

[Detailed local validation report](https://github.com/jixuan1989/tsfile-apache/blob/b772f16255c3e45a9c6599235621126d4fa399e2/issue-evidence/ts2diff-writer-precision/validation/validation-report.md) · [Raw logs, coverage, measurements and validation scripts](https://raw.githubusercontent.com/jixuan1989/tsfile-apache/b772f16255c3e45a9c6599235621126d4fa399e2/issue-evidence/ts2diff-writer-precision/validation/validation-evidence.zip)

The table precision regression inspects the encoded value page directly. Non-empty table-schema property serialization is the separate issue #1017 / PR #1018; this branch remains independent of that change. These results establish the tested precision behavior and interoperability scope, rather than complete Java/C++ feature parity.

### 中文说明

配置了 `TS_2DIFF` 和 `max_point_number` 的 FLOAT/DOUBLE 测点仍使用 C++ 默认精度 2。同一个输入 `1.23456`，精度 `0` 原来读回 `1.23`，Java 为 `1.0`；精度 `4` 原来仍是 `1.23`，Java 为 `1.2346`。

问题有两处：单个 schema 的注册重载只复制四个标量字段，丢失 `props_`；即使注册时保留了属性，chunk/page writer 初始化编码器时也没有传递它。现在显式复制属性，并通过非对齐、对齐及表模型的 value chunk/page writer 传给编码器工厂，在首次编码前设置浮点 TS_2DIFF 精度。显式复制属性可以避免误复制 schema 内部 writer 指针及其所有权。

保留原有 factory/init 重载及类布局；原有 init 重载使用空属性委托，原双参数工厂实现保持原样，新重载先调用它再应用属性。参数只在编码器初始化时解析，精度 `2` 复用编码器已有默认设置、避免重复调用 `pow`，跨页 reset 保留精度。

解析遵循新建 Java `TSEncodingBuilder.Ts2Diff` 的实际行为：缺少键或合法负数使用默认精度 `2`，格式错误或整数溢出使该 builder 保持精度 `0`；支持符号、前导零及 Java `Integer.parseInt` 接受的 BMP 十进制数字。补充字符数字、空白、尾随文本和无效 UTF-8 不被接受。极大精度使缩放系数为无穷，零乘它产生 NaN；Java `Math.round` 返回 `0`，C++ 的直接整数转换未定义。现在将 NaN 纳入原有上界分支：32 位转换使用 `!(r <= INT32_MAX)`，64 位使用 `!(r < 2^63)`；NaN 的有序比较为假，因此在该冷分支返回零，超过上界的数仍返回整数最大值。下界饱和和真正 NaN 输入的原始位处理保持原样。舍入函数使用仓库现有 `FORCE_INLINE` 宏，保持增加边界处理后正常转换路径的性能。正负零、NaN、无穷及正负半值舍入测试覆盖这些行为。

验证结果：相同 49 项 writer 回归在原版有 33 项失败，修复后全部通过；另有 5 项解析、工厂和边界测试，共新增 54 项。Windows 全量 959 项通过，Linux 全量 980 项通过。122 组编码页双向解码且字节全部一致；完整 tree 文件 16 组配置、32 个文件、64 次读取通过，另通过 135 个 Java 文件和 117 个 C++ 文件的原生互通矩阵。

修改生产可执行行覆盖率 100.00%（75/75），相同行的分支覆盖率 70.00%；新解析头文件行覆盖率 100.00%，分支覆盖率 96.77%。统计合并逐字节相同的源码与构建头文件，不排除分支、不忽略解析错误；完整报告逐项列出受影响模块，尚有分配失败及异常分支未覆盖。

4 组等价输出 Release 性能对照，record 写入各 500,000 行、Tablet 写入各 5,000,000 行；两边编译同一份独立性能驱动、使用相同选项，每种变体预热 2 次、交错测量 25 轮并固定 CPU。修复/基线配对耗时比中位数为 1.0025, 0.9853, 1.0083, 0.9978。本次所测工作负载未观察到可分辨的退化。 每轮完整读回校验；计时包含创建文件、注册、写入和关闭，Tablet 构建与读回不计入写入耗时，峰值工作集包含整个进程。原版非默认精度的输出错误，不能充当等价输出的性能基线。

表模型精度测试直接检查编码后的 value page；非空表 schema 属性的序列化由 #1017 / #1018 单独处理。本分支不包含那项修改。上述结果对应已测精度与互通范围。

**AI disclosure:** The implementation, tests and description in this pull request were written by an AI coding agent (OpenAI Codex), which also performed the reported local validation.

**AI 使用说明：** 本 PR 的代码修改、测试和正文由 AI 编程代理（OpenAI Codex）编写，文中报告的本地验证也由该 AI 代理执行。

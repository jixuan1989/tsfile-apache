/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
import org.apache.tsfile.common.conf.TSFileDescriptor;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.read.TsFileReader;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.common.Path;
import org.apache.tsfile.read.common.RowRecord;
import org.apache.tsfile.read.expression.QueryExpression;
import org.apache.tsfile.read.query.dataset.QueryDataSet;
import org.apache.tsfile.write.TsFileWriter;
import org.apache.tsfile.write.record.TSRecord;
import org.apache.tsfile.write.schema.MeasurementSchema;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PrecisionZeroRepro {
  public static void main(String[] args) throws Exception {
    if (args.length != 5) throw new IllegalArgumentException("write|read file FLOAT|DOUBLE default|precision aligned|nonaligned");
    TSDataType type = TSDataType.valueOf(args[2]);
    boolean aligned = args[4].equals("aligned");
    File file = new File(args[1]);
    TSFileDescriptor.getInstance().getConfig().setCompressor("UNCOMPRESSED");
    TSFileDescriptor.getInstance().getConfig().setFloatPrecision(2);
    if (args[0].equals("write")) {
      Map<String, String> props = args[3].equals("default") ? Map.of() : Map.of("max_point_number", args[3]);
      MeasurementSchema schema = new MeasurementSchema("v", type, TSEncoding.TS_2DIFF, CompressionType.UNCOMPRESSED, props);
      try (TsFileWriter writer = new TsFileWriter(file)) {
        if (aligned) writer.registerAlignedTimeseries(new Path("root.precision.d"), List.of(schema));
        else writer.registerTimeseries(new Path("root.precision.d"), schema);
        TSRecord record = new TSRecord("root.precision.d", 1L);
        if (type == TSDataType.FLOAT) record.addPoint("v", 0.0f);
        else record.addPoint("v", 0.0d);
        writer.writeRecord(record);
      }
    }
    System.out.printf("language=Java mode=%s type=%s precision=%s alignment=%s%n", args[0], type, args[3], args[4]);
    System.out.println("input.timestamp=1 input.value=0.000000 encoding=TS_2DIFF compression=UNCOMPRESSED");
    try (TsFileReader reader = new TsFileReader(new TsFileSequenceReader(file.getPath()))) {
      QueryDataSet result = reader.query(QueryExpression.create(List.of(new Path("root.precision.d", "v", true)), null));
      int rows = 0;
      while (result.hasNext()) {
        RowRecord row = result.next();
        double value = type == TSDataType.FLOAT ? row.getFields().get(0).getFloatV() : row.getFields().get(0).getDoubleV();
        System.out.printf(Locale.ROOT, "output.timestamp=%d output.value=%.6f%n", row.getTimestamp(), value);
        if (row.getTimestamp() != 1) throw new AssertionError("timestamp");
        rows++;
      }
      if (rows != 1) throw new AssertionError("row count=" + rows);
      System.out.println("read=SUCCESS rows=" + rows);
    }
  }
}

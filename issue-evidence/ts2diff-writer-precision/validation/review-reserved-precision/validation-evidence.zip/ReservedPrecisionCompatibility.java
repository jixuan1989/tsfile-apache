/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.encoding.decoder.Decoder;
import org.apache.tsfile.write.schema.MeasurementSchema;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.*;
import java.util.*;

public class ReservedPrecisionCompatibility {
  static int varInt(ByteBuffer buffer) {
    int result=0,shift=0; byte next;
    do { next=buffer.get();result|=(next&127)<<shift;shift+=7; } while(next<0);
    return result;
  }
  static byte[] normalizeUnusedSingleValueDelta(byte[] encoded,TSDataType type) {
    byte[] copy=encoded.clone();var b=ByteBuffer.wrap(copy);
    int precision=varInt(b);
    if(precision>=2147483646) {
      int count=varInt(b);
      b.position(b.position()+(count/8+1)*(precision==2147483646?2:1));
      varInt(b);
    }
    int block=b.position();
    if(b.getInt()!=0 || b.getInt()!=0)throw new AssertionError("not a zero-delta block");
    // With exactly one value no delta uses this field. Java leaves MAX_VALUE;
    // the existing C++ integer codec writes zero. Keep all other bytes checked.
    Arrays.fill(copy,block+8,block+8+(type==TSDataType.FLOAT?4:8),(byte)0);
    return copy;
  }
  static byte[] decoded(byte[] encoded, TSDataType type, int rows) throws Exception {
    var decoder = Decoder.getDecoderByType(TSEncoding.TS_2DIFF, type);
    var buffer = ByteBuffer.wrap(encoded);
    var bytes = new ByteArrayOutputStream();
    var output = new DataOutputStream(bytes);
    for (int row = 0; row < rows; ++row) {
      if (!decoder.hasNext(buffer)) throw new IllegalStateException("missing row="+row);
      if (type == TSDataType.FLOAT) output.writeInt(Float.floatToRawIntBits(decoder.readFloat(buffer)));
      else output.writeLong(Double.doubleToRawLongBits(decoder.readDouble(buffer)));
    }
    if (decoder.hasNext(buffer)) throw new IllegalStateException("trailing rows");
    return bytes.toByteArray();
  }
  public static void main(String[] args) throws Exception {
    Path dir = Path.of(args[1]); Files.createDirectories(dir);
    if (args[0].equals("generate")) {
      var manifest = new ArrayList<String>(); int invalid=0;
      for (var type : List.of(TSDataType.FLOAT, TSDataType.DOUBLE))
        for (int precision : new int[]{1000,2147483645,2147483646,2147483647})
          for (int rows : new int[]{1,8,129,260})
            for (boolean zero : new boolean[]{true,false}) {
              String id=type+"_"+precision+"_"+rows+"_"+(zero?"zero":"mixed");
              var encoder = new MeasurementSchema("v",type,TSEncoding.TS_2DIFF,CompressionType.UNCOMPRESSED,Map.of("max_point_number",""+precision)).getValueEncoder();
              var bytes=new ByteArrayOutputStream();
              try(var input=new DataOutputStream(Files.newOutputStream(dir.resolve(id+".input")))) {
                for(int row=0;row<rows;row++) {
                  double value=(!zero && row==rows-1)?1.23456:(row%2==0?0.0:-0.0);
                  if(type==TSDataType.FLOAT){input.writeInt(Float.floatToRawIntBits((float)value));encoder.encode((float)value,bytes);}
                  else{input.writeLong(Double.doubleToRawLongBits(value));encoder.encode(value,bytes);}
                }
              }
              encoder.flush(bytes); byte[] encoded=bytes.toByteArray();
              Files.write(dir.resolve(id+".java.bin"),encoded);
              Files.writeString(dir.resolve(id+".prop"),""+precision);
              byte[] expected;
              try { expected=decoded(encoded,type,rows); }
              catch(Exception error) {
                if(!zero || precision<2147483646) throw error;
                invalid++;
                Files.writeString(dir.resolve(id+".java-invalid"),error.getClass().getName());
                expected=new byte[rows*(type==TSDataType.FLOAT?4:8)];
                System.out.println(id+" Java self-read="+error.getClass().getSimpleName());
              }
              Files.write(dir.resolve(id+".expected"),expected);
              manifest.add(id+","+type+",1");
            }
      Files.write(dir.resolve("manifest.csv"),manifest);
      if(invalid!=16)throw new AssertionError("unexpected invalid="+invalid);
      System.out.println("java_cases="+manifest.size()+" readable=48 invalid_reserved_zero=16");
    } else {
      int cases=0,exact=0,exceptions=0,unusedDelta=0;
      for(String line:Files.readAllLines(dir.resolve("manifest.csv"))) {
        String[] parts=line.split(",");var type=TSDataType.valueOf(parts[1]);
        byte[] expected=Files.readAllBytes(dir.resolve(parts[0]+".expected"));
        byte[] cpp=Files.readAllBytes(dir.resolve(parts[0]+".cpp.bin"));
        if(!Arrays.equals(expected,decoded(cpp,type,expected.length/(type==TSDataType.FLOAT?4:8))))throw new AssertionError(parts[0]);
        if(Arrays.equals(cpp,Files.readAllBytes(dir.resolve(parts[0]+".java.bin"))))exact++;
        else if(Files.exists(dir.resolve(parts[0]+".java-invalid")))exceptions++;
        else if(expected.length==(type==TSDataType.FLOAT?4:8) && Arrays.equals(normalizeUnusedSingleValueDelta(cpp,type),normalizeUnusedSingleValueDelta(Files.readAllBytes(dir.resolve(parts[0]+".java.bin")),type)))unusedDelta++;
        else throw new AssertionError("unexpected byte difference "+parts[0]);
        cases++;
      }
      if(cases!=64 || exact!=36 || unusedDelta!=12 || exceptions!=16)throw new AssertionError("counts="+cases+","+exact+","+unusedDelta+","+exceptions);
      System.out.println("java_reads_cpp=64 exact_valid_java_pages=36 equivalent_unused_single_value_delta=12 repaired_java_invalid_layouts=16 PASS");
    }
  }
}

from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import os
import random
import statistics
import subprocess

root = Path(__file__).resolve().parent
binary = root / 'drivers/Release'
affinity = ctypes.windll.kernel32.SetProcessAffinityMask
affinity.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
affinity.restype = wintypes.BOOL
sequence = 0

def run(kind, arguments):
    global sequence
    sequence += 1
    path = root / f'benchmark-{os.getpid()}-{sequence}-{kind}.tsfile'
    assert not path.exists()
    process = subprocess.Popen([str(binary / f'benchmark_{kind}.exe'), 'benchmark', str(path), *map(str,arguments)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    applied = bool(affinity(wintypes.HANDLE(int(process._handle)), 4))
    stdout, stderr = process.communicate()
    assert applied, 'Could not set benchmark CPU affinity'
    if process.returncode: raise RuntimeError(stdout+'\n'+stderr)
    result = json.loads([line for line in stdout.splitlines() if line.startswith('{')][-1])
    result['affinity_mask'] = 4
    assert path.resolve().parent == root.resolve() and path.name.startswith('benchmark-')
    path.unlink()
    return result

def percentile(values, fraction):
    values=sorted(values); index=(len(values)-1)*fraction; lo=int(index); hi=min(lo+1,len(values)-1)
    return values[lo]*(hi-index)+values[hi]*(index-lo) if hi!=lo else values[lo]

cases = {
    'float_nonaligned_record_default':[500000,0,0,'default',1],
    'double_nonaligned_tablet_default':[5000000,0,1,'default',0],
    'float_aligned_tablet_precision_2':[5000000,1,1,'2',1],
    'double_aligned_record_precision_2':[500000,1,0,'2',0],
}
if os.environ.get('TSFILE_PRECISION_BENCH_CASES'):
    cases = json.loads(os.environ['TSFILE_PRECISION_BENCH_CASES'])
report={'baseline_commit':'1180b13675e11a0230708af2cc70d037e0e12623',
    'platform':'Windows x64 MSVC 14.50 Release; static; threads/memstat enabled; uncompressed time/value columns',
    'method':'Identical benchmark_driver.cc compiled with identical options against baseline/fixed headers and static libraries; no factory/wire validation code in either driver. Two warmup processes per variant; 25 alternating pairs; affinity mask 4; stopwatch includes writer open/register/write/close, excludes Tablet construction and complete readback; peak working set includes whole process/readback.',
    'scope':'Existing valid default and explicit precision-2 workloads; original non-default output has different precision and is not an equivalent-output performance baseline.',
    'cases':{}}
rng=random.Random(1020)
for name, arguments in cases.items():
    print('Benchmark: '+name,flush=True)
    for warmup in range(2):
        for kind in ['baseline','fixed']: run(kind,arguments)
    measurements=[]
    for pair in range(25):
        order=['baseline','fixed'] if pair%2==0 else ['fixed','baseline']
        row={kind:run(kind,arguments) for kind in order}
        measurements.append(row)
    ratios=[row['fixed']['seconds']/row['baseline']['seconds'] for row in measurements]
    bootstrap=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for repeat in range(10000))
    summary={'paired_median_latency_ratio':statistics.median(ratios),
        'bootstrap_95_percent':[percentile(bootstrap,.025),percentile(bootstrap,.975)]}
    for kind in ['baseline','fixed']:
        times=[row[kind]['seconds'] for row in measurements]
        summary[kind]={'median_seconds':statistics.median(times),'p95_seconds':percentile(times,.95),
            'median_rows_per_second':statistics.median(row[kind]['rows']/row[kind]['seconds'] for row in measurements),
            'median_peak_working_set_bytes':statistics.median(row[kind]['peak_working_set_bytes'] for row in measurements)}
    report['cases'][name]={'arguments':arguments,'summary':summary,'measurements':measurements}
    (root/'performance.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'case':name,**summary}),flush=True)

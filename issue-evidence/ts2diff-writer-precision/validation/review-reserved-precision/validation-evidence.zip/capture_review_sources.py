from pathlib import Path
import hashlib
import json
import subprocess
from datetime import datetime, timezone

root=Path(__file__).resolve().parent
source=root.parent/'fix-repo'
revision=root/'review-reserved-precision'
previous=json.loads((revision/'source-fingerprints.json').read_text(encoding='utf-8'))
record={'captured_at':datetime.now(timezone.utc).isoformat(),'source':{},'artifacts':{}}
paths=set(previous['source'])
paths.update(subprocess.check_output(['git','-C',str(source),'diff','--name-only','1180b13675e11a0230708af2cc70d037e0e12623','--','cpp/src','cpp/test'],text=True).splitlines())
for path in sorted(paths):
    record['source'][path]=hashlib.sha256((source/path).read_bytes()).hexdigest()
for path in previous['artifacts']:
    record['artifacts'][path]=hashlib.sha256((root/path).read_bytes()).hexdigest()
record['artifacts']['driver.cc']=hashlib.sha256((root/'driver.cc').read_bytes()).hexdigest()
record['artifacts']['drivers/Release/precision_fixed.exe']=hashlib.sha256((root/'drivers/Release/precision_fixed.exe').read_bytes()).hexdigest()
target=revision/'final-source-fingerprints.json'
if target.exists():
    old=json.loads(target.read_text())
    assert old['source']==record['source'] and old['artifacts']==record['artifacts'],'Measured sources/artifacts changed'
    print('Measured source/library/driver fingerprints reverified.')
else:
    target.write_text(json.dumps(record,indent=2)+'\n')
    print('Measured source/library/driver fingerprints captured.')

from pathlib import Path
import json
import random
import statistics
from datetime import datetime,timezone

root=Path(__file__).resolve().parent
revision=root/'review-reserved-precision'
report=json.loads((root/'performance.json').read_text())
first='float_nonaligned_record_default'
initial=report['cases'][first]
assert len(initial['measurements'])==25
(revision/'performance-final-before-confirmation.json').write_text(json.dumps(report,indent=2)+'\n')
plan={'reason':'Confirm the final FLOAT record path after borrowing DeviceID in schema checks; an earlier implementation showed a slowdown. Retain all initial final-source samples: '+str(initial['summary']),
      'additional_pairs':100,'pooled_pairs':125,'case':first,'arguments':initial['arguments'],
      'decision':'One fixed-size confirmation; retain all original and confirmation pairs, use pooled paired median with 10000 bootstrap resamples. If pooled CI lower bound exceeds 1, investigate implementation before pushing.',
      'started_at':datetime.now(timezone.utc).isoformat()}
(revision/'performance-final-confirmation-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
helpers={'__file__':str(root/'benchmark.py')}
exec((root/'benchmark.py').read_text().split('cases = {',1)[0],helpers)
run=helpers['run'];percentile=helpers['percentile']
for warmup in range(2):
    for kind in ['baseline','fixed']:run(kind,initial['arguments'])
additional=[]
for pair in range(100):
    order=['baseline','fixed'] if pair%2==0 else ['fixed','baseline']
    additional.append({kind:run(kind,initial['arguments']) for kind in order})
    (revision/'performance-final-confirmation-samples.json').write_text(json.dumps(additional,indent=2)+'\n')
    if pair%25==24:print(f'Confirmation pairs={pair+1}/100',flush=True)
measurements=initial['measurements']+additional
ratios=[x['fixed']['seconds']/x['baseline']['seconds'] for x in measurements]
rng=random.Random(1020)
boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
summary={'paired_median_latency_ratio':statistics.median(ratios),'bootstrap_95_percent':[percentile(boot,.025),percentile(boot,.975)]}
for kind in ['baseline','fixed']:
    times=[x[kind]['seconds'] for x in measurements]
    summary[kind]={'median_seconds':statistics.median(times),'p95_seconds':percentile(times,.95),
        'median_rows_per_second':statistics.median(x[kind]['rows']/x[kind]['seconds'] for x in measurements),
        'median_peak_working_set_bytes':statistics.median(x[kind]['peak_working_set_bytes'] for x in measurements)}
report['cases'][first].update(summary=summary,measurements=measurements,confirmation=plan)
report['method']+=' First FLOAT record case additionally includes a predeclared fixed 100-pair confirmation, pooled with all initial 25 pairs (125 total); no initial samples removed.'
(root/'performance.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'case':first,'pooled_pairs':125,**summary}),flush=True)

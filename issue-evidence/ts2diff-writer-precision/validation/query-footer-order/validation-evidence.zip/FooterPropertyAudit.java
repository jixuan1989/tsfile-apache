/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.utils.ReadWriteForEncodingUtils;
import org.apache.tsfile.utils.ReadWriteIOUtils;

public class FooterPropertyAudit {
  private static String json(Map<String, byte[]> map) {
    StringBuilder out = new StringBuilder("{");
    for (Map.Entry<String, byte[]> e : new TreeMap<>(map).entrySet()) {
      if (out.length() > 1) out.append(',');
      out.append('"').append(e.getKey()).append("\":");
      if (e.getValue() == null) out.append("null");
      else out.append('"').append(new String(e.getValue(), StandardCharsets.UTF_8)).append('"');
    }
    return out.append('}').toString();
  }
  private static void check(Map<String, byte[]> p, boolean raw) {
    if (p.size() != 3 || !p.containsKey("encryptKey")
        || (raw ? p.get("encryptKey") != null : !Arrays.equals(p.get("encryptKey"), new byte[0]))
        || !Arrays.equals(p.get("encryptLevel"), "0".getBytes(StandardCharsets.UTF_8))
        || !Arrays.equals(p.get("encryptType"), "org.apache.tsfile.encrypt.UNENCRYPTED".getBytes(StandardCharsets.UTF_8))) {
      throw new AssertionError("Footer property mismatch; raw=" + raw + "; actual=" + json(p));
    }
  }
  public static void main(String[] args) throws Exception {
    byte[] data = Files.readAllBytes(Paths.get(args[0]));
    ByteBuffer bytes = ByteBuffer.wrap(data, Integer.parseInt(args[2]), Integer.parseInt(args[3])).slice();
    int count = ReadWriteForEncodingUtils.readVarInt(bytes);
    if (count != 3) throw new AssertionError("Wrong raw property count");
    Map<String, byte[]> raw = new HashMap<>();
    for (int i = 0; i < count; i++) {
      String key = ReadWriteIOUtils.readVarIntString(bytes);
      int size = ReadWriteForEncodingUtils.readVarInt(bytes);
      if (size < -1 || size > bytes.remaining()) throw new AssertionError("Invalid property length");
      byte[] value = size == -1 ? null : new byte[size];
      if (value != null) bytes.get(value);
      if (raw.containsKey(key)) throw new AssertionError("Duplicate property");
      raw.put(key, value);
    }
    if (bytes.hasRemaining()) throw new AssertionError("Unconsumed property bytes");
    check(raw, true);
    try (TsFileSequenceReader reader = new TsFileSequenceReader(args[0])) {
      Map<String, byte[]> p = reader.getTsFileProperties();
      check(p, false);
      if (reader.readFileMetadata().getEncryptLevel() != 0) throw new AssertionError("Encryption level");
      System.out.println("{\"label\":\"" + args[1]
          + "\",\"raw_properties\":" + json(raw) + ",\"java_api_properties\":" + json(p) + ",\"PASS\":true}");
    }
  }
}

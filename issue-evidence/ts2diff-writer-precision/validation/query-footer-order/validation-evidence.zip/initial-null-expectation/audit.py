"""Identify footer differences in frozen files; no writes to originals or timings."""
from pathlib import Path
from itertools import permutations
from datetime import datetime,timezone
import hashlib
import json
import subprocess

root=Path(__file__).resolve().parent;here=root/'tail-properties';here.mkdir(exist_ok=True)
base=root.parents[1]
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
item=next(x for x in [state['active'],*state['drafts']] if x['id']=='02')
repo=base/item['implementation']['source']
plan=json.loads((root/'plan.json').read_text(encoding='utf-8'))
expected={'encryptLevel':b'0','encryptType':b'org.apache.tsfile.encrypt.UNENCRYPTED','encryptKey':None}

def varint(data,at,end):
    value=0
    for shift in range(0,35,7):
        if at>=end:raise ValueError('Truncated varint')
        b=data[at];at+=1;value|=(b&127)<<shift
        if not b&128:return (value>>1)^-(value&1),at
    raise ValueError('Oversized varint')

def encode(n):
    z=(n<<1)^(n>>31);out=bytearray()
    while z>=128:out.append((z&127)|128);z>>=7
    out.append(z);return bytes(out)

def parse(data):
    assert data[:6]==data[-6:]==b'TsFile'
    end=len(data)-10;length=int.from_bytes(data[-10:-6],'big');start=end-length
    assert 0<start<end
    candidates=[]
    for candidate in range(start,end):
        at=candidate;entries=[];bounds=[]
        try:
            count,at=varint(data,at,end)
            if count!=3:continue
            for _ in range(count):
                first=at;size,at=varint(data,at,end)
                if not 0<size<=end-at:raise ValueError('Key')
                key=data[at:at+size].decode('utf-8');at+=size
                size,at=varint(data,at,end)
                if size==-1:value=None
                elif 0<=size<=end-at:value=data[at:at+size];at+=size
                else:raise ValueError('Value')
                entries.append((key,value));bounds.append({'key':key,'start':first,'end':at,'value_is_null':value is None})
            if at==end and len(dict(entries))==3 and dict(entries)==expected:
                candidates.append({'start':candidate,'end':end,'entries':entries,'entry_bounds':bounds,'metadata_start':start,'metadata_bytes':length})
        except (ValueError,UnicodeDecodeError):pass
    assert len(candidates)==1
    return candidates[0]

def serialized(entries):
    out=encode(len(entries))
    for key,value in entries:
        raw=key.encode();out+=encode(len(raw))+raw
        out+=encode(-1) if value is None else encode(len(value))+value
    return out

records={};pairs=[];frozen={};java_inputs=[]
for sparse in [0,1]:
    c=next(c for c in plan['cases']['02'] if c['sparse']==sparse and c['name']==(
        'DOUBLE_aligned_p2_null0_props0_all_w4_batch_parallel0' if sparse==0 else
        'DOUBLE_aligned_p2_null1_props0_app50_w1_batch_parallel0'))
    parsed={}
    for platform in ['Windows','Linux']:
        for writer in ['baseline','fixed']:
            file=Path(plan['fixtures'][c['fixture_key']]['paths'][writer]) if platform=='Windows' else root/'gcc-query/data'/f'{writer}-sparse{sparse}.tsfile'
            data=file.read_bytes();meta=parse(data);label=f'{platform.lower()}_{writer}_sparse{sparse}'
            frozen[file]=hashlib.sha256(data).hexdigest()
            normalized=data[:meta['start']]+serialized(sorted(meta['entries']))+data[meta['end']:]
            assert len(normalized)==len(data)
            order=[k for k,v in meta['entries']]
            records[label]={'file_bytes':len(data),'sha256':frozen[file],'property_count':3,
                'property_order':order,'property_start':meta['start'],'property_end':meta['end'],
                'property_block_bytes':meta['end']-meta['start'],'metadata_start':meta['metadata_start'],
                'metadata_bytes':meta['metadata_bytes'],'entry_bounds':meta['entry_bounds'],
                'logical_properties':{k:None if v is None else v.decode() for k,v in meta['entries']},
                'canonical_sha256':hashlib.sha256(normalized).hexdigest(),
                'all_six_entry_permutations_keep_total_size':all(len(serialized(list(p)))==meta['end']-meta['start'] for p in permutations(meta['entries']))}
            parsed[platform,writer]=(data,meta,normalized)
            java_inputs.append((label,file))
    for platform in ['Windows','Linux']:
        assert parsed[platform,'baseline'][0]==parsed[platform,'fixed'][0]
    w,wm,wn=parsed['Windows','fixed'];l,lm,ln=parsed['Linux','fixed']
    assert wm['start']==lm['start'] and wm['end']==lm['end']
    differences=[n for n,(a,b) in enumerate(zip(w,l)) if a!=b]
    assert len(w)==len(l) and len(differences)==69
    assert all(wm['start']<=p<wm['end'] for p in differences)
    assert w[:wm['start']]==l[:lm['start']] and w[wm['end']:]==l[lm['end']:]
    assert wn==ln
    assert l[:lm['start']]+serialized(wm['entries'])+l[lm['end']:]==w
    assert w[:wm['start']]+serialized(lm['entries'])+w[wm['end']:]==l
    pairs.append({'sparse':sparse,'differing_bytes':len(differences),'first_diff':min(differences),'last_diff':max(differences),
        'identical_prefix_bytes':wm['start'],'identical_suffix_bytes':len(w)-wm['end'],
        'only_property_entry_order_differs':True,'reordering_each_side_in_memory_exactly_reconstructs_the_other':True,
        'canonical_sha256':hashlib.sha256(wn).hexdigest()})

license=(root/'QueryFixtureAudit.java').read_text(encoding='utf-8').split('import java.',1)[0]
java=license+'''import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import org.apache.tsfile.read.TsFileSequenceReader;

public class FooterPropertyAudit {
  public static void main(String[] args) throws Exception {
    try (TsFileSequenceReader reader = new TsFileSequenceReader(args[0])) {
      Map<String, byte[]> p = reader.getTsFileProperties();
      if (p == null || p.size() != 3 || !p.containsKey("encryptKey")
          || p.get("encryptKey") != null
          || !Arrays.equals(p.get("encryptLevel"), "0".getBytes(StandardCharsets.UTF_8))
          || !Arrays.equals(p.get("encryptType"), "org.apache.tsfile.encrypt.UNENCRYPTED".getBytes(StandardCharsets.UTF_8))) {
        throw new AssertionError("Footer property mismatch");
      }
      System.out.println("{\\"label\\":\\"" + args[1]
          + "\\",\\"encryptLevel\\":\\"0\\",\\"encryptType\\":\\"org.apache.tsfile.encrypt.UNENCRYPTED\\",\\"encryptKey\\":null,\\"PASS\\":true}");
    }
  }
}
'''
source=here/'FooterPropertyAudit.java';source.write_text(java,encoding='utf-8')
cp=(root.parent/'issue-04/java-classpath.txt').read_text(encoding='utf-8-sig').strip()
jdk=Path('C:/Program Files/Java/jdk-24/bin');classes=here/'java-classes';classes.mkdir(exist_ok=True)
build=subprocess.run([str(jdk/'javac.exe'),'-cp',cp,'-d',str(classes),str(source)],capture_output=True,text=True)
(here/'java-build.log').write_text(build.stdout+build.stderr,encoding='utf-8')
assert build.returncode==0,build.stderr
java_results=[]
for label,file in java_inputs:
    proc=subprocess.run([str(jdk/'java.exe'),'-cp',str(classes)+';'+cp,'FooterPropertyAudit',str(file),label],capture_output=True,text=True,timeout=30)
    record={'label':label,'exit_code':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr}
    java_results.append(record)
    (here/'java-results.json').write_text(json.dumps(java_results,indent=2)+'\n',encoding='utf-8')
    assert proc.returncode==0,record
    out=json.loads(next(line for line in proc.stdout.splitlines() if line.startswith('{')))
    assert out['PASS'] and out['encryptKey'] is None
for file,h in frozen.items():assert hashlib.sha256(file.read_bytes()).hexdigest()==h
files=['cpp/src/common/tsfile_common.h','cpp/src/common/tsfile_common.cc','cpp/src/file/tsfile_io_writer.cc','cpp/src/reader/tsfile_reader.cc']
assert not subprocess.check_output(['git','-C',str(repo),'diff','--name-only',item['implementation']['upstream_base']+'..'+item['head_commit'],'--',*files],text=True).strip()
result={'analyzed_at':datetime.now(timezone.utc).isoformat(),'head':item['head_commit'],'new_query_timing_children':0,
    'original_inputs_unchanged':True,'source_changed':False,'query_gate_cleared':False,'necessary_cost_proven':False,
    'files':records,'pairs':pairs,'java_metadata_checks':8,'java_results':java_results,
    'unchanged_source_files':files,'source_sha256':{f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in files},
    'interpretation':'The69tail-byte differences are exactly a permutation of3default nullable property entries. All other file bytes are identical. C++ serializer traverses unordered_map; its deserializer emplaces named keys. Java SDK reports the same three logical values for all8files. This is not a value/encoding/Bloom-filter difference or a demonstrated new compatibility defect. The original Windows baseline/fixed files are byte-identical, so this cross-platform permutation cannot explain their within-Windows contrast.',
    'limits':['A different map insertion order may affect metadata allocation/cache behavior; no zero timing effect is asserted.',
              'Cross-platform compiler/OS/virtualization/LTO/filesystem factors remain; no necessary cost or original Windows gate clearance.',
              'No new full-value Java cross-read matrix, reverse Java-to-C++ run, coverage, sanitizer or write/query performance result.']}
(here/'analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'property_orders':{k:v['property_order'] for k,v in records.items()},'pairs':pairs,
    'Java_metadata_checks_passed':8,'all_original_files_unchanged':True,'new_query_timings':0,'query_gate_cleared':False},indent=2))

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import org.apache.tsfile.read.TsFileSequenceReader;

public class FooterPropertyAudit {
  public static void main(String[] args) throws Exception {
    try (TsFileSequenceReader reader = new TsFileSequenceReader(args[0])) {
      Map<String, byte[]> p = reader.getTsFileProperties();
      if (p == null || p.size() != 3 || !p.containsKey("encryptKey")
          || p.get("encryptKey") != null
          || !Arrays.equals(p.get("encryptLevel"), "0".getBytes(StandardCharsets.UTF_8))
          || !Arrays.equals(p.get("encryptType"), "org.apache.tsfile.encrypt.UNENCRYPTED".getBytes(StandardCharsets.UTF_8))) {
        throw new AssertionError("Footer property mismatch");
      }
      System.out.println("{\"label\":\"" + args[1]
          + "\",\"encryptLevel\":\"0\",\"encryptType\":\"org.apache.tsfile.encrypt.UNENCRYPTED\",\"encryptKey\":null,\"PASS\":true}");
    }
  }
}

from pathlib import Path
import hashlib,json,struct
root=Path(__file__).resolve().parent
a=json.loads((root/'analysis.json').read_text(encoding='utf-8'))
def integer(data,pos):
    n=0
    for shift in range(0,35,7):
        b=data[pos];pos+=1;n|=(b&127)<<shift
        if b<128:return (n>>1)^-(n&1),pos
    raise AssertionError('varint exceeds 32 bits')
def pack(n):
    n=(n<<1)^(n>>31);out=[]
    while n>127:out.append((n&127)|128);n>>=7
    return bytes(out+[n])
normalized={};original={}
for name,record in a['files'].items():
    data=(root/'files'/(name+'.tsfile')).read_bytes();original[name]=data
    assert hashlib.sha256(data).hexdigest()==record['sha256']
    assert data[:6]==data[-6:]==b'TsFile'
    end=len(data)-10;start=record['property_start']
    assert end-struct.unpack('>I',data[-10:-6])[0]==record['metadata_start']
    count,pos=integer(data,start);assert count==3;values={};entries=[]
    for _ in range(count):
        first=pos;size,pos=integer(data,pos);assert size>0
        key=data[pos:pos+size].decode();pos+=size
        size,pos=integer(data,pos);assert size>=-1
        value=None if size==-1 else data[pos:pos+size].decode()
        if size>=0:pos+=size
        assert key not in values;values[key]=value;entries.append((key,data[first:pos]))
    assert pos==end and values==record['logical_properties']
    assert [k for k,v in entries]==record['property_order']
    norm=data[:start]+pack(count)+b''.join(v for k,v in sorted(entries))+data[end:]
    assert hashlib.sha256(norm).hexdigest()==record['canonical_sha256']
    normalized[name]=norm
for sparse in [0,1]:
    names=[f'{p}_{w}_sparse{sparse}' for p in ['windows','linux'] for w in ['baseline','fixed']]
    assert len(set(normalized[n] for n in names))==1
    assert original[names[0]]==original[names[1]] and original[names[2]]==original[names[3]]
    left,right=original[names[0]],original[names[2]]
    positions=[i for i,(x,y) in enumerate(zip(left,right)) if x!=y]
    assert len(positions)==69
    assert all(a['files'][names[0]]['property_start']<=i<len(left)-10 for i in positions)
for item in a['java_results']:
    assert item['exit_code']==0
    value=json.loads(next(s for s in item['stdout'].splitlines() if s.startswith('{')))
    assert value['PASS'] and value['raw_properties']==a['files'][item['label']]['logical_properties']
    assert value['java_api_properties']==dict(value['raw_properties'],encryptKey='')
print(json.dumps(dict(files=8,java_results_verified=8,order_only_pairs=2,query_gate_cleared=False,PASS=True)))

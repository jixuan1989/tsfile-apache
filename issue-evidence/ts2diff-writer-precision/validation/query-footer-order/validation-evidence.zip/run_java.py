from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
cp=sys.argv[1];a=json.loads((root/'analysis.json').read_text(encoding='utf-8'))
classes=root/'classes';classes.mkdir(exist_ok=True)
subprocess.run(['javac','-cp',cp,'-d',str(classes),str(root/'FooterPropertyAudit.java')],check=True)
import os
for label,r in a['files'].items():
    file=root/'files'/(label+'.tsfile')
    assert hashlib.sha256(file.read_bytes()).hexdigest()==r['sha256']
    subprocess.run(['java','-cp',str(classes)+os.pathsep+cp,'FooterPropertyAudit',str(file),label,str(r['property_start']),str(r['property_block_bytes'])],check=True)

"""Execute exactly the frozen three-case GCC/WSL comparison, retaining all samples."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import random
import shutil
import statistics
import subprocess
import time

root=Path(__file__).resolve().parent
here=root/'gcc-query'
job=Path('/tmp/tsfile-pr02-query-gcc-20261018')
plan=json.loads((here/'predeclared-plan.json').read_text())
build=json.loads((here/'build-environment.json').read_text())
assert build.get('completed_at') and not (job/'results.json').exists()
assert {2,3,4} <= os.sched_getaffinity(0)
os.sched_setaffinity(0,{4})
labels=['baseline_1','fixed_1','baseline_2','fixed_2']
cases=plan['cases']
assert len(cases)==3 and plan['quartets_per_case']==48
data_dir=job/'data';data_dir.mkdir()
image_dir=job/'images';image_dir.mkdir()
logs=job/'query-logs';logs.mkdir()
payloads={v:(job/f'query_{v}').read_bytes() for v in ['baseline','fixed']}
for v,b in payloads.items():assert hashlib.sha256(b).hexdigest()==build['versions'][v]['image_sha256']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def expected(c):
    checksum=0;accepted=0;nulls=0
    for row in range(65536):
        keep=c['scenario']!='app50' or row%100<50
        accepted+=keep
        for col in range(c['width']):
            nil=bool(c['sparse'] and col>0 and (row%32768+col)%11==0)
            nulls+=nil
            if keep:checksum+=17 if nil else row*32+col*4+1
    return {'rows_per_query':65536,'accepted_rows_per_query':accepted,'checksum':checksum*3,
            'NULL_cells':nulls*3,'fields':c['width'],'repeats':3}
expects={c['name']:expected(c) for c in cases}
positions={l:Counter() for l in labels};paths={l:Counter() for l in labels};case_positions={c['name']:Counter() for c in cases}
def order_for(r,values):
    order=values[r%len(values):]+values[:r%len(values)]
    return list(reversed(order)) if (r//len(values))%2 else order
for r in range(48):
    for pos,label in enumerate(order_for(r,labels)):positions[label][pos]+=1
    for i,label in enumerate(labels):paths[label][(i+r)%4]+=1
    for pos,c in enumerate(order_for(r,cases)):case_positions[c['name']][pos]+=1
assert all(len(c)==4 and set(c.values())=={12} for c in [*positions.values(),*paths.values()])
assert all(len(c)==3 and set(c.values())=={16} for c in case_positions.values())
report={'plan':plan,'build_environment':build,'position_balance':positions,'path_balance':paths,
    'case_order_balance':case_positions,'fixtures':{},'smokes':[],'warmups':[],
    'measurements':{c['name']:[] for c in cases},'query_gate_cleared':False,
    'deadline_seconds':600,'affinity_before_exec_verified_in_child':True}
deadline=time.monotonic()+600
result_path=job/'results.json'
def save():result_path.write_text(json.dumps(report,indent=2)+'\n')
def affinity():
    os.sched_setaffinity(0,{2,3})
    assert os.sched_getaffinity(0)=={2,3}
def native(args,log):
    assert time.monotonic()<deadline
    p=subprocess.run([str(a) for a in args],capture_output=True,text=True,timeout=30,preexec_fn=affinity)
    (logs/log).write_text(p.stdout+'\nSTDERR:\n'+p.stderr)
    assert p.returncode==0,(log,p.stdout,p.stderr)
    return json.loads([s for s in p.stdout.splitlines() if s.startswith('{')][-1])
def read(c,image,file,label,phase,r):
    args=[image,'read',file,c['layout'],c['kind'],c['precision'],c['sparse'],c['properties'],
          c['scenario'],c['width'],c['batch'],0,3]
    log=f'{phase}-{r:02}-{c["name"]}-{label}.log'
    n=native(args,log)
    assert all(n[k]==v for k,v in expects[c['name']].items()),(c['name'],label,n)
    for field in ['open_seconds','metadata_seconds','plan_seconds','first_row_seconds','first_decoded_row_seconds','full_seconds']:
        assert len(n[field])==3 and all(x is not None and x>=0 for x in n[field]),field
    assert all(t>0 for t in n['full_seconds'])
    return {'round':r,'label':label,'phase':phase,'image':Path(image).name,'log':log,'native_output':n}
try:
    for sparse in [0,1]:
        products={}
        for v in ['baseline','fixed']:
            path=data_dir/f'{v}-sparse{sparse}.tsfile'
            n=native([job/f'query_{v}','write',path,'aligned','DOUBLE',2,sparse,0],f'write-{v}-{sparse}.log')
            assert n=={'written':True,'rows':65536}
            products[v]=path
        assert products['baseline'].read_bytes()==products['fixed'].read_bytes(),'Stop: differing writer bytes'
        c=next(c for c in cases if c['sparse']==sparse)
        windows=Path(json.loads((root/'plan.json').read_text())['fixtures'][c['fixture_key']]['paths']['fixed'].replace('C:/','/mnt/c/'))
        # Plan paths use Windows drive letters; convert only this read-only comparison.
        if not windows.exists():
            from pathlib import PureWindowsPath
            raw=json.loads((root/'plan.json').read_text())['fixtures'][c['fixture_key']]['paths']['fixed']
            win=PureWindowsPath(raw)
            windows=Path('/mnt')/win.drive[0].lower()/Path(*win.parts[1:])
        report['fixtures'][str(sparse)]={'paths':{v:str(p) for v,p in products.items()},
            'sha256':{v:sha(p) for v,p in products.items()},'bytes':products['fixed'].stat().st_size,
            'baseline_fixed_byte_identical':True,'windows_fixed_sha256':sha(windows),
            'linux_equals_windows_bytes':products['fixed'].read_bytes()==windows.read_bytes()}
    for c in cases:
        for reader in ['baseline','fixed']:
            for writer in ['baseline','fixed']:
                file=report['fixtures'][str(c['sparse'])]['paths'][writer]
                report['smokes'].append(read(c,job/f'query_{reader}',file,reader+'_'+writer,'smoke',0))
    assert len(report['smokes'])==12
    save()
    for r in range(48):
        for i,label in enumerate(labels):
            p=image_dir/f'q{(i+r)%4:03}'
            p.write_bytes(payloads[label.split('_')[0]])
            p.chmod(0o755)
        for c in order_for(r,cases):
            file=report['fixtures'][str(c['sparse'])]['paths']['fixed']
            for warm in range(2):
                for label in labels:
                    image=image_dir/f'q{(labels.index(label)+r)%4:03}'
                    report['warmups'].append(read(c,image,file,label,'warm'+str(warm),r))
            rows={}
            for label in order_for(r,labels):
                image=image_dir/f'q{(labels.index(label)+r)%4:03}'
                assert image.read_bytes()==payloads[label.split('_')[0]]
                rows[label]=read(c,image,file,label,'measured',r)
            report['measurements'][c['name']].append(rows)
        if (r+1)%4==0:save()
        if (r+1)%12==0:print(f'GCC query quartets per case: {r+1}/48',flush=True)
    report['completed_at']=datetime.now(timezone.utc).isoformat()
    save()
finally:
    save()
    shutil.copy2(result_path,here/'results.json')
    shutil.copytree(logs,here/'query-logs',dirs_exist_ok=True)
    shutil.copytree(data_dir,here/'data',dirs_exist_ok=True)
print(json.dumps({'completed':True,'measured_queries':48*3*4*3,'warmup_queries':len(report['warmups'])*3,
    'smoke_queries':len(report['smokes'])*3,'query_gate_cleared':False}))

"""Extra correctness audits after the frozen timing run; not timing replacements."""
from pathlib import Path, PureWindowsPath
import hashlib
import json
import subprocess
import sys

root=Path(__file__).resolve().parent
here=root/'gcc-query'
sys.path.insert(0,str(root))
import benchmark as original
r=json.loads((here/'results.json').read_text(encoding='utf-8'))
old=original.plan
cp_path=root.parent/'issue-04/java-classpath.txt'
cp=cp_path.read_text(encoding='utf-8-sig').strip()
jdk=Path('C:/Program Files/Java/jdk-24/bin')
classes=here/'java-classes';classes.mkdir(exist_ok=True)
p=subprocess.run([str(jdk/'javac.exe'),'-cp',cp,'-d',str(classes),str(root/'QueryFixtureAudit.java')],capture_output=True,text=True)
assert p.returncode==0,p.stderr
audit={'timing_replaced':False,'cross_platform_native_reads':[],'cpp_linux_files_read_by_java':[],
    'new_java_to_cpp_runs':False,'original_compatibility_evidence_scope_unchanged':True,
    'java_audit_source_sha256':hashlib.sha256((root/'QueryFixtureAudit.java').read_bytes()).hexdigest(),
    'java_classpath_file_sha256':hashlib.sha256(cp_path.read_bytes()).hexdigest()}
for sparse in [0,1]:
    for writer in ['baseline','fixed']:
        path=here/'data'/f'{writer}-sparse{sparse}.tsfile'
        args=[str(jdk/'java.exe'),'-Xmx512m','-cp',str(classes)+';'+cp,'QueryFixtureAudit',str(path),'DOUBLE','aligned','2',str(sparse),'2']
        p=subprocess.run(args,capture_output=True,text=True,timeout=90)
        audit['cpp_linux_files_read_by_java'].append({'writer':writer,'sparse':sparse,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
        (here/'crosscheck.json').write_text(json.dumps(audit,indent=2)+'\n')
        assert p.returncode==0,p.stdout+p.stderr
for case in r['plan']['cases']:
    for reader in ['baseline','fixed']:
        file=here/'data'/f'fixed-sparse{case["sparse"]}.tsfile'
        args=[str(root/f'build/Release/query_02_{reader}.exe'),'read',str(file),case['layout'],case['kind'],str(case['precision']),str(case['sparse']),str(case['properties']),case['scenario'],str(case['width']),str(case['batch']),'0','3']
        p=subprocess.run(args,capture_output=True,text=True,timeout=30)
        assert p.returncode==0,p.stdout+p.stderr
        n=json.loads(next(x for x in p.stdout.splitlines() if x.startswith('{')))
        assert all(n[k]==v for k,v in original.expected(case).items())
        audit['cross_platform_native_reads'].append({'case':case['name'],'reader':reader,'direction':'Linux_cpp_file_to_Windows_cpp','native_output':n})
        win=PureWindowsPath(old['fixtures'][case['fixture_key']]['paths']['fixed'])
        posix=str(Path('/mnt')/win.drive[0].lower()/Path(*win.parts[1:])).replace('\\','/')
        args=['wsl.exe','-d','Ubuntu-22.04','--',f'/tmp/tsfile-pr02-query-gcc-20261018/query_{reader}','read',posix,case['layout'],case['kind'],str(case['precision']),str(case['sparse']),str(case['properties']),case['scenario'],str(case['width']),str(case['batch']),'0','3']
        p=subprocess.run(args,capture_output=True,text=True,timeout=30)
        assert p.returncode==0,p.stdout+p.stderr
        n=json.loads(next(x for x in p.stdout.splitlines() if x.startswith('{')))
        assert all(n[k]==v for k,v in original.expected(case).items())
        audit['cross_platform_native_reads'].append({'case':case['name'],'reader':reader,'direction':'Windows_cpp_file_to_Linux_cpp','native_output':n})
        (here/'crosscheck.json').write_text(json.dumps(audit,indent=2)+'\n')
assert len(audit['cross_platform_native_reads'])==12
assert len(audit['cpp_linux_files_read_by_java'])==4
audit.update(cross_platform_checked_queries=36,java_cpp_file_checks=4,passed=True)
(here/'crosscheck.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'passed':True,'cross_platform_checked_queries':36,'Linux_cpp_files_audited_by_Java':4,'new_Java_to_cpp_runs':False}))

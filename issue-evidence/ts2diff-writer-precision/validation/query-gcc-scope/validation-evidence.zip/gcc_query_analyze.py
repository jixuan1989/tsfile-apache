"""Offline verification and fixed block summaries; never reruns a benchmark."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import random
import statistics
import sys

root=Path(__file__).resolve().parent
here=root/'gcc-query'
sys.path.insert(0,str(root))
import benchmark as original
r=json.loads((here/'results.json').read_text(encoding='utf-8'))
plan=json.loads((here/'predeclared-plan.json').read_text(encoding='utf-8'))
assert r.get('completed_at') and r['plan']==plan
cases={c['name']:c for c in plan['cases']}
expected_by_case={name:original.expected(c) for name,c in cases.items()}
assert len(r['smokes'])==12 and len(r['warmups'])==1152
assert sum(len(rows)*4 for rows in r['measurements'].values())==576
all_children=r['smokes']+r['warmups']+[c for rows in r['measurements'].values() for row in rows for c in row.values()]
assert len(all_children)==1740
case_by_log={}
for c in plan['cases']:
    for row in r['measurements'][c['name']]:
        for child in row.values():case_by_log[child['log']]=c
for child in r['smokes']+r['warmups']:
    matched=[c for n,c in cases.items() if n in child['log']]
    assert len(matched)==1
    case_by_log[child['log']]=matched[0]
for child in all_children:
    text=(here/'query-logs'/child['log']).read_text(encoding='utf-8')
    n=json.loads(next(s for s in text.splitlines() if s.startswith('{')))
    assert n==child['native_output']
    c=case_by_log[child['log']]
    assert all(n[k]==v for k,v in expected_by_case[c['name']].items()),child['log']
    assert n['fields']==c['width'] and n['repeats']==3
positions={};paths={}
for name,rows in r['measurements'].items():
    assert len(rows)==48
    for index,row in enumerate(rows):
        for pos,(label,child) in enumerate(row.items()):
            assert child['round']==index and child['phase']=='measured'
            positions.setdefault((name,label),Counter())[pos]+=1
            paths.setdefault((name,label),Counter())[child['image']]+=1
assert all(len(c)==4 and set(c.values())=={12} for c in [*positions.values(),*paths.values()])
for sparse,fixture in r['fixtures'].items():
    files={v:here/'data'/Path(p).name for v,p in fixture['paths'].items()}
    assert files['baseline'].read_bytes()==files['fixed'].read_bytes()
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==fixture['sha256'][v] for v,p in files.items())
for v,build in r['build_environment']['versions'].items():
    assert hashlib.sha256((here/f'query_{v}').read_bytes()).hexdigest()==build['image_sha256']
rng=random.Random(102420)
def pct(values,f):
    values=sorted(values);i=(len(values)-1)*f;a=int(i);b=min(a+1,len(values)-1)
    return values[a] if a==b else values[a]*(b-i)+values[b]*(i-a)
def summarize(ratios):
    blocks=[statistics.median(ratios[i:i+4]) for i in range(0,48,4)]
    boots=sorted(statistics.median(rng.choices(blocks,k=12)) for _ in range(10000))
    return {'round_ratios':ratios,'paired_median_ratio':statistics.median(ratios),'chronological_block_medians':blocks,
        'block_median_ratio':statistics.median(blocks),'bootstrap95':[pct(boots,.025),pct(boots,.975)]}
out={'analyzed_at':datetime.now(timezone.utc).isoformat(),'source_heads':plan['source_heads'],
    'platform':'GCC11.4, Ubuntu22.04 WSL2, stock Release O3/LTO, static, warm ext4; guest CPUs2,3 parent4',
    'measured_queries':1728,'excluded_warmup_queries':3456,'excluded_cross_read_smoke_queries':36,
    'all_1740_native_read_logs_verified':True,'all_fixture_pairs_byte_identical':True,
    'query_gate_cleared':False,'windows_gate_replaced':False,'production_source_changed':False,
    'new_coverage_or_write_throughput_validation':False,
    'new_cpp_linux_files_audited_by_java':4 if (here/'crosscheck.json').exists() else 0,
    'new_java_to_cpp_runs':False,'cases':{},'limits':plan['unmeasured']}
for name,rows in r['measurements'].items():
    def total(row,label,metric='full_seconds'):return sum(row[label]['native_output'][metric])
    contrast=summarize([(total(row,'fixed_1')+total(row,'fixed_2'))/(total(row,'baseline_1')+total(row,'baseline_2')) for row in rows])
    controls={v:summarize([total(row,v+'_2')/total(row,v+'_1') for row in rows]) for v in ['baseline','fixed']}
    variants={}
    for v in ['baseline','fixed']:
        children=[row[v+'_'+i]['native_output'] for row in rows for i in ['1','2']]
        stats={}
        for metric in ['open_seconds','metadata_seconds','plan_seconds','first_row_seconds','first_decoded_row_seconds','full_seconds']:
            values=[x for c in children for x in c[metric]]
            stats[metric]={'samples':len(values),'p50':statistics.median(values),'p95':pct(values,.95)}
        stats['peak_process_rss_bytes']={'median':statistics.median(c['peak_process_working_set_bytes'] for c in children),
            'maximum':max(c['peak_process_working_set_bytes'] for c in children),'measurement':'Linux ru_maxrss *1024; whole process high-water RSS'}
        for kind,field in [('decoded_rows','rows_per_query'),('accepted_rows','accepted_rows_per_query')]:
            stats[kind+'_per_second_p50']=statistics.median(c[field]/t for c in children for t in c['full_seconds'])
        variants[v]=stats
    control_shifts=[v for v,s in controls.items() if s['bootstrap95'][0]>1 or s['bootstrap95'][1]<1]
    signal=contrast['bootstrap95'][0]>1
    p95_ratio=variants['fixed']['full_seconds']['p95']/variants['baseline']['full_seconds']['p95']
    out['cases'][name]={'fixed_over_baseline':contrast,'same_binary_copy2_over_copy1':controls,'variants':variants,
        'repeatable_upward_interval_in_this_protocol':signal,'nonneutral_copy_control_intervals':control_shifts,
        'descriptive_query_p95_ratio':p95_ratio,
        'qualification':'Scope observation only; preserve all samples and original Windows gate. Neutral intervals are not proof of equivalence.'}
(here/'analysis.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'measured_queries':1728,'warmups':3456,'smokes':36,'all_logs_verified':True,
    'cases':{n:{'block_change_percent':(x['fixed_over_baseline']['block_median_ratio']-1)*100,
        'bootstrap95':x['fixed_over_baseline']['bootstrap95'],'copy_control_shifts':x['nonneutral_copy_control_intervals'],
        'p95_ratio':x['descriptive_query_p95_ratio']} for n,x in out['cases'].items()},'query_gate_cleared':False},indent=2))

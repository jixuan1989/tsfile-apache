"""Freeze a separate GCC/WSL scope comparison before any Linux query timing."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

root=Path(__file__).resolve().parent
base=root.parents[1]
here=root/'gcc-query'
here.mkdir()
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
item=next(x for x in [state['active'],*state['drafts']] if x['id']=='02')
repo=base/item['implementation']['source']
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==item['head_commit']
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
heads={'baseline':item['implementation']['upstream_base'],'fixed':item['head_commit']}
for version,head in heads.items():
    subprocess.run(['git','-C',str(repo),'archive','--format=tar','-o',str(here/f'{version}-cpp.tar'),head,'cpp'],check=True)
driver=(root/'query_benchmark.cc').read_bytes()
(here/'query_benchmark.cc').write_bytes(driver)
old=json.loads((root/'plan.json').read_text(encoding='utf-8'))
names=['DOUBLE_aligned_p2_null0_props0_all_w4_row_parallel0',
       'DOUBLE_aligned_p2_null0_props0_all_w4_batch_parallel0',
       'DOUBLE_aligned_p2_null1_props0_app50_w1_batch_parallel0']
cases=[next(c for c in old['cases']['02'] if c['name']==n) for n in names]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan={'created_at':datetime.now(timezone.utc).isoformat(),'purpose':'Separate GCC/WSL scope comparison; not a Windows remedy or replacement acceptance.',
    'hypothesis':'The existing reader-path code/relocations are unchanged while MSVC image context differs. Establish whether the same three observed scenarios show a repeatable upward direction under independently built GCC Release images. Platform/compiler/LTO/filesystem conditions change together; this does not isolate compiler or cache causality.',
    'source_heads':heads,'source_archive_sha256':{v:sha(here/f'{v}-cpp.tar') for v in heads},
    'original_driver_sha256':sha(root/'query_benchmark.cc'),'driver_sha256':sha(here/'query_benchmark.cc'),
    'source_policy':'Fresh git archives of exact pinned commits; original production checkout remains untouched. No private rounding/layout/source candidate.',
    'cases':cases,'quartets_per_case':48,'queries_per_measured_child':3,'measured_query_count':1728,
    'warmup_policy':'Two excluded three-query children per label and case before each newly assigned image-path round; 3456 warmup queries total.',
    'position_path_case_order_policy':'Four labels baseline_1/fixed_1/baseline_2/fixed_2; rotated and alternated order. Every label appears12times per position and common path. Three cases rotate16times per execution position. No optional extension.',
    'statistics':'For each case/round sum full_seconds over both fixed copies divided by baseline copies. Twelve chronological four-round median blocks, median bootstrap10000, seed102420. Also preserve all pair medians, per-query p50/p95, per-version copy2/copy1 controls. These are finite scope comparisons, not global no-regression proof.',
    'child_guest_cpu_affinity':[2,3],'parent_guest_cpu_affinity':[4],
    'affinity_policy':'Set and assert child affinity in preexec_fn before exec, parent separate reported guest core. Guest topology is recorded; host mapping/SMT contention is not independently controlled.',
    'pool_threads':2,'parallel_query':False,'cache':'Warm Linux filesystem; no controlled cold-cache claim.',
    'filesystem':'Query executables and measured files reside in a new dedicated WSL ext4 /tmp directory; Windows NTFS source files are archived then extracted there before building.',
    'build':'GCC11 stock project Release (-O3 -flto -DNDEBUG), static, threads/memstat enabled, SIMD/ANTLR4 disabled, all six bundled compressors enabled. All query data UNCOMPRESSED. Driver compiled from same unchanged source, -O3 -DNDEBUG -flto -std=c++14.',
    'fixtures':'Generate dense and sparse aligned DOUBLE p2 with each native writer. Require matching logical expectations and byte-identical baseline/fixed writer files before timing; otherwise stop this protocol and retain artifacts. Compare Windows writer bytes separately and do not infer elapsed-time equivalence across OS.',
    'metrics':['open/metadata/plan','first accepted and first decoded row','fully consumed query latency and throughput','per-process peak RSS reported by ru_maxrss (not isolated query RSS)'],
    'stop_rules':['Any checksum/NULL/order/row count or fixture equivalence failure stops timing, preserves outputs and does not trigger a replacement workload.',
                  'No extension beyond48quartets, source padding/order/attributes/arithmetic changes or result trimming.',
                  'Any upward or biased-control result remains reported; a GCC outcome cannot clear the original Windows gate.'],
    'unmeasured':['bare-metal Linux','controlled cold cache','P99 inference','general parallel scaling','compressed-query timing','new Java/file interoperability/coverage/write-throughput validation'],
    'query_gate_cleared':False,'new_production_source_change':False}
(here/'predeclared-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'prepared':True,'heads':heads,'cases':len(cases),'quartets_per_case':48,'measured_queries':1728,'production_changed':False}))

"""Build pinned archived sources on WSL ext4; no measured query runs here."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import platform
import shutil
import subprocess
import tarfile

root=Path(__file__).resolve().parent
base=root.parents[1]
here=root/'gcc-query'
job=Path('/tmp/tsfile-pr02-query-gcc-20261018')
plan=json.loads((here/'predeclared-plan.json').read_text())
if job.exists():
    # Only the initial archive preflight failed; its directory contains no files.
    assert not any(p.is_file() or p.is_symlink() for p in job.rglob('*'))
else:
    job.mkdir()
cmake=base/'work/wsl-tools/cmake/data/bin/cmake'
cache=base/'work/issue-01/validation/linux-coverage/dependency-cache'
record={'created_at':datetime.now(timezone.utc).isoformat(),'job':str(job),'source_heads':plan['source_heads'],
    'uname':platform.uname()._asdict(),'compiler':subprocess.check_output(['g++','--version'],text=True),
    'cmake':subprocess.check_output([str(cmake),'--version'],text=True),
    'guest_topology':subprocess.check_output(['lscpu','-e=CPU,CORE,SOCKET,ONLINE'],text=True),
    'versions':{},'measured_queries_started':False}
(here/'build-environment.json').write_text(json.dumps(record,indent=2)+'\n')
def run(args,log):
    with (here/log).open('w') as out:
        subprocess.run([str(x) for x in args],stdout=out,stderr=subprocess.STDOUT,check=True,timeout=1200)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(here/'query_benchmark.cc')==plan['driver_sha256']
for version in ['baseline','fixed']:
    archive=here/f'{version}-cpp.tar'
    assert sha(archive)==plan['source_archive_sha256'][version]
    source=job/'sources'/version
    source.mkdir(parents=True,exist_ok=True)
    with tarfile.open(archive) as tar:
        assert all((m.name.startswith('cpp/') or (m.name=='cpp' and m.isdir()))
            and '..' not in Path(m.name).parts and not m.islnk()
            and (not m.issym() or (m.name=='cpp/AGENTS.md' and m.linkname=='CLAUDE.md')) for m in tar.getmembers())
        tar.extractall(source)
    build=job/'build'/version
    args=[cmake,'-S',source/'cpp','-B',build,'-DCMAKE_BUILD_TYPE=Release','-DTSFILE_BUILD_SHARED=OFF',
          '-DBUILD_TEST=OFF','-DBUILD_TOOLS=OFF','-DENABLE_ANTLR4=OFF','-DENABLE_SIMD=OFF','-DENABLE_THREADS=ON',
          '-DENABLE_MEM_STAT=ON','-DENABLE_SNAPPY=ON','-DENABLE_LZ4=ON','-DENABLE_LZOKAY=ON',
          '-DENABLE_ZLIB=ON','-DENABLE_ZSTD=ON','-DENABLE_LZMA2=ON','-DCOV_ENABLED=OFF','-DENABLE_ASAN=OFF',
          '-DTSFILE_ENABLE_NATIVE_ARCH=OFF','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',f'-DTSFILE_DEPENDENCY_CACHE={cache}']
    run(args,f'{version}-configure.log')
    run([cmake,'--build',build,'--target','tsfile','--parallel','6'],f'{version}-build.log')
    libs=[build/'lib'/n for n in ['libtsfile.a','libsnappy.a','libtsfile_lz4_bundled.a','libtsfile_lzokay_bundled.a','libz.a','libzstd.a','liblzma.a']]
    assert all(p.is_file() for p in libs)
    image=job/f'query_{version}'
    link=['g++','-O3','-DNDEBUG','-flto','-std=c++14','-DTSFILE_STATIC','-DENABLE_MEM_STAT','-DENABLE_THREADS',
          '-I',str(source/'cpp/src'),str(here/'query_benchmark.cc'),'-Wl,--start-group',*[str(p) for p in libs],
          '-Wl,--end-group','-pthread','-ldl','-o',str(image)]
    run(link,f'{version}-driver-build.log')
    shutil.copy2(image,here/f'query_{version}')
    record['versions'][version]={'source_head':plan['source_heads'][version],'image_sha256':sha(image),
        'libraries':{p.name:sha(p) for p in libs},'driver_command':link}
    (here/f'{version}-CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
    (here/f'{version}-compile_commands.json').write_bytes((build/'compile_commands.json').read_bytes())
    (here/'build-environment.json').write_text(json.dumps(record,indent=2)+'\n')
    print('Built pinned GCC Release:',version,flush=True)
record['completed_at']=datetime.now(timezone.utc).isoformat()
(here/'build-environment.json').write_text(json.dumps(record,indent=2)+'\n')

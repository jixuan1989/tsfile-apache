"""Private three-function order intervention for the three retained DOUBLE signals."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import random
import statistics
import sys
import matched_callers as m

here = Path(__file__).resolve().parent
rounds = 192
labels = ['original_baseline', 'original_fixed', 'ordered_baseline', 'ordered_fixed']
prior = json.loads((here/'counterbalanced-matrix-confirmation.json').read_text())
cases = {n: x['case'] for n, x in prior['cases'].items() if x['summary']['confirmation_signals']}
assert len(cases) == 3
m.cases.update(cases)
images = {}
for label in labels:
    condition, version = label.split('_')
    path = Path(m.executables['mixed'][version]['path']) if condition == 'original' else here/f'order-control/build/Release/ordered_{version}.exe'
    images[label] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
locations = json.loads((here/'order-control/ordered-locations.json').read_text())
assert all(x['baseline'] == x['fixed'] for x in locations.values())
payloads = {label: Path(x['path']).read_bytes() for label, x in images.items()}
image_dir = here/'order-images'
paths = [image_dir/f'j{i:03}.exe' for i in range(4)]
assignments = [{label: str(paths[(i+b) % 4]) for i, label in enumerate(labels)} for b in range(24)]
for path in paths:
    counts = Counter(label for a in assignments for label, p in a.items() if p == str(path))
    assert counts == {label: 6 for label in labels}
for values in [labels, list(cases)]:
    positions = {str(x): Counter() for x in values}
    for r in range(rounds):
        for i, x in enumerate(m.order(r, values)):
            positions[str(x)][i] += 1
    assert all(len(v) == len(values) and len(set(v.values())) == 1 for v in positions.values())

report = {
    'created_at': datetime.now(timezone.utc).isoformat(),
    'hypothesis': 'The completed joint identity comparison showed a positive caller interaction for dense DOUBLE batch queries. Test a private linker intervention: reuse EXACT original mixed caller objects/static libraries, adding /ORDER for three unchanged query functions so their baseline/fixed RVAs match. No C++ production edits/recompilation. Primary interaction = original F/B divided by ordered F/B. Static data and other function locations are not held constant; a positive interaction supports linked-layout contribution, not a particular cache mechanism or universal fix.',
    'selection': 'Same three prior retained signals. Fixed 192 matched rounds each. The dense batch caller interaction is the motivation; row and sparse queries remain diagnostics. This is not acceptance or full-matrix confirmation.',
    'ordered_function_locations': locations,
    'linker_documentation': 'https://learn.microsoft.com/en-us/cpp/build/reference/order-put-functions-in-order?view=msvc-170',
    'stopping_rule': '192 matched rounds per scenario, 4 children/round, 3 checked complete queries/child. No optional extension or outlier removal. Two warmups per image/scenario after copying each eight-round block, before all measured rounds in that block.',
    'analysis': 'Per matched round, F/B full-query sum within each caller. Primary interaction = original F/B divided by ordered F/B. 24 chronological block medians of eight rounds; bootstrap 20000 draws with fixed seed. All variants consume the same file identity; both original writer products are SHA256 identical in these three scenarios.',
    'settings': {'affinity_mask': 12, 'before_initial_resume': True, 'pool_threads': 2, 'parallel': False, 'cache': 'warm filesystem, interactive-host power/background not controlled'},
    'images': images, 'identity_assignments': assignments, 'fixtures': {},
    'cases': {name: {'case': case, 'measurements': []} for name, case in cases.items()}}


def copy_block(block):
    image_dir.mkdir(exist_ok=True)
    for label, path in assignments[block].items():
        p = Path(path)
        assert p.parent.resolve() == image_dir.resolve()
        p.write_bytes(payloads[label])
        assert hashlib.sha256(p.read_bytes()).hexdigest() == images[label]['sha256']


def prepare_fixtures():
    for name, case in cases.items():
        fixture = m.core.plan['fixtures'][case['fixture_key']]
        b, f = [Path(fixture['paths'][v]).read_bytes() for v in ['baseline', 'fixed']]
        assert b == f
        p = image_dir/(case['fixture_key']+'.tsfile')
        p.write_bytes(f)
        report['fixtures'][name] = {'path': str(p), 'sha256': hashlib.sha256(f).hexdigest(), 'baseline_fixed_bytes_equal': True}


def run(name, label, block):
    condition, version = label.rsplit('_', 1)
    caller = 'mixed'
    m.executables[caller][version]['path'] = assignments[block][label]
    m.fixture = {'paths': {'fixed': report['fixtures'][name]['path']}}
    data = m.run(name, caller, version)
    data.update(actual_image=assignments[block][label], payload_sha256=images[label]['sha256'])
    return data


def analyze(data):
    rng = random.Random(10241801)
    def estimate(values):
        assert len(values) == rounds
        blocks = [statistics.median(values[i:i+8]) for i in range(0, rounds, 8)]
        boot = sorted(statistics.median(rng.choices(blocks, k=len(blocks))) for _ in range(20000))
        return {'paired_median_ratio': statistics.median(values), 'block_median_ratio': statistics.median(blocks),
                'bootstrap_95_percent': [m.core.percentile(boot, .025), m.core.percentile(boot, .975)], 'block_ratios': blocks}
    for name, cell in data['cases'].items():
        rows = cell['measurements']
        ratios = {caller: [sum(x[caller+'_fixed']['full_seconds'])/sum(x[caller+'_baseline']['full_seconds']) for x in rows]
                  for caller in ['original', 'ordered']}
        variants = {}
        for label in labels:
            variants[label] = {}
            for metric in ['open_seconds', 'metadata_seconds', 'plan_seconds', 'first_row_seconds', 'first_decoded_row_seconds', 'full_seconds']:
                values = [v for x in rows for v in x[label][metric] if v is not None]
                variants[label][metric] = {'p50': statistics.median(values), 'p95': m.core.percentile(values, .95)}
            times = [v for x in rows for v in x[label]['full_seconds']]
            variants[label]['decoded_rows_per_second'] = statistics.median(rows[0][label]['rows_per_query']/v for v in times)
            variants[label]['median_peak_process_working_set_bytes'] = statistics.median(x[label]['peak_process_working_set_bytes'] for x in rows)
        cell['summary'] = {'callers': {c: estimate(v) for c, v in ratios.items()},
                           'primary_interaction': estimate([a/b for a, b in zip(ratios['original'], ratios['ordered'])]),
                           'variants': variants}
    data['completed_at'] = datetime.now(timezone.utc).isoformat()
    return data


def main():
    target = here/'order-intervention-results.json'
    if '--analyze-only' in sys.argv:
        result = analyze(json.loads(target.read_text()))
    else:
        assert not target.exists(), 'Do not overwrite measured data.'
        copy_block(0)
        prepare_fixtures()
        if '--smoke' in sys.argv:
            for name in cases:
                for label in labels:
                    d = run(name, label, 0)
                    print(json.dumps({'case': name, 'image': label, 'rows': d['rows_per_query'], 'PASS': True}), flush=True)
            return
        (here/'order-intervention-plan.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
        for r in range(rounds):
            if r % 8 == 0:
                copy_block(r//8)
                for name in cases:
                    for _ in range(2):
                        for label in labels:
                            run(name, label, r//8)
            for name in m.order(r, list(cases)):
                report['cases'][name]['measurements'].append({label: run(name, label, r//8) for label in m.order(r, labels)})
            if (r+1) % 8 == 0:
                target.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
                print('Order-intervention matched rounds:', r+1, flush=True)
        result = analyze(report)
    target.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({n: x['summary'] for n, x in result['cases'].items()}, indent=2), flush=True)


if __name__ == '__main__':
    main()

#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2
validation_root="$task_root/work/issue-02/validation"
evidence_root="$validation_root/ci-asan-test-lifetime"
task_cmake="$task_root/work/wsl-tools/cmake/data/bin/cmake"
"$task_cmake" -S "$task_root/work/issue-02/fix-repo/cpp" -B "$evidence_root/linux-debug-asan" \
  -DCMAKE_BUILD_TYPE=Debug -DENABLE_ASAN=ON \
  -DTSFILE_BUILD_SHARED=OFF -DBUILD_TEST=ON -DBUILD_TOOLS=OFF \
  -DENABLE_ANTLR4=OFF -DENABLE_SIMD=OFF -DENABLE_THREADS=ON \
  -DENABLE_SNAPPY=ON -DENABLE_LZ4=ON -DENABLE_LZOKAY=ON \
  -DENABLE_ZLIB=ON -DENABLE_ZSTD=ON -DENABLE_LZMA2=ON \
  -DTSFILE_DEPENDENCY_CACHE="$task_root/work/issue-01/validation/linux-coverage/dependency-cache" \
  > "$evidence_root/full-configure.log" 2>&1
"$task_cmake" --build "$evidence_root/linux-debug-asan" --target TsFile_Test --parallel 6 \
  > "$evidence_root/full-build.log" 2>&1
cd "$evidence_root"
export TSFILE_COMPAT_GENERATE_DIR="$validation_root/native-cpp-fixtures"
export TSFILE_COMPAT_VALIDATE_DIR="$validation_root/native-java-fixtures"
export ASAN_OPTIONS=detect_leaks=1
./linux-debug-asan/test/lib/TsFile_Test --gtest_output=xml:linux-debug-asan.xml \
  > linux-debug-asan.log 2>&1
tail -n 14 linux-debug-asan.log

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parent
validation = root.parent
base = root.parents[3]
repo = validation.parent / 'fix-repo'
before_head = '1e8d230805d5823f1e0cd7a82af4e815510080e0'
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()
assert git('rev-parse', 'HEAD') == before_head
assert git('diff', '--name-only') == 'cpp/test/encoding/encoding_props_test.cc'
assert '424 byte(s) leaked in 32 allocation(s)' in (root/'before.log').read_text()
for name in ['after', 'linux-debug-asan', 'windows-all-tests']:
    xml = ET.parse(root/f'{name}.xml').getroot()
    assert int(xml.attrib['failures']) == 0 and int(xml.attrib.get('errors', 0)) == 0
    assert 'ERROR: LeakSanitizer' not in (root/f'{name}.log').read_text(encoding='utf-8',errors='replace')
assert 'BUILD SUCCESS' in (root/'format-check.log').read_text()
old = json.loads((validation/'review-reserved-precision/final-source-fingerprints.json').read_text())
for name, digest in old['source'].items():
    if name.startswith('cpp/src/'):
        assert hashlib.sha256((repo/name).read_bytes()).hexdigest() == digest
for name, digest in old['artifacts'].items():
    assert hashlib.sha256((validation/name).read_bytes()).hexdigest() == digest
shutil.copyfile(repo/'cpp/test/encoding/encoding_props_test.cc',root/'after_encoding_props_test.cc')
subprocess.run(['git','-C',str(repo),'diff','--check'],check=True)
(root/'test-lifetime.diff').write_text(git('diff')+'\n')
results={}
for name in ['before','after','linux-debug-asan','windows-all-tests']:
    xml = ET.parse(root/f'{name}.xml').getroot()
    results[name]={k:int(xml.attrib.get(k,0)) for k in ['tests','failures','errors','disabled']}
    results[name]['skipped']=len(xml.findall('.//testcase/skipped'))
    results[name]['passed']=results[name]['tests']-results[name]['disabled']-results[name]['skipped']-results[name]['failures']-results[name]['errors']
summary={'validated_at':datetime.now(timezone.utc).isoformat(),'production_reference_head':before_head,
         'scope':'Test-only lifetime correction; production sources and prior measured artifacts SHA-256 identical',
         'results':results,'before_lsan_leaked_bytes':424,'before_lsan_allocations':32,
         'after_asan_exit_code':0,'production_hashes':{k:v for k,v in old['source'].items() if k.startswith('cpp/src/')},
         'prior_artifact_hashes':old['artifacts'],'gates_passed':True,
         'inherited_coverage':'97/97 changed production executable lines; 180/402 corresponding branches (44.78%)',
         'inherited_compatibility_and_performance':'See immutable validation at evidence commit 53a84d4ea12598d32ea202e32db5313c5b2bbf04; unchanged sources and artifacts verified; benchmarks not rerun for test-only changes.'}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
report='''# PR #1024: sanitizer test lifetime correction

The Ubuntu Debug/Release ASan jobs on `1e8d230805d5823f1e0cd7a82af4e815510080e0` reported the same **424 bytes in 32 allocations** in `EncodingProps.ZeroOnlyPagesEscapeReservedPrecisionMarkers`. The functional assertions passed; LeakSanitizer failed the process at exit.

The test allocated a floating-point decoder through `DecoderFactory` and then used `DecoderFactory::free`, which only calls `common::mem_free`. It does not invoke the virtual destructor. The decoder's page bitmap vectors consequently lost their allocations. The fixture now constructs FLOAT and DOUBLE decoders on the stack and selects a non-owning base pointer. Both destructors run at scope exit, including on fatal assertion returns. The factory allocation/null check and matching raw free are removed from this test. No production file or wire behavior changes.

## Validation

- A local GCC 11 AddressSanitizer build of the original seven encoding tests reproduces the exact 424-byte / 32-allocation leak and exits 1. Its seven functional tests pass, illustrating why assertion-only runs missed the problem.
- The changed seven-test build exits 0 with `ASAN_OPTIONS=detect_leaks=1` and no ASan/LSan error.
- Full Linux Debug AddressSanitizer results: {linux}. All six optional codecs are enabled; ANTLR, tools and SIMD are disabled. The standalone reproduction instruments the test translation unit and inline codec code, while linking the previous non-ASan static library; the full run separately rebuilds the complete library and tests with ASan.
- Windows MSVC Release results: {windows}. Existing disabled/skipped tests remain recorded in XML.
- clang-format 17.0.6, repository Spotless check and `git diff --check` pass.

SHA-256 verifies every production file changed in this PR and every library/benchmark/compatibility artifact from the previous validation is identical. The existing Java bidirectional, raw-byte compatibility, 97/97 changed executable-line coverage (44.78% corresponding branches) and retained 125/25-pair performance results therefore still apply to the same production implementation. No new performance run is claimed for this test-only correction. The prior report's Java invalid zero-page and table-schema limitations remain unchanged.

Raw logs, test sources before/after, XML, exact patch and build scripts are included in the supplementary archive. Public CI job links:

- https://github.com/apache/tsfile/actions/runs/39058914012/job/117472630774
- https://github.com/apache/tsfile/actions/runs/39058914012/job/117472630753

## 中文

两个 Ubuntu ASan 任务均由新测试遗漏 decoder 析构导致：`DecoderFactory::free` 只释放对象原始内存，不调用析构，因此页位图的 vector 分配泄漏了 424 字节，共 32 次。功能断言全部通过，但 LeakSanitizer 在进程退出时判定失败。测试现在在栈上构造两种 decoder，用基类指针选择当前类型；正常离开作用域及致命断言提前返回时均会析构。没有修改生产代码和文件格式。

本地保留了修改前相同泄漏及退出码 1 的证据；修改后的七项编码测试在启用泄漏检测时退出码为 0。Linux 全量重建为 Debug ASan，并启用六种可选压缩库；Windows Release 全量也重新执行。详细计数见上文及 XML。生产源码与此前测量的库、性能及兼容性程序均逐个核对 SHA-256 一致，因此沿用之前完全相同生产实现的兼容性、覆盖率和性能证据；未声称为测试生命周期修改重跑了性能。Java 无效全零页和表 schema 的已知限制仍保留。

**AI disclosure:** The correction, reproduction and reported validation were prepared/performed by OpenAI Codex.

**AI 使用说明：** 本修正、复现及报告的验证由 OpenAI Codex 编写或执行。
'''
def count(name):
    r=results[name]
    return f"{r['passed']} passed / {r['skipped']} skipped / {r['disabled']} disabled"
report=report.replace('{linux}',count('linux-debug-asan')).replace('{windows}',count('windows-all-tests'))
(root/'validation-report.md').write_text(report,encoding='utf-8')
outputs=base/'outputs'
shutil.copyfile(root/'validation-report.md',outputs/'TsFile_PR_02_ASan测试生命周期修正报告.md')
archive=outputs/'TsFile_PR_02_ASan测试生命周期证据.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for file in sorted(root.iterdir()):
        if file.is_file() and file.suffix in ['.py','.sh','.md','.xml','.log','.cc','.json','.diff'] and file.name not in ['api-request.json','publication.json']:
            z.write(file,file.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'gates_passed':True,'results':results,'archive_bytes':archive.stat().st_size}))

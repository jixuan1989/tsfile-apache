#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2
validation_root="$task_root/work/issue-02/validation"
evidence_root="$validation_root/ci-asan-test-lifetime"
repo_root="$task_root/work/issue-02/fix-repo"
variant=${1:?before or after}
source="$evidence_root/before_encoding_props_test.cc"
if [ "$variant" = after ]; then
    source="$repo_root/cpp/test/encoding/encoding_props_test.cc"
fi
g++ -std=c++11 -g -O1 -fsanitize=address -fno-omit-frame-pointer \
    -DTSFILE_STATIC -DENABLE_MEM_STAT -DENABLE_THREADS \
    -I"$repo_root/cpp/src" \
    -I"$validation_root/linux-coverage-atomic/googletest-extract/googletest-release-1.12.1/googletest/include" \
    "$source" -o "$evidence_root/encoding_props_$variant" \
    -Wl,--start-group "$validation_root"/linux-coverage-atomic/lib/*.a \
    -Wl,--end-group -lgcov -pthread > "$evidence_root/build-$variant.log" 2>&1
cd "$evidence_root"
export GCOV_PREFIX="$evidence_root/profiling-$variant"
export ASAN_OPTIONS=detect_leaks=1
set +e
./encoding_props_"$variant" --gtest_filter=EncodingProps.* \
    --gtest_output=xml:"$variant.xml" > "$variant.log" 2>&1
result=$?
set -e
printf 'exit_code=%s\n' "$result"
tail -n 16 "$variant.log"
exit "$result"

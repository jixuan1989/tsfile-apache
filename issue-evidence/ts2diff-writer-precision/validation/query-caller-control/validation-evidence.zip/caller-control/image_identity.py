"""Exact-byte image copies in balanced neutral paths; diagnostic crossover."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import random
import statistics
import sys
import matched_callers as m

here=Path(__file__).resolve().parent
rounds=192
labels=m.labels
conditions=['original_path','neutral_crossover']
cells=[(name,c) for name in m.cases for c in conditions]
original={v:dict(x) for v,x in m.executables['reader_only'].items()}
payloads={v:Path(x['path']).read_bytes() for v,x in original.items()}
clonedir=here/'neutral-images'
paths=[clonedir/f'n{i:03}.exe' for i in range(4)]
assignments=[]
for block in range(rounds//8):
    assignments.append({label:str(paths[(i+block)%4]) for i,label in enumerate(labels)})
for path in paths:
    counts=Counter(label.split('_')[0] for a in assignments for label,p in a.items() if p==str(path))
    assert counts=={'baseline':12,'fixed':12}
for values in [labels,cells]:
    balance={str(x):Counter() for x in values}
    for r in range(rounds):
        for i,x in enumerate(m.order(r,values)):balance[str(x)][i]+=1
    assert all(len(v)==len(values) and len(set(v.values()))==1 for v in balance.values())
report={'created_at':datetime.now(timezone.utc).isoformat(),
    'stage_selection':'Chosen after the completed matched-caller interaction intervals included 1 while both original callers showed upward signals. This is a new, separately fixed diagnostic protocol; it is not preregistered confirmation of the first stage.',
    'hypothesis':'Test whether the signal depends on original image path/backing identity: same original reader-only executable bytes copied to four neutral paths, with baseline/fixed assignments rotated every eight-round block. Static code/data bytes and RVAs are unchanged, but path, new backing allocation, ASLR choice and loader/cache history may change together. A change in ratio would not identify which mechanism causes it.',
    'stopping_rule':'Exactly 192 quartets for row/batch x original-path/neutral-crossover. No adaptive extension, outlier removal or acceptance-margin change.',
    'settings':m.report['settings'],'original_images':original,'block_path_assignments':assignments,
    'warmups':'Original paths: two per label/mode before measurement. Neutral copies: one per label/mode after each block copy, before the block. No queries overlap file replacement.',
    'primary_analysis':'For every round/mode, each condition uses six fixed-reader full-query times / six baseline-reader full-query times. Primary crossover interaction is neutral ratio / original ratio. 24 chronological blocks of eight balanced rounds; 20,000 bootstrap draws, median within block. Internal same-version repeat-label controls compare distinct neutral paths as assigned, so those are image-copy rather than same-path controls.',
    'cases':{name+'__'+condition:{'name':name,'condition':condition,'measurements':[]} for name,condition in cells}}

def run(name,condition,label,block):
    version=label.split('_')[0]
    path=original[version]['path'] if condition=='original_path' else assignments[block][label]
    m.executables['reader_only'][version]['path']=path
    d=m.run(name,'reader_only',label)
    d.update(actual_image_path=path,image_payload_sha256=original[version]['sha256'])
    return d

def prepare_block(block):
    clonedir.mkdir(exist_ok=True)
    for label,path in assignments[block].items():
        p=Path(path);assert p.parent.resolve()==clonedir.resolve()
        version=label.split('_')[0]
        p.write_bytes(payloads[version])
        assert hashlib.sha256(p.read_bytes()).hexdigest()==original[version]['sha256']
    for name in m.cases:
        for label in labels:run(name,'neutral_crossover',label,block)

def analyze(d):
    rng=random.Random(1024072802)
    def estimate(values):
        assert len(values)==rounds
        blocks=[statistics.median(values[i:i+8]) for i in range(0,rounds,8)]
        boot=sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(20000))
        return {'paired_median_ratio':statistics.median(values),'block_median_ratio':statistics.median(blocks),
            'bootstrap_95_percent':[m.core.percentile(boot,.025),m.core.percentile(boot,.975)],'block_ratios':blocks}
    interactions={}
    for name in m.cases:
        ratios={}
        for condition in conditions:
            cell=d['cases'][name+'__'+condition];rows=cell['measurements'];assert len(rows)==rounds
            values=[sum(sum(x['fixed_'+i]['full_seconds']) for i in ['1','2'])/
                    sum(sum(x['baseline_'+i]['full_seconds']) for i in ['1','2']) for x in rows]
            ratios[condition]=values
            cell['summary']={'fixed_over_baseline_full':estimate(values),
                'same_version_repeat_labels':{v:estimate([sum(x[v+'_2']['full_seconds'])/sum(x[v+'_1']['full_seconds']) for x in rows]) for v in ['baseline','fixed']}}
        interactions[name]=estimate([a/b for a,b in zip(ratios['neutral_crossover'],ratios['original_path'])])
    d['primary_image_identity_interaction']=interactions;d['completed_at']=datetime.now(timezone.utc).isoformat()
    return d

def main():
    path=here/'image-identity-results.json'
    if '--analyze-only' in sys.argv:
        result=analyze(json.loads(path.read_text()))
    else:
        assert not path.exists(),'Refuse to overwrite measured data.'
        (here/'image-identity-plan.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        for name in m.cases:
            for _ in range(2):
                for label in labels:run(name,'original_path',label,0)
        for r in range(rounds):
            if r%8==0:prepare_block(r//8)
            for name,condition in m.order(r,cells):
                report['cases'][name+'__'+condition]['measurements'].append({label:run(name,condition,label,r//8) for label in m.order(r,labels)})
            if (r+1)%8==0:
                path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
                print('Image-identity quartets/cell:',r+1,flush=True)
        result=analyze(report)
    path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'interaction':result['primary_image_identity_interaction'],
        'conditions':{k:v['summary'] for k,v in result['cases'].items()}},indent=2),flush=True)
if __name__=='__main__':main()

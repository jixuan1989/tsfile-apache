from datetime import datetime, timezone
from pathlib import Path
from urllib.request import urlopen
import base64
import hashlib
import json
import os
import subprocess
import time
import zipfile

here=Path(__file__).resolve().parent
base=here.parents[2]
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
item=next(x for x in state['drafts'] if x['id']=='02')
summary=json.loads((here/'summary.json').read_text())
assert item['head_commit']==summary['source_head'] and item['pr_number']==summary['pr_number']
footer=state['workflow']['ai_disclosure']['pr_footer']
env=os.environ.copy();env['GODEBUG']='http2client=0'
record_path=here/'publication.json'
record=json.loads(record_path.read_text()) if record_path.exists() else {}
def save():record_path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def api(path,payload=None,method='POST'):
    args=['C:/Program Files/GitHub CLI/gh.exe','api',path]
    data=None
    if payload is not None:args+=['--method',method,'--input','-'];data=json.dumps(payload,ensure_ascii=False)
    for attempt in range(4 if payload is None else 1):
        p=subprocess.run(args,input=data,capture_output=True,text=True,encoding='utf-8',env=env,timeout=120)
        if not p.returncode:return json.loads(p.stdout)
        if attempt==3 or payload is not None:raise RuntimeError(p.stderr)
        time.sleep(2)
assert api('user')['login']==state['github_login']
n=item['pr_number'];upstream=state['upstream'];fork=state['fork'];branch=item['evidence_branch']
before=api(f'repos/{upstream}/pulls/{n}')
assert before['state']=='open' and not before['merged'] and before['head']['sha']==item['head_commit']
assets={'validation-report.md':base/'outputs/TsFile_PR_02_调用程序对照报告.md',
        'validation-evidence.zip':base/'outputs/TsFile_PR_02_调用程序对照证据.zip'}
assert assets['validation-report.md'].read_text(encoding='utf-8').strip().endswith(footer)
with zipfile.ZipFile(assets['validation-evidence.zip']) as z:
    manifest=json.loads(z.read('evidence-manifest.json'))
    assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items())
    assert z.read('validation-report.md')==assets['validation-report.md'].read_bytes()
hashes={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in assets.items()}
assert not record.get('asset_hashes') or record['asset_hashes']==hashes
record['asset_hashes']=hashes
prefix='issue-evidence/ts2diff-writer-precision/validation/query-caller-control'
if not record.get('evidence_commit'):
    parent=api(f'repos/{fork}/git/ref/heads/{branch}')['object']['sha']
    original=api(f'repos/{fork}/git/commits/{parent}')
    entries=[]
    for name,p in assets.items():
        blob=api(f'repos/{fork}/git/blobs',{'encoding':'base64','content':base64.b64encode(p.read_bytes()).decode('ascii')})
        entries.append({'path':f'{prefix}/{name}','mode':'100644','type':'blob','sha':blob['sha']})
    tree=api(f'repos/{fork}/git/trees',{'base_tree':original['tree']['sha'],'tree':entries})
    commit=api(f'repos/{fork}/git/commits',{'message':f'Record matched caller and image controls for TsFile #{n}',
        'tree':tree['sha'],'parents':[parent]})
    record.update(evidence_commit=commit['sha'],parent_commit=parent);save()
if not record.get('ref_updated'):
    remote=api(f'repos/{fork}/git/ref/heads/{branch}')['object']['sha']
    assert remote in [record['parent_commit'],record['evidence_commit']]
    if remote!=record['evidence_commit']:api(f'repos/{fork}/git/refs/heads/{branch}',{'sha':record['evidence_commit'],'force':False},'PATCH')
    record['ref_updated']=True;save()
urls={}
for name in assets:
    url=f'https://raw.githubusercontent.com/{fork}/{record["evidence_commit"]}/{prefix}/{name}'
    for attempt in range(4):
        try:
            with urlopen(url,timeout=60) as response:data=response.read()
            assert hashlib.sha256(data).hexdigest()==hashes[name]
            break
        except Exception:
            if attempt==3:raise
            time.sleep(2)
    urls[name]=url
report_url=f'https://github.com/{fork}/blob/{record["evidence_commit"]}/{prefix}/validation-report.md'
full=summary['counterbalanced_matrix']
gate_en='The corrected, counterbalanced comparison passes the unchanged confirmation rule for the 32 measured scenarios.' if summary['query_gate_cleared'] else 'The corrected comparison still has unresolved confirmation signals, so the query gate remains uncleared.'
gate_zh='纠正后的身份均衡比较在 32 个测量场景中通过原有复查规则。' if summary['query_gate_cleared'] else '纠正后的比较仍有未解决的复查信号，查询门槛未通过。'
remaining_effects='; '.join(f'`{name}` {(d["block_median_latency_ratio"]-1)*100:+.2f}%' for name,d in full['remaining_end_to_end_effects'].items()) or 'none'
def fmt(d):
    a,b=d['bootstrap_95_percent'];return f'{d["block_median_ratio"]:.5f} [{a:.5f}, {b:.5f}]'
def short(name):return 'row' if '_row_' in name else 'batch'
caller_rows=[];image_rows=[]
for name,v in summary['primary_caller_interaction'].items():
    a=summary['caller_ratios'][name+'__mixed'];b=summary['caller_ratios'][name+'__reader_only']
    caller_rows.append(f'| {short(name)} | {fmt(a)} | {fmt(b)} | {fmt(v)} |')
for name,v in summary['image_identity_control']['primary_interaction'].items():
    a=summary['image_identity_control']['condition_ratios'][name+'__original_path']
    b=summary['image_identity_control']['condition_ratios'][name+'__neutral_crossover']
    image_rows.append(f'| {short(name)} | {fmt(a)} | {fmt(b)} | {fmt(v)} |')
caller_table='| Mode | Mixed F/B | Reader-only F/B | Paired mixed/reader-only interaction |\n|---|---|---|---|\n'+'\n'.join(caller_rows)
image_table='| Mode | Original-path F/B | Neutral-copy F/B | Paired neutral/original interaction |\n|---|---|---|---|\n'+'\n'.join(image_rows)
en=f'''### Matched caller and image controls (2026-10-18)

Two separately fixed diagnostic stages each run four cells × 192 balanced quartets, three complete verified queries/child: 6,144 measured processes and 18,432 queries total. First, original mixed versus single-object reader-only callers use the identical suspended-launch/affinity/file/query protocol. Both caller-interaction intervals include one while reader-only also shows upward latency ratios; this does not support blaming only the mixed caller, nor prove caller equivalence. Ratios below are block medians with 95% block-bootstrap intervals; all raw samples and internal repeat-label controls are retained.

{caller_table}

After those results, the second stage records a new plan: exact reader-only binary bytes are copied to four neutral paths, with baseline/fixed assignments rotated every eight-round block and SHA-256 checked. Each neutral path carries each version equally. Warmup occurs after copying, before timed queries. This changes image identity/loading context without patching static code/data/RVAs, but path, backing allocation, loader/cache history and possible ASLR choices change together. Loaded bases and physical/cache hardware counters are unmeasured; the interaction is diagnostic, not proof of a filename-only cause.

{image_table}

The original-path reader-only ratios are about +0.75–0.78%, while exact-byte neutral copies are near zero with intervals including one; both image-identity interactions are below one. Thus the loading/file-identity context measurably affects the comparison without a code patch. The concrete repair is to counterbalance identities in the benchmark, rather than introduce a numeric margin or alter production padding. The full original 32-case corpus is remeasured at 64 quartets/case, balancing reader versions and writer products across neutral image/data paths. Each initially signaled case gets one independent 192-quartet confirmation under the unchanged rule (paired median CI above1, median >1.03 or descriptive p95 >1.10). There are {full['confirmation_cases']} such confirmations; remaining signals: `{json.dumps(full['remaining_confirmation_flags'])}`.

**{gate_en}** Remaining end-to-end block-median effects: {remaining_effects}. The image-identity correction is not a complete explanation for remaining repeated mixed-caller signals. This is measured-scope evidence under corrected comparable conditions, not a claim that every original image identity has zero latency difference. The original fixed-identity effect and all contradictory sessions remain published. Open/cached schema, first row, full latency/throughput, p50/p95 and whole-process peak memory are reported; cache is warm and P99/formal tail non-inferiority unmeasured. Original map sidecars preserve `.text`/`.pdata`, with `.rdata` differences only at debug timestamps. Production source and binary hashes remain unchanged; Java/coverage/write evidence retains its scope. [Caller/image and corrected matrix report]({report_url}) · [Plans, complete arrays, actual products, maps and reproduction]({urls['validation-evidence.zip']})
'''
zh=f'''### 同协议调用程序与映像交叉对照（2026-10-18）

两个阶段分别事先固定四组 × 192 轮均衡四标签、每进程完整核验三次查询，共 6,144 个计时进程、18,432 次查询。第一阶段统一恢复执行前绑核、相同亲和性/文件/查询协议，对比原混合程序与单一编译对象的独立 reader。两项调用程序交互区间均包含 1，独立 reader 也有延迟上升，因此未支持“仅混合程序受影响”，也不能证明调用程序完全等效。上方第一表列出区块中位数和 95% 区块 bootstrap 区间，全部样本与重复标签负对照保留。

得到第一阶段结果后，另行固定第二阶段计划：四个中性路径轮换放入字节完全相同的两版原 reader-only 程序，每 8 轮更换分配，每条路径均等承载两版；副本核验 SHA-256，复制后单独预热再计时。静态指令/数据/RVA 不改，但映像文件背景、加载/缓存历史及可能的 ASLR 位置会一起变化，基址/物理映射/缓存硬件计数器未测，不能只归因于文件名。上方第二表保留全部主比较，详情见报告。

原路径的独立 reader 约慢 0.75%–0.78%，字节完全相同的中性副本接近零且区间包含 1，两项身份交互都小于 1，因此不改代码也能测到加载/文件身份背景的影响。具体修复在基准比较方法：平衡程序/数据路径上的两版 reader 与真实 writer 产物分配，不引入数值容忍阈值或修改 padding。完整原有 32 场景各测 64 轮，沿用区间完全大于1、中位数>1.03或描述性p95比>1.10的触发规则，对初测触发的 {full['confirmation_cases']} 个场景各独立复查192轮；剩余信号为 `{json.dumps(full['remaining_confirmation_flags'])}`。

**{gate_zh}** 剩余端到端区块中位数效应为 {remaining_effects}；映像身份纠正还不能完整解释这些重复出现的混合程序信号。这只适用于纠正后的可比条件，并不声称所有原固定映像身份都没有延迟差异，旧效应及反向轮次保留。打开/缓存schema/首行/完整延迟与吞吐、p50/p95及进程峰值内存均报告，冷缓存/P99/正式尾延迟非劣性未测。旁路地址映射保持原始指令/异常信息，rdata只允许debug时间戳差异；生产源码和原程序哈希不变，既有Java兼容、覆盖率、写入证据沿用原范围。[调用程序/映像与纠正矩阵报告]({report_url}) · [计划、完整原始数据、真实产物、地址映射及复现]({urls['validation-evidence.zip']})
'''
body=before['body'].replace('\r\n','\n').strip();assert body.endswith(footer)
if summary['query_gate_cleared']:
    body=body.replace('**The query gate remains qualified and uncleared.**',
        '**At this diagnostic stage the query gate was qualified and uncleared; the later counterbalanced-corpus disposition below supersedes this status.**')
    body=body.replace('**查询门槛仍有保留，未标为通过。**',
        '**本诊断阶段的查询门槛有保留、未通过；当前结论以后文身份均衡完整矩阵为准。**')
marker='### Matched caller and image controls (2026-10-18)'
if marker not in body:
    assert '### 中文说明' in body
    body=body.replace('### 中文说明',en+'\n\n### 中文说明',1)
    body=body[:-len(footer)].rstrip()+'\n\n'+zh.strip()+'\n\n'+footer
else:assert en.strip() in body and zh.strip() in body
assert body.endswith(footer) and len(body.encode('utf-8'))<65536
(here/'github-proposed-pr-body.md').write_text(body,encoding='utf-8')
if body!=before['body'].replace('\r\n','\n').strip():api(f'repos/{upstream}/pulls/{n}',{'body':body},'PATCH')
verified=api(f'repos/{upstream}/pulls/{n}')
assert verified['head']['sha']==item['head_commit'] and verified['body'].replace('\r\n','\n').strip()==body
(here/'github-verified-pr.json').write_text(json.dumps(verified,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(base/'outputs/TsFile_PR_02_说明.md').write_text('# '+verified['title']+'\n\n'+body+'\n',encoding='utf-8')
record.update(report_url=report_url,evidence_url=urls['validation-evidence.zip'],verified=True,
              source_head=item['head_commit'],published_at=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({'report_url':report_url,'verified':True}),flush=True)

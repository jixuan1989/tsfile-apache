"""Counterbalance executable/data identities over the retained PR02 query corpus."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import random
import statistics
import sys
import matched_callers as m

here=Path(__file__).resolve().parent
root=here.parent
core=m.core
cases=core.plan['cases']['02']
labels=['baseline_baseline','fixed_baseline','baseline_fixed','fixed_fixed']
images={v:dict(x) for v,x in m.executables['mixed'].items()}
payloads={v:Path(x['path']).read_bytes() for v,x in images.items()}
image_dir=here/'matrix-images';file_dir=here/'matrix-files'
image_paths=[image_dir/f'e{i:03}.exe' for i in range(4)]
file_paths=[file_dir/f'f{i:03}.tsfile' for i in range(4)]
preexisting=here/'counterbalanced-matrix-initial.json'

def assignment(block):
    return {label:{'image':str(image_paths[(i+block)%4]),'file':str(file_paths[(i+block//2)%4])} for i,label in enumerate(labels)}
assignments=[assignment(b) for b in range(24)]
for count in [8,24]:
    for paths,field,part in [(image_paths,'image',0),(file_paths,'file',1)]:
        for path in paths:
            tally=Counter(label.split('_')[part] for a in assignments[:count] for label,x in a.items() if x[field]==str(path))
            assert tally['baseline']==tally['fixed']==count//2

def copy_block(case,block):
    image_dir.mkdir(exist_ok=True);file_dir.mkdir(exist_ok=True)
    fixture=core.plan['fixtures'][case['fixture_key']]
    data={v:Path(path).read_bytes() for v,path in fixture['paths'].items()}
    digests={v:hashlib.sha256(x).hexdigest() for v,x in data.items()}
    a=assignments[block]
    for label,paths in a.items():
        reader,writer=label.split('_');image=Path(paths['image']);file=Path(paths['file'])
        assert image.parent.resolve()==image_dir.resolve() and file.parent.resolve()==file_dir.resolve()
        image.write_bytes(payloads[reader]);file.write_bytes(data[writer])
        assert hashlib.sha256(image.read_bytes()).hexdigest()==images[reader]['sha256']
        assert hashlib.sha256(file.read_bytes()).hexdigest()==digests[writer]
    return digests

def run(case,label,block):
    c=case;reader,writer=label.split('_');paths=assignments[block][label]
    # Reuse the validated suspended-process launcher, while supplying this case's full options.
    # The native executable and result verifier remain unchanged.
    import _winapi,msvcrt,os,subprocess,ctypes
    from ctypes import wintypes
    args=[paths['image'],'read',paths['file'],c['layout'],c['kind'],str(c['precision']),str(c['sparse']),
          str(c['properties']),c['scenario'],str(c['width']),str(c['batch']),str(c['parallel']),'3']
    output=here/'matrix-child.log'
    with output.open('w+b') as out,open(os.devnull,'rb') as inp:
        for f in [out,inp]:os.set_handle_inheritable(msvcrt.get_osfhandle(f.fileno()),True)
        si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESTDHANDLES
        si.hStdInput=msvcrt.get_osfhandle(inp.fileno());si.hStdOutput=si.hStdError=msvcrt.get_osfhandle(out.fileno())
        hp,ht,pid,tid=_winapi.CreateProcess(args[0],subprocess.list2cmdline(args),None,None,True,
            subprocess.CREATE_NO_WINDOW|4,None,None,si)
        try:
            m.require(m.k.SetProcessAffinityMask(hp,12));allowed,system=ctypes.c_size_t(),ctypes.c_size_t()
            m.require(m.k.GetProcessAffinityMask(hp,ctypes.byref(allowed),ctypes.byref(system)));assert allowed.value==12
            assert m.k.ResumeThread(ht)==1
            assert _winapi.WaitForSingleObject(hp,30000)==0
            code=_winapi.GetExitCodeProcess(hp)
        finally:_winapi.CloseHandle(ht);_winapi.CloseHandle(hp)
    text=output.read_text(encoding='utf-8');assert code==0,text
    d=json.loads([x for x in text.splitlines() if x.startswith('{')][-1])
    for name,value in core.expected(c).items():assert d[name]==value,(name,d[name],value)
    if c['scenario']=='app0':assert all(x is None for x in d['first_row_seconds'])
    d.update(actual_image=paths['image'],actual_file=paths['file'],affinity_mask=12)
    return d

contrasts={'reader_on_baseline_file':('fixed_baseline','baseline_baseline'),
           'reader_on_fixed_file':('fixed_fixed','baseline_fixed'),
           'writer_products_fixed_reader':('fixed_fixed','fixed_baseline'),
           'end_to_end':('fixed_fixed','baseline_baseline')}
def summarize(rows):
    rng=random.Random(1024072803);result={};signals=[]
    for name,(after,before) in contrasts.items():
        ratios=[sum(x[after]['full_seconds'])/sum(x[before]['full_seconds']) for x in rows]
        blocks=[statistics.median(ratios[i:i+8]) for i in range(0,len(rows),8)]
        boot=sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(20000))
        ci=[core.percentile(boot,.025),core.percentile(boot,.975)]
        p95=core.percentile([v for x in rows for v in x[after]['full_seconds']],.95)/core.percentile([v for x in rows for v in x[before]['full_seconds']],.95)
        ratio=statistics.median(ratios)
        result[name]={'paired_median_latency_ratio':ratio,'block_median_latency_ratio':statistics.median(blocks),
            'bootstrap_95_percent':ci,'descriptive_query_p95_ratio':p95,'block_ratios':blocks}
        if ci[0]>1 or ratio>1.03 or p95>1.10:signals.append(name)
    return {'contrasts':result,'confirmation_signals':signals}

def measure_case(case,rounds):
    assert rounds in [64,192]
    positions={label:Counter() for label in labels}
    for r in range(rounds):
        for i,label in enumerate(m.order(r,labels)):positions[label][i]+=1
    assert all(len(v)==4 and len(set(v.values()))==1 for v in positions.values())
    record={'case':case,'measurements':[],'file_sha256':{},'rounds':rounds}
    for r in range(rounds):
        if r%8==0:
            record['file_sha256']=copy_block(case,r//8)
            for _ in range(2):
                for label in labels:run(case,label,r//8)
        record['measurements'].append({label:run(case,label,r//8) for label in m.order(r,labels)})
    record['summary']=summarize(record['measurements'])
    return record

plan={'created_at':datetime.now(timezone.utc).isoformat(),
    'hypothesis':'Original image identity/loading context measurably changed ratios despite identical static bytes. Correct the full PR02 query harness by counterbalancing image and data-file identities rather than patching production layout or relaxing the regression rule.',
    'settings':'Same 32 retained mixed-caller scenarios, old unchanged binaries and Java-verified writer products, affinity12 before initial-thread resume, pool2, original parallel setting, three complete checked queries/child, warmed filesystem cache. Every block copies exact image/data bytes into private neutral paths and performs two warmups/label before timing.',
    'identity_assignments':assignments,
    'balance':'Over eight or 24 blocks, every image path carries each reader version equally; every data path carries each writer product equally. Label positions are equal. Joint path interactions are not fully factorial or separately estimated.',
    'initial_rounds_per_case':64,'confirmation_rounds_per_signaled_case':192,
    'trigger_policy_unchanged':'Any paired median bootstrap interval wholly above1, paired median >1.03, or descriptive p95 ratio >1.10 triggers one independent confirmation. CI resamples eight or24 chronological blocks of eight balanced quartets,20k draws. Preserve every sample. P95 remains descriptive.',
    'stopping_rule':'Measure all32 initial cases once. Independently confirm each initially signaled case once,192 quartets. No further adaptive re-runs; unresolved confirmed increases retain uncleared gate.',
    'source_head':m.manifest['sources']['02']['head'],'images':images,'cases':cases}

def main():
    if '--analyze-only' in sys.argv:
        for phase in ['initial','confirmation']:
            p=here/f'counterbalanced-matrix-{phase}.json'
            if p.exists():
                d=json.loads(p.read_text())
                for v in d['cases'].values():v['summary']=summarize(v['measurements'])
                p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
        return
    assert not preexisting.exists(),'Refuse to overwrite measured run.'
    (here/'counterbalanced-matrix-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
    report={'created_at':plan['created_at'],'cases':{}}
    for case in cases:
        print('Initial',case['name'],flush=True)
        d=measure_case(case,64);report['cases'][case['name']]=d
        preexisting.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print('Initial signals',case['name'],json.dumps(d['summary']['confirmation_signals']),flush=True)
    report['completed_at']=datetime.now(timezone.utc).isoformat()
    preexisting.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    selected=[v['case'] for v in report['cases'].values() if v['summary']['confirmation_signals']]
    confirmation={'created_at':datetime.now(timezone.utc).isoformat(),'cases':{},'selected_names':[x['name'] for x in selected]}
    target=here/'counterbalanced-matrix-confirmation.json'
    for case in selected:
        print('Confirmation',case['name'],flush=True)
        d=measure_case(case,192);confirmation['cases'][case['name']]=d
        target.write_text(json.dumps(confirmation,indent=2)+'\n',encoding='utf-8')
        print('Confirmation signals',case['name'],json.dumps(d['summary']['confirmation_signals']),flush=True)
    confirmation['completed_at']=datetime.now(timezone.utc).isoformat()
    target.write_text(json.dumps(confirmation,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'initial_cases':32,'confirmation_cases':len(selected),
        'confirmed_remaining_signals':{k:v['summary']['confirmation_signals'] for k,v in confirmation['cases'].items()}},indent=2),flush=True)
if __name__=='__main__':main()

"""Describe linked locations from map-only sidecars; do not infer cache causality."""
from pathlib import Path
import hashlib
import json
import re
import struct

here=Path(__file__).resolve().parent
root=here.parent

def pe(path):
    d=path.read_bytes();h=struct.unpack_from('<I',d,60)[0]
    count=struct.unpack_from('<H',d,h+6)[0];optional=struct.unpack_from('<H',d,h+20)[0]
    debug_rva,debug_size=struct.unpack_from('<II',d,h+24+112+6*8)
    result={'debug_time_bytes':{debug_rva+i+4+j for i in range(0,debug_size,28) for j in range(4)}}
    for i in range(count):
        at=h+24+optional+40*i;name=d[at:at+8].split(b'\0')[0].decode('ascii')
        size_virtual,rva,size,raw=struct.unpack_from('<IIII',d,at+8)
        result[name]={'rva':rva,'data':d[raw:raw+size]}
    return result

report={'method':'Sidecar links reuse the exact measured mixed caller objects or the one reader-only object and pinned static libraries. Require .text/.pdata equality with original measured executables; .rdata may differ only at debug-directory timestamps. Compare exact linker-symbol locations and alignment; these are not cache/branch/retired-instruction measurements or a layout intervention.',
        'images':{},'selected_symbols':[]}
maps={}
for caller in ['mixed','reader_only']:
    maps[caller]={}
    report['images'][caller]={}
    for version in ['baseline','fixed']:
        path=root/(f'build/Release/query_02_{version}.exe' if caller=='mixed' else f'reader-only/build/Release/read_only_02_{version}.exe')
        old=pe(path);new=pe(here/f'build/Release/{caller}_{version}.exe')
        assert old['.text']==new['.text'] and old['.pdata']==new['.pdata']
        a,b=old['.rdata'],new['.rdata'];assert a['rva']==b['rva'] and len(a['data'])==len(b['data'])
        diffs={a['rva']+i for i,(x,y) in enumerate(zip(a['data'],b['data'])) if x!=y}
        assert diffs <= old['debug_time_bytes'] & new['debug_time_bytes']
        report['images'][caller][version]={'original_binary_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'text_bytes':len(old['.text']['data']),'text_sha256':hashlib.sha256(old['.text']['data']).hexdigest(),
            'sidecar_text_and_pdata_exact':True,'rdata_diff_only_debug_timestamp':True}
        symbols={}
        for line in (here/f'build/{caller}_{version}.map').read_text().splitlines():
            m=re.match(r'\s+([0-9A-Fa-f]{4}):[0-9A-Fa-f]+\s+(\S+)\s+([0-9A-Fa-f]{16})\s',line)
            if m and m[1]=='0001':symbols[m[2]]=int(m[3],16)-0x140000000
        maps[caller][version]=symbols

selection=['?read_fixture@@','?cell@Verifier@@','?next@Verifier@@','?next@TableResultSet@',
           '?read_double@DoubleTS2DIFFDecoder@','?read_batch_double@DoubleTS2DIFFDecoder@',
           '?decode@DoubleTS2DIFFDecoder@','?mem_free@common@@']
all_symbols=set.intersection(*(set(maps[c][v]) for c in maps for v in maps[c]))
for name in sorted(all_symbols):
    if not any(name.startswith(prefix) for prefix in selection):continue
    row={'symbol':name,'locations':{}}
    for caller in maps:
        row['locations'][caller]={v:{'rva':hex(maps[caller][v][name]),'offset_mod_64':maps[caller][v][name]%64} for v in maps[caller]}
    report['selected_symbols'].append(row)
assert any(x['symbol'].startswith('?read_fixture@@') for x in report['selected_symbols'])
(here/'linked-layout.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))

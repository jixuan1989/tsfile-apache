from pathlib import Path
import hashlib
import json
import statistics
import sys
import zipfile

here=Path(__file__).resolve().parent
root=here.parent
base=root.parents[1]
sys.path.insert(0,str(root))
from benchmark import percentile
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
item=next(x for x in state['drafts'] if x['id']=='02')
data=json.loads((here/'matched-callers-results.json').read_text())
identity=json.loads((here/'image-identity-results.json').read_text())
matrix=json.loads((here/'counterbalanced-matrix-initial.json').read_text())
confirmation=json.loads((here/'counterbalanced-matrix-confirmation.json').read_text())
layout=json.loads((here/'linked-layout.json').read_text())
assert 'completed_at' in data and all(len(x['measurements'])==192 for x in data['cases'].values())
assert 'completed_at' in identity and all(len(x['measurements'])==192 for x in identity['cases'].values())
assert 'completed_at' in matrix and 'completed_at' in confirmation and len(matrix['cases'])==32
assert all(len(x['measurements'])==64 for x in matrix['cases'].values())
assert all(len(x['measurements'])==192 for x in confirmation['cases'].values())
selected={k for k,v in matrix['cases'].items() if v['summary']['confirmation_signals']}
assert selected==set(confirmation['cases'])==set(confirmation['selected_names'])
for group in [data,identity,matrix,confirmation]:
    for case in group['cases'].values():
        for row in case['measurements']:
            for child in row.values():
                assert child['repeats']==3
                for metric in ['open_seconds','metadata_seconds','plan_seconds','first_row_seconds','first_decoded_row_seconds','full_seconds']:
                    assert len(child[metric])==3
                assert all(x>0 for x in child['full_seconds'])
remaining={k:v['summary']['confirmation_signals'] for k,v in confirmation['cases'].items() if v['summary']['confirmation_signals']}
gate_passed=not remaining
original=json.loads((root/'tested-artifact-hashes.json').read_text(encoding='utf-8'))
for caller,versions in data['executables'].items():
    for version,artifact in versions.items():
        p=Path(artifact['path']);digest=hashlib.sha256(p.read_bytes()).hexdigest()
        assert digest==artifact['sha256']==original['files'][p.relative_to(base).as_posix()]['sha256']
assert hashlib.sha256(Path(data['settings']['file']).read_bytes()).hexdigest()==data['settings']['file_sha256']
checks={}
for topic,repo in [('01',Path(state['local_repository'])),('02',base/item['implementation']['source'])]:
    import subprocess
    head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
    clean=not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
    assert clean and head==original['sources'][topic]['head']
    checks[topic]={'head':head,'clean':True}
integrity={'tested_binaries_and_file_unchanged':True,'repositories':checks}
(here/'post-run-integrity.json').write_text(json.dumps(integrity,indent=2)+'\n',encoding='utf-8')

def fmt(x):
    lo,hi=x['bootstrap_95_percent'];return f'{x["block_median_ratio"]:.5f} [{lo:.5f}, {hi:.5f}]'
def short(name):return 'row' if '_row_' in name else 'batch'
interaction=data['primary_caller_interaction']
signals={short(name):'mixed_relative_cost_higher' if v['bootstrap_95_percent'][0]>1 else
         'mixed_relative_cost_lower' if v['bootstrap_95_percent'][1]<1 else 'interaction_interval_includes_one'
         for name,v in interaction.items()}
summary={'pr_number':item['pr_number'],'source_head':item['head_commit'],'query_gate_cleared':False,
    'production_unchanged':True,'cases':4,'quartets_per_case':192,'measured_processes':3072,
    'fully_checked_queries':9216,'primary_caller_interaction':interaction,'interpretation':signals,
    'caller_ratios':{k:v['summary']['fixed_over_baseline_full'] for k,v in data['cases'].items()},
    'next_boundary':'Caller feature/link contents change together; this diagnoses interaction but is not an intervention isolating code layout. Retain strict gate and all contradictory sessions.'}
summary['image_identity_control']={'cases':4,'quartets_per_case':192,'measured_processes':3072,
    'fully_checked_queries':9216,'primary_interaction':identity['primary_image_identity_interaction'],
    'condition_ratios':{k:v['summary']['fixed_over_baseline_full'] for k,v in identity['cases'].items()}}
summary['total_measured_processes']=6144;summary['total_fully_checked_queries']=18432
summary['counterbalanced_matrix']={'initial_cases':32,'initial_quartets_per_case':64,
    'confirmation_cases':len(selected),'confirmation_quartets_per_case':192,
    'initial_flags':{k:matrix['cases'][k]['summary']['confirmation_signals'] for k in selected},
    'remaining_confirmation_flags':remaining,'passed_for_measured_scope':gate_passed,
    'measured_processes':8192+len(selected)*768,'fully_checked_queries':24576+len(selected)*2304,
    'query_gate_status':'passed_corrected_counterbalanced_measured_scope' if gate_passed else 'uncleared_after_counterbalanced_confirmation',
    'no_regression_margin_introduced':True,'fixed_original_image_effect_retained':True,
    'scope_limit':'Balanced image/data-file identity comparison, not a claim of zero cost for every fixed executable identity, cold cache, workload or host.'}
summary['counterbalanced_matrix']['remaining_end_to_end_effects']={
    k:{field:value for field,value in confirmation['cases'][k]['summary']['contrasts']['end_to_end'].items()
       if field!='block_ratios'} for k in remaining}
summary['query_gate_cleared']=gate_passed
summary['total_measured_processes']+=8192+len(selected)*768
summary['total_fully_checked_queries']+=24576+len(selected)*2304
(here/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
text=f'''# TsFile PR #{item['pr_number']}: matched-protocol caller control

Baseline `1180b13675e11a0230708af2cc70d037e0e12623`; PR head `{item['head_commit']}`. All four measured original executable hashes, the Java-audited input file, and both production source checkouts match the retained backfill. No production or upstream source commit is made. The two diagnostic stages alone do not clear the query gate; the corrected full-matrix disposition is reported below. Earlier repeated slowdowns and opposite-direction runs remain intact.

## Question and fixed protocol

Earlier mixed-caller timing showed small dense DOUBLE slowdowns, while earlier reader-only controls changed both caller and CPU/protocol. This experiment compares the two original caller forms under the **same** launch, file, pinning, timing and query protocol. The mixed executable contains its writer path; the reader-only executable reuses one compiled reader object across the two libraries. Removing writer contents and fixing caller compilation change together, so this is not a pure layout intervention or proof of a source-level cause.

The plan is saved before measurement with a stopping rule of **192 complete process quartets in each of four cells**: row/batch × mixed/reader-only. Every child is created suspended, pinned to mask 12, checked, then resumed. Pool size 2, parallel read disabled, same fixed-produced precision-2 file in all children. The baseline/fixed precision-2 products are byte-identical. Mask 12 is two SMT siblings of one physical core. Filesystem cache is warmed; host background load/power/clock state are uncontrolled. Two warmups per label/cell precede measurement.

Each quartet contains two runs of each version, three complete queries per child. For each round/caller, the primary fixed/baseline ratio uses the **sum of six fixed queries / sum of six baseline queries**, keeping all repeats. The direct caller interaction is that round's mixed ratio / reader-only ratio. Its 95% bootstrap interval resamples 24 chronological blocks of eight complete, position-balanced rounds (20,000 draws; median within each block). Caller cells rotate/reverse across rounds, and all label/cell execution positions are asserted equal before sampling. This paired interaction is the primary test of caller dependence; it is not inferred by comparing separate significance labels.

All 3,072 measured child processes consume and validate 9,216 queries, each with 65,536 rows and four projected fields. Every value, NULL state, timestamp and row order is checked by the unchanged native driver; Python independently checks row counts/checksum. No result truncation/early exit is timed as a speedup. Each quartet's second/first same-version run supplies two internal same-binary controls. All samples are retained; no adaptive stopping, outlier removal or acceptance-margin change occurs.

## Primary caller interaction

Ratios are fixed/baseline within each caller. The interaction is mixed ratio / reader-only ratio; brackets are block-bootstrap 95% intervals. A positive interaction narrows the scope to caller/link context without identifying which constituent change is causal. A non-significant interaction does not prove equality.

| Mode | Mixed caller | Reader-only caller | Paired caller interaction |
|---|---|---|---|
'''
for name,v in interaction.items():
    a=data['cases'][name+'__mixed']['summary']['fixed_over_baseline_full']
    b=data['cases'][name+'__reader_only']['summary']['fixed_over_baseline_full']
    text+=f'| {short(name)} | {fmt(a)} | {fmt(b)} | {fmt(v)} |\n'
text+='''
## Internal negative controls and lifetime cycles

Same-binary controls compare the two repeat labels of the identical binary reading the same file; their intervals are not source-regression tests. Main-thread cycle ratios cover initialization, printing and exit in addition to the queries; they are not query-only CPU costs or retired instruction counts. No short-process OS CPU-time ratio is collected after the preceding experiment exposed zero-accounting granularity.

| Mode | Caller | Baseline repeat 2 / 1 | Fixed repeat 2 / 1 | Main-thread lifetime fixed / baseline cycles |
|---|---|---|---|---|
'''
for cell in data['cases'].values():
    v=cell['summary'];n=v['same_binary_repeat_controls']
    text+=f'| {short(cell["name"])} | {cell["caller"]} | {fmt(n["baseline"])} | {fmt(n["fixed"])} | {fmt(v["main_thread_lifetime_cycles_ratio"])} |\n'
text+='''
## Descriptive full-query latency

Each version/cell has 1,152 individual queries clustered within 384 child processes and 192 matched rounds. These p50/p95 values are descriptive distributions, not independent-tail non-inferiority guarantees. Raw open, cached schema lookup, plan, first decoded/accepted row, full-result times and process peak-memory measurements are retained; this report analyzes full latency and caller interaction rather than claiming a new complete metric matrix.

| Mode | Caller | Baseline / fixed full p50 (ms) | Baseline / fixed full p95 (ms) |
|---|---|---|---|
'''
for cell in data['cases'].values():
    times={version:[t for row in cell['measurements'] for label,value in row.items() if label.startswith(version+'_') for t in value['full_seconds']]
           for version in ['baseline','fixed']}
    assert all(len(v)==1152 for v in times.values())
    text+=f'| {short(cell["name"])} | {cell["caller"]} | {statistics.median(times["baseline"])*1e3:.4f} / {statistics.median(times["fixed"])*1e3:.4f} | {percentile(times["baseline"],.95)*1e3:.4f} / {percentile(times["fixed"],.95)*1e3:.4f} |\n'
text+='''
## Original linked locations

After the first-stage timings finish, map-only sidecars reuse the exact measured object files and pinned static libraries. Original `.text`/`.pdata` equality is checked, and `.rdata` differences must be only PE debug-directory timestamps. The following table records exact symbol locations and offsets modulo 64. These are layout observations, not cache-miss/branch hardware-counter measurements or proof that aligning a function would fix performance. The original binaries are not overwritten or retimed as sidecars.

| Symbol | Caller | Baseline RVA (mod 64) | Fixed RVA (mod 64) |
|---|---|---|---|
'''
image_section='''
## Follow-up: exact-byte image-identity crossover

This second-stage hypothesis was selected **after** the caller interaction was measured. The reader-only caller also shows upward ratios in the matched protocol, and both primary caller-interaction intervals include one; the first-stage results therefore do not support attributing the signal solely to the mixed executable. This is a new, separately fixed diagnostic plan, not a predeclared confirmatory test of the first stage.

The second stage uses the same original reader-only bytes and launch/query protocol, comparing original executable paths to four neutral file copies. Baseline/fixed content assignments rotate among the four neutral paths every eight-round block. Every neutral path carries each version for twelve blocks; label/cell execution positions are balanced. Each copied image is SHA-256 checked before its block; no instruction, static data byte, PE header or relative address is patched. Copies are warmed once per label/mode after each block replacement, before any timed child. Original paths have two initial warmups per label/mode. Additional warmups/copy preparation are outside each driver query timer.

There are four cells (row/batch × original/neutral) × 192 quartets, another 3,072 measured processes and 9,216 complete queries. Per-round neutral ratio / original ratio is the primary image-identity interaction, with 24 chronological blocks of eight and 20,000 bootstrap draws. Within-version repeat labels refer to distinct neutral copies in that condition; they are not same-path controls. Path, file backing allocation, loader/cache history and possible ASLR placement change together, so this cannot isolate a filename-only or code-layout cause. Loaded image bases, physical mapping, cache misses and hardware instruction counters were not measured.

| Mode | Original path fixed / baseline | Neutral crossover fixed / baseline | Paired image-identity interaction |
|---|---|---|---|
'''
for name,v in identity['primary_image_identity_interaction'].items():
    a=identity['cases'][name+'__original_path']['summary']['fixed_over_baseline_full']
    b=identity['cases'][name+'__neutral_crossover']['summary']['fixed_over_baseline_full']
    image_section+=f'| {short(name)} | {fmt(a)} | {fmt(b)} | {fmt(v)} |\n'
image_section+='''
| Mode | Condition | Baseline repeat 2 / 1 | Fixed repeat 2 / 1 |
|---|---|---|---|
'''
for cell in identity['cases'].values():
    n=cell['summary']['same_version_repeat_labels']
    image_section+=f'| {short(cell["name"])} | {cell["condition"]} | {fmt(n["baseline"])} | {fmt(n["fixed"])} |\n'
image_section+='''
All previous positive and opposite-direction observations remain intact. These two stages measure 6,144 child processes and 18,432 fully checked queries in total, plus separately described warmups. Neither an interaction interval containing one nor a changed point estimate establishes complete equivalence or authorizes clearing the strict query gate.

'''
text=text.replace('## Original linked locations\n',image_section+'## Original linked locations\n',1)
for row in layout['selected_symbols']:
    name=row['symbol'].split('@@')[0]
    for caller,versions in row['locations'].items():
        a,b=versions['baseline'],versions['fixed']
        text+=f'| `{name}` | {caller} | `{a["rva"]}` ({a["offset_mod_64"]}) | `{b["rva"]}` ({b["offset_mod_64"]}) |\n'
text+='''
## Scope and disposition

The tables report every primary comparison, internal negative control and original code-location check. They narrow or constrain caller dependence; they do not establish intrinsic reader-source overhead or demonstrate a production fix. Earlier same-binary launch controls, contradictory sessions, raw-object and normalized linked-instruction comparisons remain published. Strict no-regression status is not relaxed, and untested workloads are not silently cleared.

The first two stages are uncompressed, warm-cache, dense aligned DOUBLE full-scan diagnostics in a single SMT-core configuration. The later corrected matrix below separately remeasures the original FLOAT/non-aligned/NULL/filter/projection corpus. None of these stages retests writer throughput, compressed queries, cold cache, P99 or physical-core scaling. Earlier correctness/Java interoperability/coverage/write evidence keeps its original scope. No production coverage or sanitizer rerun is claimed for unchanged C++ artifacts. The Python launcher smoke checks both callers; the full run additionally validates every child result and all affinity operations.

The archive contains pre-sample plans, complete order/raw arrays, scripts, linker maps, code-location/integrity reports, pinned backfill metadata and actual input products. Build static libraries and original benchmark objects at the pinned base/head using the previous evidence; run `matched_callers.py --smoke`, then `matched_callers.py` once. Configure/build `CMakeLists.txt` in Release outside a timing run and run `compare_layout.py`. Paths are preserved for reproducibility and need adaptation on another machine. Measurement scripts refuse to overwrite existing runs; `--analyze-only` recomputes statistics without launching children. Generate the report only after all three stages below finish.

After the first-stage results, `image_identity.py` records its separate plan and creates/rotates four private image copies, then measures the second stage. `counterbalanced_matrix.py` subsequently records its own corrected full-corpus plan and runs the initial and any required independent confirmations. Finally run `prepare_report.py`. The evidence contains each plan, assignments, every raw child result and internal controls; executable copies need not be distributed because each is an exact hash-checked copy of an original measured binary.

## 中文说明

为减少旧实验中调用程序、CPU 与协议同时改变的混杂，本轮统一为恢复执行前绑核、相同亲和性 12、相同文件与查询计时。行/批 × 混合/独立 reader 共四组，每组固定 192 轮四标签、每个版本每轮两个进程、每进程三次完整查询。全部 3,072 个计时进程、9,216 次查询逐单元格核验完整结果；原二进制、输入文件哈希及源码目录状态均复核一致。两次预热与全部异常样本保留，未按结果延长采样或更改通过阈值。

主比较直接估计同一轮“混合程序前后比 / 独立 reader 前后比”，按 24 个连续时间块重采样，结果见上表。这样可以约束调用程序依赖性，但混合 writer 路径和统一编译对象等因素一起改变，仍不能单独确定链接布局因果关系。置信区间包含 1 也不能证明完全等价。每轮同一版本的两次运行作为内部负对照；主线程生命周期周期数包含启动/输出/退出，不是查询区间 CPU 或退休指令数。

链接地址映射在全部计时结束后生成，旁路程序的指令/异常信息与原计时程序相同，rdata 只允许 debug 构建时间戳不同；地址和模 64 偏移不等同于缓存计数器证据。旧的正向、反向结果与所有原始证据继续保留，**这两项诊断本身不清除门槛，完整矩阵结论另列**，不会通过修改 padding 或放宽标准得到通过结果。原 Java 兼容、覆盖率与写入性能证据沿用原范围；本轮没有生产代码修改或新的完整 sanitizer/覆盖率测试声明。

第一阶段两种调用程序的交互区间都包含 1，且独立 reader 也有延迟上升，因此未支持“只有混合程序受影响”的解释。得到该结果后，另行事先固定第二阶段计划：四个中性路径轮换放入两版原始 reader-only 二进制，每 8 轮更换分配，每个路径承载两版各 12 个区块；副本字节、静态地址均不修改，复制后核对 SHA-256 并单独预热。行/批 × 原路径/中性路径再测四组各 192 轮，同一轮的中性路径比 / 原路径比作为主交互。两阶段总计 6,144 个计时进程、18,432 次完整查询，另有明确列出的预热。

第二阶段同时改变文件路径、映像文件背景、加载/缓存历史和可能的 ASLR 位置；运行基址、物理映射及硬件缓存计数器未测，不能只归因于文件名。主结果与全部重复标签对照见上表，两阶段分开保留，不把第二阶段冒充第一阶段事先规定的确认实验；任何区间包含 1 也不等同于证明完全兼容或性能等价。
'''
def matrix_ratio(d):
    lo,hi=d['bootstrap_95_percent']
    return f'{d["block_median_latency_ratio"]:.5f} [{lo:.5f}, {hi:.5f}]'
matrix_section='''## Corrected full query corpus: counterbalanced identities

The exact-byte crossover demonstrates that image identity/loading context changes the ratio while static code/data/RVAs stay fixed. The concrete repair is in the **benchmark comparison protocol**, not production source: use private neutral executable/data paths and balance which version occupies each path. This corrects a demonstrated comparison confound without a numeric acceptance margin or production padding change. It does not identify whether path, backing pages, ASLR or another loader/cache mechanism supplies the effect.

The full original 32-case PR02 corpus is remeasured with the original mixed binaries and actual Java-audited baseline/fixed writer products. For every case, 64 position-balanced quartets are grouped in eight blocks; each block copies exact images/products to neutral paths and performs two warmups per label before timings. Each image path carries each reader version equally, and each data path carries each writer product equally. Joint path interactions are not fully factorial. Affinity 12 is applied before initial-thread resume, with the original pool, parallel flag, three complete checked queries/process and warm-cache conditions. Existing application FIELD references still consume/validate all native rows before applying their 0/1/50% reference filter; they do not imply native pushdown.

The **unchanged trigger rule** is: a paired-median 95% interval wholly above 1, paired median above 1.03, or descriptive p95 ratio above 1.10 triggers one independent 192-quartet confirmation. No additional adaptive re-runs are allowed. Intervals now resample entire eight-round identity blocks (eight initial blocks or 24 confirmation blocks), because samples sharing an identity assignment are dependent. Per-variant p50/p95 use 192 initial or 576 confirmation queries clustered by process/block; P99 and formal tail non-inferiority remain unmeasured. Earlier failures and all initial flags are retained.

| Scenario | Reader on baseline product | Reader on fixed product | Writer products, fixed reader | End-to-end | Initial signals |
|---|---|---|---|---|---|
'''
keys=['reader_on_baseline_file','reader_on_fixed_file','writer_products_fixed_reader','end_to_end']
for name,v in matrix['cases'].items():
    values=[matrix_ratio(v['summary']['contrasts'][k]) for k in keys]
    matrix_section+='| `'+name+'` | '+' | '.join(values)+' | '+(', '.join(v['summary']['confirmation_signals']) or 'none')+' |\n'
matrix_section+='\n### Independent confirmations\n\n'
if not selected:matrix_section+='No initial case triggered confirmation.\n'
else:
    matrix_section+='| Scenario | Contrast | Block-median ratio [95% CI] | Descriptive p95 ratio |\n|---|---|---|---|\n'
    for name,v in confirmation['cases'].items():
        for key,d in v['summary']['contrasts'].items():
            matrix_section+=f'| `{name}` | `{key}` | {matrix_ratio(d)} | {d["descriptive_query_p95_ratio"]:.5f} |\n'
matrix_section+='\n### Full-result descriptive metrics\n\n'
matrix_section+='| Scenario | Baseline / fixed full p50 (ms) | Baseline / fixed full p95 (ms) |\n|---|---|---|\n'
for name,v in matrix['cases'].items():
    times={label:[t for row in v['measurements'] for t in row[label]['full_seconds']] for label in ['baseline_baseline','fixed_fixed']}
    a,b=times['baseline_baseline'],times['fixed_fixed']
    assert len(a)==len(b)==192
    matrix_section+=f'| `{name}` | {statistics.median(a)*1e3:.4f} / {statistics.median(b)*1e3:.4f} | {percentile(a,.95)*1e3:.4f} / {percentile(b,.95)*1e3:.4f} |\n'
verdict='The corrected, identity-balanced comparison passes the unchanged signal/confirmation policy for these 32 measured scenarios.' if gate_passed else 'The corrected comparison still has unresolved confirmation signals; the query gate remains uncleared.'
matrix_section+='\n### Open, first row, throughput and memory\n\n'
matrix_section+='''Open includes native initialization; schema lookup may reuse metadata loaded by open. First accepted-row latency includes initialization/query setup and full row validation; app0 has no accepted first row. Throughput is computed from complete verified per-query latency (input and accepted rows separately). Peak working set is the whole native child process, not incremental query memory. These are descriptive baseline/fixed medians from end-to-end variants.

| Scenario | Open µs B/F | Cached schema µs B/F | First accepted µs B/F | Input rows/s B/F | Accepted rows/s B/F | Peak MiB B/F |
|---|---|---|---|---|---|---|
'''
for name,v in matrix['cases'].items():
    values={}
    for label in ['baseline_baseline','fixed_fixed']:
        children=[x[label] for x in v['measurements']]
        metrics={k:[z for d in children for z in d[k] if z is not None] for k in ['open_seconds','metadata_seconds','first_row_seconds']}
        values[label]={k:statistics.median(z)*1e6 if z else None for k,z in metrics.items()}
        values[label]['input_rate']=statistics.median(d['rows_per_query']/t for d in children for t in d['full_seconds'])
        values[label]['accepted_rate']=statistics.median(d['accepted_rows_per_query']/t for d in children for t in d['full_seconds'])
        values[label]['peak']=statistics.median(d['peak_process_working_set_bytes'] for d in children)/1048576
    a,b=values['baseline_baseline'],values['fixed_fixed']
    def pair(key,digits=2):
        return 'N/A (zero accepted)' if a[key] is None else f'{a[key]:.{digits}f} / {b[key]:.{digits}f}'
    matrix_section+=f'| `{name}` | {pair("open_seconds")} | {pair("metadata_seconds")} | {pair("first_row_seconds")} | {pair("input_rate",0)} | {pair("accepted_rate",0)} | {pair("peak")} |\n'
matrix_section+=f'''
**Disposition:** {verdict} There were {len(selected)} initial cases selected for independent confirmation; remaining confirmation signals: `{json.dumps(remaining)}`. This is a measured-scope disposition, not a promise that every original fixed image identity has zero latency change. Its observed approximately 0.75–0.78% context effect stays explicitly published. No production source fix or new Java/coverage/write benchmark is inferred from the protocol repair. All 22 existing PR02 writer products retain their Java audit and exact copied SHA-256; open/metadata/first-row/full-result/memory arrays are retained for every child. The previous write/correctness/coverage reports retain their scope and known Java-side boundary failures.

Cold cache, P99, native FIELD pushdown, sole/all-NULL projections, large metadata sets, physical-core scaling and compressed-query performance remain outside this corpus. The initial/confirmation results and fixed protocol are in `counterbalanced-matrix-*.json`; run `counterbalanced_matrix.py` only in a fresh result directory. It refuses to overwrite an initial run. `--analyze-only` recomputes statistics without new timing samples.

'''
text=text.replace('## 中文说明\n',matrix_section+'## 中文说明\n',1)
if remaining:
    effects=[]
    for name,value in summary['counterbalanced_matrix']['remaining_end_to_end_effects'].items():
        effects.append(f'`{name}`: {(value["block_median_latency_ratio"]-1)*100:+.2f}%')
    latest='**Latest controlled-confirmation disposition: query gate uncleared.** Remaining end-to-end block medians are '+ '; '.join(effects)+'. Image identity/loading context is a measured contributor, but correcting it does not fully explain or eliminate these repeated mixed-caller signals. No source fix is inferred or production padding changed.\n\n'
    text=text.replace('## Question and fixed protocol\n',latest+'## Question and fixed protocol\n',1)
zh_verdict='纠正后的身份均衡比较在本次 32 个场景中通过原有触发/复查规则' if gate_passed else '纠正后的比较仍有未解决的复查信号，查询门槛未通过'
text+=f'''
第三阶段修复的是已验证的**基准比较条件混杂**，没有修改 C++ 生产代码、padding 或数值容忍阈值：四个中性程序路径均等承载两版 reader，四个数据路径均等承载两版真实 writer 产物。完整 32 场景各测 64 轮（八个身份区块），每区块复制核验后每标签两次预热，再完整消费核对三次查询；身份与标签位置均衡，未估计全部路径高阶交互。整组置信区间按身份区块重采样，避免把共享路径分配的样本冒充独立观测。

沿用原有规则：配对中位数区间完全大于 1、中位数超过 1.03 或描述性 p95 比超过 1.10 时，独立复查该场景一次、192 轮；之后不再反复重跑求通过。本轮初测 {len(selected)} 个场景触发复查；剩余信号为 `{json.dumps(remaining)}`。**{zh_verdict}**，只适用于报告中的可比条件和场景，并不声称原固定映像身份的约 0.75%–0.78% 差异已从所有环境消失。该原始效应和所有相反方向结果仍公开保留，不把修复比较方法冒充源码修复或 Java/覆盖率/写入性能重测。

全部 22 个原 PR02 writer 文件的 Java 审计与复制 SHA-256 可追溯；每个计时子进程仍保留打开、schema、构建查询、首行、完整延迟与峰值内存数组。初测每版本/产物有 64 个进程、192 次查询，复查为 192 个进程、576 次查询，不能把它们当作全部独立样本。未测项继续列出，所有初测触发和异常样本保留。两项诊断加完整矩阵总计 {summary['total_measured_processes']} 个计时进程、{summary['total_fully_checked_queries']} 次完整查询，另有单列的预热。
'''
report_path=base/'outputs/TsFile_PR_02_调用程序对照报告.md'
report_path.write_text(text+'\n'+state['workflow']['ai_disclosure']['pr_footer']+'\n',encoding='utf-8')
files={}
for p in here.iterdir():
    if p.is_file() and p.suffix in {'.py','.txt','.json','.log'} and p.name not in ['publication.json','child.log','report-generation.log'] and not p.name.startswith('github-'):
        files['caller-control/'+p.name]=p
for p in (here/'build').glob('*.map'):files['caller-control/build/'+p.name]=p
files['caller-control/CMakeLists.txt']=here/'CMakeLists.txt'
files['query-backfill/benchmark.py']=root/'benchmark.py'
files['query-backfill/plan.json']=root/'plan.json'
files['query-backfill/tested-artifact-hashes.json']=root/'tested-artifact-hashes.json'
for name in ['query_benchmark.cc','reader_only.cc','CMakeLists.txt']:files['query-backfill/'+name]=root/name
files['query-backfill/reader-only/CMakeLists.txt']=root/'reader-only/CMakeLists.txt'
files['query-backfill/java-fixture-audit.json']=root/'java-fixture-audit.json'
for name in ['QueryFixtureAudit.java','audit_java.py','java-fixture-audit.log']:files['query-backfill/'+name]=root/name
plan=json.loads((root/'plan.json').read_text())
for fixture in plan['fixtures'].values():
    if fixture['item']=='02':
        for version,path in fixture['paths'].items():
            p=Path(path);assert hashlib.sha256(p.read_bytes()).hexdigest()==fixture['sha256'][version]
            files['query-backfill/data/'+p.name]=p
actual=Path(data['settings']['file']);files['query-backfill/data/'+actual.name]=actual
files['validation-report.md']=report_path
manifest={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in files.items()}
with zipfile.ZipFile(base/'outputs/TsFile_PR_02_调用程序对照证据.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,p in files.items():z.write(p,name)
    z.writestr('evidence-manifest.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'interpretation':signals,'interaction':interaction,'report':str(report_path)},ensure_ascii=True,indent=2))

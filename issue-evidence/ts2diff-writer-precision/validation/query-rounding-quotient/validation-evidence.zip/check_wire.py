from pathlib import Path
import json
import subprocess

here = Path(__file__).resolve().parent
validation = here.parents[1]/'issue-02/validation'
result = json.loads((here/'build-result.json').read_text())
assert result['java_int32_int64_oracle_passed']
classpath = (validation/'java-classpath.txt').read_text().strip()
classes = here/'java-classes'; classes.mkdir(exist_ok=True)
data = here/'wire-data'; data.mkdir(exist_ok=False)
java = 'C:/Program Files/Java/jdk-24/bin/java.exe'
javac = 'C:/Program Files/Java/jdk-24/bin/javac.exe'
def run(args,name):
    with (here/name).open('w',encoding='utf-8') as output:
        subprocess.run(args,stdout=output,stderr=subprocess.STDOUT,check=True)
run([javac,'-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(validation/'PrecisionWireCompatibility.java')],'wire-javac.log')
run([java,'-cp',str(classes)+';'+classpath,'PrecisionWireCompatibility','generate',str(data)],'wire-java-generate.log')
run([str(here/'client-candidate/Release/precision_screen.exe'),'wire',str(data)],'wire-cpp-read-java.log')
run([java,'-cp',str(classes)+';'+classpath,'PrecisionWireCompatibility','verify',str(data)],'wire-java-read-cpp.log')
manifest = (data/'manifest.csv').read_text().splitlines()
assert len(manifest) == 122
assert all((data/(x.split(',')[0]+'.java.bin')).read_bytes() == (data/(x.split(',')[0]+'.cpp.bin')).read_bytes() for x in manifest)
result.update(wire_cases=122,wire_rows_per_case=260,java_cpp_bidirectional_wire_passed=True,wire_exact_bytes=122)
(here/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

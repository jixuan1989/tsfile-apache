"""Predeclared mixed/read-only caller interaction with identical launch/file protocol."""
from collections import Counter
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path
import _winapi
import ctypes
import hashlib
import json
import msvcrt
import os
import random
import statistics
import subprocess
import sys

here=Path(__file__).resolve().parent
root=here.parent
base=root.parents[1]
sys.path.insert(0,str(root))
import benchmark as core
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.SetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.c_size_t];k.SetProcessAffinityMask.restype=wintypes.BOOL
k.GetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.GetProcessAffinityMask.restype=wintypes.BOOL
k.ResumeThread.argtypes=[wintypes.HANDLE];k.ResumeThread.restype=wintypes.DWORD
k.QueryThreadCycleTime.argtypes=[wintypes.HANDLE,ctypes.POINTER(ctypes.c_ulonglong)];k.QueryThreadCycleTime.restype=wintypes.BOOL
def require(ok):
    if not ok:raise ctypes.WinError(ctypes.get_last_error())

rounds=192
cases={x['name']:x for x in core.plan['cases']['02'] if x['name'] in [
    'DOUBLE_aligned_p2_null0_props0_all_w4_row_parallel0',
    'DOUBLE_aligned_p2_null0_props0_all_w4_batch_parallel0']}
assert len(cases)==2
callers=['mixed','reader_only']
cells=[(name,caller) for name in cases for caller in callers]
labels=['baseline_1','fixed_1','baseline_2','fixed_2']
manifest=json.loads((root/'tested-artifact-hashes.json').read_text(encoding='utf-8'))
executables={}
for caller in callers:
    executables[caller]={}
    for version in ['baseline','fixed']:
        path=root/(f'build/Release/query_02_{version}.exe' if caller=='mixed' else f'reader-only/build/Release/read_only_02_{version}.exe')
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest==manifest['files'][path.relative_to(base).as_posix()]['sha256']
        executables[caller][version]={'path':str(path),'sha256':digest}
fixture=core.plan['fixtures']['02_DOUBLE_aligned_p2_null0_props0']
assert hashlib.sha256(Path(fixture['paths']['baseline']).read_bytes()).digest()==hashlib.sha256(Path(fixture['paths']['fixed']).read_bytes()).digest()

def key(name,caller):return name+'__'+caller
def order(round,values):
    off=round%len(values);result=values[off:]+values[:off]
    return list(reversed(result)) if (round//len(values))%2 else result
balance={}
for name,values in [('labels',labels),('cells',cells)]:
    positions={str(x):Counter() for x in values}
    for r in range(rounds):
        for i,x in enumerate(order(r,values)):positions[str(x)][i]+=1
    assert all(len(v)==len(values) and len(set(v.values()))==1 for v in positions.values())
    balance[name]={str(x):dict(v) for x,v in positions.items()}
report={'created_at':datetime.now(timezone.utc).isoformat(),
    'hypothesis':'The retained query latency signal depends on the final linked mixed caller versus one-object reader-only caller, rather than an added reader-source operation. A statistically positive interaction would narrow but not prove linked layout causality; caller features/link contents change together.',
    'primary_analysis':'Per round and caller, sum six fixed-reader query times over two child processes divided by sum six baseline-reader query times. Primary interaction per matched round is mixed ratio / reader-only ratio. Bootstrap 24 chronological blocks of eight complete, balanced rounds. Exploratory within-binary repeat-label ratios are negative controls. Do not replace older measurements or clear the strict query gate from this diagnostic alone.',
    'stopping_rule':'Exactly 192 complete quartets per each of four cells; 2 warmups per label/cell; no adaptive extension. Abort on result/hash/affinity failure; preserve partial data.',
    'settings':{'mask':12,'pin_before_initial_thread_resume':True,'pool_threads':2,'parallel_read':False,
                'queries_per_child':3,'cache':'warm filesystem cache, uncontrolled interactive-host background/power state',
                'file':fixture['paths']['fixed'],'file_sha256':hashlib.sha256(Path(fixture['paths']['fixed']).read_bytes()).hexdigest(),
                'rows_per_query':65536,'projected_fields':4},
    'cpu_cycle_scope':'Whole main-thread lifetime including startup/printing/exit, not query-only or retired instructions.',
    'execution_position_balance':balance,'executables':executables,
    'cases':{key(n,c):{'name':n,'caller':c,'measurements':[]} for n,c in cells}}

def run(name,caller,label):
    c=cases[name];version=label.split('_')[0]
    args=[executables[caller][version]['path'],'read',fixture['paths']['fixed'],c['layout'],c['kind'],
          str(c['precision']),str(c['sparse']),str(c['properties']),c['scenario'],str(c['width']),str(c['batch']),'0','3']
    output=here/'child.log'
    with output.open('w+b') as out,open(os.devnull,'rb') as inp:
        for file in [out,inp]:os.set_handle_inheritable(msvcrt.get_osfhandle(file.fileno()),True)
        si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESTDHANDLES
        si.hStdInput=msvcrt.get_osfhandle(inp.fileno());si.hStdOutput=si.hStdError=msvcrt.get_osfhandle(out.fileno())
        hp,ht,pid,tid=_winapi.CreateProcess(args[0],subprocess.list2cmdline(args),None,None,True,
            subprocess.CREATE_NO_WINDOW|4,None,None,si)
        try:
            require(k.SetProcessAffinityMask(hp,12));allowed,system=ctypes.c_size_t(),ctypes.c_size_t()
            require(k.GetProcessAffinityMask(hp,ctypes.byref(allowed),ctypes.byref(system)));assert allowed.value==12
            assert k.ResumeThread(ht)==1
            assert _winapi.WaitForSingleObject(hp,30000)==0
            code=_winapi.GetExitCodeProcess(hp)
            cycles=ctypes.c_ulonglong();require(k.QueryThreadCycleTime(ht,ctypes.byref(cycles)))
        finally:_winapi.CloseHandle(ht);_winapi.CloseHandle(hp)
    text=output.read_text(encoding='utf-8');assert code==0,text
    data=json.loads([x for x in text.splitlines() if x.startswith('{')][-1])
    for name,value in core.expected(c).items():assert data[name]==value
    data.update(main_thread_lifetime_cycles=cycles.value,affinity_mask=12)
    return data

def analyze(report):
    rng=random.Random(10240728)
    def estimate(ratios):
        assert len(ratios)==rounds
        blocks=[statistics.median(ratios[i:i+8]) for i in range(0,rounds,8)]
        boot=sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(20000))
        return {'paired_median_ratio':statistics.median(ratios),'block_median_ratio':statistics.median(blocks),
            'bootstrap_95_percent':[core.percentile(boot,.025),core.percentile(boot,.975)],'block_ratios':blocks}
    primary={}
    for name in cases:
        per_caller={}
        for caller in callers:
            d=report['cases'][key(name,caller)];rows=d['measurements']
            assert len(rows)==rounds
            ratios=[sum(sum(x['fixed_'+i]['full_seconds']) for i in ['1','2'])/
                    sum(sum(x['baseline_'+i]['full_seconds']) for i in ['1','2']) for x in rows]
            cycles=[sum(x['fixed_'+i]['main_thread_lifetime_cycles'] for i in ['1','2'])/
                    sum(x['baseline_'+i]['main_thread_lifetime_cycles'] for i in ['1','2']) for x in rows]
            repeats={v:estimate([sum(x[v+'_2']['full_seconds'])/sum(x[v+'_1']['full_seconds']) for x in rows])
                     for v in ['baseline','fixed']}
            d['summary']={'fixed_over_baseline_full':estimate(ratios),'main_thread_lifetime_cycles_ratio':estimate(cycles),
                          'same_binary_repeat_controls':repeats}
            per_caller[caller]=ratios
        primary[name]=estimate([a/b for a,b in zip(per_caller['mixed'],per_caller['reader_only'])])
    report['primary_caller_interaction']=primary
    report['completed_at']=datetime.now(timezone.utc).isoformat()
    return report

def main():
    if '--smoke' in sys.argv:
        for caller in callers:
            d=run(next(iter(cases)),caller,'baseline_1')
            print(json.dumps({'caller':caller,'rows':d['rows_per_query'],'PASS':True}))
        return
    path=here/'matched-callers-results.json'
    if '--analyze-only' in sys.argv:
        result=analyze(json.loads(path.read_text()))
    else:
        assert not path.exists(),'Refuse to overwrite a measured run.'
        (here/'matched-callers-plan.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        for name,caller in cells:
            for _ in range(2):
                for label in labels:run(name,caller,label)
        for r in range(rounds):
            for name,caller in order(r,cells):
                report['cases'][key(name,caller)]['measurements'].append({label:run(name,caller,label) for label in order(r,labels)})
            if (r+1)%8==0:
                path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
                print('Matched-protocol quartets/cell:',r+1,flush=True)
        result=analyze(report)
    path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'interaction':result['primary_caller_interaction'],
        'callers':{k:v['summary'] for k,v in result['cases'].items()}},indent=2),flush=True)
if __name__=='__main__':main()

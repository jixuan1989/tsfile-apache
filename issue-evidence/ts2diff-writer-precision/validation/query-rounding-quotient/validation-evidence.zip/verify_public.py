"""Offline evidence consistency checks; run in the extracted public ZIP."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import statistics

root = Path(__file__).resolve().parent
report = json.loads((root/'query-results.json').read_text())
assert report['completed_at'] and not report['query_gate_cleared']
queries = children = 0
for name,cell in report['cases'].items():
    c = cell['case']; rows = cell['measurements']
    assert len(rows) == 144
    expected = {'rows_per_query':65536,'accepted_rows_per_query':0,'checksum':0,'NULL_cells':0}
    for r in range(65536):
        keep = c['scenario'] != 'app50' or r%100 < 50
        expected['accepted_rows_per_query'] += keep
        for f in range(c['width']):
            nil = c['sparse'] and f > 0 and (r%32768+f)%11 == 0
            expected['NULL_cells'] += bool(nil)*3
            if keep: expected['checksum'] += (17 if nil else (r*8+f)*4+1)*3
    positions = {label:Counter() for label in rows[0]}
    identities = {label:Counter() for label in rows[0]}
    for row in rows:
        assert len(row) == 6
        for pos,(label,data) in enumerate(row.items()):
            v = label.split('_')[0]
            assert data['payload_sha256'] == report['images'][v]['sha256']
            assert data['repeats'] == 3 and len(data['full_seconds']) == 3
            assert data['affinity_mask'] == 12
            assert all(data[k] == value for k,value in expected.items())
            positions[label][pos] += 1; identities[label][data['actual_image']] += 1
            children += 1; queries += 3
    assert all(len(x) == 6 and len(set(x.values())) == 1 for x in positions.values())
    assert all(len(x) == 6 and len(set(x.values())) == 1 for x in identities.values())
    for key,x in cell['summary']['comparisons'].items():
        after,before = key.split('_over_')
        ratios = [sum(sum(row[after+'_'+i]['full_seconds']) for i in ['1','2'])/sum(sum(row[before+'_'+i]['full_seconds']) for i in ['1','2']) for row in rows]
        blocks = [statistics.median(ratios[i:i+6]) for i in range(0,144,6)]
        assert statistics.median(ratios) == x['paired_median_ratio']
        assert statistics.median(blocks) == x['block_median_ratio'] and blocks == x['block_ratios']
assert children == 2592 and queries == 7776 and report['warmup_children'] == 864
manifest = json.loads((root/'manifest.json').read_text()) if (root/'manifest.json').exists() else {}
for name,digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest
print(json.dumps({'measured_children':children,'verified_queries':queries,'cases':len(report['cases']),'all_paths_and_positions_balanced':True,'paired_and_block_medians_verified':True,'manifest_files_verified':len(manifest)}))

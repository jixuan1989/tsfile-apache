from pathlib import Path
import hashlib
import json
import struct
import subprocess
import tarfile

here = Path(__file__).resolve().parent
root = here.parent
source = here/'source'
cmake = 'C:/Program Files/CMake/bin/cmake.exe'
def run(args,name):
    print(name,flush=True)
    with (here/name).open('w',encoding='utf-8') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)

changes = []
with tarfile.open(here/'source.tar') as archive:
    for member in archive.getmembers():
        if member.isfile() and hashlib.sha256(archive.extractfile(member).read()).digest() != hashlib.sha256((source/member.name).read_bytes()).digest():
            changes.append(member.name)
assert changes == ['cpp/src/encoding/ts2diff_encoder.h'], changes
run([cmake,'--build',str(here/'build'),'--config','Release','--target','tsfile','--parallel','12'],'candidate-build.log')
run([cmake,'-S',str(here/'client'),'-B',str(here/'client-candidate'),'-G','Visual Studio 18 2026','-A','x64',
     '-DTSFILE_SCREEN_LIBRARY='+str(here/'build/lib/Release/tsfile.lib')],'candidate-client-configure.log')
run([cmake,'--build',str(here/'client-candidate'),'--config','Release','--parallel','12'],'candidate-client-build.log')

def sections(path):
    data = path.read_bytes()
    pe = struct.unpack_from('<I',data,0x3c)[0]
    n = struct.unpack_from('<H',data,pe+6)[0]
    start = pe+24+struct.unpack_from('<H',data,pe+20)[0]
    result = {}
    for i in range(n):
        pos = start+40*i
        name = data[pos:pos+8].rstrip(b'\0').decode()
        virtual,rva,length,offset = struct.unpack_from('<IIII',data,pos+8)
        result[name] = {'virtual_bytes':virtual,'rva':rva,'raw_bytes':length,
                        'raw_sha256':hashlib.sha256(data[offset:offset+length]).hexdigest()}
    return {'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'file_bytes':len(data),'sections':result}

variants = {name:sections(path) for name,path in {
    'baseline':root/'build/Release/query_02_baseline.exe',
    'original_current':root/'build/Release/query_02_fixed.exe',
    'current':here/'client-control/Release/query_screen.exe',
    'candidate':here/'client-candidate/Release/query_screen.exe'}.items()}
assert variants['current']['sections']['.text'] == variants['original_current']['sections']['.text']
(here/'variants.json').write_text(json.dumps(variants,indent=2)+'\n')
delta = variants['candidate']['sections']['.text']['virtual_bytes']-variants['current']['sections']['.text']['virtual_bytes']
result = {'changed_files':changes,'matched_control_text_exact':True,'candidate_text_change_bytes':delta,
          'code_footprint_screen_passed':delta < 0,'query_gate_cleared':False}
(here/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
oracle = here/'client-candidate/Release/round_oracle.exe'
data = root.parent/'issue-02/validation/review-reserved-precision/round-oracle.bin'
assert hashlib.sha256(data.read_bytes()).hexdigest() == '3ca19b4154b5a794bf5d19f03c23a98afe9575893419f058cadbfa9a8fee4f98'
run([str(oracle),str(data)],'java-oracle-check.log')
result['java_oracle_inputs'] = 1088975
result['java_int32_int64_oracle_passed'] = True
(here/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)

"""One finite six-label query screen of the algebraic rounding candidate."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import random
import statistics
import sys

here = Path(__file__).resolve().parent
root = here.parent
sys.path.insert(0,str(root/'caller-control'))
import matched_callers as m

rounds = 144
labels = ['baseline_1','current_1','candidate_1','baseline_2','current_2','candidate_2']
variants = json.loads((here/'variants.json').read_text())
checks = json.loads((here/'build-result.json').read_text())
assert checks['code_footprint_screen_passed'] and checks['java_cpp_bidirectional_wire_passed']
prior = json.loads((root/'caller-control/counterbalanced-matrix-confirmation.json').read_text())
cases = {n:x['case'] for n,x in prior['cases'].items() if x['summary']['confirmation_signals']}
assert len(cases) == 3
m.cases.update(cases)
m.here = here
images = {v:{k:variants[v][k] for k in ['path','sha256']} for v in ['baseline','current','candidate']}
payloads = {v:Path(x['path']).read_bytes() for v,x in images.items()}
assert all(hashlib.sha256(payloads[v]).hexdigest() == x['sha256'] for v,x in images.items())
directory = here/'query-images'; directory.mkdir(exist_ok=True)
paths = [directory/f'q{i:03}.exe' for i in range(6)]
assignments = [{label:str(paths[(i+b)%6]) for i,label in enumerate(labels)} for b in range(24)]
for p in paths:
    assert Counter(label for a in assignments for label,path in a.items() if path == str(p)) == {label:4 for label in labels}
for values in [labels,list(cases)]:
    positions = {x:Counter() for x in values}
    for r in range(rounds):
        for i,x in enumerate(m.order(r,values)): positions[x][i] += 1
    assert all(len(p) == len(values) and len(set(p.values())) == 1 for p in positions.values())

report = {'created_at':datetime.now(timezone.utc).isoformat(),'source_head':json.loads((here/'plan.json').read_text())['source_head'],
    'query_gate_cleared':False,'production_source_unchanged':True,
    'method':'144 matched six-label rounds/scenario, two copies each of original upstream baseline, matched unchanged current-head rebuild and candidate. Six neutral paths rotate every six rounds; all identities/positions balanced. 24 chronological blocks, 20000 fixed-seed block-bootstrap draws. Three full checked queries/child. Two warmup children per label/scenario after each copy block; all measured samples retained.',
    'settings':{'affinity_mask':12,'before_initial_resume':True,'pool_threads':2,'parallel':False,'cache':'Warm filesystem; uncontrolled interactive-host background and power. No WPR or invasive sampler.'},
    'limits':['Private candidate screening, not full query/Java/file/write/coverage acceptance.','Current is an unchanged source matched rebuild with original.text exact; full PE file hash differs.','Three original residual scenarios on identical valid baseline/fixed writer products; other scenarios and changed writer-product output latency not measured here.','24 clustered identity/time blocks; exploratory correlated contrasts, not equivalence proof.','No cold-cache/P99 or CPU-counter claim.'],
    'stopping_rule':'One fixed run; no optional extension, trimming or parameter changes. Candidate is rejected if any retained scenario still has a candidate/baseline upward signal under the existing CI/median/p95 trigger. If the current/baseline signal is absent or candidate/current improvement is inconclusive, retain as inconclusive rather than claiming a cure; do not repeat for a pass.',
    'images':images,'identity_assignments':assignments,'fixtures':{},'warmup_children':0,
    'cases':{n:{'case':c,'measurements':[]} for n,c in cases.items()}}
for name,c in cases.items():
    f = m.core.plan['fixtures'][c['fixture_key']]
    b,a = [Path(f['paths'][v]).read_bytes() for v in ['baseline','fixed']]
    assert b == a
    path = directory/(c['fixture_key']+'.tsfile'); path.write_bytes(a)
    report['fixtures'][name] = {'path':str(path),'sha256':hashlib.sha256(a).hexdigest(),'baseline_fixed_bytes_equal':True}

def copy_block(block):
    for label,path in assignments[block].items():
        p = Path(path); assert p.parent == directory
        v = label.split('_')[0]
        p.write_bytes(payloads[v])
        assert hashlib.sha256(p.read_bytes()).hexdigest() == images[v]['sha256']

def run(name,label,block):
    v = label.split('_')[0]
    m.executables['screen'] = {v:{'path':assignments[block][label]}}
    m.fixture = {'paths':{'fixed':report['fixtures'][name]['path']}}
    result = m.run(name,'screen',label)
    result.update(actual_image=assignments[block][label],payload_sha256=images[v]['sha256'])
    return result

def analyze(data):
    rng = random.Random(1024181140)
    def estimate(values):
        assert len(values) == rounds
        blocks = [statistics.median(values[i:i+6]) for i in range(0,rounds,6)]
        boot = sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(20000))
        return {'paired_median_ratio':statistics.median(values),'block_median_ratio':statistics.median(blocks),
                'bootstrap_95_percent':[m.core.percentile(boot,.025),m.core.percentile(boot,.975)],'block_ratios':blocks}
    for name,cell in data['cases'].items():
        rows = cell['measurements']
        comparisons = {}; stats = {}
        def total(row,v):return sum(sum(row[v+'_'+copy]['full_seconds']) for copy in ['1','2'])
        for after,before in [('current','baseline'),('candidate','baseline'),('candidate','current')]:
            key = after+'_over_'+before
            values = [total(row,after)/total(row,before) for row in rows]
            x = estimate(values)
            a = [t for row in rows for copy in ['1','2'] for t in row[after+'_'+copy]['full_seconds']]
            b = [t for row in rows for copy in ['1','2'] for t in row[before+'_'+copy]['full_seconds']]
            x['descriptive_p95_ratio'] = m.core.percentile(a,.95)/m.core.percentile(b,.95)
            x['upward_trigger'] = x['bootstrap_95_percent'][0] > 1 or x['paired_median_ratio'] > 1.03 or x['descriptive_p95_ratio'] > 1.10
            comparisons[key] = x
        for v in images:
            by_metric = {}
            for metric in ['open_seconds','metadata_seconds','plan_seconds','first_row_seconds','first_decoded_row_seconds','full_seconds']:
                vals = [t for row in rows for copy in ['1','2'] for t in row[v+'_'+copy][metric] if t is not None]
                by_metric[metric] = {'samples':len(vals),'p50':statistics.median(vals),'p95':m.core.percentile(vals,.95)}
            times = [t for row in rows for copy in ['1','2'] for t in row[v+'_'+copy]['full_seconds']]
            by_metric['decoded_rows_per_second'] = statistics.median(rows[0][v+'_1']['rows_per_query']/t for t in times)
            by_metric['accepted_rows_per_second'] = statistics.median(rows[0][v+'_1']['accepted_rows_per_query']/t for t in times)
            by_metric['projected_cells_per_second'] = statistics.median(rows[0][v+'_1']['rows_per_query']*cell['case']['width']/t for t in times)
            by_metric['peak_working_set_median_bytes'] = statistics.median(row[v+'_'+copy]['peak_process_working_set_bytes'] for row in rows for copy in ['1','2'])
            stats[v] = by_metric
        controls = {v:estimate([sum(row[v+'_2']['full_seconds'])/sum(row[v+'_1']['full_seconds']) for row in rows]) for v in images}
        cell['summary'] = {'comparisons':comparisons,'negative_controls':controls,'variants':stats}
    data['completed_at'] = datetime.now(timezone.utc).isoformat()
    return data

def main():
    target = here/'query-results.json'
    if '--analyze-only' in sys.argv:
        data = analyze(json.loads(target.read_text()))
    else:
        assert not target.exists(), 'Never overwrite or replace a measured run.'
        (here/'query-plan.json').write_text(json.dumps(report,indent=2)+'\n')
        copy_block(0)
        if '--smoke' in sys.argv:
            checked = [{label:run(name,label,0) for label in labels} for name in cases]
            (here/'query-smoke.json').write_text(json.dumps(checked,indent=2)+'\n')
            print('Three cases/six labels/54 complete checked smoke queries passed.')
            return
        try:
            for r in range(rounds):
                if r%6 == 0:
                    copy_block(r//6)
                    for name in cases:
                        for _ in range(2):
                            for label in labels:
                                run(name,label,r//6); report['warmup_children'] += 1
                for name in m.order(r,list(cases)):
                    report['cases'][name]['measurements'].append({label:run(name,label,r//6) for label in m.order(r,labels)})
                if (r+1)%6 == 0:
                    target.write_text(json.dumps(report,indent=2)+'\n')
                    print('Complete sextets per case:',r+1,flush=True)
        finally:
            target.write_text(json.dumps(report,indent=2)+'\n')
        data = analyze(report)
    target.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({n:{k:{metric:value for metric,value in x.items() if metric != 'block_ratios'} for k,x in c['summary']['comparisons'].items()} for n,c in data['cases'].items()},indent=2),flush=True)

if __name__ == '__main__':main()

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path(__file__).resolve().parent
base = root.parent.parent
here = root/'rounding-quotient'
here.mkdir(exist_ok=False)
state = json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
item = next(x for x in state['drafts'] if x['id'] == '02')
repo = base/item['implementation']['source']
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip() == item['head_commit']
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
archive = here/'source.tar'
subprocess.run(['git','-C',str(repo),'archive','--format=tar','-o',str(archive),'HEAD'],check=True)
source = here/'source'
source.mkdir()
with tarfile.open(archive) as tar: tar.extractall(source,filter='data')
shutil.copyfile(root/'pmu/cold-factory/source/cpp/third_party/googletest-release-1.12.1.zip',source/'cpp/third_party/googletest-release-1.12.1.zip')
plan = {'source_head':item['head_commit'],'created_at':datetime.now(timezone.utc).isoformat(),
    'hypothesis':'Replace remainder-mask/threshold comparison by an equivalent quotient expression in java_round; fewer integer operations and smaller writer code without precision/wire/API changes. One algebraic candidate; no alignment/order parameter search.',
    'formula':'For positive shift k, q=(((significand-negative)>>(k-1))+1)>>1. Positive ties round up; subtracting one for negative magnitudes moves only exact ties down before restoring the sign.',
    'proof_domain':'2^52 <= significand < 2^53, 1<=k<=53. Subtraction cannot underflow and addition cannot overflow uint64_t. Existing exponent/NaN/saturation/integral gates remain unchanged.',
    'predeclared_screens':['Matched control exact.text check','Smaller linked.text and Java 1088975-input int32/int64 oracle','One 3-scenario,144-round,six-label query screen with original baseline/current/candidate, two copies each; neutral path rotation and position balance, all samples retained'],
    'stop_rule':'Reject on oracle mismatch or failure to remove the retained query signals; do not vary the expression, binary padding or timing rounds to seek a pass. A screen success requires full affected correctness/Java/coverage/write/query gates before any source push.',
    'production_source_unchanged':True,'query_gate_cleared':False}
(here/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
client = here/'client'; client.mkdir()
(client/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.20)
project(tsfile_rounding_candidate LANGUAGES CXX)
get_filename_component(ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../.." ABSOLUTE)
get_filename_component(WORKSPACE "${ROOT}/../.." ABSOLUTE)
add_executable(query_screen "${ROOT}/query_benchmark.cc")
add_executable(round_oracle "${WORKSPACE}/work/issue-02/validation/round_oracle.cc")
add_executable(precision_screen "${WORKSPACE}/work/issue-02/validation/driver.cc")
add_executable(benchmark_screen "${WORKSPACE}/work/issue-02/validation/benchmark_driver.cc")
foreach(target query_screen round_oracle precision_screen benchmark_screen)
    target_compile_features(${target} PRIVATE cxx_std_14)
    target_compile_definitions(${target} PRIVATE TSFILE_STATIC NOMINMAX ENABLE_MEM_STAT ENABLE_THREADS)
    target_compile_options(${target} PRIVATE /utf-8 /EHsc /bigobj /W0)
    target_include_directories(${target} PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../source/cpp/src")
    target_link_libraries(${target} PRIVATE "${TSFILE_SCREEN_LIBRARY}" psapi)
endforeach()
target_compile_definitions(precision_screen PRIVATE FIXED_PRECISION_PROPS)
target_link_options(query_screen PRIVATE "/MAP:${CMAKE_CURRENT_BINARY_DIR}/query_screen.map")
''',encoding='utf-8')
cmake = 'C:/Program Files/CMake/bin/cmake.exe'
def run(args,name):
    print(name,flush=True)
    with (here/name).open('w',encoding='utf-8') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
args = [cmake,'-S',str(source/'cpp'),'-B',str(here/'build'),'-G','Visual Studio 18 2026','-A','x64',
    '-DTSFILE_BUILD_SHARED=OFF','-DBUILD_TEST=ON','-DTSFILE_DEPENDENCY_SOURCE=BUNDLED','-DTSFILE_DEPENDENCY_OFFLINE=ON',
    '-DENABLE_ANTLR4=OFF','-DENABLE_THREADS=ON','-DENABLE_MEM_STAT=ON','-DENABLE_SIMD=OFF']
args += ['-DENABLE_'+c+'=OFF' for c in ['LZ4','LZMA2','LZOKAY','SNAPPY','ZLIB','ZSTD']]
run(args,'control-configure.log')
run([cmake,'--build',str(here/'build'),'--config','Release','--target','tsfile','--parallel','12'],'control-build.log')
shutil.copyfile(here/'build/lib/Release/tsfile.lib',here/'control-tsfile.lib')
run([cmake,'-S',str(client),'-B',str(here/'client-control'),'-G','Visual Studio 18 2026','-A','x64','-DTSFILE_SCREEN_LIBRARY='+str(here/'control-tsfile.lib')],'control-client-configure.log')
run([cmake,'--build',str(here/'client-control'),'--config','Release','--parallel','12'],'control-client-build.log')
header = source/'cpp/src/encoding/ts2diff_encoder.h'
old = header.read_text(encoding='utf-8')
fragment = '''        const uint64_t remainder = significand & ((uint64_t{1} << shift) - 1);
        const uint64_t threshold = (uint64_t{1} << (shift - 1)) + negative;
        rounded = (significand >> shift) + (remainder >= threshold);'''
replacement = '''        // Keep the half-unit bit, add one and drop that bit. Subtracting
        // one for a negative magnitude makes exact ties round toward zero.
        rounded = (((significand - static_cast<uint64_t>(negative)) >>
                    (shift - 1)) +
                   1) >>
                  1;'''
assert old.count(fragment) == 1
(here/'original-ts2diff_encoder.h').write_bytes(old.encode('utf-8'))
header.write_bytes(old.replace(fragment,replacement).encode('utf-8'))
plan['candidate_header_sha256_before_format'] = hashlib.sha256(header.read_bytes()).hexdigest()
plan['status'] = 'control_built_candidate_requires_format_and_build'
(here/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'status':plan['status'],'source':str(source)}))

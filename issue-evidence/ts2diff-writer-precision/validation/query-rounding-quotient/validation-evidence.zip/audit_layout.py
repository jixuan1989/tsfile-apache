from pathlib import Path
import hashlib
import json
import re
import struct

here = Path(__file__).resolve().parent
variants = json.loads((here/'variants.json').read_text())

def image(path):
    raw = path.read_bytes(); pe = struct.unpack_from('<I',raw,0x3c)[0]
    opt = pe+24; start = opt+struct.unpack_from('<H',raw,pe+20)[0]
    sections = []
    for i in range(struct.unpack_from('<H',raw,pe+6)[0]):
        p = start+i*40; name = raw[p:p+8].rstrip(b'\0').decode()
        size,rva,length,offset = struct.unpack_from('<IIII',raw,p+8)
        sections.append((name,rva,size,offset,length))
    def file_offset(rva):
        return next(o+rva-r for n,r,s,o,l in sections if r <= rva < r+max(s,l))
    debug_rva,debug_size = struct.unpack_from('<II',raw,opt+112+6*8)
    timestamps = []
    if debug_size:
        off = file_offset(debug_rva)
        timestamps = [off+i+4 for i in range(0,debug_size,28)]
    name,rva,size,offset,length = next(x for x in sections if x[0] == '.rdata')
    original = raw[offset:offset+length]; normalized = bytearray(original)
    for p in timestamps:
        assert offset <= p < offset+length
        normalized[p-offset:p-offset+4] = b'\0'*4
    return {'rdata':original,'rdata_timestamp_zeroed':bytes(normalized),'debug_timestamp_rdata_offsets':[p-offset for p in timestamps]}

images = {n:image(Path(v['path'])) for n,v in variants.items()}
a,b = images['original_current'],images['current']
comparison = {'original_current_vs_matched_control':{
    'text_exact':variants['original_current']['sections']['.text'] == variants['current']['sections']['.text'],
    'rdata_raw_difference_bytes':sum(x!=y for x,y in zip(a['rdata'],b['rdata'])),
    'rdata_equal_after_zeroing_only_debug_directory_timestamps':a['rdata_timestamp_zeroed'] == b['rdata_timestamp_zeroed'],
    'normalized_rdata_sha256':hashlib.sha256(b['rdata_timestamp_zeroed']).hexdigest(),
    'debug_timestamp_offsets':b['debug_timestamp_rdata_offsets']}}
maps = {}
for v,folder in [('current','client-control'),('candidate','client-candidate')]:
    text = (here/folder/'query_screen.map').read_text(errors='replace')
    preferred = int(re.search(r'Preferred load address is ([0-9a-fA-F]+)',text).group(1),16)
    symbols = {}
    for line in text.splitlines():
        m = re.match(r'\s+[0-9a-fA-F]{4}:[0-9a-fA-F]{8}\s+(\S+)\s+([0-9a-fA-F]{16})\s',line)
        if m: symbols[m.group(1)] = int(m.group(2),16)-preferred
    maps[v] = symbols
prefixes = ['?read_fixture@@','?multi_DECODE_TV_BATCH@AlignedChunkReader@','?read_batch_double@DoubleTS2DIFFDecoder@','?read_batch_int64@TS2DIFFDecoder@']
comparison['selected_hot_function_rvas'] = {}
for prefix in prefixes:
    common = [name for name in maps['current'] if name.startswith(prefix) and name in maps['candidate']]
    for symbol in common:
        comparison['selected_hot_function_rvas'][symbol] = {v:maps[v][symbol] for v in maps}
(here/'static-layout-audit.json').write_text(json.dumps(comparison,indent=2)+'\n')
print(json.dumps(comparison,indent=2))

"""Finite diagnostic experiment, including identical-binary negative controls."""
from collections import Counter
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path
import _winapi
import ctypes
import hashlib
import json
import msvcrt
import os
import random
import statistics
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
root = here.parent
sys.path.insert(0,str(root))
import benchmark as core

k = ctypes.WinDLL('kernel32',use_last_error=True)
k.SetProcessAffinityMask.argtypes = [wintypes.HANDLE,ctypes.c_size_t]
k.SetProcessAffinityMask.restype = wintypes.BOOL
k.GetProcessAffinityMask.argtypes = [wintypes.HANDLE,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
k.GetProcessAffinityMask.restype = wintypes.BOOL
k.ResumeThread.argtypes = [wintypes.HANDLE]
k.ResumeThread.restype = wintypes.DWORD
k.QueryThreadCycleTime.argtypes = [wintypes.HANDLE,ctypes.POINTER(ctypes.c_ulonglong)]
k.QueryThreadCycleTime.restype = wintypes.BOOL
k.GetThreadTimes.argtypes = [wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
k.GetThreadTimes.restype = wintypes.BOOL
k.GetProcessTimes.argtypes = k.GetThreadTimes.argtypes
k.GetProcessTimes.restype = wintypes.BOOL

def require(ok):
    if not ok: raise ctypes.WinError(ctypes.get_last_error())

def cpu_seconds(handle, method):
    creation,exit,kernel,user = [wintypes.FILETIME() for _ in range(4)]
    require(method(handle,ctypes.byref(creation),ctypes.byref(exit),ctypes.byref(kernel),ctypes.byref(user)))
    def seconds(t): return ((t.dwHighDateTime<<32)+t.dwLowDateTime)*1e-7
    return {'kernel':seconds(kernel),'user':seconds(user),'total':seconds(kernel)+seconds(user)}

cases = {x['name']:x for x in core.plan['cases']['02'] if x['name'] in [
    'DOUBLE_aligned_p2_null0_props0_all_w4_row_parallel0',
    'DOUBLE_aligned_p2_null0_props0_all_w4_batch_parallel0']}
cells = [(name,pinning,mapping) for name in cases for pinning in ['after_create','before_resume']
         for mapping in ['baseline_vs_fixed','baseline_vs_baseline','fixed_vs_fixed']]
labels = ['baseline_baseline','fixed_baseline','baseline_fixed','fixed_fixed']
rounds = 96
report = {'created_at':datetime.now(timezone.utc).isoformat(), 'purpose':'Diagnostic only; not a replacement pass/fail benchmark.',
    'predeclared_rounds':rounds, 'cases':{},
    'method':'Two dense aligned DOUBLE cases; mixed original binaries; one byte-identical precision-2 fixed file for all labels. Cross launch pinning (post-CreateProcess versus CREATE_SUSPENDED then affinity before ResumeThread) with actual baseline/fixed, baseline/baseline and fixed/fixed negative controls. Four position-balanced labels, 96 quartets/cell, 3 full checked queries/process; 2 warmups/label/cell. Same mask 12 and pool=2. CPU metrics are whole main-thread/process lifetime, including initialization/printing/exit; thread cycle count is hardware-dependent, not retired instructions or a calibrated clock-frequency estimate. Primary diagnostic CI bootstraps 12 chronological blocks of 8 quartets; all data retained.',
    'limits':['Same-file reader diagnosis, not writer-product latency','Warm filesystem cache','No production code changes','Exploratory diagnostic comparisons, no multiplicity-adjusted inference or no-regression gate'],
    'binary_sha256':{v:hashlib.sha256((root/f'build/Release/query_02_{v}.exe').read_bytes()).hexdigest() for v in ['baseline','fixed']}}

def cell_key(name,pinning,mapping): return name+'__'+pinning+'__'+mapping
def order_for(round, values):
    off=round%len(values); order=values[off:]+values[:off]
    return list(reversed(order)) if (round//len(values))%2 else order

for name,pinning,mapping in cells:
    key = cell_key(name,pinning,mapping)
    report['cases'][key] = {'name':name,'pinning':pinning,'mapping':mapping,'measurements':[]}
for values in [labels,cells]:
    positions={str(x):Counter() for x in values}
    for round in range(rounds):
        for i,x in enumerate(order_for(round,values)): positions[str(x)][i]+=1
    assert all(len(set(v.values()))==1 and len(v)==len(values) for v in positions.values())
report['execution_position_balance_asserted'] = True
# Preserve the fixed protocol before any diagnostic samples.
if '--analyze-only' not in sys.argv:
    (here/'launch-control-plan.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

def run(name,pinning,mapping,label):
    c=cases[name];fixture=core.plan['fixtures'][c['fixture_key']]
    assert hashlib.sha256(Path(fixture['paths']['baseline']).read_bytes()).digest()==hashlib.sha256(Path(fixture['paths']['fixed']).read_bytes()).digest()
    reader=label.split('_')[0]
    if mapping == 'baseline_vs_baseline': reader='baseline'
    if mapping == 'fixed_vs_fixed': reader='fixed'
    args=[str(root/f'build/Release/query_02_{reader}.exe'),'read',fixture['paths']['fixed'],c['layout'],c['kind'],
          str(c['precision']),str(c['sparse']),str(c['properties']),c['scenario'],str(c['width']),str(c['batch']),'0','3']
    output=here/'launch-child.log'
    with output.open('w+b') as out, open(os.devnull,'rb') as inp:
        for file in [out,inp]: os.set_handle_inheritable(msvcrt.get_osfhandle(file.fileno()),True)
        si=subprocess.STARTUPINFO();si.dwFlags |= subprocess.STARTF_USESTDHANDLES
        si.hStdInput=msvcrt.get_osfhandle(inp.fileno());si.hStdOutput=si.hStdError=msvcrt.get_osfhandle(out.fileno())
        start=time.perf_counter()
        hp,ht,pid,tid=_winapi.CreateProcess(args[0],subprocess.list2cmdline(args),None,None,True,
            subprocess.CREATE_NO_WINDOW | (4 if pinning=='before_resume' else 0),None,None,si)
        try:
            require(k.SetProcessAffinityMask(hp,12))
            allowed,system=ctypes.c_size_t(),ctypes.c_size_t()
            require(k.GetProcessAffinityMask(hp,ctypes.byref(allowed),ctypes.byref(system)))
            assert allowed.value == 12
            if pinning=='before_resume': assert k.ResumeThread(ht)==1
            assert _winapi.WaitForSingleObject(hp,30000)==0
            code=_winapi.GetExitCodeProcess(hp)
            cycles=ctypes.c_ulonglong();require(k.QueryThreadCycleTime(ht,ctypes.byref(cycles)))
            metrics={'main_thread_lifetime_cycles':cycles.value,'main_thread_lifetime_cpu_seconds':cpu_seconds(ht,k.GetThreadTimes),
                     'process_lifetime_cpu_seconds':cpu_seconds(hp,k.GetProcessTimes),'process_lifetime_wall_seconds':time.perf_counter()-start,
                     'affinity_mask':allowed.value,'reader_binary':reader}
        finally:
            _winapi.CloseHandle(ht);_winapi.CloseHandle(hp)
    text=output.read_text(encoding='utf-8');assert code==0,text
    result=json.loads([x for x in text.splitlines() if x.startswith('{')][-1])
    for key,value in core.expected(c).items(): assert result[key]==value,(key,result[key],value)
    return {**result,**metrics}

if '--smoke' in sys.argv:
    for pinning in ['after_create','before_resume']:
        value=run(next(iter(cases)),pinning,'baseline_vs_fixed','baseline_baseline')
        print(json.dumps({'pinning':pinning,'rows':value['rows_per_query'],'cycles':value['main_thread_lifetime_cycles']}))
    raise SystemExit(0)

if '--analyze-only' in sys.argv:
    report=json.loads((here/'launch-control-results.json').read_text())
    assert all(len(x['measurements'])==rounds for x in report['cases'].values())
    report['analysis_warnings']=['The first post-collection analysis divided by a zero OS-accounted lifetime CPU sample. Its failure log and all 96 raw rounds are retained. Reanalysis launches no children. Any CPU-time contrast containing zero is unavailable as a whole; no nonzero-only estimate is substituted. Latency/cycle samples remain complete.']
else:
    for name,pinning,mapping in cells:
        for _ in range(2):
            for label in labels: run(name,pinning,mapping,label)
    for round in range(rounds):
        for name,pinning,mapping in order_for(round,cells):
            record={label:run(name,pinning,mapping,label) for label in order_for(round,labels)}
            report['cases'][cell_key(name,pinning,mapping)]['measurements'].append(record)
        if (round+1)%8==0:
            (here/'launch-control-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
            print('Diagnostic quartets/cell:',round+1,flush=True)
rng=random.Random(10240529)
for key,case in report['cases'].items():
    result={}
    for name,(after,before) in {'first_file_labels':('fixed_baseline','baseline_baseline'),
                              'second_file_labels':('fixed_fixed','baseline_fixed'),
                              'end_labels':('fixed_fixed','baseline_baseline')}.items():
        result[name]={}
        for metric in ['full_seconds','main_thread_lifetime_cycles','main_thread_lifetime_cpu_seconds']:
            def value(d):
                if metric=='full_seconds': return sum(d[metric])
                if metric.endswith('cpu_seconds'):return d[metric]['total']
                return d[metric]
            zero_count=sum(value(x[before])<=0 or value(x[after])<=0 for x in case['measurements'])
            if zero_count:
                result[name][metric]={'available':False,'zero_accounted_time_pairs':zero_count,
                    'unavailable_reason':'OS CPU accounting granularity produces zero for short processes. All raw samples retained; do not discard zeros or divide by them.'}
                continue
            ratios=[value(x[after])/value(x[before]) for x in case['measurements']]
            blocks=[statistics.median(ratios[i:i+8]) for i in range(0,rounds,8)]
            boot=sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(10000))
            result[name][metric]={'paired_median_ratio':statistics.median(ratios),
                'block_median_ratio':statistics.median(blocks),'bootstrap_95_percent':[core.percentile(boot,.025),core.percentile(boot,.975)]}
    case['summary']=result
    print(key,json.dumps(result),flush=True)
report['completed_at']=datetime.now(timezone.utc).isoformat()
(here/'launch-control-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

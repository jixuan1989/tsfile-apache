from pathlib import Path
import bisect
import json
import re

here=Path(__file__).resolve().parent
locations=json.loads((here/'reader-linked-difference-locations.json').read_text())
symbols={}
for version in ['baseline','fixed']:
    table={}
    for line in (here/f'build/map_{version}.map').read_text().splitlines():
        m=re.match(r'\s+[0-9A-Fa-f]{4}:[0-9A-Fa-f]+\s+(\S+)\s+([0-9A-Fa-f]{16})\s',line)
        if m:table.setdefault(int(m[2],16),[]).append(m[1])
    symbols[version]=table

def instructions(path):
    lines=path.read_text().splitlines();result={}
    for line in lines:
        m=re.match(r'\s+([0-9A-F]{16}): (.*?) {2,}([a-z].*)$',line)
        if m:result[int(m[1],16)]=m[3]
    return result

rows=[]
for function in locations['functions']:
    start=int(function['start_rva'],16)
    variants={v:instructions(here/f'disassembly-{start:x}-{v}.txt') for v in ['baseline','fixed']}
    assert set(variants['baseline'])==set(variants['fixed'])
    addresses=sorted(variants['baseline'])
    changed=sorted(set(addresses[bisect.bisect_right(addresses,int(rva,16)+0x140000000)-1]
                       for rva in function['differing_rvas']))
    for address in changed:
        texts={v:d[address] for v,d in variants.items()}
        targets={v:[int(x,16) for x in re.findall(r'[0-9A-F]{16}',s)] for v,s in texts.items()}
        assert len(targets['baseline'])==len(targets['fixed'])==1,texts
        schematic={v:re.sub(r'[0-9A-F]{16}','<address>',s) for v,s in texts.items()}
        assert schematic['baseline']==schematic['fixed'],texts
        resolved={v:symbols[v].get(x[0],[]) for v,x in targets.items()}
        common=sorted(set(resolved['baseline'])&set(resolved['fixed']))
        assert common,(texts,resolved)
        rows.append({'instruction_address':hex(address),'raw_disassembly':texts,
                     'same_instruction_with_different_address_operand':True,
                     'common_map_target_symbols':common})
out={'method':'Map sidecar relinks were asserted to preserve original .text/.pdata exactly. For every instruction containing a differing code byte, decode via MSVC dumpbin and require equal instruction schematic and at least one identical exact-target linker symbol. This establishes address-reference differences, not identical cache behavior or identical referenced runtime data.',
     'differing_text_bytes':locations['differing_text_bytes'],'changed_instructions':len(rows),
     'all_changed_instructions_are_same_operations_addressing_common_symbols':True,'instructions':rows}
(here/'normalized-instruction-differences.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='instructions'},indent=2))

from pathlib import Path
import hashlib
import json
import zipfile

here=Path(__file__).resolve().parent
root=here.parent
base=root.parents[1]
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
item=next(x for x in state['drafts'] if x['id']=='02')
control=json.loads((here/'launch-control-results.json').read_text())
assert 'completed_at' in control and len(control['cases'])==12
assert all(len(x['measurements'])==96 and 'summary' in x for x in control['cases'].values())
assert control['execution_position_balance_asserted']
history=json.loads((here/'historical-stage-decomposition.json').read_text())
normalized=json.loads((here/'normalized-instruction-differences.json').read_text())
mixed=json.loads((here/'mixed-driver-query-code-comparison.json').read_text())
environment=json.loads((here/'environment-and-integrity.json').read_text())
assert normalized['all_changed_instructions_are_same_operations_addressing_common_symbols']
assert mixed['all_selected_equal'] and mixed['selected_functions']==30
negative=[];ab=[]
for key,v in control['cases'].items():
    for contrast,result in v['summary'].items():
        row={'cell':key,'contrast':contrast,**result['full_seconds']}
        (ab if v['mapping']=='baseline_vs_fixed' else negative).append(row)
negative_up=[x for x in negative if x['bootstrap_95_percent'][0]>1]
negative_down=[x for x in negative if x['bootstrap_95_percent'][1]<1]
ab_up=[x for x in ab if x['bootstrap_95_percent'][0]>1]
ab_down=[x for x in ab if x['bootstrap_95_percent'][1]<1]

def fmt(d):
    lo,hi=d['bootstrap_95_percent']
    return f'{d["block_median_ratio"]:.5f} [{lo:.5f}, {hi:.5f}]'

summary={'pr_number':item['pr_number'],'source_head':item['head_commit'],'production_unchanged':True,
         'query_gate_cleared':False,'diagnostic_cases':12,'quartets_per_case':96,
         'fully_checked_measured_child_processes':12*96*4,'queries_per_process':3,
         'negative_control_contrasts':len(negative),'negative_control_above_one':len(negative_up),
         'negative_control_below_one':len(negative_down),'actual_ab_contrasts':len(ab),
         'actual_ab_above_one':len(ab_up),'actual_ab_below_one':len(ab_down),
         'negative_control_signals':negative_up+negative_down,'actual_ab_upward_signals':ab_up,
         'disposition':'Diagnostic narrowing only; retain earlier 0.4-0.7% observations. No unqualified query-gate pass or causal production fix.'}
text=f'''# TsFile PR #{item['pr_number']}: query signal diagnosis

Tested head `{item['head_commit']}`; baseline `1180b13675e11a0230708af2cc70d037e0e12623`. Production code, the six measured original binaries, and their source checkouts remain unchanged/clean. This report supplements the previous query backfill and preserves its small dense-DOUBLE slowdown and later contradictory controls. The query gate remains qualified; no universal or zero-regression claim is made.

## Retained measurements: where was the earlier difference?

Retrospective decomposition uses every original 192-quartet confirmation sample, with 24 chronological blocks of eight. `consume_validate_close` is full-result time minus open, explicit cached schema lookup and plan time. It combines native read/decode, application materialization/verification and cleanup; it is not pure decoder timing. Component medians are not additive. These exploratory subcomponents reuse the same processes and do not form independent confirmation evidence.

| Case | Contrast | Full paired median delta/query (µs) | Consume/validate/close delta/query (µs) | Open delta/query (µs) |
|---|---|---:|---:|---:|
'''
for name,contrasts in history['cases'].items():
    if 'null0' not in name:continue
    for key in ['reader_on_fixed_file','end_to_end']:
        v=contrasts[key]
        text+=f'| `{name}` | `{key}` | {v["full_seconds"]["median_delta_seconds_per_query"]*1e6:.3f} | {v["consume_validate_close_seconds"]["median_delta_seconds_per_query"]*1e6:.3f} | {v["open_seconds"]["median_delta_seconds_per_query"]*1e6:.3f} |\n'
text+='''
The retained difference predominantly occurs after query construction (roughly 13–25 µs/query in these comparisons), rather than a stable file-open increase. It remains incorrect to replace these original observations with the later opposite-direction samples.

## What actually differs in linked reader code?

Linker-map sidecars are generated from the original single reader object and pinned libraries. Their `.text` and `.pdata` are asserted byte-identical to the previously measured executables; `.rdata` differences are verified to occur only in PE debug-directory build timestamps. The maps therefore describe those original code layouts. All 60 differing `.text` bytes lie in **52 instructions**. MSVC dumpbin decoding verifies each changed instruction has the same operation/operand form and references at least one common, exact-target linker symbol in both executables. Examples are shifted `__imp_free` import slots and metadata vtable addresses. This is stronger evidence than comparing raw, pre-relocation COFF sections alone. It does not establish identical referenced runtime data, memory/cache behavior, imported function runtime placement, or wall time.

For the original mixed caller, 30 selected query/verification/main/cleanup function sections also have identical raw code and relocation `(offset, type, target symbol)` triples. Writer functions and all other helper functions are outside that selection. Earlier seven-reader-object raw code equality remains in the preceding evidence. These checks narrow the investigation to linked references/layout and execution conditions; they do not identify a causal fix or justify modifying production alignment/padding.

## Fixed diagnostic protocol

The finite protocol was saved before samples: two dense aligned DOUBLE cases (row and batch), three binary mappings (actual baseline/fixed, baseline/baseline, fixed/fixed), and two launch methods. Each of the **12 cells** runs **96 four-label process quartets**, after two warmups per label. Each child executes three complete verified queries. Both original precision-2 products are byte-identical; every label reads the same fixed-produced file, so this is a same-file reader diagnosis, not writer-product performance.

The `after_create` mode sets affinity immediately after CreateProcess returns. The `before_resume` mode creates the process suspended, sets and checks affinity, then resumes its initial thread. The latter removes the opportunity for child initialization to run before affinity is set. This experiment does not prove that such a race occurred in old runs. Both modes use the same Windows CreateProcess wrapper, redirects, binary arguments, affinity mask 12 and pool size 2. Execution positions are asserted balanced for labels and cells before measurement.

AMD Ryzen 9 9900X, Windows, MSVC 14.50 Release/static and CPython 3.12.14. The recorded topology confirms logical processors 2 and 3 (mask 12) are **SMT siblings on one physical core**. Previous reports correctly named logical CPUs; this is not two-physical-core scaling. The filesystem cache is warm. The interactive host is not an isolated laboratory; background load, clock/power state and cache effects are not controlled hardware-counter measurements.

Each child checks all 65,536 rows × four projected fields, timestamps, types, values and NULL positions. Python independently checks aggregate rows and checksum. The same original, Java-audited input file is used; this round does not add a Java-writer matrix, production coverage run, sanitizer suite or writer benchmark.

Main-thread lifetime cycle count, OS-accounted main-thread/process CPU time and whole child-process wall time are additional diagnostics. They include initialization, printing and exit; they are **not query-only CPU costs**. QueryThreadCycleTime is hardware-dependent and is not retired instruction count or a calibrated clock-frequency estimate. Some short processes have zero OS-accounted CPU time, so any CPU-time contrast containing such samples is unavailable as a whole; no nonzero-only estimate is substituted. The first post-collection analyzer divided by such a zero: its failure log is retained, then analysis was repaired without launching any additional children or replacing any samples. Full-result timing remains the unchanged driver measurement. Confidence intervals resample 12 chronological blocks of eight quartets (10,000 bootstrap draws). All initial, outlier and negative-control samples are retained. No multiplicity-adjusted inference or formal non-inferiority test is claimed.

## Diagnostic results

Ratios are later-label/earlier-label time. For actual A/B mappings this is fixed/baseline; for A/A and F/F both labels execute the very same binary. Brackets are block-bootstrap 95% intervals. A negative-control interval excluding one demonstrates uncertainty in this measurement setup; it cannot be a production source regression.

| Case | Launch affinity | Binary mapping | First label-pair full latency | Second label-pair full latency | End-label full latency | End-label main-thread lifetime cycles |
|---|---|---|---|---|---|---|
'''
for key,v in control['cases'].items():
    s=v['summary'];name='row' if '_row_' in v['name'] else 'batch'
    text+=f'| {name} | `{v["pinning"]}` | `{v["mapping"]}` | {fmt(s["first_file_labels"]["full_seconds"])} | {fmt(s["second_file_labels"]["full_seconds"])} | {fmt(s["end_labels"]["full_seconds"])} | {fmt(s["end_labels"]["main_thread_lifetime_cycles"])} |\n'
text+=f'''
Across **{len(negative)} negative-control latency contrasts**, {len(negative_up)} intervals lie wholly above 1 and {len(negative_down)} wholly below 1. Across {len(ab)} actual A/B latency contrasts, {len(ab_up)} lie wholly above 1 and {len(ab_down)} wholly below 1. These are correlated exploratory contrasts, not independent hypothesis tests. The complete CPU-time/cycle and per-query arrays are included in the archive.

In particular, all four actual-A/B **end-label** latency comparisons have confidence intervals wholly above one: row queries increase approximately 0.5–0.6%, and batch queries approximately 0.8–1.0% by block medians. Both post-create and pre-resume affinity modes show this direction, so affinity timing alone does not explain the signal in this round. Same-binary controls must be consulted alongside those comparisons; these diagnostics do not justify dismissing the actual difference as noise. The original opposite-direction factorial measurements are also retained, so stability across sessions remains a limit.

## Disposition and limits

The new evidence narrows the code differences and quantifies same-binary/launch controls. It neither erases the earlier 0.4–0.7% signal nor establishes a specific query-source defect. No speculative production change is made. **The strict query gate stays qualified and uncleared** pending a justified resolution/acceptance criterion; earlier correctness, compatibility, coverage and write-performance evidence retains its original scope. New upstream source submission is not justified by these diagnostics alone.

This is a finite diagnostic experiment rather than repeated sampling until a passing result appears. Further timing should have a stated causal hypothesis and stopping rule. An engineering acceptance margin would require an explicit decision and prospective validation; this report does not silently introduce one. Cold-cache behavior, P99, broad parallel scaling, compressed-query performance and large-corpus generalization remain outside this experiment.

## Reproduction and artifacts

The archive includes the fixed pre-sample plan, all raw diagnostic arrays and execution order, stage analysis/source, code/relocation comparisons, original linked-address maps and dumpbin output, environment/binary integrity checks, the retained original confirmation input, and the same actual DOUBLE input file. It references the previously published full backfill for the pinned static-library builds and earlier correctness/Java/coverage/write results. Build the map helper with CMake Release using the original compiled reader object; its exact-code assertion must pass. Run `analyze_history.py`, `map_differences.py`, `normalize_disassembly.py`, `compare_driver_code.py`, `capture_environment.py`, then `launch_control.py` with CPython on Windows. `launch_control.py --smoke` validates the two launch modes first. Local source/library/tool paths are preserved and need adaptation on another machine; any recompiled driver is a new measurement artifact.

## 中文说明

本轮没有生产代码修改，原有六个查询程序哈希及两个源码目录状态均核对一致。历史复查中的约 0.4%–0.7% 差异主要位于读取/解码、物化校验与关闭阶段，约每次 13–25 微秒；打开文件没有稳定变慢。该分项不是纯 decoder 计时，也不是独立于旧数据的新证据。

通过保持原始 `.text`/`.pdata` 字节一致的旁路链接生成地址映射，确认独立 reader 的 60 个差异字节位于 52 条指令，全部只改变引用地址、仍指向同名符号（如 `__imp_free` 与元数据虚表）。原混合程序选查的 30 个查询/校验/main/清理函数，链接前代码及重定位目标一致。该结果缩小了排查范围，但不能证明缓存、导入函数运行地址和数据布局性能一致，也没有确认根因。

诊断计划在采样前固定：行/批两场景 × 真实前后版本/原版自身/修复版自身三种映射 × 启动后绑核/恢复执行前绑核两种方法，共 12 组，每组 96 轮四标签、每进程三次完整结果核验。总计 4,608 个计时子进程、13,824 次查询；另有各标签两轮预热。位置均衡先断言通过，所有样本保留。同一文件由两版读取，未重复冒充 writer 产物对照；亲和性 12 对应同一物理核的两个 SMT 逻辑处理器。

主线程生命周期周期数/CPU 时间包含初始化、输出和退出，不能替代查询区间 CPU 计时或退休指令数。短进程的部分 OS CPU 计时为零，对应 CPU 时间比较整体标为不可用，不剔除零值再作估计。最初分析在全部采样结束后因此出现除零，失败日志保留；修正后仅重新分析，没有重跑子进程或替换样本。上述表格保留全部同版本负对照与真实比较，置信区间按 12 个连续时间块重采样，未做多重比较校正。{len(negative)} 个同版本延迟比较中 {len(negative_up)} 个区间完全大于 1、{len(negative_down)} 个完全小于 1；{len(ab)} 个真实前后版本比较中分别为 {len(ab_up)}、{len(ab_down)} 个。不能把同一二进制自身出现的测量差异解释为生产代码退化。

旧的小幅差异及相反方向结果始终保留，**查询性能门槛仍有保留，未标为通过**。本轮辅助诊断不产生新的覆盖率、完整 sanitizer、Java writer 或写入性能结论。进一步测量应围绕可验证的因果假设并设定停止规则；若采用工程允许误差，须明确决定后再预先定义验证标准，不能为得到通过结果事后改变标准。

本轮四项真实前后版本的末标签延迟比较，其置信区间均完全大于 1：行模式区块中位数约慢 0.5%–0.6%，批模式约慢 0.8%–1.0%；两种绑核方法均存在。因此，启动绑核时机不能单独解释这批样本，不能把差异直接归为噪声。旧的反向控制结果也继续保留，不因此声称所有轮次稳定一致。
'''
footer=state['workflow']['ai_disclosure']['pr_footer']
report_path=base/'outputs/TsFile_PR_02_查询性能诊断报告.md'
report_path.write_text(text+'\n'+footer+'\n',encoding='utf-8')
(here/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
files={}
for p in here.iterdir():
    if p.is_file() and p.suffix in {'.py','.json','.txt','.log'} and p.name not in ['publication.json','github-request.json','launch-child.log'] and not p.name.startswith('github-'):
        files['diagnosis/'+p.name]=p
for p in (here/'build').glob('*.map'):files['diagnosis/build/'+p.name]=p
for name in ['query-performance-02-confirmation.json','plan.json','query_benchmark.cc','reader_only.cc','benchmark.py','tested-artifact-hashes.json']:
    files['query-backfill/'+name]=root/name
files['diagnosis/CMakeLists.txt']=here/'CMakeLists.txt'
fixture=json.loads((root/'plan.json').read_text())['fixtures']['02_DOUBLE_aligned_p2_null0_props0']
actual=Path(fixture['paths']['fixed']);files['query-backfill/data/'+actual.name]=actual
files['validation-report.md']=report_path
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()}
archive=base/'outputs/TsFile_PR_02_查询性能诊断证据.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,p in files.items():z.write(p,name)
    z.writestr('evidence-manifest.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=True,indent=2))

from pathlib import Path
import bisect
import hashlib
import json
import re
import struct
import subprocess

here = Path(__file__).resolve().parent
root = here.parent
dumpbin = 'D:/software/visualstudio2026/buildtools/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/dumpbin.exe'

def pe(path):
    data = path.read_bytes()
    offset = struct.unpack_from('<I',data,0x3c)[0]
    count = struct.unpack_from('<H',data,offset+6)[0]
    optional = struct.unpack_from('<H',data,offset+20)[0]
    result = {}
    for i in range(count):
        at = offset+24+optional+i*40
        name = data[at:at+8].split(b'\0')[0].decode('ascii')
        virtual_size,rva,size,raw = struct.unpack_from('<IIII',data,at+8)
        result[name] = {'rva':rva,'data':data[raw:raw+size], 'virtual_bytes':virtual_size}
    debug_rva,debug_size=struct.unpack_from('<II',data,offset+24+112+6*8)
    result['_debug_timestamp_bytes']=set(debug_rva+i+4+j for i in range(0,debug_size,28) for j in range(4))
    return result

images, maps = {}, {}
for version in ['baseline','fixed']:
    original = pe(root/f'reader-only/build/Release/read_only_02_{version}.exe')
    linked = pe(here/f'build/Release/map_{version}.exe')
    assert original['.text']['data'] == linked['.text']['data'], version
    assert original['.pdata']['data'] == linked['.pdata']['data'], version
    # IMAGE_DEBUG_DIRECTORY timestamps change on the map-only relink.
    oa,la=original['.rdata'],linked['.rdata']
    assert oa['rva']==la['rva'] and len(oa['data'])==len(la['data'])
    differences={oa['rva']+i for i,(x,y) in enumerate(zip(oa['data'],la['data'])) if x!=y}
    assert differences <= original['_debug_timestamp_bytes'] & linked['_debug_timestamp_bytes'], version
    images[version] = original
    symbols = []
    for line in (here/f'build/map_{version}.map').read_text().splitlines():
        m = re.match(r'\s+[0-9A-Fa-f]{4}:[0-9A-Fa-f]+\s+(\S+)\s+([0-9A-Fa-f]{16})\s',line)
        if m: symbols.append((int(m[2],16)-0x140000000,m[1]))
    maps[version] = sorted(symbols)
a,b = images['baseline']['.text'],images['fixed']['.text']
offsets = [i for i,(x,y) in enumerate(zip(a['data'],b['data'])) if x != y]
pdata = images['baseline']['.pdata']['data']
ranges = [struct.unpack_from('<III',pdata,i) for i in range(0,len(pdata)-11,12)]
functions = {}
for offset in offsets:
    rva = a['rva']+offset
    candidates = [x for x in ranges if x[0] <= rva < x[1]]
    assert len(candidates) <= 1, hex(rva)
    if candidates:
        start,end,unwind = candidates[0]
    else:
        addresses = sorted(set(x[0] for x in maps['baseline']))
        index = bisect.bisect_right(addresses,rva)-1
        start,end = addresses[index:index+2]
    functions.setdefault((start,end),[]).append(rva)
report = {'map_relinks_preserve_original_text_and_pdata':True,
          'map_relink_rdata_differences_only_in_debug_directory_timestamps':True,
          'differing_text_bytes':len(offsets),'functions':[]}
for (start,end),rvas in functions.items():
    names = {}
    for version,symbols in maps.items():
        index = bisect.bisect_right([x[0] for x in symbols],start)-1
        names[version] = symbols[index]
        p = subprocess.run([dumpbin,'/NOLOGO','/DISASM:BYTES',f'/RANGE:0x{0x140000000+start:x},0x{0x140000000+end-1:x}',
                            str(root/f'reader-only/build/Release/read_only_02_{version}.exe')],capture_output=True)
        assert p.returncode == 0
        (here/f'disassembly-{start:x}-{version}.txt').write_bytes(p.stdout)
    report['functions'].append({'start_rva':hex(start),'end_rva':hex(end),'nearest_map_symbols':names,
                                'differing_rvas':[hex(x) for x in rvas]})
(here/'reader-linked-difference-locations.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))

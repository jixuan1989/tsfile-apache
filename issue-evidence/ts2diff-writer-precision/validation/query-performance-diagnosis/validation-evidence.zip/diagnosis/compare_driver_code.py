from pathlib import Path
import hashlib
import json
import struct

here=Path(__file__).resolve().parent
root=here.parent

def load(path):
    d=path.read_bytes()
    big=d[:4]==b'\0\0\xff\xff'
    start=56 if big else 20
    count=struct.unpack_from('<I' if big else '<H',d,44 if big else 2)[0]
    sym_offset,sym_count=struct.unpack_from('<II',d,48 if big else 8)
    sym_size=20 if big else 18
    strings=sym_offset+sym_count*sym_size
    names={};details={};index=0
    while index<sym_count:
        at=sym_offset+index*sym_size
        if d[at:at+4]==b'\0'*4:
            off=struct.unpack_from('<I',d,at+4)[0]
            text=d[strings+off:].split(b'\0',1)[0].decode('utf-8')
        else:text=d[at:at+8].split(b'\0',1)[0].decode('utf-8')
        section=struct.unpack_from('<i' if big else '<h',d,at+12)[0]
        names[index]=text;details[index]=(text,section)
        index+=1+d[at+sym_size-1]
    selected={}
    for index,(name,section) in details.items():
        if section<=0:continue
        if not (name.startswith(('?read_fixture@@','?cell@Verifier@@','?next@Verifier@@','?time@Verifier@@',
                                  '?is_null_value@@','?value_at@@','?elapsed@@','?emit_array@@','?peak_memory@@',
                                  '?require@@','?check@@')) or ('?dtor$' in name and 'read_fixture' in name) or name=='main'):continue
        at=start+40*(section-1)
        flags=struct.unpack_from('<I',d,at+36)[0]
        if not flags & 0x20:continue
        size,raw,reloc=struct.unpack_from('<III',d,at+16)
        reloc_count=struct.unpack_from('<H',d,at+32)[0]
        relocations=[]
        for i in range(reloc_count):
            address,target,kind=struct.unpack_from('<IIH',d,reloc+i*10)
            relocations.append([address,kind,names[target]])
        payload=d[raw:raw+size]
        selected[name]={'bytes':size,'sha256':hashlib.sha256(payload).hexdigest(),'relocations':relocations}
    return selected

data={v:load(root/f'build/query_02_{v}.dir/Release/query_benchmark.obj') for v in ['baseline','fixed']}
assert data['baseline'].keys()==data['fixed'].keys()
rows={name:{'bytes':a['bytes'],'raw_code_equal':a['sha256']==b['sha256'],
            'relocation_targets_equal':a['relocations']==b['relocations'],
            'baseline':a,'fixed':b} for name,a in data['baseline'].items() for b in [data['fixed'][name]]}
report={'method':'Original mixed-caller object files: compare selected query/verification/cleanup/main function section bytes and relocation (offset,type,target symbol) triples before link. Writer functions excluded. No assertion about final link placement or all other helper functions.',
        'selected_functions':len(rows),'all_selected_equal':all(x['raw_code_equal'] and x['relocation_targets_equal'] for x in rows.values()),'functions':rows}
(here/'mixed-driver-query-code-comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'selected_functions':len(rows),'all_selected_equal':report['all_selected_equal'],
                  'different':[k for k,v in rows.items() if not v['raw_code_equal'] or not v['relocation_targets_equal']]}))

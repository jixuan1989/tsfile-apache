"""Localize retained historical timings without collecting replacement samples."""
from pathlib import Path
import json
import random
import statistics
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmark import percentile

root = Path(__file__).resolve().parents[1]
source = json.loads((root/'query-performance-02-confirmation.json').read_text(encoding='utf-8'))
rng = random.Random(10240529)
report = {'method': 'Retrospective decomposition of all retained 192-quartet confirmation data; no replacement samples. 24 chronological blocks of 8 quartets, bootstrapped as blocks. Consume/validation/close is full minus open, cached metadata and plan. Per-repeat comparisons are exploratory and share the same processes.', 'cases': {}}
for name, case in source['cases'].items():
    output = {}
    for contrast, definition in case['summary']['contrasts'].items():
        before, after = definition['before'], definition['after']
        output[contrast] = {}
        for metric in ['full_seconds', 'open_seconds', 'metadata_seconds', 'plan_seconds', 'consume_validate_close_seconds']:
            def values(d):
                if metric == 'consume_validate_close_seconds':
                    return [f-o-m-p for f,o,m,p in zip(d['full_seconds'], d['open_seconds'], d['metadata_seconds'], d['plan_seconds'])]
                return d[metric]
            a = [values(p[before]) for p in case['measurements']]
            b = [values(p[after]) for p in case['measurements']]
            ratios = [sum(y)/sum(x) for x,y in zip(a,b)]
            deltas = [sum(y)-sum(x) for x,y in zip(a,b)]
            blocks = [statistics.median(ratios[i:i+8]) for i in range(0,192,8)]
            boot = sorted(statistics.median(rng.choices(blocks,k=24)) for _ in range(20000))
            output[contrast][metric] = {
                'baseline_median_seconds_per_query': statistics.median([v for row in a for v in row]),
                'fixed_median_seconds_per_query': statistics.median([v for row in b for v in row]),
                'median_delta_seconds_per_query': statistics.median(deltas)/3,
                'block_median_ratio': statistics.median(blocks),
                'bootstrap_95_percent': [percentile(boot,.025),percentile(boot,.975)],
                'paired_median_ratio_by_query_index': [statistics.median(y[i]/x[i] for x,y in zip(a,b)) for i in range(3)]}
    report['cases'][name] = output
out = root/'diagnosis/historical-stage-decomposition.json'
out.write_text(json.dumps(report,indent=2)+'\n', encoding='utf-8')
for name, contrasts in report['cases'].items():
    if 'null0' not in name: continue
    print(name)
    for key in ['reader_on_fixed_file','end_to_end']:
        print(key, json.dumps(contrasts[key]))

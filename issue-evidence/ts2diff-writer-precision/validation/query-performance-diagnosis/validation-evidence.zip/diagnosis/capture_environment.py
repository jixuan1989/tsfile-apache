from pathlib import Path
from ctypes import wintypes
import ctypes
import hashlib
import json
import platform
import struct
import subprocess
import sys

here=Path(__file__).resolve().parent
root=here.parent
base=root.parents[1]
k=ctypes.WinDLL('kernel32',use_last_error=True)
size=wintypes.DWORD()
k.GetLogicalProcessorInformation(None,ctypes.byref(size))
buf=ctypes.create_string_buffer(size.value)
assert k.GetLogicalProcessorInformation(buf,ctypes.byref(size))
assert size.value%32==0
cores=[]
for i in range(0,size.value,32):
    mask,relationship=struct.unpack_from('<QI',buf.raw,i)
    if relationship==0:cores.append({'mask':mask,'logical_processors':[j for j in range(64) if mask&(1<<j)]})
original=json.loads((root/'tested-artifact-hashes.json').read_text(encoding='utf-8'))
hashes={}
for path in sorted(list((root/'build/Release').glob('query_*.exe'))+
                   list((root/'reader-only/build/Release').glob('read_only_*.exe'))):
    key=path.relative_to(base).as_posix()
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    assert original['files'][key]['sha256']==digest
    hashes[key]=digest
record={'captured_python':sys.version,'platform':platform.platform(),'processor':platform.processor(),
        'physical_core_masks':cores,'mask12_logical_processors':[2,3],
        'mask12_same_physical_core':any((x['mask']&12)==12 for x in cores),
        'tested_binary_sha256_unchanged':hashes,
        'library_heads':{}}
for key,repo in [('01','D:/code/tsfile'),('02',str(base/'work/issue-02/fix-repo'))]:
    head=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
    status=subprocess.check_output(['git','-C',repo,'status','--porcelain'],text=True).strip()
    assert head==original['sources'][key]['head'] and not status
    record['library_heads'][key]={'head':head,'clean':True}
(here/'environment-and-integrity.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'same_physical_core':record['mask12_same_physical_core'],'binaries_unchanged':len(hashes),'repos_clean':True}))

from pathlib import Path
import csv
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parent
base = root.parents[2]
source = root.parent / 'fix-repo'
out = base / 'outputs'
state = json.loads((base / 'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
coverage = json.loads((root / 'coverage-summary.json').read_text())
performance = json.loads((root / 'performance.json').read_text())
head = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert head != '1180b13675e11a0230708af2cc70d037e0e12623'
fingerprints = json.loads((root / 'source-fingerprints.json').read_text())
for name, digest in fingerprints['source'].items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
for name, digest in fingerprints['artifacts'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name

def tests(name):
    result = ET.parse(root / name).getroot()
    skipped = len(result.findall('.//testcase/skipped'))
    attrs = {k: int(result.get(k, '0')) for k in ['tests', 'failures', 'disabled', 'errors']}
    return {**attrs, 'skipped': skipped, 'passed': attrs['tests'] - attrs['failures'] - attrs['disabled'] - skipped}

counts = {side: len(list(csv.DictReader((root / f'native-{side}-fixtures/manifest.csv').open(encoding='utf-8')))) for side in ['java','cpp']}
test_results = {name: tests(name) for name in ['baseline-regressions.xml','fixed-regressions.xml','fixed-focused.xml','windows-all-tests.xml','linux-all-tests.xml']}
assert test_results['baseline-regressions.xml']['failures'] == 33
assert test_results['fixed-regressions.xml']['passed'] == 49
assert test_results['fixed-focused.xml']['passed'] == 54
for name, result in test_results.items():
    if not name.startswith('baseline'):
        assert result['failures'] == result['errors'] == 0
linux_xml = ET.parse(root / 'linux-all-tests.xml').getroot()
for fixture_test in ['GenerateFixtures', 'ValidateFixtures']:
    cases = [x for x in linux_xml.findall('.//testcase') if x.get('name') == fixture_test]
    assert len(cases) == 1 and cases[0].find('skipped') is None
assert counts == {'java': 135, 'cpp': 117}
assert 'OK (2 tests)' in (root / 'native-java-validate.log').read_text()
assert 'exact_wire_bytes=122 result=PASS' in (root / 'java-reads-cpp-wire.log').read_text()
assert 'total_reads=64 result=PASS' in (root / 'full-file-compatibility.log').read_text()
assert 'BUILD SUCCESS' in (root / 'format-check.log').read_text()
assert coverage['changed_production']['line_percent'] >= 90
assert len(performance['cases']) == 4
for case in performance['cases'].values():
    assert len(case['measurements']) == 25
    assert case['summary']['bootstrap_95_percent'][0] <= 1, 'Investigate statistically resolved slowdown before publishing'

def coverage_row(label, item):
    return f'| {label} | {item["covered_lines"]}/{item["executable_lines"]} ({item["line_percent"]:.2f}%) | {item["covered_branches"]}/{item["branches"]} ({item["branch_percent"]:.2f}%) |'

coverage_rows = [coverage_row('修改的生产可执行行', coverage['changed_production'])]
for name, item in sorted(coverage['per_file'].items()):
    coverage_rows.append(coverage_row(f'`{name}` 整个文件', item['whole_file']))
performance_rows = []
memory_rows = []
ratios = []
for name, case in performance['cases'].items():
    item = case['summary']; lo, hi = item['bootstrap_95_percent']
    ratios.append(f'{item["paired_median_latency_ratio"]:.4f}')
    performance_rows.append(f'| {name} | {item["baseline"]["median_seconds"]*1000:.3f} | {item["fixed"]["median_seconds"]*1000:.3f} | {ratios[-1]} | [{lo:.4f}, {hi:.4f}] |')
    memory_rows.append(f'| {name} | {item["baseline"]["median_rows_per_second"]:,.0f} | {item["fixed"]["median_rows_per_second"]:,.0f} | {item["baseline"]["median_peak_working_set_bytes"]:,} | {item["fixed"]["median_peak_working_set_bytes"]:,} |')

windows = test_results['windows-all-tests.xml']
linux = test_results['linux-all-tests.xml']
report = f'''# TsFile #1020 本地验证报告

基线：`1180b13675e11a0230708af2cc70d037e0e12623`。修复提交：`{head}`。

输入值 `1.23456`，FLOAT/DOUBLE TS_2DIFF 的 `max_point_number=0` 原来写入后读回 `1.23`，现在与 Java 一致为 `1.0`；精度 `4` 从 `1.23` 修正为 `1.2346`。修复显式复制注册 schema 的属性，将其传至 chunk/page writer 与 encoder factory；保留旧接口重载和类布局。参数仅在初始化解析。极大精度下零乘无穷产生 NaN，增加 Java Math.round 对应的返回零处理。

## 正确性

同一组 49 项 writer 回归使用原版头文件/静态库时 33 项失败、16 项通过；修复后 49 项全部通过。48 项参数化案例覆盖 FLOAT/DOUBLE × 对齐/非对齐 × 复制/转移所有权 schema × Tablet/record × 精度 0/4/default，各 520 行、页上限 17、两次 chunk flush；另有表 value chunk 直接编码检查。另新增 5 项编码器测试，覆盖 35 个解析边界、其他 codec/type、跨页 reset、无穷缩放系数下的正/负零及整数饱和/舍入边界，共 54 项。

| 全量回归 | 通过 | 跳过 | 原有禁用 | 失败 |
|---|---:|---:|---:|---:|
| Windows x64 / MSVC 14.50 / Release / 静态库 | {windows['passed']} | {windows['skipped']} | {windows['disabled']} | 0 |
| Linux GCC / Debug / 原子 gcov | {linux['passed']} | {linux['skipped']} | {linux['disabled']} | 0 |

Linux 启用 SNAPPY、LZ4、LZOKAY、ZLIB、ZSTD、LZMA2；Windows 关闭可选压缩库。两者均启用线程和内存统计，关闭 ANTLR、SIMD 和 BUILD_TOOLS，本地批次不包含 CLI E2E。Linux 配置跨语言夹具后两项互通测试实际执行；仍跳过外部数据集索引测试。

## Java 兼容

- 最新基线 Java Maven `CompatibilityTest` 两项通过，JDK 24。
- 122 组 FLOAT/DOUBLE 编码页，每页 260 个值，跨 TS_2DIFF block；Java 写 C++ 读，C++ 写 Java 读，并逐字节比较编码页，122 组全部相同。
- 属性包括缺失键、无关键、0/2/4/9/1000、int-max、溢出、合法负数、符号、空白、内嵌 NUL、补充字符数字及 Java 接受的全部 BMP 数字字符“4”。输入包含正负有限值、正负零、极小值、NaN、无穷、FLOAT/DOUBLE 最大最小值。
- 完整 tree TsFile：FLOAT/DOUBLE × 对齐/非对齐 × 精度 0/2/4/default，共 16 组配置，Java/C++ 各写一份，32 个文件、64 次自身/交叉读取全部通过。
- 原生表模型互通：C++ 读取 135 个 Java 文件，Java 读取 117 个 C++ 文件；包括真实 UNCOMPRESSED/LZ4/ZSTD/LZMA2 数据压缩。仅 CSV 清单换行规范化，TsFile 二进制不改动。
- 表属性序列化仍由独立 #1017 / #1018 处理，本分支不包含那项修改；本项表精度回归直接核对编码页。当前证据对应已列的参数、类型和读写路径，不代表整个 C++ 库与 Java 所有功能完全等价。

## 覆盖率

采用全新 GCC `--coverage -fprofile-update=atomic` 构建，全量测试完成后收集 gcovr。初次普通计数构建出现 GCC 负分支计数错误，旧错误日志单独保留；最终原子计数报告未忽略解析错误、未裁剪负数、未排除异常或错误分支。

| 范围 | 行覆盖率 | 分支覆盖率 |
|---|---|---|
{chr(10).join(coverage_rows)}

新增/修改行按 `git diff --unified=0 1180b13675e11a0230708af2cc70d037e0e12623 -- cpp/src` 的新行集合，与 gcov 可执行行相交。构建复制头文件时先验证源码/副本字节及 SHA-256 相同，再按物理行及 source-block/branch 编号合并。统计包含完整旧模块，不能将其局部结果当作全库覆盖。未覆盖的分支主要涉及内存分配、异常及错误注入路径；完整明细见 coverage-summary.json。

## 性能

同机同 MSVC 14.50 Release 配置、静态库、线程/内存统计启用，时间和值列均 UNCOMPRESSED。两边编译同一份独立 benchmark_driver.cc，使用相同选项，分别链接原版和修复库。record 每组 500,000 行、Tablet 每组 5,000,000 行，每变体预热两次，25 轮交错先后顺序，均固定 CPU 掩码 4。配对比值 bootstrap 10,000 次。计时包含 writer open/register/write/close，Tablet 构造与读回不计入写入耗时；每轮读回全部行并核对值。工作集包括整个进程及读回。最终性能测量期间本任务没有构建或覆盖率收集负载。

| 工作负载 | 基线中位 ms | 修复中位 ms | 配对耗时比中位数 | 配对比 95% CI |
|---|---:|---:|---:|---|
{chr(10).join(performance_rows)}

| 工作负载 | 基线行/s | 修复行/s | 基线峰值工作集中位 bytes | 修复峰值工作集中位 bytes |
|---|---:|---:|---:|---:|
{chr(10).join(memory_rows)}

本次四组有效输出工作负载未观察到可分辨的性能退化。原版非默认精度 0/4 的输出错误，无法提供等价输出的性能基线，因此性能对照使用原来有效的 default/2，分别覆盖 FLOAT/DOUBLE、aligned/nonaligned、record/Tablet。

排查过程也保留在验证包中：早期驱动只有修复版包含额外 wire 验证代码，可能改变链接实现和代码布局，该数据不作为库性能结论。换为相同的独立驱动后，下界判断方案仍复现 FLOAT 对齐 Tablet 变慢。最终实现将 NaN 纳入原有上界分支，使用现有 FORCE_INLINE 宏保持小舍入函数内联，并避免精度 2 的重复设置；以上表格为最终代码的完整四组测量。此前探索结果、对照和补丁均另行命名保留。

## 格式与证据

clang-format 17.0.6 对 14 份改动逐一检查通过；仓库 Spotless apply/check 通过；补丁空白检查通过。验证包保留失败与通过的日志/XML、编解码原始页和清单、完整文件、覆盖率原始 JSON 和合并脚本、全部性能原始样本与脚本、构建命令、格式日志及提交补丁。

{state['workflow']['ai_disclosure']['pr_footer']}
'''
(out / 'TsFile_PR_02_本地验证报告.md').write_text(report, encoding='utf-8')
(root / 'validation-report.md').write_text(report, encoding='utf-8')
summary = {'base_commit':'1180b13675e11a0230708af2cc70d037e0e12623', 'head_commit':head,
           'tests':test_results, 'native_fixture_counts':counts, 'wire_cases':122,
           'exact_wire_bytes':122, 'full_file_configurations':16, 'full_file_reads':64,
           'coverage':coverage, 'performance':{name:case['summary'] for name,case in performance['cases'].items()},
           'gates_passed':True}
(root / 'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
changed = coverage['changed_production']; parser = coverage['per_file']['cpp/src/encoding/encoding_props.h']['whole_file']
replacements = {'WINDOWS_PASS':windows['passed'], 'LINUX_PASS':linux['passed'], 'LINUX_SKIP':linux['skipped'],
                'JAVA_FILES':counts['java'], 'CPP_FILES':counts['cpp'], 'CHANGED_LINE':f'{changed["line_percent"]:.2f}',
                'CHANGED_COVERED':changed['covered_lines'], 'CHANGED_TOTAL':changed['executable_lines'],
                'CHANGED_BRANCH':f'{changed["branch_percent"]:.2f}', 'PARSER_LINE':f'{parser["line_percent"]:.2f}',
                'PARSER_BRANCH':f'{parser["branch_percent"]:.2f}', 'RATIOS':', '.join(ratios),
                'PERF_CONCLUSION':'No distinguishable regression was observed in these measured workloads.',
                'PERF_CONCLUSION_ZH':'本次所测工作负载未观察到可分辨的退化。', 'AI_FOOTER':state['workflow']['ai_disclosure']['pr_footer']}
template = (root / 'pr-body-template.md').read_text(encoding='utf-8')
for name, value in replacements.items():
    template = template.replace('{'+name+'}',str(value))
(root / 'pr-body-ready.md').write_text(template,encoding='utf-8')
patch = subprocess.check_output(['git','-C',str(source),'diff',summary['base_commit'],head],text=True)
(root / 'contribution.diff').write_text(patch,encoding='utf-8')
readme = f'''# Validation evidence for Apache TsFile #1020

Baseline: 1180b13675e11a0230708af2cc70d037e0e12623
Fixed source: {head}

Start with validation-report.md and validation-summary.json. performance.json is the final measurement using identical benchmark_driver.cc, 500,000 record rows / 5,000,000 Tablet rows, and 25 alternating pairs. Files prefixed performance-initial, performance-scaled, performance-combined, performance-lower, performance-upper or performance-no-nan are investigation records, not final performance claims. Their associated source differences are retained where applicable.

source-fingerprints.json records the 14 source hashes, benchmark source and measured Windows libraries/executables. These were checked again after the final tests. coverage-raw.json contains all collected physical source/build header records; summarize_coverage.py verifies byte identity before merging them. coverage-initial-negative-counts.log is the rejected initial counter report; coverage-collection.log and coverage-raw.json are from the successful final atomic build.

The scripts record the actual Windows x64 / MSVC 14.50, JDK 24 and Ubuntu 22.04 / GCC 11.4 environment used here. Their task-root/JDK paths must be adjusted on another machine. The benchmark uses Windows process affinity and PSAPI working-set statistics.

To rebuild, extract this archive to work/issue-02/validation in a new task folder. Create sibling baseline-source and fix-repo checkouts of the two commits above. Copy reproduction/precision_repro.cc to the parent issue-02 folder, as referenced by CMakeLists.txt. Build both cpp libraries into validation/msvc-baseline and validation/msvc-fixed with Release, static, tests on, tools/ANTLR/SIMD and optional codecs off, threads/memory statistics on. Configure CMakeLists.txt into validation/drivers and build Release; benchmark.py compares the two benchmark executables and checks every generated row on readback. Use an idle machine and retain all samples.

For Java, run Maven with -P with-java -pl java/tsfile -am -Dtest=CompatibilityTest -Dsurefire.failIfNoSpecifiedTests=false -Dspotless.skip=true test. Export java.class.path from the resulting Surefire XML to java-classpath.txt; compile PrecisionWireCompatibility.java and reproduction/PrecisionRepro.java into the validation folder. Generate the Java wire fixtures, run precision_fixed wire wire-fixtures, then run PrecisionWireCompatibility verify wire-fixtures. full_file_compatibility.py generates and cross-reads complete files in a fresh fixture directory. The classpath file itself is machine-specific and is regenerated rather than supplied.

build-linux.sh records the complete all-codec atomic coverage configure/build/test/collection command. Adjust its task root and dependency-cache location. Native Java/C++ fixtures are supplied with their manifests, and the upstream TableModelEncodingCompressionCompatibilityTest generator/validator can regenerate them. The full contribution.diff can be applied to the baseline; it includes both source and tests.
'''
(root / 'README.md').write_text(readme,encoding='utf-8')
package = out / 'TsFile_PR_02_验证证据.zip'
names = ['README.md','source-fingerprints.json','validation-report.md','validation-summary.json','baseline-regressions.log','baseline-regressions.xml',
         'fixed-regressions.log','fixed-regressions.xml','fixed-focused.log','fixed-focused.xml',
         'windows-all-tests.log','windows-all-tests.xml','linux-all-tests.log','linux-all-tests.xml',
         'native-java-generate.log','native-java-validate.log','java-wire-generate.log','java-reads-cpp-wire.log','cpp-wire.log',
         'full-file-compatibility.log','full-file-compatibility.json','coverage-raw.json','coverage-summary.json',
         'coverage-collection.log','coverage-initial-negative-counts.log','performance.json','performance.log',
         'performance-initial-regression.json','performance-initial-regression.log','performance-initial-implementation.diff',
         'performance-scaled-check.json','performance-scaled-check.log','performance-scaled-check.diff',
         'performance-combined-driver.json','performance-combined-driver.log','performance-identical-driver-short.json','performance-identical-driver-short.log',
         'performance-lower-guard.json','performance-lower-guard.log','performance-lower-guard.diff','performance-upper-guard.json','performance-upper-guard.log',
         'performance-no-nan-control.json','performance-no-nan-control.log',
         'format-check.log','linux-configure.log','linux-build.log','driver.cc','benchmark_driver.cc','CMakeLists.txt','PrecisionWireCompatibility.java','full_file_compatibility.py',
         'benchmark.py','summarize_coverage.py','build-linux.sh','prepare_delivery.py','production.diff','contribution.diff']
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        archive.write(root / name, name)
    for folder in ['wire-fixtures','full-file-fixtures-final-validated','native-java-fixtures','native-cpp-fixtures']:
        for path in (root / folder).rglob('*'):
            if path.is_file(): archive.write(path,str(path.relative_to(root)))
    for name in ['precision_repro.cc','PrecisionRepro.java']:
        archive.write(root.parent / name,'reproduction/'+name)
    archive.write(root.parent / 'java-build.log','java-build.log')
print(json.dumps({'gates_passed':True,'head':head,'coverage':changed,'evidence_bytes':package.stat().st_size},indent=2))

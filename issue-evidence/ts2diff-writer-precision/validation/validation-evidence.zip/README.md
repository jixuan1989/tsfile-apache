# Validation evidence for Apache TsFile #1020

Baseline: 1180b13675e11a0230708af2cc70d037e0e12623
Fixed source: 5f4bc79a6db4d6cf79eb089a9dabe0e1fc4e12bb

Start with validation-report.md and validation-summary.json. performance.json is the final measurement using identical benchmark_driver.cc, 500,000 record rows / 5,000,000 Tablet rows, and 25 alternating pairs. Files prefixed performance-initial, performance-scaled, performance-combined, performance-lower, performance-upper or performance-no-nan are investigation records, not final performance claims. Their associated source differences are retained where applicable.

source-fingerprints.json records the 14 source hashes, benchmark source and measured Windows libraries/executables. These were checked again after the final tests. coverage-raw.json contains all collected physical source/build header records; summarize_coverage.py verifies byte identity before merging them. coverage-initial-negative-counts.log is the rejected initial counter report; coverage-collection.log and coverage-raw.json are from the successful final atomic build.

The scripts record the actual Windows x64 / MSVC 14.50, JDK 24 and Ubuntu 22.04 / GCC 11.4 environment used here. Their task-root/JDK paths must be adjusted on another machine. The benchmark uses Windows process affinity and PSAPI working-set statistics.

To rebuild, extract this archive to work/issue-02/validation in a new task folder. Create sibling baseline-source and fix-repo checkouts of the two commits above. Copy reproduction/precision_repro.cc to the parent issue-02 folder, as referenced by CMakeLists.txt. Build both cpp libraries into validation/msvc-baseline and validation/msvc-fixed with Release, static, tests on, tools/ANTLR/SIMD and optional codecs off, threads/memory statistics on. Configure CMakeLists.txt into validation/drivers and build Release; benchmark.py compares the two benchmark executables and checks every generated row on readback. Use an idle machine and retain all samples.

For Java, run Maven with -P with-java -pl java/tsfile -am -Dtest=CompatibilityTest -Dsurefire.failIfNoSpecifiedTests=false -Dspotless.skip=true test. Export java.class.path from the resulting Surefire XML to java-classpath.txt; compile PrecisionWireCompatibility.java and reproduction/PrecisionRepro.java into the validation folder. Generate the Java wire fixtures, run precision_fixed wire wire-fixtures, then run PrecisionWireCompatibility verify wire-fixtures. full_file_compatibility.py generates and cross-reads complete files in a fresh fixture directory. The classpath file itself is machine-specific and is regenerated rather than supplied.

build-linux.sh records the complete all-codec atomic coverage configure/build/test/collection command. Adjust its task root and dependency-cache location. Native Java/C++ fixtures are supplied with their manifests, and the upstream TableModelEncodingCompressionCompatibilityTest generator/validator can regenerate them. The full contribution.diff can be applied to the baseline; it includes both source and tests.

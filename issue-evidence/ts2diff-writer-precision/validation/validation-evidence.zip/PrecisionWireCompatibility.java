import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.encoding.decoder.Decoder;
import org.apache.tsfile.write.schema.MeasurementSchema;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class PrecisionWireCompatibility {
  static void check(boolean valid, String message) { if (!valid) throw new AssertionError(message); }
  static void decode(byte[] bytes, TSDataType type, Path expected, boolean generate) throws Exception {
    Decoder decoder = Decoder.getDecoderByType(TSEncoding.TS_2DIFF, type);
    ByteBuffer input = ByteBuffer.wrap(bytes);
    try (var output = generate ? new DataOutputStream(Files.newOutputStream(expected)) : null;
         var reference = generate ? null : new DataInputStream(Files.newInputStream(expected))) {
      int rows = 0;
      while (decoder.hasNext(input)) {
        if (type == TSDataType.FLOAT) {
          float actual = decoder.readFloat(input);
          if (generate) output.writeInt(Float.floatToRawIntBits(actual));
          else { float value = Float.intBitsToFloat(reference.readInt()); check(Float.floatToIntBits(actual) == Float.floatToIntBits(value), "float row="+rows); }
        } else {
          double actual = decoder.readDouble(input);
          if (generate) output.writeLong(Double.doubleToRawLongBits(actual));
          else { double value = Double.longBitsToDouble(reference.readLong()); check(Double.doubleToLongBits(actual) == Double.doubleToLongBits(value), "double row="+rows); }
        }
        rows++;
      }
      check(rows == 260, "rows="+rows);
      if (!generate) check(reference.available() == 0, "trailing expected data");
    }
  }
  public static void main(String[] args) throws Exception {
    Path directory = Path.of(args[1]);
    Files.createDirectories(directory);
    if (args[0].equals("generate")) {
      List<String> properties = new ArrayList<>(Arrays.asList(null, "<unit>", "0", "2", "4", "9", "1000", "2147483647", "2147483648", "-2147483648", "-2147483649", "-4", "-0", "+4", "0004", "", " 4", "4 ", "+", "-", "4x", "4.0", "4\u0000", "\ud835\udfdc"));
      for (int code = 0; code <= 0xffff; code++) if (Character.digit((char) code, 10) == 4) properties.add(String.valueOf((char)code));
      List<String> manifest = new ArrayList<>();
      double[] values = {1.23456, -2.34567, 0.0, -0.0, 0.00001, -0.00001, Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Float.MAX_VALUE, Float.MIN_VALUE, Double.MAX_VALUE, Double.MIN_VALUE};
      for (TSDataType type : List.of(TSDataType.FLOAT, TSDataType.DOUBLE)) {
        for (int variant = 0; variant < properties.size(); variant++) {
          String property = properties.get(variant);
          String id = type + "_" + variant;
          int flag = property == null ? 0 : property.equals("<unit>") ? 2 : 1;
          Map<String,String> props = flag == 0 ? Map.of() : flag == 2 ? Map.of("unit","celsius") : Map.of("max_point_number",property);
          if (flag == 1) Files.writeString(directory.resolve(id+".prop"), property, StandardCharsets.UTF_8);
          var schema = new MeasurementSchema("v",type,TSEncoding.TS_2DIFF,CompressionType.UNCOMPRESSED,props);
          var encoder = schema.getValueEncoder();
          var output = new ByteArrayOutputStream();
          try (var input = new DataOutputStream(Files.newOutputStream(directory.resolve(id+".input")))) {
            for (int row = 0; row < 260; row++) {
              double value = values[row % values.length];
              if (type == TSDataType.FLOAT) { input.writeInt(Float.floatToRawIntBits((float)value)); encoder.encode((float)value,output); }
              else { input.writeLong(Double.doubleToRawLongBits(value)); encoder.encode(value,output); }
            }
          }
          encoder.flush(output);
          byte[] encoded = output.toByteArray();
          Files.write(directory.resolve(id+".java.bin"),encoded);
          decode(encoded,type,directory.resolve(id+".expected"),true);
          manifest.add(id+","+type+","+flag);
        }
      }
      Files.write(directory.resolve("manifest.csv"),manifest, StandardCharsets.UTF_8);
      System.out.println("java_wire_cases="+manifest.size()+" rows_per_page=260 generated=PASS");
    } else {
      int cases=0, exact=0;
      for (String line : Files.readAllLines(directory.resolve("manifest.csv"))) {
        String[] fields=line.split(",");
        byte[] cpp=Files.readAllBytes(directory.resolve(fields[0]+".cpp.bin"));
        decode(cpp,TSDataType.valueOf(fields[1]),directory.resolve(fields[0]+".expected"),false);
        if (Arrays.equals(cpp,Files.readAllBytes(directory.resolve(fields[0]+".java.bin")))) exact++;
        cases++;
      }
      System.out.println("java_reads_cpp_cases="+cases+" exact_wire_bytes="+exact+" result=PASS");
    }
  }
}

from pathlib import Path
import json
import re
import subprocess

root=Path(__file__).resolve().parent
classpath=(root/'java-classpath.txt').read_text(encoding='utf-8-sig').strip()+';'+str(root)
java=[r'C:\Program Files\Java\jdk-24\bin\java.exe','-cp',classpath,'PrecisionRepro']
cpp=[str(root/'drivers/Release/precision_repro.exe')]
files=root/'full-file-fixtures-final-validated'
files.mkdir(exist_ok=True)
records=[]
def run(arguments):
    result=subprocess.run(list(map(str,arguments)),capture_output=True,text=True,encoding='utf-8')
    records.append({'command':list(map(str,arguments)),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    (root/'full-file-compatibility.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if result.returncode: raise RuntimeError(result.stdout+'\n'+result.stderr)
    found=re.findall('output.value=([0-9.]+)',result.stdout)
    assert len(found)==1
    return found[0]
for data_type in ['FLOAT','DOUBLE']:
    for alignment in ['aligned','nonaligned']:
        for precision in ['0','2','4','default']:
            key=f'{data_type}-{alignment}-{precision}'
            java_file=files/(key+'-java.tsfile'); cpp_file=files/(key+'-cpp.tsfile')
            assert not java_file.exists() and not cpp_file.exists()
            expected={'0':'1.000000','4':'1.234600'}.get(precision,'1.230000')
            actual=[run([*java,'write',java_file,data_type,precision,alignment]),
                run([*cpp,'write',cpp_file,data_type,precision,alignment]),
                run([*java,'read',cpp_file,data_type,precision,alignment]),
                run([*cpp,'read',java_file,data_type,precision,alignment])]
            assert actual==[expected]*4, (key,actual)
            print(key+' all_four_reads='+expected+' PASS',flush=True)
print('full_file_configurations=16 files=32 total_reads=64 result=PASS',flush=True)

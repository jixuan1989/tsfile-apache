/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file for additional
 * information regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy at http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

std::string utf8(const wchar_t* text) {
    if (!text || !*text) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, text, -1, nullptr, 0, nullptr, nullptr);
    std::string out(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, text, -1, &out[0], n, nullptr, nullptr);
    out.pop_back(); return out;
}
std::string json(const std::string& text) {
    std::ostringstream out; out << '"';
    for (unsigned char c : text) {
        if (c == '"' || c == '\\') out << '\\' << c;
        else if (c < 32) { char b[8]{}; sprintf_s(b, "\\u%04x", c); out << b; }
        else out << c;
    }
    out << '"'; return out.str();
}
std::string guid(const GUID& g) {
    char b[64]{};
    sprintf_s(b, "%08lx-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x", g.Data1, g.Data2, g.Data3,
              g.Data4[0], g.Data4[1], g.Data4[2], g.Data4[3], g.Data4[4], g.Data4[5], g.Data4[6], g.Data4[7]);
    return b;
}
template<class T> T raw(const EVENT_RECORD* e, size_t offset) {
    T value{};
    if (offset+sizeof(value) <= e->UserDataLength) std::memcpy(&value, static_cast<const char*>(e->UserData)+offset, sizeof(value));
    return value;
}
struct Target { DWORD pid, tid; uint64_t begin, end; };
std::unordered_map<DWORD, std::vector<Target>> tids, pids;
bool target(DWORD id, uint64_t at, bool process = false, uint64_t allowance = 0) {
    const auto& table = process ? pids : tids;
    auto it = table.find(id); if (it == table.end()) return false;
    for (const auto& t : it->second) if (at+allowance >= t.begin && at <= t.end) return true;
    return false;
}
std::ofstream events, schemas;
struct Meta { std::vector<unsigned char> bytes; std::wstring name; std::vector<std::wstring> fields; };
std::map<std::string, Meta> metadata;
uint64_t event_count{}, pmc_events{}, pmc_target{}, samples{}, stacks{}, interval_errors{}, time_min = ~uint64_t{}, time_max{};
std::map<unsigned, uint64_t> counter_sizes;
struct Running { DWORD tid{}; uint64_t at{}; std::vector<uint64_t> counters; };
std::unordered_map<unsigned, Running> running;
std::unordered_map<DWORD, DWORD> thread_owners;
struct Exposure { uint64_t total{}, busy{}, own_worker{}, unknown_owner{}, cpu2{}, cpu3{}; };
std::unordered_map<DWORD, Exposure> exposures;
uint64_t pair_last{}, target_thread_starts{}, target_thread_ends{}, cpu_pair_chain_errors{};
bool callback_failed = false;

Meta& meta(EVENT_RECORD* e) {
    std::string key = guid(e->EventHeader.ProviderId)+":"+std::to_string(e->EventHeader.EventDescriptor.Id)+":"+
        std::to_string(e->EventHeader.EventDescriptor.Opcode)+":"+std::to_string(e->EventHeader.EventDescriptor.Version);
    auto found = metadata.find(key); if (found != metadata.end()) return found->second;
    Meta m;
    ULONG size{}; ULONG status = TdhGetEventInformation(e, 0, nullptr, nullptr, &size);
    if (status == ERROR_INSUFFICIENT_BUFFER) {
        m.bytes.resize(size);
        auto info = reinterpret_cast<TRACE_EVENT_INFO*>(m.bytes.data());
        status = TdhGetEventInformation(e, 0, nullptr, info, &size);
        if (status == ERROR_SUCCESS) {
            auto str = [&](ULONG offset) -> const wchar_t* { return offset ? reinterpret_cast<wchar_t*>(m.bytes.data()+offset) : L""; };
            m.name = str(info->TaskNameOffset); m.name += L"/"; m.name += str(info->OpcodeNameOffset);
            for (ULONG i = 0; i < info->TopLevelPropertyCount; ++i) m.fields.push_back(str(info->EventPropertyInfoArray[i].NameOffset));
        }
    }
    schemas << "{\"key\":" << json(key) << ",\"status\":" << status << ",\"name\":" << json(utf8(m.name.c_str())) << ",\"fields\":[";
    for (size_t i = 0; i < m.fields.size(); ++i) { if (i) schemas << ','; schemas << json(utf8(m.fields[i].c_str())); }
    schemas << "],\"all_properties\":[";
    if (status == ERROR_SUCCESS && !m.bytes.empty()) {
        auto info = reinterpret_cast<TRACE_EVENT_INFO*>(m.bytes.data());
        for (ULONG i = 0; i < info->PropertyCount; ++i) {
            if (i) schemas << ',';
            auto& p = info->EventPropertyInfoArray[i];
            schemas << "{\"name\":" << json(utf8(reinterpret_cast<wchar_t*>(m.bytes.data()+p.NameOffset))) << ",\"flags\":" << p.Flags;
            if (p.Flags & PropertyStruct) schemas << ",\"struct_start\":" << p.structType.StructStartIndex << ",\"members\":" << p.structType.NumOfStructMembers;
            else schemas << ",\"input_type\":" << p.nonStructType.InType;
            schemas << '}';
        }
    }
    schemas << "],\"user_length\":" << e->UserDataLength << ",\"extended\":[";
    for (USHORT i = 0; i < e->ExtendedDataCount; ++i) { if (i) schemas << ','; schemas << "[" << e->ExtendedData[i].ExtType << ',' << e->ExtendedData[i].DataSize << ']'; }
    schemas << "]}\n";
    // Local-only discovery of counter configuration, never process/image payloads.
    if ((m.name.find(L"Pmc") != std::wstring::npos || m.name.find(L"PMC") != std::wstring::npos || m.name.find(L"Counter") != std::wstring::npos) && e->EventHeader.EventDescriptor.Opcode != 46) {
        schemas << "{\"config_key\":" << json(key) << ",\"hex\":\"";
        for (USHORT i = 0; i < e->UserDataLength; ++i) { char b[3]{}; sprintf_s(b, "%02x", static_cast<unsigned char*>(e->UserData)[i]); schemas << b; }
        schemas << "\"}\n";
    }
    return metadata.emplace(key, std::move(m)).first->second;
}
std::vector<unsigned char> property(EVENT_RECORD* e, const Meta& m, const wchar_t* desired) {
    for (const auto& field : m.fields) if (_wcsicmp(field.c_str(), desired) == 0) {
        PROPERTY_DATA_DESCRIPTOR descriptor{}; descriptor.PropertyName = reinterpret_cast<ULONGLONG>(field.c_str()); descriptor.ArrayIndex = ULONG_MAX;
        ULONG size{};
        if (TdhGetPropertySize(e, 0, nullptr, 1, &descriptor, &size) != ERROR_SUCCESS) return {};
        std::vector<unsigned char> out(size);
        if (TdhGetProperty(e, 0, nullptr, 1, &descriptor, size, out.data()) != ERROR_SUCCESS) return {};
        return out;
    }
    return {};
}
template<class T> T number(EVENT_RECORD* e, const Meta& m, const wchar_t* name) {
    auto bytes = property(e, m, name); T value{};
    if (!bytes.empty() && bytes.size() <= sizeof(T)) std::memcpy(&value, bytes.data(), bytes.size());
    return value;
}
void list(const std::vector<uint64_t>& values) {
    events << '['; for (size_t i = 0; i < values.size(); ++i) { if (i) events << ','; events << values[i]; } events << ']';
}
void WINAPI callback(EVENT_RECORD* e) {
    try {
        ++event_count;
        uint64_t at = e->EventHeader.TimeStamp.QuadPart;
        time_min = std::min(time_min, at); time_max = std::max(time_max, at);
        unsigned cpu = e->BufferContext.ProcessorIndex;
        const auto& id = e->EventHeader.ProviderId;
        unsigned op = e->EventHeader.EventDescriptor.Opcode;
        Meta& m = meta(e);
        if (id.Data1 == 0x3d6fa8d1 && (op == 1 || op == 3) && e->UserDataLength >= 8) {
            DWORD pid = raw<DWORD>(e, 0), tid = raw<DWORD>(e, 4);
            thread_owners[tid] = pid;
            if (tids.count(tid) && pids.count(pid)) ++target_thread_starts;
        }
        if (id.Data1 == 0x3d6fa8d1 && op == 2 && e->UserDataLength >= 8 &&
            target(raw<DWORD>(e, 4), at) && pids.count(raw<DWORD>(e, 0))) ++target_thread_ends;
        if (id.Data1 == 0xce1dbfb4 && (op == 48 || op == 49)) {
            events << "{\"kind\":\"pmc_config\",\"opcode\":" << op << ",\"qpc\":" << at << ",\"data_hex\":\"";
            for (USHORT i = 0; i < e->UserDataLength; ++i) { char b[3]{}; sprintf_s(b, "%02x", static_cast<unsigned char*>(e->UserData)[i]); events << b; }
            events << "\"}\n";
        }
        std::vector<uint64_t> counters;
        for (USHORT i = 0; i < e->ExtendedDataCount; ++i) if (e->ExtendedData[i].ExtType == EVENT_HEADER_EXT_TYPE_PMC_COUNTERS) {
            auto& ext = e->ExtendedData[i];
            counters.resize(ext.DataSize/sizeof(uint64_t));
            std::memcpy(counters.data(), reinterpret_cast<void*>(ext.DataPtr), counters.size()*sizeof(uint64_t));
            ++pmc_events; ++counter_sizes[static_cast<unsigned>(counters.size())];
        }
        if (id.Data1 == 0x3d6fa8d1 && op == 36 && e->UserDataLength >= 8) {
            DWORD next = raw<DWORD>(e, 0), old = raw<DWORD>(e, 4);
            auto previous = running[cpu];
            if (cpu == 2 || cpu == 3) {
                if (previous.at && previous.tid != old) ++cpu_pair_chain_errors;
                if (pair_last && at >= pair_last) for (unsigned logical : {2U, 3U}) {
                    auto active = running[logical].tid;
                    auto it = tids.find(active);
                    if (it == tids.end()) continue;
                    for (const auto& t : it->second) {
                        uint64_t begin = std::max(pair_last, t.begin), end = std::min(at, t.end);
                        if (end <= begin) continue;
                        auto& x = exposures[active]; auto dt = end-begin; x.total += dt;
                        (logical == 2 ? x.cpu2 : x.cpu3) += dt;
                        auto sibling = running[logical == 2 ? 3 : 2].tid;
                        if (sibling) {
                            x.busy += dt;
                            auto owner = thread_owners.find(sibling);
                            if (owner == thread_owners.end()) x.unknown_owner += dt;
                            else if (owner->second == t.pid) x.own_worker += dt;
                        }
                    }
                }
                pair_last = at;
            }
            if (target(old, at)) {
                bool valid = previous.tid == old && previous.at < at && previous.counters.size() == counters.size() && !counters.empty();
                std::vector<uint64_t> delta;
                if (valid) for (size_t i = 0; i < counters.size(); ++i) {
                    if (counters[i] < previous.counters[i]) valid = false;
                    delta.push_back(counters[i]-previous.counters[i]);
                }
                events << "{\"kind\":\"interval\",\"tid\":" << old << ",\"begin\":" << previous.at << ",\"end\":" << at << ",\"cpu\":" << cpu << ",\"valid\":" << (valid ? "true" : "false") << ",\"delta\":";
                list(delta); events << "}\n";
                if (!valid) ++interval_errors;
            }
            if (target(next, at) || target(old, at)) {
                if (!counters.empty()) ++pmc_target;
                events << "{\"kind\":\"switch\",\"qpc\":" << at << ",\"cpu\":" << cpu
                    << ",\"in\":" << (target(next, at) ? next : 0) << ",\"out\":" << (target(old, at) ? old : 0) << ",\"counters\":";
                list(counters); events << "}\n";
            }
            running[cpu] = {next, at, std::move(counters)};
        } else if (id.Data1 == 0xce1dbfb4 && op == 46 && e->UserDataLength >= 12) {
            DWORD tid = raw<DWORD>(e, 8);
            if (target(tid, at)) {
                ++samples;
                events << "{\"kind\":\"sample\",\"qpc\":" << at << ",\"tid\":" << tid << ",\"ip\":" << raw<uint64_t>(e, 0) << ",\"cpu\":" << cpu << "}\n";
            }
        } else if (id.Data1 == 0xdef2fe46 && op == 32 && e->UserDataLength >= 16) {
            uint64_t stamp = raw<uint64_t>(e, 0); DWORD pid = raw<DWORD>(e, 8), tid = raw<DWORD>(e, 12);
            if (target(tid, stamp)) {
                ++stacks; unsigned ptr = (e->EventHeader.Flags & EVENT_HEADER_FLAG_32_BIT_HEADER) ? 4 : 8;
                events << "{\"kind\":\"stack\",\"qpc\":" << stamp << ",\"tid\":" << tid << ",\"pid\":" << pid << ",\"addresses\":[";
                for (unsigned offset = 16; offset+ptr <= e->UserDataLength; offset += ptr) {
                    if (offset != 16) events << ',';
                    events << (ptr == 8 ? raw<uint64_t>(e, offset) : raw<DWORD>(e, offset));
                }
                events << "]}\n";
            }
        } else if (id.Data1 == 0x2cb15d1d) {
            DWORD pid = number<DWORD>(e, m, L"ProcessId");
            if (target(pid, at, true, 10000000)) {
                auto bytes = property(e, m, L"FileName");
                std::string name = bytes.size() >= 2 ? utf8(reinterpret_cast<const wchar_t*>(bytes.data())) : "";
                size_t slash = name.find_last_of("/\\"); if (slash != std::string::npos) name = name.substr(slash+1);
                events << "{\"kind\":\"image\",\"qpc\":" << at << ",\"pid\":" << pid << ",\"op\":" << op << ",\"name\":" << json(name)
                    << ",\"base\":" << number<uint64_t>(e, m, L"ImageBase") << ",\"size\":" << number<uint64_t>(e, m, L"ImageSize") << "}\n";
            }
        }
    } catch (...) { callback_failed = true; }
}
int wmain(int argc, wchar_t** argv) {
    if (argc != 5) return 2;
    std::ifstream input(argv[2]); Target target_row{};
    while (input >> target_row.pid >> target_row.tid >> target_row.begin >> target_row.end) {
        tids[target_row.tid].push_back(target_row); pids[target_row.pid].push_back(target_row);
    }
    if (tids.empty()) return 3;
    events.open(argv[3]); schemas.open(argv[4]);
    EVENT_TRACE_LOGFILEW log{}; log.LogFileName = argv[1];
    log.ProcessTraceMode = PROCESS_TRACE_MODE_EVENT_RECORD|PROCESS_TRACE_MODE_RAW_TIMESTAMP;
    log.EventRecordCallback = callback;
    TRACEHANDLE handle = OpenTraceW(&log);
    if (handle == INVALID_PROCESSTRACE_HANDLE) { std::cerr << "OpenTrace " << GetLastError(); return 4; }
    ULONG status = ProcessTrace(&handle, 1, nullptr, nullptr); CloseTrace(handle);
    for (const auto& entry : exposures) {
        const auto& x = entry.second;
        events << "{\"kind\":\"sibling_exposure\",\"tid\":" << entry.first << ",\"scheduled_ticks\":" << x.total
            << ",\"sibling_busy_ticks\":" << x.busy << ",\"sibling_own_worker_ticks\":" << x.own_worker
            << ",\"sibling_unknown_owner_ticks\":" << x.unknown_owner << ",\"cpu2_ticks\":" << x.cpu2 << ",\"cpu3_ticks\":" << x.cpu3 << "}\n";
    }
    std::cout << "{\"process_trace_status\":" << status << ",\"callback_failed\":" << (callback_failed ? "true" : "false")
        << ",\"events\":" << event_count << ",\"pmc_events\":" << pmc_events << ",\"target_pmc_events\":" << pmc_target
        << ",\"target_samples\":" << samples << ",\"target_stacks\":" << stacks << ",\"invalid_intervals\":" << interval_errors
        << ",\"target_thread_starts\":" << target_thread_starts << ",\"target_thread_ends\":" << target_thread_ends << ",\"cpu_pair_chain_errors\":" << cpu_pair_chain_errors
        << ",\"time_min\":" << time_min << ",\"time_max\":" << time_max << ",\"events_lost\":" << log.LogfileHeader.EventsLost
        << ",\"buffers_lost\":" << log.LogfileHeader.BuffersLost << ",\"perf_frequency\":" << log.LogfileHeader.PerfFreq.QuadPart
        << ",\"clock_type\":" << log.LogfileHeader.ReservedFlags << ",\"counter_sizes\":{";
    bool first = true; for (const auto& x : counter_sizes) { if (!first) std::cout << ','; first = false; std::cout << json(std::to_string(x.first)) << ':' << x.second; }
    std::cout << "}}\n";
    return status || callback_failed ? 1 : 0;
}

from bisect import bisect_right
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import statistics
import struct
import analyze_samples as symbol_tables

here = Path(__file__).resolve().parent
selection = json.loads((here/'etl-selection.json').read_text())
capture = Path(selection['directory'])
workload = json.loads((capture/'workload-results.json').read_text())
reader = json.loads((capture/'etl-reader-summary-v4.json').read_text())
assert reader['process_trace_status'] == 0 and not reader['callback_failed']
assert reader['events_lost'] == reader['buffers_lost'] == reader['invalid_intervals'] == reader['cpu_pair_chain_errors'] == 0
assert reader['perf_frequency'] == workload['plan']['qpc_frequency'] == 10000000 and reader['clock_type'] == 1
children = workload['measured']
assert len({c['main_tid'] for c in children}) == len(children) == 32
by_tid = {c['main_tid']: c for c in children}
configs = []; statuses = []
images = defaultdict(list); samples = []; stacks = defaultdict(list); intervals = defaultdict(list); exposure = {}
for line in (capture/'target-events-v4.jsonl').open():
    e = json.loads(line)
    if e['kind'] == 'pmc_config':
        b = bytes.fromhex(e['data_hex'])
        if e['opcode'] == 48:
            n = struct.unpack_from('<I', b)[0]
            names = b[4:].decode('utf-16le').rstrip('\0').split('\0')
            assert len(names) == n == 5
            configs.append(names)
        else:
            cpu, count = struct.unpack_from('<II', b)
            assert len(b) == 8+count*12
            statuses.append({'cpu': cpu, 'source_id_and_raw_status_u64': [list(struct.unpack_from('<IQ', b, 8+i*12)) for i in range(count)]})
    elif e['kind'] == 'image' and e['op'] in [3, 10]: images[e['pid']].append(e)
    elif e['kind'] == 'sample': samples.append(e)
    elif e['kind'] == 'stack': stacks[(e['tid'], e['qpc'])].extend(e['addresses'])
    elif e['kind'] == 'interval': intervals[e['tid']].append(e)
    elif e['kind'] == 'sibling_exposure': exposure[e['tid']] = e
assert configs and all(c == configs[0] for c in configs)
names = configs[0]
assert names == ['BranchMispredictions', 'DcacheMisses', 'IcacheMisses', 'InstructionRetired', 'TotalCycles']
assert len(statuses) == 24 and all(v == 0 for s in statuses for _, v in s['source_id_and_raw_status_u64'])
per_child = {}; aggregate = {v: {'leaf': Counter(), 'inclusive': Counter(), 'samples': 0, 'query_samples': 0} for v in ['baseline', 'fixed']}
for c in children:
    tid = c['main_tid']; version = c['label'].split('_')[0]
    totals = {n: 0 for n in names}; ticks = 0
    for e in intervals[tid]:
        assert e['valid'] and e['cpu'] in [2, 3] and len(e['delta']) == len(names)
        assert c['resume_qpc'] <= e['begin'] < e['end'] <= c['finish_qpc']
        ticks += e['end']-e['begin']
        for n, v in zip(names, e['delta']): totals[n] += v
    assert intervals[tid] and exposure[tid]['scheduled_ticks'] == ticks
    assert totals['InstructionRetired'] > 0 and totals['TotalCycles'] > 0
    mods = {(m['base'], m['name']): m for m in images[c['pid']]}
    main = [m for m in mods.values() if m['name'].lower().endswith('.exe')]
    assert len(main) == 1
    main = main[0]
    table = symbol_tables.maps[version]
    per_child[tid] = {'pid': c['pid'], 'tid': tid, 'round': c['round'], 'label': c['label'], 'version': version,
        'queries': c['queries'], 'pmc_totals': totals, 'cpi': totals['TotalCycles']/totals['InstructionRetired'],
        'instructions_per_query': totals['InstructionRetired']/c['queries'], 'cycles_per_query': totals['TotalCycles']/c['queries'],
        'icache_per_1000_instructions': totals['IcacheMisses']*1000/totals['InstructionRetired'],
        'branch_mispredictions_per_1000_instructions': totals['BranchMispredictions']*1000/totals['InstructionRetired'],
        'native_full_sum_seconds': sum(c['native_output']['full_seconds']),
        'native_full_p50_seconds': statistics.median(c['native_output']['full_seconds']),
        'context_switch_intervals': len(intervals[tid]), 'scheduled_seconds': ticks/reader['perf_frequency'],
        'sibling_busy_fraction': exposure[tid]['sibling_busy_ticks']/ticks,
        'sibling_own_worker_fraction': exposure[tid]['sibling_own_worker_ticks']/ticks,
        'sibling_owner_unknown_fraction': exposure[tid]['sibling_unknown_owner_ticks']/ticks,
        'cpu2_fraction': exposure[tid]['cpu2_ticks']/ticks, 'leaf_counts': Counter(), 'query_leaf_counts': Counter(),
        'inclusive_counts': Counter(), 'sample_count': 0, 'query_sample_count': 0, 'matched_stack_samples': 0,
        'main_base': main['base'], 'main_size': main['size'], 'modules': list(mods.values())}

def resolve(c, ip):
    rva = ip-c['main_base']
    if 0 <= rva < c['main_size']:
        info = symbol_tables.maps[c['version']]
        i = bisect_right(info['keys'], rva)-1
        name = '|'.join(sorted(info['symbols'][info['keys'][i]])) if i >= 0 else '<unmapped main image>'
        return name, True, info['query_range'][0] <= rva < info['query_range'][1]
    if ip >= 0xffff000000000000: return '<kernel>', False, False
    for m in c['modules']:
        if m['base'] <= ip < m['base']+m['size']: return m['name']+'!<RVA>', False, False
    return '<unresolved user module>', False, False

for e in samples:
    c = per_child[e['tid']]; raw = by_tid[e['tid']]
    assert raw['resume_qpc'] <= e['qpc'] <= raw['finish_qpc'] and e['cpu'] in [2, 3]
    frames = stacks.get((e['tid'], e['qpc']), [])
    decoded = [resolve(c, ip) for ip in [e['ip'], *frames]]
    leaf = decoded[0][0]
    c['sample_count'] += 1; c['leaf_counts'][leaf] += 1
    if frames: c['matched_stack_samples'] += 1
    a = aggregate[c['version']]; a['samples'] += 1
    if any(f[2] for f in decoded):
        c['query_sample_count'] += 1; c['query_leaf_counts'][leaf] += 1; a['query_samples'] += 1; a['leaf'][leaf] += 1
        own_names = set(f[0] for f in decoded if f[1])
        c['inclusive_counts'].update(own_names); a['inclusive'].update(own_names)
assert len(samples) == reader['target_samples']
ratios = []
for r in range(8):
    values = {c['label']: c for c in per_child.values() if c['round'] == r}
    assert len(values) == 4
    totals = {v: {n: sum(values[v+'_'+i]['pmc_totals'][n] for i in ['1', '2']) for n in names} for v in aggregate}
    row = {'round': r, **{n: totals['fixed'][n]/totals['baseline'][n] if totals['baseline'][n] else None for n in names}}
    row['CPI'] = (totals['fixed']['TotalCycles']/totals['fixed']['InstructionRetired'])/(totals['baseline']['TotalCycles']/totals['baseline']['InstructionRetired'])
    row['native_full_query_time'] = sum(values['fixed_'+i]['native_full_sum_seconds'] for i in ['1', '2'])/sum(values['baseline_'+i]['native_full_sum_seconds'] for i in ['1', '2'])
    ratios.append(row)
summary = {'source_head': workload['plan']['source_head'], 'query_gate_cleared': False, 'production_unchanged': True,
    'counter_order_from_trace': names, 'zero_counter_not_interpretable': ['DcacheMisses'],
    'counter_status_raw_u64_all_zero': True, 'counter_status_records': statuses, 'reader': reader,
    'selection': selection, 'measured_children': len(children), 'verified_queries': sum(c['queries'] for c in children),
    'paired_round_ratios': ratios, 'paired_descriptive': {}, 'children': list(per_child.values()), 'hotspots': {},
    'limits': ['Main-thread PMCs include startup, kernel/interrupt work, all query iterations, printing and teardown; not exact query-only PMCs.',
               'Elevated token,1024 in-process queries and active WPR differ from original acceptance conditions.',
               'Eight rounds and two full identity/order cycles; descriptive paired medians/ranges only, not a new acceptance CI.',
               'HAL event semantics on this CPU are not independently calibrated; DcacheMisses is all zero and unusable.',
               'CPU samples identify code occupancy, not which instruction caused each cache miss.',
               'Sibling non-idle exposure is scheduler-based; IRQ/DPC and other-core/L3/power effects remain uncontrolled.']}
assert reader['target_thread_starts'] == reader['target_thread_ends'] == 32
summary['negative_controls'] = {}
for version in aggregate:
    controls = defaultdict(list)
    for r in range(8):
        rows = {c['label']: c for c in per_child.values() if c['round'] == r}
        a, b = rows[version+'_2'], rows[version+'_1']
        for key in ['InstructionRetired', 'TotalCycles', 'IcacheMisses', 'BranchMispredictions']:
            controls[key].append(a['pmc_totals'][key]/b['pmc_totals'][key])
        controls['native_full_query_time'].append(a['native_full_sum_seconds']/b['native_full_sum_seconds'])
    summary['negative_controls'][version] = {key: {'round_ratios': values, 'median_ratio': statistics.median(values), 'range': [min(values), max(values)]} for key, values in controls.items()}
for key in names+['CPI', 'native_full_query_time']:
    vals = [r[key] for r in ratios if r[key] is not None]
    summary['paired_descriptive'][key] = {'median_ratio': statistics.median(vals), 'range': [min(vals), max(vals)]} if vals else None
for version, a in aggregate.items():
    summary['hotspots'][version] = {'samples': a['samples'], 'query_samples': a['query_samples'],
        'query_leaves': [{'symbol': n, 'count': v, 'percent': v*100/a['query_samples']} for n, v in a['leaf'].most_common(20)],
        'inclusive': [{'symbol': n, 'count': v, 'percent': v*100/a['query_samples']} for n, v in a['inclusive'].most_common(20)],
        'sibling_busy_fraction_median': statistics.median(c['sibling_busy_fraction'] for c in per_child.values() if c['version'] == version)}
(capture/'pmu-analysis.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({'paired': summary['paired_descriptive'], 'sample_coverage': {v: {k:x[k] for k in ['samples','query_samples','sibling_busy_fraction_median']} for v,x in summary['hotspots'].items()},
                  'hot_leaves': {v:x['query_leaves'][:6] for v,x in summary['hotspots'].items()}}, indent=2))

from bisect import bisect_right
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re
import statistics
import struct

here = Path(__file__).resolve().parent
root = here.parent

def pe_functions(path):
    data = path.read_bytes()
    pe = struct.unpack_from('<I', data, 60)[0]
    count = struct.unpack_from('<H', data, pe+6)[0]
    optional_size = struct.unpack_from('<H', data, pe+20)[0]
    section_start = pe+24+optional_size
    pdata = None
    for i in range(count):
        at = section_start+40*i
        name = data[at:at+8].split(b'\0')[0]
        if name == b'.pdata':
            virtual_size, rva, size, offset = struct.unpack_from('<IIII', data, at+8)
            pdata = [struct.unpack_from('<III', data, offset+j)[:2] for j in range(0, virtual_size, 12)]
    assert pdata
    return sorted(pdata)

maps = {}
for version in ['baseline', 'fixed']:
    symbols = defaultdict(list)
    for line in (root/f'caller-control/build/mixed_{version}.map').read_text().splitlines():
        m = re.match(r'\s+0001:[0-9A-Fa-f]+\s+(\S+)\s+([0-9A-Fa-f]{16})\s+f\s', line)
        if m:
            symbols[int(m[2], 16)-0x140000000].append(m[1])
    assert symbols
    keys = sorted(symbols)
    ranges = pe_functions(root/f'build/Release/query_02_{version}.exe')
    begin = next(at for at, names in symbols.items() if any(n.startswith('?read_fixture@@') for n in names))
    query_range = next((a, b) for a, b in ranges if a == begin)
    maps[version] = {'symbols': symbols, 'keys': keys, 'query_range': query_range, 'ranges': ranges}

def analyze(directory):
    run = json.loads((directory/'results.json').read_text())
    assert run.get('completed_at')
    children = []
    totals = {v: {'leaves': Counter(), 'inclusive': Counter(), 'top_exe': Counter(), 'query_samples': 0, 'samples': 0} for v in maps}
    for child in run['children']:
        version = child['version']
        profile = json.loads(Path(child['profile_path']).read_text())
        main_module = next(m for m in profile['modules'] if m['name'].endswith('.exe'))
        assert profile['sampler_affinity_mask'] == 16 and profile['affinity_mask'] == 12
        info = maps[version]
        def resolve(ip):
            for mod in profile['modules']:
                if mod['base'] <= ip < mod['base']+mod['size']:
                    rva = ip-mod['base']
                    if mod != main_module: return mod['name']+'!<RVA>', False, False
                    idx = bisect_right(info['keys'], rva)-1
                    # Nearest map public function, not a PDB source-line or inline-frame result.
                    name = '|'.join(sorted(info['symbols'][info['keys'][idx]])) if idx >= 0 else '<unmapped executable RVA>'
                    return name, True, info['query_range'][0] <= rva < info['query_range'][1]
            return '<not in initial module inventory>', False, False
        leaves = Counter()
        inclusive = Counter()
        top_exe = Counter()
        query_samples = 0
        for sample in profile['samples']:
            resolved = [resolve(ip) for ip in [sample['rip'], *sample['stack']]]
            if not any(x[2] for x in resolved): continue
            query_samples += 1
            leaves[resolved[0][0]] += 1
            names = [x[0] for x in resolved if x[1]]
            inclusive.update(set(names))
            if names: top_exe[names[0]] += 1
        elapsed = (profile['end_qpc']-profile['start_qpc'])/profile['qpc_frequency']
        suspension = sum(x['suspend_qpc_ticks'] for x in profile['samples'])/profile['qpc_frequency']
        record = {'round': child['round'], 'label': child['label'], 'version': version,
            'profile_samples': len(profile['samples']), 'query_frame_samples': query_samples,
            'query_frame_fraction': query_samples/len(profile['samples']), 'image_base': hex(main_module['base']),
            'initial_modules': [m['name'] for m in profile['modules']], 'elapsed_seconds': elapsed,
            'inventory_seconds': (profile['inventory_done_qpc']-profile['start_qpc'])/profile['qpc_frequency'],
            'total_suspension_seconds': suspension, 'suspension_wall_fraction': suspension/elapsed,
            'native_full_median_seconds': statistics.median(child['native_output']['full_seconds']),
            'main_thread_lifetime_cycles': profile['main_thread_lifetime_cycles'],
            'leaf_counts': dict(leaves), 'inclusive_counts': dict(inclusive), 'top_executable_frame_counts': dict(top_exe)}
        assert record['query_frame_fraction'] > .9, 'Profiler validation failed; retain this run but do not publish as valid profile.'
        children.append(record)
        for key, counts in [('leaves', leaves), ('inclusive', inclusive), ('top_exe', top_exe)]: totals[version][key].update(counts)
        totals[version]['query_samples'] += query_samples
        totals[version]['samples'] += len(profile['samples'])
    result = {'source_head': run['plan']['source_head'], 'completed_at': run['completed_at'], 'query_gate_cleared': False,
              'method_limits': run['plan']['limitations'], 'query_runtime_function_ranges': {v: list(x['query_range']) for v, x in maps.items()},
              'children': children, 'totals': {}, 'profiled_latency_not_acceptance': True}
    for version, t in totals.items():
        result['totals'][version] = {'samples': t['samples'], 'query_samples': t['query_samples'],
            'top_query_leaves': [{'symbol': name, 'samples': count, 'query_sample_percent': count*100/t['query_samples']} for name, count in t['leaves'].most_common(20)],
            'top_inclusive_executable_frames': [{'symbol': name, 'samples': count, 'query_sample_percent': count*100/t['query_samples']} for name, count in t['inclusive'].most_common(20)]}
    all_leaves = set(totals['baseline']['leaves']) | set(totals['fixed']['leaves'])
    per_round = []
    for r in sorted({x['round'] for x in children}):
        rows = {x['label']: x for x in children if x['round'] == r}
        ratios = {}
        for metric in ['native_full_median_seconds', 'main_thread_lifetime_cycles']:
            ratios[metric] = sum(rows['fixed_'+i][metric] for i in ['1', '2'])/sum(rows['baseline_'+i][metric] for i in ['1', '2'])
        per_round.append(ratios)
    result['profiled_descriptive_ratios'] = {k: {'median_fixed_over_baseline': statistics.median(x[k] for x in per_round), 'round_ratios': [x[k] for x in per_round]} for k in per_round[0]}
    result['same_version_negative_controls'] = {version: {k: [next(x[k] for x in children if x['round'] == r and x['label'] == version+'_2')/next(x[k] for x in children if x['round'] == r and x['label'] == version+'_1') for r in range(8)] for k in ['native_full_median_seconds', 'main_thread_lifetime_cycles']} for version in maps} if len(children) == 32 else {}
    differences = []
    for name in all_leaves:
        percents = {v: totals[v]['leaves'][name]*100/totals[v]['query_samples'] for v in maps}
        differences.append({'symbol': name, 'baseline_percent': percents['baseline'], 'fixed_percent': percents['fixed'], 'difference_percentage_points': percents['fixed']-percents['baseline']})
    result['largest_descriptive_leaf_differences'] = sorted(differences, key=lambda x: abs(x['difference_percentage_points']), reverse=True)[:20]
    (directory/'analysis.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'children': len(children), 'totals': result['totals'], 'profiled_descriptive_ratios': result['profiled_descriptive_ratios']}, indent=2))
    return result

if __name__ == '__main__': analyze(here/'samples')

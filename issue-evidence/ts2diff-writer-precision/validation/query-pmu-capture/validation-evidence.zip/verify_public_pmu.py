"""Verify the public target-filtered evidence without access to the system ETL."""
from collections import Counter, defaultdict
from pathlib import Path
import json
import statistics

root = Path(__file__).resolve().parent
analysis = json.loads((root / 'pmu-analysis.json').read_text())
workload = json.loads((root / 'workload-results.json').read_text())
children = {c['main_tid']: c for c in workload['measured']}
assert len(children) == 32 and sum(c['queries'] for c in children.values()) == 32768
totals = defaultdict(lambda: [0] * 5)
counts = Counter()
for line in (root / 'target-events-normalized.jsonl').open():
    e = json.loads(line)
    counts[e['kind']] += 1
    if e['kind'] == 'interval':
        c = children[e['tid']]
        assert e['valid'] and e['cpu'] in [2, 3]
        assert c['resume_qpc'] <= e['begin'] < e['end'] <= c['finish_qpc']
        totals[e['tid']] = [a + b for a, b in zip(totals[e['tid']], e['delta'])]
    if e['kind'] in ['sample', 'stack']:
        assert e['tid'] in children
        assert children[e['tid']]['resume_qpc'] <= e['qpc'] <= children[e['tid']]['finish_qpc']
    if e['kind'] == 'sample':
        assert 'ip' not in e and isinstance(e['location'], dict)
    if e['kind'] == 'stack':
        assert 'addresses' not in e and all(isinstance(x, dict) for x in e['frames'])
assert counts['interval'] == 510 and counts['sample'] == 88135 and counts['stack'] == 93109
names = analysis['counter_order_from_trace']
assert all(totals[t] == [c['pmc_totals'][n] for n in names] for t, c in {c['tid']: c for c in analysis['children']}.items())
ratios = defaultdict(list)
for r in range(8):
    rows = {c['label']: c for c in children.values() if c['round'] == r}
    assert len(rows) == 4
    for i, n in enumerate(names):
        before = sum(totals[rows['baseline_' + x]['main_tid']][i] for x in ['1', '2'])
        after = sum(totals[rows['fixed_' + x]['main_tid']][i] for x in ['1', '2'])
        if before:
            ratios[n].append(after / before)
    ratios['native_full_query_time'].append(
        sum(sum(rows['fixed_' + x]['native_output']['full_seconds']) for x in ['1', '2']) /
        sum(sum(rows['baseline_' + x]['native_output']['full_seconds']) for x in ['1', '2']))
for k, vals in ratios.items():
    assert statistics.median(vals) == analysis['paired_descriptive'][k]['median_ratio']
    assert [min(vals), max(vals)] == analysis['paired_descriptive'][k]['range']
assert analysis['paired_descriptive']['DcacheMisses'] is None
for c in children.values():
    n = c['native_output']
    assert n['repeats'] == 1024 and len(n['full_seconds']) == 1024
    assert all(n[k] == v for k, v in analysis['expected_native_output'].items())
print(json.dumps({'verified_children': 32, 'verified_queries': 32768, 'events': dict(counts), 'paired_metrics_verified': list(ratios)}))

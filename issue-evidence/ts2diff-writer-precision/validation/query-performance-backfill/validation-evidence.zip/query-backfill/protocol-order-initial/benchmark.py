from pathlib import Path
import ctypes
from ctypes import wintypes
import hashlib
import json
import random
import statistics
import subprocess

root=Path(__file__).resolve().parent
plan=json.loads((root/'plan.json').read_text(encoding='utf-8'))
affinity=ctypes.windll.kernel32.SetProcessAffinityMask
affinity.argtypes=[wintypes.HANDLE,ctypes.c_size_t];affinity.restype=wintypes.BOOL
mask=plan['affinity_mask'];rng=random.Random(10181024)

def percentile(values,fraction):
    values=sorted(values);index=(len(values)-1)*fraction;lo=int(index);hi=min(lo+1,len(values)-1)
    return values[lo] if lo==hi else values[lo]*(hi-index)+values[hi]*(index-lo)

def expected(case):
    low=8195 if case['scenario']=='time' else 0
    high=24581 if case['scenario']=='time' else 32767
    devices=[1] if case['scenario']=='tag' else [0,1]
    pct={'app0':0,'app1':1,'app50':50}.get(case['scenario'],100)
    checksum=0;nulls=0;accepted=0
    for d in devices:
        for r in range(low,high+1):
            keep=(d*32768+r)%100<pct
            accepted+=keep
            for c in range(case['width']):
                nil=case['sparse'] and c>0 and (r+c)%11==0
                nulls+=nil
                if keep: checksum+=17 if nil else ((d*32768+r)*8+c)*4+(0 if case['precision']==0 else 1)
    return {'rows_per_query':len(devices)*(high-low+1),'accepted_rows_per_query':accepted,
        'checksum':checksum*plan['repeats'],'NULL_cells':nulls*plan['repeats']}

def run(case,label):
    reader,writer=label.split('_')
    fixture=plan['fixtures'][case['fixture_key']]
    args=[str(root/f'build/Release/query_{case["item"]}_{reader}.exe'),'read',fixture['paths'][writer],
        case['layout'],case['kind'],str(case['precision']),str(case['sparse']),str(case['properties']),
        case['scenario'],str(case['width']),str(case['batch']),str(case['parallel']),str(plan['repeats'])]
    p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    pinned=bool(affinity(wintypes.HANDLE(int(p._handle)),mask))
    stdout,stderr=p.communicate()
    assert pinned,'affinity'
    if p.returncode:raise RuntimeError(stdout+'\n'+stderr)
    row=json.loads([line for line in stdout.splitlines() if line.startswith('{')][-1])
    for key,value in case['expected'].items():assert row[key]==value,(key,row[key],value)
    assert row['repeats']==plan['repeats']
    if case['scenario']=='app0':assert all(t is None for t in row['first_row_seconds'])
    row['affinity_mask']=mask
    return row

def summarize(measurements):
    labels=list(measurements[0]);s={}
    if 'baseline_baseline' in labels:
        contrasts={
          'reader_on_baseline_file':('fixed_baseline','baseline_baseline'),
          'reader_on_fixed_file':('fixed_fixed','baseline_fixed'),
          'writer_products_fixed_reader':('fixed_fixed','fixed_baseline'),
          'end_to_end':('fixed_fixed','baseline_baseline')}
    else:contrasts={'reader_on_valid_nonempty_property_file':('fixed_fixed','baseline_fixed')}
    signals=[]
    for name,(after,before) in contrasts.items():
        ratios=[sum(r[after]['full_seconds'])/sum(r[before]['full_seconds']) for r in measurements]
        boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
        before_times=[t for r in measurements for t in r[before]['full_seconds']]
        after_times=[t for r in measurements for t in r[after]['full_seconds']]
        ci=[percentile(boot,.025),percentile(boot,.975)]
        p95_ratio=percentile(after_times,.95)/percentile(before_times,.95)
        s[name]={'paired_median_latency_ratio':statistics.median(ratios),'bootstrap_95_percent':ci,
            'descriptive_query_p95_ratio':p95_ratio,'before':before,'after':after}
        if ci[0]>1 or statistics.median(ratios)>1.03 or p95_ratio>1.10:signals.append(name)
    variants={}
    for label in labels:
        d={}
        for metric in ['open_seconds','metadata_seconds','plan_seconds','first_row_seconds','first_decoded_row_seconds','full_seconds']:
            values=[v for r in measurements for v in r[label][metric] if v is not None]
            d[metric]={'samples':len(values),'p50':statistics.median(values) if values else None,'p95':percentile(values,.95) if values else None}
        times=[t for r in measurements for t in r[label]['full_seconds']]
        rows=measurements[0][label]['rows_per_query'];accepted=measurements[0][label]['accepted_rows_per_query'];width=measurements[0][label]['fields']
        d['median_decoded_rows_per_second']=statistics.median(rows/t for t in times)
        d['median_accepted_rows_per_second']=statistics.median(accepted/t for t in times)
        d['median_projected_cells_per_second']=statistics.median(rows*width/t for t in times)
        d['median_peak_process_working_set_bytes']=statistics.median(r[label]['peak_process_working_set_bytes'] for r in measurements)
        d['max_peak_process_working_set_bytes']=max(r[label]['peak_process_working_set_bytes'] for r in measurements)
        variants[label]=d
    return {'contrasts':s,'variants':variants,'confirmation_signals':signals}

for item,cases in plan['cases'].items():
    report={'item':item,'plan':'plan.json','method':'Same verified fixtures and MSVC Release static options; 3 complete verified queries/process; 2 warmups/variant, 25 independent alternating process quartets/pairs; affinity mask 12, 2 worker threads, warm filesystem cache. Per-query p50/p95 use 75 queries/variant/case clustered in 25 processes; bootstrap resamples processes. Full time includes open/header/footer initialization, explicit cached schema lookup, query setup, typed result materialization/checking, application predicate if requested, destruction and close. No cold-cache/P99 or p95 non-inferiority claim.',
        'application_FIELD_reference':'app0/app1/app50 evaluate floor(v0/8)%100 < acceptance over fully materialized, validated native scan results. All input rows/cells are consumed; materialization cost is included. Existing native FIELD predicate paths in these PRs ignore/hang, so they are not used as fast equivalent baselines.',
        'cases':{}}
    for case in cases:
        case['expected']=expected(case)
        labels=['baseline_fixed','fixed_fixed'] if case['properties'] else ['baseline_baseline','fixed_baseline','baseline_fixed','fixed_fixed']
        print('Benchmark',item,case['name'],flush=True)
        for _ in range(plan['warmups']):
            for label in labels:run(case,label)
        measurements=[]
        for pair in range(plan['pairs']):
            offset=pair%len(labels);order=labels[offset:]+labels[:offset]
            if pair%2:order=list(reversed(order))
            measurements.append({label:run(case,label) for label in order})
        summary=summarize(measurements)
        report['cases'][case['name']]={'case':case,'summary':summary,'measurements':measurements}
        (root/f'query-performance-{item}-initial.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'case':case['name'],'contrasts':summary['contrasts'],'signals':summary['confirmation_signals']}),flush=True)

#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2
evidence_root="$task_root/work/query-backfill"
asan_root="$task_root/work/issue-02/validation/ci-asan-test-lifetime/linux-debug-asan"
g++ -std=c++14 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer \
  -DTSFILE_STATIC -DENABLE_MEM_STAT -DENABLE_THREADS \
  -I"$task_root/work/issue-02/fix-repo/cpp/src" \
  "$evidence_root/query_benchmark.cc" \
  -Wl,--start-group "$asan_root/lib/libtsfile.a" "$asan_root/lib/libsnappy.a" \
  "$asan_root/lib/libtsfile_lz4_bundled.a" "$asan_root/lib/libtsfile_lzokay_bundled.a" \
  "$asan_root/lib/libz.a" "$asan_root/lib/libzstd.a" "$asan_root/lib/liblzma.a" \
  -Wl,--end-group -pthread -o /tmp/tsfile-query-backfill-asan \
  > "$evidence_root/sanitizer-build.log" 2>&1
export ASAN_OPTIONS=detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1
{
  /tmp/tsfile-query-backfill-asan read "$evidence_root/data/01_FLOAT_aligned_p2_null1_props1_fixed.tsfile" aligned FLOAT 2 1 1 all 4 0 0 1
  /tmp/tsfile-query-backfill-asan read "$evidence_root/data/02_DOUBLE_nonaligned_p0_null1_props0_fixed.tsfile" nonaligned DOUBLE 0 1 0 time 4 1024 1 1
  /tmp/tsfile-query-backfill-asan read "$evidence_root/data/02_FLOAT_aligned_p0_null1_props0_baseline.tsfile" aligned FLOAT 0 1 0 app1 4 1024 1 1
  /tmp/tsfile-query-backfill-asan write /tmp/tsfile-query-backfill-asan.tsfile nonaligned FLOAT 0 1 0
  /tmp/tsfile-query-backfill-asan read /tmp/tsfile-query-backfill-asan.tsfile nonaligned FLOAT 0 1 0 app0 4 1024 0 1
} > "$evidence_root/sanitizer-validation.log" 2>&1
echo 'New benchmark harness: Linux ASan/UBSan + leak detection passed (PR02 library); not a rerun of each PR full suite.' >> "$evidence_root/sanitizer-validation.log"

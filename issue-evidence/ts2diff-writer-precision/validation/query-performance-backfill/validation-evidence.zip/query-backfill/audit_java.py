from pathlib import Path
import json
import os
import subprocess
root=Path(__file__).resolve().parent
plan=json.loads((root/'plan.json').read_text(encoding='utf-8'))
cp=Path(os.environ.get('TSFILE_QUERY_JAVA_CLASSPATH_FILE',str(root.parent/'issue-04/java-classpath.txt'))).read_text(encoding='utf-8-sig').strip()
(root/'java-classes').mkdir(exist_ok=True)
jdk=Path('C:/Program Files/Java/jdk-24/bin')
p=subprocess.run([str(jdk/'javac.exe'),'-cp',cp,'-d',str(root/'java-classes'),str(root/'QueryFixtureAudit.java')],capture_output=True,text=True)
assert p.returncode==0,p.stderr
records={}
for key,fixture in plan['fixtures'].items():
  for writer,path in fixture['paths'].items():
    if fixture['item']=='01' and fixture['properties'] and writer=='baseline':continue
    actual_precision=-1 if fixture['item']=='01' else fixture['precision'] if writer=='fixed' else 2
    p=subprocess.run([str(jdk/'java.exe'),'-Xmx512m','-cp',str(root/'java-classes')+';'+cp,
        'QueryFixtureAudit',path,fixture['kind'],fixture['layout'],str(fixture['precision']),str(fixture['sparse']),str(actual_precision)],capture_output=True,text=True)
    records[key+'_'+writer]={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    (root/'java-fixture-audit.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    assert p.returncode==0,records[key+'_'+writer]
    print(key,writer,p.stdout.strip(),flush=True)
print('All valid C++ writer products audited in Java:',len(records),flush=True)

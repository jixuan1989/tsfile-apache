from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parent
base=root.parents[1]
state=json.loads((base/'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
plan=json.loads((root/'plan.json').read_text(encoding='utf-8'))
audit=json.loads((root/'java-fixture-audit.json').read_text(encoding='utf-8'))
assert len(audit)==29 and all(v['exit_code']==0 for v in audit.values())
assert 'leak detection passed' in (root/'sanitizer-validation.log').read_text(encoding='utf-8')
assert 'ERROR:' not in (root/'sanitizer-validation.log').read_text(encoding='utf-8')
footer=state['workflow']['ai_disclosure']['pr_footer']
sources={'01':('12e39fe9d9dace63cc0ad39664aa0fbf5e29f52f','5fb363774ed7b492252d2933707545edca5ca981'),
         '02':('1180b13675e11a0230708af2cc70d037e0e12623','75592b89d1523a96090e8bca1dcb4cd2180162e5')}
def ratio(d,key='paired_median_latency_ratio'):
    lo,hi=d['bootstrap_95_percent'];return f'{d[key]:.4f} [{lo:.4f}, {hi:.4f}]'
def matrix(data):
    lines=['| Scenario | Reader on baseline file | Reader on fixed file | Writer products, fixed reader | End-to-end |',
           '|---|---|---|---|---|']
    for name,c in data['cases'].items():
        d=c['summary']['contrasts']
        if c['case']['properties']:
            lines.append(f'| `{name}` | invalid old producer excluded | {ratio(d["reader_on_valid_nonempty_property_file"])} | N/A | N/A |')
        else:
            vals=[ratio(d[k]) for k in ['reader_on_baseline_file','reader_on_fixed_file','writer_products_fixed_reader','end_to_end']]
            lines.append('| `'+name+'` | '+' | '.join(vals)+' |')
    return '\n'.join(lines)
def metrics(data):
    lines=['| Scenario | Baseline / fixed full p50 (ms) | Baseline / fixed full p95 (ms) | Baseline / fixed first accepted p50 (ms) | Baseline / fixed peak working set median (MiB) |',
           '|---|---|---|---|---|']
    for name,c in data['cases'].items():
        v=c['summary']['variants'];a=v['baseline_fixed' if c['case']['properties'] else 'baseline_baseline'];b=v['fixed_fixed']
        def pair(key,field='p50'):
            x=a[key][field];y=b[key][field]
            return 'N/A (zero accepted rows)' if x is None else f'{1000*x:.3f} / {1000*y:.3f}'
        lines.append(f'| `{name}` | {pair("full_seconds")} | {pair("full_seconds","p95")} | {pair("first_row_seconds")} | {a["median_peak_process_working_set_bytes"]/1048576:.3f} / {b["median_peak_process_working_set_bytes"]/1048576:.3f} |')
    return '\n'.join(lines)
def observed_range(data,key):
    v=[c['summary']['contrasts'][key]['paired_median_latency_ratio'] for c in data['cases'].values() if key in c['summary']['contrasts']]
    return [min(v),max(v)]

records={}
for item,expected_count in [('01',16),('02',32)]:
    old,new=sources[item]
    initial=json.loads((root/f'query-performance-{item}-initial.json').read_text(encoding='utf-8'))
    assert len(initial['cases'])==expected_count
    assert all(len(c['measurements'])==32 for c in initial['cases'].values())
    original_item=state['active'] if item=='01' else next(x for x in state['drafts'] if x['id']==item)
    heading=f'# TsFile PR #{original_item["pr_number"]}: query performance backfill\n\n'
    text=f'''Baseline `{old}`; tested PR head `{new}`. No production code or new upstream source commit was made for this backfill. Existing correctness, bidirectional interoperability, coverage and write-performance results remain in the earlier reports, with their original limits. This follow-up adds query timings rather than treating untimed readback as performance evidence.

## 数据与独立校验

Each file contains 2 devices × 32,768 rows × 4 FLOAT/DOUBLE FIELDs, plus a STRING TAG in table metadata. The writer flushes every 8,192 rows/device (4 value chunks per field/device; 32 value chunks/file). Page limit is 256 rows. Java independently reads every value, NULL position, timestamp and type, and audits actual chunk compression, page count and precision. Dense/aligned files have 1,024 value pages; sparse non-aligned files have 976. All values use UNCOMPRESSED; the time codec is also configured UNCOMPRESSED. Multi-device aligned/non-aligned files carry an explicit table schema and are queried through the native table row/batch APIs; this is not a benchmark of every tree-query API.

Nullable FIELDs v1–v3 omit `(row+column)%11==0`; v0 remains present as the row anchor. Precision-2 data uses exact `.25` fractions; precision-0 data uses integer-valued inputs, so the original default-2 writer and revised precision-0 writer return identical logical values. Both versions write their own products; both reader versions fully read each valid product before timings. Across this backfill there are 29 valid C++ products audited in Java and 58 successful native cross/own read preflights. The single malformed original property-file control is expected to fail in both readers and is excluded from timing.

## 测量定义与条件

MSVC 14.50 Release/static, identical native driver source/options, threads enabled, two-worker pool, optional codecs/ANTLR/SIMD disabled. Two warmups per variant then **32 independent position-balanced process quartets** (pairs for the one valid property-file comparison). Each process runs 3 complete queries, so per-query p50/p95 use **96 queries clustered in 32 processes**, not 96 independent processes. The bootstrap median latency ratios resample processes. Every label occupies every execution position equally. Full-result latency includes open/header/footer initialization, explicit schema lookup, query setup, decoded-cell validation/materialization, optional application filtering, result destruction and close. Fixture generation and process startup are excluded.

`open_seconds` measures `TsFileReader::open`, including its internal initialization; `metadata_seconds` measures the subsequent native schema lookup and may reuse metadata loaded during open. `plan_seconds` is query construction. `first_decoded_row_seconds` measures first native row/block availability. `first_row_seconds` measures the first accepted, validated application row (N/A for app0). Full query latency, decoded/accepted row throughput, projected-cell throughput and whole-process peak working set are retained. Peak memory includes the process/thread pool and is not incremental query allocation. Filesystem cache is warmed; fresh processes do not establish cold-cache measurements. No P99, controlled cold-cache, or p95 non-inferiority guarantee is claimed.

The initial mixed driver uses affinity mask 12 (two logical CPUs) for all cases. Parallel read configuration is reported in each scenario; this is not a general parallel-scaling study. The later reader-only controls below refine caller/CPU placement explicitly.

Native TAG equality selects device d1 (50% of input rows); the time window is `[8195,24581]`. `app0`, `app1`, `app50` apply `floor(v0/8)%100 < percent` **after fully materializing and validating the native scan**. Their cost includes reading all input rows/cells. The old native FIELD paths ignored the predicate or hung, so those paths are not used as an equivalent fast filtering baseline. Application filtering is clearly a materializing reference, not native predicate pushdown. Both input and accepted counts/checksums are independently checked in Python; every cell is also checked in the driver.

## 原始顺序检查

A first, interrupted attempt had an ordering bug (cyclic rotation followed by odd-round reversal). For two variants it always ran baseline first; four variants also did not occupy all positions evenly. These samples and their original script/plan are preserved under `protocol-order-initial/` and are **not used for the performance conclusions**. The replacement 32-round order is checked for equal label/position counts before measurement. No samples or outliers from the valid replacement runs are removed.

## 原有 writer + reader 混合程序结果

Ratios below are fixed/baseline; brackets are process-cluster bootstrap 95% intervals. The columns separately isolate reader cost on an identical baseline/fixed file, changed writer product cost through the fixed reader, and end-to-end original-writer/original-reader versus revised-writer/revised-reader cost.

'''+matrix(initial)+'\n\n'+metrics(initial)+'\n'
    if item=='01':
        assert not any(c['summary']['confirmation_signals'] for c in initial['cases'].values())
        text+='''
## PR #1018 的结论与边界

All 16 measured cases pass full result checks, and none triggers the recorded confirmation policy (paired-median 95% interval wholly above 1, median ratio above 1.03, or descriptive p95 ratio above 1.10). Valid empty-property baseline/fixed files are byte-identical. For nonempty properties the original producer output returns `E_PARTIAL_READ` (`code=6`) in both readers, so it cannot be timed as a valid original producer. The valid fixed nonempty-property file is timed with both reader versions, preserving its additional metadata work. This does not claim a valid before/after producer latency for previously malformed nonempty output.

The measured query gate is cleared for this corpus. It is not a guarantee of zero regression on every application/hardware/cache condition. Native FIELD pushdown, sole/all-NULL projections, OFFSET/LIMIT timing, compressed-query timing, special floating values, very large metadata sets and full parallel scaling are outside these measurements. Existing embedded-NUL string parsing limitations remain unchanged.
'''
        gate='passed_for_measured_query_scope'
    else:
        confirmation=json.loads((root/'query-performance-02-confirmation.json').read_text(encoding='utf-8'))
        reader_only=json.loads((root/'query-performance-02-reader-only.json').read_text(encoding='utf-8'))
        factorial=json.loads((root/'query-performance-02-factorial.json').read_text(encoding='utf-8'))
        assert len(reader_only['cases'])==32 and len(factorial['cases'])==12
        assert all(len(c['measurements'])==192 and 'summary' in c for c in factorial['cases'].values())
        text+='''
## 初测信号与独立复测

Three initial DOUBLE cases triggered confirmation. With the **unchanged mixed caller and two-CPU affinity**, 192 independent quartets/case were then measured (3 queries/process). The primary confirmation CI resamples 24 chronological blocks of 8 complete order cycles. The two dense aligned DOUBLE full scans retain approximately 0.4–0.7% increases in some comparisons; the sparse application-filter case does not reproduce its initial signal. These observations are retained as **confirmed mixed-caller measurements**, not silently relabeled as passing.

| Case / contrast | Confirmatory block-median ratio [95% CI] |
|---|---|
'''
        for n,c in confirmation['cases'].items():
            for k,v in c['blocked_summary'].items():text+=f'| `{n}` / `{k}` | {ratio(v,"block_median_latency_ratio")} |\n'
        text+='''
## 查询代码与调用程序隔离

No reader/decoder source changed in PR #1024. For seven reader object files, the multisets of raw `.text` section payloads match (13,672 sections); this comparison is before relocation/linking and does **not** prove identical runtime addresses. The mixed caller also compiles writer/encoder helpers against different headers, so its linked code layout differs widely. A separate reader-only caller is compiled **once against baseline public reader headers**, then that exact same object is linked with each library. The two reader-only binaries have matching `.pdata` and only 60 differing bytes in their 491,008-byte `.text` sections; relocation targets/constants are not claimed identical.

The 32-case reader-only matrix pins serial cases to one logical CPU (mask 4); parallel-enabled cases retain mask 12. This changes both caller and serial CPU placement, so it is shown as a separate control rather than overwriting the mixed-caller data.

'''+matrix(reader_only)+'\n\n'+metrics(reader_only)+'''
## 调用程序 × CPU 的独立控制

An independent 2×2 control compares mixed/reader-only callers and affinity mask 4/12, with parallel reads disabled. Each cell runs 192 alternating baseline/fixed process pairs, 3 complete queries/process, 2 warmups/variant. Both versions read the same fixed file for DOUBLE, and the same baseline file for FLOAT. Every sample is retained; the CI resamples 24 chronological blocks of 8 pairs.

| Case | Caller | CPU mask | Fixed / baseline block-median ratio [95% CI] |
|---|---|---:|---|
'''
        for v in factorial['cases'].values():text+=f'| `{v["name"]}` | `{v["caller"]}` | {v["mask"]} | {ratio(v["summary"],"block_median_latency_ratio")} |\n'
        text+='''
## PR #1024 的当前结论

The query timing backfill is measured and disclosed, including the original small mixed-caller slowdown and all controls. It is **not marked as an unconditional no-regression pass**. In the final 12-cell control, every reader-only block-median confidence interval includes 1, while the mixed-caller point estimates reverse direction (fixed slightly faster), including mask 12 used in the earlier confirmation. Thus the earlier slowdown is not stable across independent sessions/protocols. Caller/link layout and CPU placement are possible influences, not proven causes; this experiment changes from quartets to same-file reader pairs as well. Unchanged reader source and object-section matches alone cannot erase the earlier measured latency increase. The sub-percent, session-dependent signal remains unresolved; these observations do not justify a specific reader-source fix or a universal zero-regression claim. Production source and all previous failures remain unchanged.

Precision-2 writer products are byte-identical for these fixtures. Requested precision-0 inputs are integer-valued so both old/default-2 and fixed/0 files remain logically equivalent; Java inspects every value-page prefix and confirms actual precision 2 versus 0. The smaller revised files and their query effects are measured separately from same-file reader cost. This does not compare different rounded answers as if they were the same operation.

Native FIELD pushdown, sole/all-NULL projections, OFFSET/LIMIT timing, compressed-query performance, NaN/extreme-value performance, very large files/metadata and broad parallel scaling are unmeasured. Earlier correctness/coverage/write evidence and known Java extreme-precision failures remain intact in the prior report.
'''
        gate='not_unconditionally_cleared_small_mixed_caller_signal_disclosed'
    text+='''
## 辅助程序内存检查与复现资料

The new helper passes five Linux ASan/UBSan scenarios with leak detection enabled against the previously validated PR02 library: nonempty-property read, non-aligned DOUBLE time/batch/parallel read, aligned FLOAT application filtering, fixture writing and zero-accepted-row read. This is helper validation, not a rerun of each PR's entire suite. No sanitizer suppression was added. Production source is unchanged, so the existing production coverage and write measurements are retained rather than relabeled as newly collected.

The archive includes driver/source/build scripts, all actual writer products for this PR (including the marked invalid control), Java raw-page/type/value audit, binary/library hashes, preflights, all raw timing arrays and discarded-order/initial/confirmation/control data. To reproduce, build static libraries from the pinned base/head with the stated MSVC Release options; configure `CMakeLists.txt` using its `PR01_SOURCE`, `PR01_BASE_INCLUDE`, `PR01_BASE_LIBRARY`, `PR01_FIXED_LIBRARY`, `PR02_BASE_SOURCE`, `PR02_FIXED_SOURCE`, `PR02_BASE_LIBRARY`, `PR02_FIXED_LIBRARY` cache parameters. Run `prepare_data.py`, then `benchmark.py`. The Java audit accepts `TSFILE_QUERY_JAVA_CLASSPATH_FILE` pointing to the classpath from the matching Java build. Reader-only and sanitizer scripts preserve their original local build locations; adapt those paths when replaying in another checkout.
'''
    report_path=base/f'outputs/TsFile_PR_{item}_查询性能补测报告.md'
    report_path.write_text(heading+text+'\n'+footer+'\n',encoding='utf-8')
    data={ 'item':item,'pr_number':original_item['pr_number'],'base_commit':old,'head_commit':new,
       'mixed_cases':expected_count,'query_gate':gate,'end_to_end_initial_range':observed_range(initial,'end_to_end'),
       'raw_initial':f'work/query-backfill/query-performance-{item}-initial.json','report_path':str(report_path),
       'source_unchanged':True,'query_timing_complete':True,'global_no_regression_claim':False}
    (root/f'summary-{item}.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    appendix=f'''### Query performance backfill (2026-10-18)

Added {expected_count} native table-query scenarios over aligned/non-aligned chunks, row/batch APIs, 1/4 projected fields, time/TAG filters, sparse NULLs and parallel settings; application FIELD references include full native materialization cost. Two devices × 32,768 rows × four fields, 32 position-balanced process repetitions and three full checked queries/process. Open/initialization, cached schema lookup, setup, first decoded/accepted row, full-result latency/throughput, per-query p50/p95 and whole-process peak working set are retained. Query samples are clustered by process; no cold-cache, P99 or universal no-regression claim.

'''
    if item=='01':
        appendix+='''No scenario triggers the confirmation policy in the measured corpus. Valid empty-property products are byte-identical. The original nonempty-property product is malformed and is retained as an untimed expected failure; both readers instead time the valid revised nonempty-property file. This does not present invalid output as a fast baseline. Existing write/coverage/bidirectional compatibility results retain their original scope.
'''
    else:
        appendix+='''The initial matrix and 192-quartet independent confirmation show approximately 0.4–0.7% increases in some dense aligned DOUBLE comparisons with the mixed writer/reader caller. This is explicitly **not an unconditional no-regression pass**. All initial samples, the identical-object 32-case reader-only matrix, and independent 12-cell caller × CPU controls (192 pairs/cell) are published separately. The final control does not reproduce the slowdown: all reader-only confidence intervals include 1, and mixed-caller point estimates reverse direction. Its same-file pairs differ from the earlier quartets, so the session/protocol-dependent sub-percent signal remains unresolved; unchanged reader source/object sections do not erase it or establish a cause. No new production commit was made. Precision-0 product comparisons use integer-valued inputs so both writers return the same values; Java verifies actual page precision 2 versus 0. Existing write/coverage and bidirectional correctness evidence is retained.
'''
    appendix+='''
One initial ordering attempt was stopped after its self-check found unequal execution positions; those samples are preserved and excluded from conclusions. The corrected order gives each variant every position equally. Every native returned cell/NULL/timestamp and Python row/checksum expectation is checked. Java independently audits all valid C++ products and actual value-page codecs/counts/precision; five new helper sanitizer scenarios pass with Linux leak detection.

[Query backfill report]({REPORT_URL}) · [Sources, actual products, raw timing arrays and controls]({EVIDENCE_URL})
'''
    (root/f'pr-appendix-{item}.md').write_text(appendix,encoding='utf-8')
    zh=f'''### 查询性能补测（2026-10-18）

新增 {expected_count} 个原生表查询场景，覆盖对齐/非对齐 chunk、行/批接口、1/4 个投影字段、时间/TAG 过滤、稀疏 NULL 和并行配置；应用层 FIELD 参考包含完整原生读取与物化成本。每文件 2 个设备 × 32,768 行 × 4 个字段，32 轮执行位置均衡的独立进程，每进程完整消费并核对 3 次查询。保留打开/初始化、缓存 schema 查询、查询构建、首个解码/接受行、完整延迟/吞吐、逐查询 p50/p95 和进程峰值工作集。统计按进程聚类，不声称冷缓存、P99 或所有场景均无退化。

'''
    if item=='01':
        zh+='''本次 16 个场景均未触发复查条件；有效的空属性前后产物字节一致。旧版本非空属性文件本身损坏，作为预期失败保留且不计时；改用修复后的有效非空属性文件分别计时两个 reader，没有把无效输出当作快速基线。原有写入、覆盖率与双向兼容证据保留原先范围。
'''
    else:
        zh+='''初测及每场景 192 组独立四版本复查中，混合 writer/reader 调用程序的部分稠密对齐 DOUBLE 比较变慢约 0.4%–0.7%，因此**未标为查询性能无条件通过**。全部初测、相同编译对象链接的独立 reader 程序 32 场景，以及调用程序 × CPU 的 12 组控制（每组 192 对进程）均单独公开。最终控制未复现该变慢：所有独立 reader 置信区间均包含 1，混合程序的点估计反向；但其相同文件双版本配对协议与先前四版本协议不同，不能覆盖原始结果。这个与测量轮次/协议相关的小幅信号仍未解释，reader 源码和对象段一致不能抹去它，也不足以确认原因。本次没有生产代码提交。精度 0 产物比较使用整数输入，保证两个 writer 返回相同值；Java 核验实际页精度分别为 2 与 0。保留既有写入、覆盖率与双向正确性证据。
'''
    zh+='''
最初一次执行顺序存在位置不均衡，已中止并保留数据，不用于结论；修正后各版本在所有执行位置出现次数相等。原生程序逐单元格核验值/NULL/时间戳，Python 独立核验行数与校验和；Java 独立核验全部有效 C++ 产物及实际页编码/数量/精度。新增辅助程序的 5 个 Linux sanitizer 场景通过，开启泄漏检测。

[查询补测报告]({REPORT_URL}) · [源码、实际文件、原始计时与控制实验]({EVIDENCE_URL})
'''
    (root/f'pr-appendix-{item}-zh.md').write_text(zh,encoding='utf-8')
    records[item]=data
    files={}
    for p in root.iterdir():
        if p.is_file() and p.suffix in {'.py','.cc','.java','.json','.log','.txt','.md','.sh'}:
            if p.name.startswith('github-') or 'publication' in p.name:continue
            files['query-backfill/'+p.name]=p
    for p in (root/'protocol-order-initial').iterdir():
        if p.is_file():files['query-backfill/protocol-order-initial/'+p.name]=p
    for key,v in plan['fixtures'].items():
        if v['item']==item:
            for path in v['paths'].values():
                p=Path(path);files['query-backfill/data/'+p.name]=p
    for p in (root/'reader-only').glob('*.txt'):files['query-backfill/reader-only/'+p.name]=p
    files['validation-report.md']=report_path
    manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()}
    with zipfile.ZipFile(base/f'outputs/TsFile_PR_{item}_查询性能补测证据.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name,p in files.items():z.write(p,name)
        z.writestr('evidence-manifest.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps(records,ensure_ascii=True,indent=2))

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
#include <chrono>
#include <cmath>
#include <cstring>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>
#include "common/global.h"
#include "reader/filter/tag_filter.h"
#include "reader/tsfile_reader.h"
#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#else
#include <sys/resource.h>
#endif

using namespace common;
using namespace storage;
using Clock = std::chrono::steady_clock;
const int N = 32768, FIELDS = 4, CHUNK_ROWS = 8192;

void check(int code) {
    if (code != E_OK) throw std::runtime_error("code=" + std::to_string(code));
}
void require(bool ok, const char* what) {
    if (!ok) throw std::runtime_error(what);
}
double elapsed(Clock::time_point start) {
    return std::chrono::duration<double>(Clock::now() - start).count();
}
bool is_null_value(bool sparse, int row, int column) {
    return sparse && column > 0 && (row + column) % 11 == 0;
}
double value_at(int device, int row, int column, int precision) {
    return double((device * N + row) * 8 + column) + (precision == 0 ? 0 : .25);
}
uint64_t peak_memory() {
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS counters{};
    counters.cb = sizeof(counters);
    require(GetProcessMemoryInfo(GetCurrentProcess(), &counters, sizeof(counters)) != 0, "working set");
    return counters.PeakWorkingSetSize;
#else
    struct rusage info{};
    require(getrusage(RUSAGE_SELF, &info) == 0, "rusage");
    return uint64_t(info.ru_maxrss) * 1024;
#endif
}

struct Verifier {
    bool is_float, sparse;
    int precision, width, low, high, first_device, read_rows = 0, accepted = 0;
    int application_percent;
    uint64_t checksum = 0, null_cells = 0;
    bool row_accepted = false;
    int row_count() const { return (2 - first_device) * (high - low + 1); }
    int current_row() const { return low + read_rows % (high - low + 1); }
    int current_device() const { return first_device + read_rows / (high - low + 1); }
    void time(int64_t value) const { require(value == current_row(), "timestamp/order mismatch"); }
    void cell(int column, bool nil, double value) {
        const bool expected_null = is_null_value(sparse, current_row(), column);
        require(nil == expected_null, "NULL mismatch");
        if (nil) ++null_cells;
        else require(value == value_at(current_device(), current_row(), column, precision), "value mismatch");
        if (column == 0) {
            require(!nil, "anchor is NULL");
            row_accepted = (int64_t(value) / 8) % 100 < application_percent;
        }
        if (row_accepted)
            checksum += nil ? 17 : uint64_t(value * 4);
    }
    void next() {
        if (row_accepted) ++accepted;
        ++read_rows;
        require(read_rows <= row_count(), "extra row");
    }
};

void emit_array(const std::vector<double>& values, bool nullable = false) {
    std::cout << '[';
    for (size_t i = 0; i < values.size(); ++i) {
        if (i) std::cout << ',';
        if (nullable && values[i] < 0) std::cout << "null";
        else std::cout << values[i];
    }
    std::cout << ']';
}

void read_fixture(const char* path, bool is_float, int precision, bool sparse,
                  const std::string& scenario, int width, int batch, int repeats) {
    const int low = scenario == "time" ? N/4+3 : 0;
    const int high = scenario == "time" ? 3*N/4+5 : N-1;
    const int first_device = scenario == "tag" ? 1 : 0;
    const int percent = scenario == "app0" ? 0 : scenario == "app1" ? 1 : scenario == "app50" ? 50 : 100;
    std::vector<std::string> names;
    for (int c = 0; c < width; ++c) names.push_back("v" + std::to_string(c));
    std::vector<double> opens, metadata, plans, firsts, decoded_firsts, fulls;
    uint64_t checksum = 0, null_cells = 0;
    int rows = 0, accepted = 0;
    for (int repeat = 0; repeat < repeats; ++repeat) {
        const auto start = Clock::now();
        double open_time = 0, metadata_time = 0, plan_time = 0, first = -1, decoded_first = -1;
        Verifier verify{is_float, sparse, precision, width, low, high, first_device, 0, 0, percent};
        {
            TsFileReader reader;
            check(reader.open(path));
            open_time = elapsed(start);
            const auto meta_start = Clock::now();
            std::shared_ptr<TableSchema> schema;
            check(reader.get_table_schema("bench", schema));
            require(schema != nullptr, "missing schema");
            metadata_time = elapsed(meta_start);
            const auto plan_start = Clock::now();
            TagEq tag(1, "d1"); // Borrowed by query: stack lifetime includes result destruction.
            ResultSet* raw = nullptr;
            check(reader.query("bench", names, low, high, raw, scenario == "tag" ? &tag : nullptr, batch));
            std::unique_ptr<ResultSet> result(raw);
            require(result != nullptr, "missing result");
            plan_time = elapsed(plan_start);
            bool has = false;
            while (true) {
                check(result->next(has));
                if (!has) break;
                if (batch <= 0) {
                    if (decoded_first < 0) decoded_first = elapsed(start);
                    verify.time(result->get_value<int64_t>(1));
                    for (int c = 0; c < width; ++c) {
                        bool nil = result->is_null(c+2);
                        double value = nil ? 0 : is_float ? result->get_value<float>(c+2) : result->get_value<double>(c+2);
                        verify.cell(c, nil, value);
                    }
                    if (first < 0 && verify.row_accepted) first = elapsed(start);
                    verify.next();
                } else {
                    TsBlock* block = nullptr;
                    check(result->get_next_tsblock(block));
                    require(block != nullptr, "missing block");
                    if (decoded_first < 0) decoded_first = elapsed(start);
                    RowIterator iter(block);
                    while (iter.has_next()) {
                        uint32_t length = 0; bool nil = false;
                        char* bytes = iter.read(0, &length, &nil);
                        require(!nil && length == sizeof(int64_t), "time cell");
                        int64_t time; std::memcpy(&time, bytes, sizeof(time)); verify.time(time);
                        for (int c = 0; c < width; ++c) {
                            bytes = iter.read(c+1, &length, &nil);
                            double value = 0;
                            if (!nil) {
                                require(length == (is_float ? sizeof(float) : sizeof(double)), "value cell size");
                                if (is_float) { float f; std::memcpy(&f, bytes, sizeof(f)); value = f; }
                                else std::memcpy(&value, bytes, sizeof(value));
                            }
                            verify.cell(c, nil, value);
                        }
                        if (first < 0 && verify.row_accepted) first = elapsed(start);
                        verify.next(); iter.next();
                    }
                }
            }
            require(verify.read_rows == verify.row_count(), "missing rows");
            result.reset();
            check(reader.close());
        }
        fulls.push_back(elapsed(start));
        opens.push_back(open_time); metadata.push_back(metadata_time); plans.push_back(plan_time); firsts.push_back(first); decoded_firsts.push_back(decoded_first);
        checksum += verify.checksum; null_cells += verify.null_cells;
        rows = verify.read_rows; accepted = verify.accepted;
    }
    std::cout.precision(10);
    std::cout << "{\"open_seconds\":"; emit_array(opens);
    std::cout << ",\"metadata_seconds\":"; emit_array(metadata);
    std::cout << ",\"plan_seconds\":"; emit_array(plans);
    std::cout << ",\"first_row_seconds\":"; emit_array(firsts, true);
    std::cout << ",\"first_decoded_row_seconds\":"; emit_array(decoded_firsts, true);
    std::cout << ",\"full_seconds\":"; emit_array(fulls);
    std::cout << ",\"rows_per_query\":" << rows << ",\"accepted_rows_per_query\":" << accepted
              << ",\"fields\":" << width << ",\"repeats\":" << repeats
              << ",\"checksum\":" << checksum << ",\"NULL_cells\":" << null_cells
              << ",\"peak_process_working_set_bytes\":" << peak_memory() << "}\n";
}

int main(int argc, char** argv) {
    try {
        require(argc >= 8, "write file aligned|nonaligned FLOAT|DOUBLE precision sparse properties [scenario width batch parallel repeats]");
        g_config_value_.thread_count_ = 2;
        check(libtsfile_init());
        struct Cleanup { ~Cleanup() { libtsfile_destroy(); } } cleanup;
        g_config_value_.time_compress_type_ = UNCOMPRESSED;
        g_config_value_.page_writer_max_point_num_ = 256;
        g_config_value_.page_writer_max_memory_bytes_ = 1048576;
        g_config_value_.parallel_write_enabled_ = false;
        bool is_float = std::string(argv[4]) == "FLOAT";
        int precision = std::stoi(argv[5]);
        bool sparse = std::stoi(argv[6]) != 0;
        require(argc == 13 && std::string(argv[1]) == "read", "read args");
        g_config_value_.parallel_read_enabled_ = std::stoi(argv[11]) != 0;
        read_fixture(argv[2], is_float, precision, sparse, argv[8], std::stoi(argv[9]), std::stoi(argv[10]), std::stoi(argv[12]));
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}

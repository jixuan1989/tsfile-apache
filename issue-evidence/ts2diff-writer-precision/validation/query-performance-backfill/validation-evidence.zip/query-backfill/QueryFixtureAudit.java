/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.header.PageHeader;
import org.apache.tsfile.file.metadata.ChunkMetadata;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.read.TsFileReader;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.common.Chunk;
import org.apache.tsfile.read.common.Path;
import org.apache.tsfile.read.common.RowRecord;
import org.apache.tsfile.read.expression.QueryExpression;
import org.apache.tsfile.read.query.dataset.QueryDataSet;
import org.apache.tsfile.utils.ReadWriteForEncodingUtils;

public class QueryFixtureAudit {
  static final int N = 32768;
  public static void main(String[] args) throws Exception {
    boolean isFloat=args[1].equals("FLOAT"), aligned=args[2].equals("aligned");
    int precision=Integer.parseInt(args[3]), encodedPrecision=Integer.parseInt(args[5]);
    boolean sparse=args[4].equals("1");
    List<Path> paths=new ArrayList<>();
    for(int d=0;d<2;d++) for(int c=0;c<4;c++) paths.add(new Path("bench.d"+d,"v"+c,true));
    long checksum=0, nullCells=0; int rows=0, chunks=0, pages=0;
    try(TsFileSequenceReader sequence=new TsFileSequenceReader(args[0]);
        TsFileReader reader=new TsFileReader(sequence)) {
      QueryDataSet result=reader.query(QueryExpression.create(paths,null));
      while(result.hasNext()) {
        RowRecord record=result.next();
        if(rows>=N || record.getTimestamp()!=rows || record.getFields().size()!=8) throw new AssertionError("row");
        for(int d=0;d<2;d++) for(int c=0;c<4;c++) {
          var field=record.getFields().get(d*4+c);
          boolean nil=field==null || field.getDataType()==null;
          boolean expectedNull=sparse && c>0 && (rows+c)%11==0;
          if(nil!=expectedNull) throw new AssertionError("NULL");
          if(nil) {nullCells++; checksum+=17;}
          else {
            if(field.getDataType()!=(isFloat?TSDataType.FLOAT:TSDataType.DOUBLE)) throw new AssertionError("type");
            double actual=isFloat?field.getFloatV():field.getDoubleV();
            double expected=(d*N+rows)*8+c+(precision==0?0:.25);
            if(actual!=expected) throw new AssertionError("value="+actual+" expected="+expected);
            checksum+=(long)(actual*4);
          }
        }
        rows++;
      }
      if(rows!=N) throw new AssertionError("count="+rows);
      for(Path path:paths) {
        List<ChunkMetadata> metadata=sequence.getChunkMetadataList(path);
        if(metadata.size()!=4) throw new AssertionError("chunks="+metadata.size());
        for(ChunkMetadata entry:metadata) {
          Chunk chunk=sequence.readMemChunk(entry);
          if(chunk.getHeader().getCompressionType()!=CompressionType.UNCOMPRESSED) throw new AssertionError("codec");
          ByteBuffer body=chunk.getData().duplicate();
          chunks++;
          while(body.hasRemaining()) {
            PageHeader header=PageHeader.deserializeFrom(body,chunk.getHeader().getDataType());
            if(header.getCompressedSize()==0) continue;
            int size=header.getCompressedSize();
            ByteBuffer payload=body.slice();payload.limit(size);
            body.position(body.position()+size);pages++;
            if(encodedPrecision>=0) {
              if(aligned) {
                int count=payload.getInt();
                if(count<=0 || count>256) throw new AssertionError("page rows="+count);
                payload.position(payload.position()+(count+7)/8);
              } else {
                int timeBytes=ReadWriteForEncodingUtils.readUnsignedVarInt(payload);
                payload.position(payload.position()+timeBytes);
              }
              int actual=ReadWriteForEncodingUtils.readUnsignedVarInt(payload);
              if(actual!=encodedPrecision) throw new AssertionError("page precision="+actual+" expected="+encodedPrecision);
            }
          }
        }
      }
    }
    System.out.printf("{\"rows_per_device\":%d,\"devices\":2,\"fields\":4,\"checksum\":%d,\"NULL_cells\":%d,\"value_chunks\":%d,\"value_pages\":%d,\"page_precision\":%d,\"PASS\":true}%n",
        rows,checksum,nullCells,chunks,pages,encodedPrecision);
  }
}

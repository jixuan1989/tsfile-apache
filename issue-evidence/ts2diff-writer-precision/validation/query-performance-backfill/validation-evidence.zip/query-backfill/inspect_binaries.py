"""Compare raw COFF code payloads and PE sections, without claiming relocation equality."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import struct

root = Path(__file__).resolve().parent
base = root.parents[1]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sections(data, start, count):
    result = []
    for i in range(count):
        at = start + 40 * i
        name = data[at:at+8].split(b'\0', 1)[0].decode('ascii')
        size, raw = struct.unpack_from('<II', data, at+16)
        result.append((name, data[raw:raw+size]))
    return result

def coff(path):
    data = path.read_bytes()
    if data[:4] == b'\0\0\xff\xff':
        start, count = 56, struct.unpack_from('<I', data, 44)[0]
    else:
        start, count = 20, struct.unpack_from('<H', data, 2)[0]
    return Counter(digest(v) for n, v in sections(data, start, count) if n.startswith('.text') and v)

names = ['table_result_set', 'aligned_chunk_reader', 'chunk_reader',
         'tsfile_series_scan_iterator', 'tsfile_reader', 'table_query_executor',
         'single_device_tsblock_reader']
objects = {}
manifest_path = root/'tested-artifact-hashes.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))

def capture(path):
    data = path.read_bytes()
    key = path.relative_to(base).as_posix()
    value = {'sha256': digest(data), 'bytes': len(data)}
    if key in manifest['files']:
        assert manifest['files'][key]['sha256'] == value['sha256'], key
    else:
        manifest['files'][key] = value

for name in names:
    paths = []
    for version in ['baseline', 'fixed']:
        found = list((base/f'work/issue-02/validation/msvc-{version}').rglob(name+'.obj'))
        assert len(found) == 1
        paths.append(found[0])
        capture(found[0])
    a, b = map(coff, paths)
    assert a == b, name
    objects[name] = {'matching_text_sections': sum((a & b).values()),
                     'baseline_sections': sum(a.values()), 'fixed_sections': sum(b.values()),
                     'baseline_only': sum((a-b).values()), 'fixed_only': sum((b-a).values())}
(root/'reader-object-text-comparison.json').write_text(json.dumps(objects, indent=2)+'\n', encoding='utf-8')

linked = {}
for caller, folder, prefix in [('mixed', root/'build/Release', 'query_02_'),
                               ('reader_only', root/'reader-only/build/Release', 'read_only_02_')]:
    entry, actual = {}, {}
    for version in ['baseline', 'fixed']:
        path = folder/(prefix+version+'.exe')
        capture(path)
        data = path.read_bytes()
        pe = struct.unpack_from('<I', data, 0x3c)[0]
        assert data[pe:pe+4] == b'PE\0\0'
        count = struct.unpack_from('<H', data, pe+6)[0]
        optional = struct.unpack_from('<H', data, pe+20)[0]
        actual[version] = dict(sections(data, pe+24+optional, count))
        entry[version] = {'binary_sha256': digest(data), 'sections': {
            n: {'bytes': len(v), 'sha256': digest(v)} for n, v in actual[version].items()}}
    entry['text_differing_byte_positions'] = sum(
        a != b for a, b in zip(actual['baseline']['.text'], actual['fixed']['.text']))
    entry['text_length_difference'] = len(actual['fixed']['.text'])-len(actual['baseline']['.text'])
    linked[caller] = entry
(root/'linked-binary-section-comparison.json').write_text(json.dumps(linked, indent=2)+'\n', encoding='utf-8')

for path in list((root/'build/Release').glob('query_01_*.exe')) + [root/'reader-only/build/reader_object.dir/Release/reader_only.obj']:
    capture(path)
manifest_path.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'matching_reader_sections': sum(x['matching_text_sections'] for x in objects.values()),
                  'text_differing_bytes': {k:v['text_differing_byte_positions'] for k,v in linked.items()},
                  'tested_binaries_unchanged': True}))

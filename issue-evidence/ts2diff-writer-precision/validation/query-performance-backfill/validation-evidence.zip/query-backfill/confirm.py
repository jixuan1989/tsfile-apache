from pathlib import Path
import json
import random
import statistics
import benchmark as core

root=Path(__file__).resolve().parent
initial=json.loads((root/'query-performance-02-initial.json').read_text(encoding='utf-8'))
selected={name:case for name,case in initial['cases'].items() if case['summary']['confirmation_signals']}
if not selected:
    print('No cases triggered the initial confirmation policy.')
    raise SystemExit(0)
report={'item':'02','independent_of_initial_samples':True,'rounds_per_case':192,'queries_per_process':3,
    'method':'Unchanged binaries/fixtures/options; 2 warmups per variant; 192 position-balanced process quartets per selected case; case order rotated/reversed across rounds. Preserve every sample. Primary 95% bootstrap interval resamples 24 chronological blocks of 8 quartets (each complete label-position cycle), using median within each block. Also report unblocked summary; per-query p95 remains descriptive.',
    'cases':{name:{'case':v['case'],'initial_signals':v['summary']['confirmation_signals'],'measurements':[]} for name,v in selected.items()}}
labels=['baseline_baseline','fixed_baseline','baseline_fixed','fixed_fixed']
for name,v in report['cases'].items():
    for _ in range(2):
        for label in labels:core.run(v['case'],label)
rng=random.Random(1024192)
names=list(report['cases'])
for round in range(192):
    offset=round%len(names);case_order=names[offset:]+names[:offset]
    if (round//len(names))%2:case_order=list(reversed(case_order))
    for name in case_order:
        offset=round%4;order=labels[offset:]+labels[:offset]
        if (round//4)%2:order=list(reversed(order))
        v=report['cases'][name]
        v['measurements'].append({label:core.run(v['case'],label) for label in order})
    if (round+1)%8==0:
        (root/'query-performance-02-confirmation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print('Confirmation quartets/case:',round+1,flush=True)
for name,v in report['cases'].items():
    summary=core.summarize(v['measurements']);v['summary']=summary
    blocked={}
    for contrast,d in summary['contrasts'].items():
        ratios=[sum(row[d['after']]['full_seconds'])/sum(row[d['before']]['full_seconds']) for row in v['measurements']]
        blocks=[statistics.median(ratios[i:i+8]) for i in range(0,len(ratios),8)]
        boot=sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(20000))
        blocked[contrast]={'block_median_latency_ratio':statistics.median(blocks),
            'bootstrap_95_percent':[core.percentile(boot,.025),core.percentile(boot,.975)],'block_ratios':blocks}
    v['blocked_summary']=blocked
    print(json.dumps({'case':name,'blocked_summary':blocked}),flush=True)
(root/'query-performance-02-confirmation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

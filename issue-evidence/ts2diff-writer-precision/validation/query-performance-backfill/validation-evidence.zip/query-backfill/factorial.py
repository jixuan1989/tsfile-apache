from pathlib import Path
from ctypes import wintypes
import json
import random
import statistics
import subprocess
import benchmark as core

root=Path(__file__).resolve().parent
previous=json.loads((root/'query-performance-02-reader-only.json').read_text(encoding='utf-8'))
names=['DOUBLE_aligned_p2_null0_props0_all_w4_row_parallel0',
       'DOUBLE_aligned_p2_null0_props0_all_w4_batch_parallel0',
       'FLOAT_nonaligned_p2_null0_props0_all_w4_row_parallel0']
cells=[]
for name in names:
    for caller in ['mixed','reader_only']:
        for mask in [4,12]:cells.append((name,caller,mask))
report={'method':'Independent 2x2 control: mixed writer/reader caller versus one-object reader-only caller; single-CPU mask 4 versus two-CPU mask 12. All cases have parallel reads disabled, 2 idle worker threads, identical fixed-produced file for DOUBLE and identical baseline-produced file for FLOAT. 2 warmups/variant/cell and 192 balanced baseline/fixed process pairs per cell, 3 full checked queries/process. Cell order rotated/reversed; paired ratio CI resamples 24 chronological blocks of 8 pairs. This diagnoses caller/CPU effects; it does not erase original observations.',
    'cases':{}}
def run(name,caller,mask,reader):
    case=previous['cases'][name]['case'];fixture=core.plan['fixtures'][case['fixture_key']]
    writer='baseline' if case['kind']=='FLOAT' else 'fixed'
    exe=root/(f'build/Release/query_02_{reader}.exe' if caller=='mixed' else f'reader-only/build/Release/read_only_02_{reader}.exe')
    args=[str(exe),'read',fixture['paths'][writer],case['layout'],case['kind'],str(case['precision']),str(case['sparse']),str(case['properties']),case['scenario'],str(case['width']),str(case['batch']),'0','3']
    p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    pinned=bool(core.affinity(wintypes.HANDLE(int(p._handle)),mask));stdout,stderr=p.communicate();assert pinned
    if p.returncode:raise RuntimeError(stdout+'\n'+stderr)
    d=json.loads([l for l in stdout.splitlines() if l.startswith('{')][-1])
    for k,v in case['expected'].items():assert d[k]==v
    d['affinity_mask']=mask
    return d
def key(n,c,m):return n+'__'+c+'__mask'+str(m)
for name,caller,mask in cells:
    k=key(name,caller,mask);report['cases'][k]={'name':name,'caller':caller,'mask':mask,'measurements':[]}
    for _ in range(2):
        for reader in ['baseline','fixed']:run(name,caller,mask,reader)
for round in range(192):
    offset=round%len(cells);order=cells[offset:]+cells[:offset]
    if (round//len(cells))%2:order=list(reversed(order))
    for name,caller,mask in order:
        readers=['baseline','fixed'] if round%2==0 else ['fixed','baseline']
        report['cases'][key(name,caller,mask)]['measurements'].append({v:run(name,caller,mask,v) for v in readers})
    if (round+1)%8==0:
        (root/'query-performance-02-factorial.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print('Factorial process pairs/cell:',round+1,flush=True)
rng=random.Random(1024124)
for k,v in report['cases'].items():
    ratios=[sum(p['fixed']['full_seconds'])/sum(p['baseline']['full_seconds']) for p in v['measurements']]
    blocks=[statistics.median(ratios[i:i+8]) for i in range(0,len(ratios),8)]
    boot=sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(20000))
    v['summary']={'paired_median_latency_ratio':statistics.median(ratios),
        'block_median_latency_ratio':statistics.median(blocks),'bootstrap_95_percent':[core.percentile(boot,.025),core.percentile(boot,.975)],'block_ratios':blocks}
    print(k,json.dumps(v['summary']),flush=True)
(root/'query-performance-02-factorial.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

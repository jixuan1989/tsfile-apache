from pathlib import Path
import hashlib
import json
import subprocess

root=Path(__file__).resolve().parent
data=root/'data';data.mkdir(exist_ok=True)
cases={ '01': [], '02': [] }

def add(item,layout,kind,precision,sparse,properties,scenario,width,parallel):
    for batch in (0,1024):
        cases[item].append({'name':f'{kind}_{layout}_p{precision}_null{int(sparse)}_props{int(properties)}_{scenario}_w{width}_'+('row' if batch==0 else 'batch')+f'_parallel{parallel}',
           'item':item,'layout':layout,'kind':kind,'precision':precision,'sparse':int(sparse),'properties':int(properties),'scenario':scenario,'width':width,'batch':batch,'parallel':parallel})

add('01','aligned','FLOAT',2,False,False,'all',4,0)
add('01','aligned','FLOAT',2,False,False,'time',1,0)
add('01','aligned','FLOAT',2,False,False,'tag',4,1)
add('01','aligned','FLOAT',2,True,False,'all',4,1)
add('01','aligned','FLOAT',2,True,False,'app1',4,0)
add('01','nonaligned','FLOAT',2,True,False,'time',4,1)
add('01','aligned','FLOAT',2,True,True,'all',4,0)
add('01','aligned','FLOAT',2,True,True,'tag',1,1)
for kind in ('FLOAT','DOUBLE'):
    for layout in ('aligned','nonaligned'):
        add('02',layout,kind,2,False,False,'all',4,0)
        add('02',layout,kind,0,True,False,'time',1,1)
        add('02',layout,kind,0,True,False,'app1',4,1)
add('02','aligned','FLOAT',2,True,False,'tag',4,1)
add('02','nonaligned','DOUBLE',2,True,False,'tag',4,0)
add('02','aligned','DOUBLE',2,True,False,'app50',1,0)
add('02','nonaligned','FLOAT',0,True,False,'app0',1,0)

fixtures={}
for item,values in cases.items():
    for case in values:
        key=f'{item}_{case["kind"]}_{case["layout"]}_p{case["precision"]}_null{case["sparse"]}_props{case["properties"]}'
        case['fixture_key']=key
        if key not in fixtures: fixtures[key]={k:case[k] for k in ('item','layout','kind','precision','sparse','properties')}

records={}
def run(item,reader,args):
    p=subprocess.run([str(root/f'build/Release/query_{item}_{reader}.exe'),*map(str,args)],capture_output=True,text=True,encoding='utf-8')
    return {'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}

for key,case in fixtures.items():
    case['paths']={}
    for writer in ('baseline','fixed'):
        path=data/f'{key}_{writer}.tsfile'
        result=run(case['item'],writer,['write',path,case['layout'],case['kind'],case['precision'],case['sparse'],case['properties']])
        assert result['exit_code']==0,result
        case['paths'][writer]=str(path)
        case.setdefault('sha256',{})[writer]=hashlib.sha256(path.read_bytes()).hexdigest()
        case.setdefault('bytes',{})[writer]=path.stat().st_size
        records[key+'_'+writer+'_write']=result
    case['byte_identical']=case['sha256']['baseline']==case['sha256']['fixed']
    print(key,case['bytes'],'byte_identical',case['byte_identical'],flush=True)
    for writer in ('baseline','fixed'):
        for reader in ('baseline','fixed'):
            args=['read',case['paths'][writer],case['layout'],case['kind'],case['precision'],case['sparse'],case['properties'],'all',4,1024,0,1]
            result=run(case['item'],reader,args)
            records[key+'_'+writer+'_to_'+reader]=result
            expected_invalid=case['item']=='01' and case['properties'] and writer=='baseline'
            if expected_invalid:
                assert result['exit_code']!=0 and 'code=6' in result['stderr'], result
            else:
                assert result['exit_code']==0,result
                row=json.loads(result['stdout'].strip().splitlines()[-1]);assert row['rows_per_query']==65536

plan={'cases':cases,'fixtures':fixtures,'repeats':3,'warmups':2,'pairs':32,'affinity_mask':12,
    'order_policy':'offset=pair%label_count; reverse when (pair//label_count)%2==1. Thirty-two repetitions balance every label over every execution position.',
    'comparisons':{'reader_on_baseline_file':'fixed_reader_baseline_file / baseline_reader_baseline_file',
       'reader_on_fixed_file':'fixed_reader_fixed_file / baseline_reader_fixed_file',
       'writer_products_fixed_reader':'fixed_reader_fixed_file / fixed_reader_baseline_file',
       'end_to_end':'fixed_reader_fixed_file / baseline_reader_baseline_file'},
    'nonempty_property_control':'Original malformed producer files are retained as untimed expected failures. Only the valid fixed-produced nonempty-property file is compared between readers.',
    'confirmation_policy':'Preserve all initial samples. Any paired-median 95% interval wholly above 1, median ratio above 1.03, or descriptive p95 ratio above 1.10 is flagged for independent confirmation and investigation; no automatic performance pass from a noisy initial run.'}
(root/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
(root/'preflight.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
print('Cases', {k:len(v) for k,v in cases.items()},'fixtures',len(fixtures),flush=True)

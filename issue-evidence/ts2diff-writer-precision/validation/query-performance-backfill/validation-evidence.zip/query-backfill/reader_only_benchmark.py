from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import subprocess
import benchmark as core

root=Path(__file__).resolve().parent
original=json.loads((root/'query-performance-02-initial.json').read_text(encoding='utf-8'))
selected=[(n,v) for n,v in original['cases'].items() if v['summary']['confirmation_signals']]
others=[(n,v) for n,v in original['cases'].items() if not v['summary']['confirmation_signals']]
report={'item':'02','method':'Query-only caller compiled once against baseline public read headers; the exact same object is linked to each static library. No writer/encoder helper code is compiled into the caller. Serial cases pinned to one CPU (mask 4); parallel-enabled cases pinned to two CPUs (mask 12), two-worker pool. Same fixtures, 2 warmups, 32 position-balanced quartets, 3 complete queries/process. Original mixed-driver dual-CPU measurements and confirmation remain preserved as a separate workload, not erased or reclassified as passing.',
    'cases':{}}
labels=['baseline_baseline','fixed_baseline','baseline_fixed','fixed_fixed']
def run(case,label):
    reader,writer=label.split('_');fixture=core.plan['fixtures'][case['fixture_key']]
    mask=12 if case['parallel'] else 4
    args=[str(root/f'reader-only/build/Release/read_only_02_{reader}.exe'),'read',fixture['paths'][writer],
        case['layout'],case['kind'],str(case['precision']),str(case['sparse']),str(case['properties']),
        case['scenario'],str(case['width']),str(case['batch']),str(case['parallel']),'3']
    p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    pinned=bool(core.affinity(wintypes.HANDLE(int(p._handle)),mask));stdout,stderr=p.communicate()
    assert pinned
    if p.returncode:raise RuntimeError(stdout+'\n'+stderr)
    data=json.loads([l for l in stdout.splitlines() if l.startswith('{')][-1])
    for key,value in case['expected'].items():assert data[key]==value,(key,data[key],value)
    data['affinity_mask']=mask
    return data

for name,previous in selected+others:
    case=previous['case'];print('Reader-only:',name,flush=True)
    for _ in range(2):
        for label in labels:run(case,label)
    measurements=[]
    for pair in range(32):
        offset=pair%4;order=labels[offset:]+labels[:offset]
        if (pair//4)%2:order=list(reversed(order))
        measurements.append({label:run(case,label) for label in order})
    summary=core.summarize(measurements)
    report['cases'][name]={'case':case,'summary':summary,'measurements':measurements}
    (root/'query-performance-02-reader-only.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'case':name,'contrasts':summary['contrasts'],'signals':summary['confirmation_signals']}),flush=True)

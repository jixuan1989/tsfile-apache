### Query performance backfill (2026-10-18)

Added 16 native table-query scenarios over aligned/non-aligned chunks, row/batch APIs, 1/4 projected fields, time/TAG filters, sparse NULLs and parallel settings; application FIELD references include full native materialization cost. Two devices × 32,768 rows × four fields, 32 position-balanced process repetitions and three full checked queries/process. Open/initialization, cached schema lookup, setup, first decoded/accepted row, full-result latency/throughput, per-query p50/p95 and whole-process peak working set are retained. Query samples are clustered by process; no cold-cache, P99 or universal no-regression claim.

No scenario triggers the confirmation policy in the measured corpus. Valid empty-property products are byte-identical. The original nonempty-property product is malformed and is retained as an untimed expected failure; both readers instead time the valid revised nonempty-property file. This does not present invalid output as a fast baseline. Existing write/coverage/bidirectional compatibility results retain their original scope.

One initial ordering attempt was stopped after its self-check found unequal execution positions; those samples are preserved and excluded from conclusions. The corrected order gives each variant every position equally. Every native returned cell/NULL/timestamp and Python row/checksum expectation is checked. Java independently audits all valid C++ products and actual value-page codecs/counts/precision; five new helper sanitizer scenarios pass with Linux leak detection.

[Query backfill report]({REPORT_URL}) · [Sources, actual products, raw timing arrays and controls]({EVIDENCE_URL})

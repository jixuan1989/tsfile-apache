from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import random
import statistics
import subprocess

root = Path(__file__).resolve().parent
binary = root / 'msvc-drivers/Release'
set_affinity = ctypes.windll.kernel32.SetProcessAffinityMask
set_affinity.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
set_affinity.restype = wintypes.BOOL

def run(kind, args):
    process = subprocess.Popen([str(binary / f'schema_{kind}.exe'), *map(str, args)],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    affinity_applied = bool(set_affinity(wintypes.HANDLE(int(process._handle)), 4))
    stdout, stderr = process.communicate()
    if process.returncode:
        raise RuntimeError(f'{kind} {args}: {stdout}\n{stderr}')
    result = json.loads([line for line in stdout.splitlines() if line.startswith('{')][-1])
    result['affinity_mask'] = 4 if affinity_applied else None
    return result

def percentile(values, fraction):
    values = sorted(values)
    index = (len(values) - 1) * fraction
    lo = int(index)
    hi = min(lo + 1, len(values) - 1)
    return values[lo] * (hi - index) + values[hi] * (index - lo) if hi != lo else values[lo]

cases = {
    'schema_empty_original_baseline': {
        'baseline': ['serialize', 1000000, 0, 0], 'fixed': ['serialize', 1000000, 0, 0],
        'comparison': 'Original valid empty-property serializer versus fixed serializer',
    },
    'table_empty_original_baseline': {
        'baseline': ['table', root / 'benchmark-baseline.tsfile', 50000, 0],
        'fixed': ['table', root / 'benchmark-fixed.tsfile', 50000, 0],
        'comparison': 'Original valid no-property table writer versus fixed writer; 50,000 rows x 16 FLOAT PLAIN UNCOMPRESSED fields; both outputs read back',
    },
    'schema_one_valid_reference': {
        'baseline': ['serialize', 1000000, 1, 1], 'fixed': ['serialize', 1000000, 1, 0],
        'comparison': 'Valid manual format reference versus fixed serializer; original non-empty output is invalid and is not a valid-output performance baseline',
    },
    'schema_many_valid_reference': {
        'baseline': ['serialize', 100000, 64, 1], 'fixed': ['serialize', 100000, 64, 0],
        'comparison': 'Valid manual format reference versus fixed serializer for 64 properties',
    },
}
report = {'platform': 'Windows x64, MSVC 14.50 Release, same flags, ENABLE_THREADS/ENABLE_MEM_STAT on',
          'baseline_commit': '12e39fe9d9dace63cc0ad39664aa0fbf5e29f52f',
          'warmup_processes_per_variant': 2, 'measured_pairs': 25,
          'process_affinity_requested': 4, 'cases': {}}
rng = random.Random(1017)
for name, case in cases.items():
    print(f'Benchmark: {name}', flush=True)
    for _ in range(2):
        for kind in ['baseline', 'fixed']:
            run(kind, case[kind])
    measurements = []
    for pair in range(25):
        row = {}
        order = ['baseline', 'fixed'] if pair % 2 == 0 else ['fixed', 'baseline']
        for kind in order:
            row[kind] = run(kind, case[kind])
        if 'serialized_bytes' in row['baseline']:
            assert row['baseline']['serialized_bytes'] == row['fixed']['serialized_bytes']
        measurements.append(row)
    ratios = [row['fixed']['seconds'] / row['baseline']['seconds'] for row in measurements]
    bootstrap = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    summary = {'comparison': case['comparison'], 'latency_ratio_fixed_over_baseline': statistics.median(ratios),
               'paired_median_ratio_bootstrap_95_percent': [percentile(bootstrap, .025), percentile(bootstrap, .975)]}
    for kind in ['baseline', 'fixed']:
        values = [row[kind] for row in measurements]
        seconds = [value['seconds'] for value in values]
        units = values[0].get('iterations', values[0].get('points'))
        summary[kind] = {'median_seconds': statistics.median(seconds), 'p95_seconds': percentile(seconds, .95),
                         'median_units_per_second': statistics.median(units / value for value in seconds),
                         'median_peak_working_set_bytes': statistics.median(value['peak_working_set_bytes'] for value in values),
                         'max_peak_working_set_bytes': max(value['peak_working_set_bytes'] for value in values)}
    report['cases'][name] = {'summary': summary, 'measurements': measurements}
    (root / 'performance.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'case': name, **summary}), flush=True)

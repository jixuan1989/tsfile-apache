import org.apache.tsfile.common.conf.TSFileDescriptor;
import org.apache.tsfile.enums.ColumnCategory;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.TableSchema;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.query.dataset.ResultSet;
import org.apache.tsfile.read.v4.ITsFileReader;
import org.apache.tsfile.read.v4.TsFileReaderBuilder;
import org.apache.tsfile.write.TsFileWriter;
import org.apache.tsfile.write.record.Tablet;
import org.apache.tsfile.write.schema.IMeasurementSchema;
import org.apache.tsfile.write.schema.MeasurementSchema;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class SchemaCompatibility {
  static void check(boolean valid, String message) {
    if (!valid) throw new AssertionError(message);
  }

  static Map<String, String> properties(int variant) {
    Map<String, String> props = new TreeMap<>();
    switch (variant) {
      case 0: break;
      case 1: props.put("max_point_number", "0"); break;
      case 2:
        props.put("", ""); props.put("max_point_number", "0"); props.put("unit", "celsius"); break;
      case 3: props.put("k".repeat(131), "v".repeat(4097)); break;
      case 4:
        props.put("\u6e29\u5ea6", "\u6444\u6c0f\ud83c\udf21");
        props.put("unit", "unicode-value"); break;
      case 5:
        for (int i = 0; i < 64; i++) props.put(String.format("key%03d", i), "value" + i); break;
    }
    return props;
  }

  static void matrix(Path javaDir, Path cppDir, boolean generate) throws Exception {
    Files.createDirectories(javaDir);
    List<String> names = new ArrayList<>();
    String[] types = {"BOOLEAN", "INT32", "INT64", "FLOAT", "DOUBLE", "TEXT", "TIMESTAMP", "DATE", "BLOB", "STRING"};
    for (String type : types) {
      for (CompressionType compression : CompressionType.values()) {
        for (int variant = 0; variant < 6; variant++) {
          String name = type + "_" + compression + "_" + variant + ".schema";
          names.add(name);
          MeasurementSchema expected = new MeasurementSchema("temperature", TSDataType.valueOf(type),
              TSEncoding.PLAIN, compression, properties(variant));
          ByteArrayOutputStream stream = new ByteArrayOutputStream();
          expected.serializeTo(stream);
          byte[] reference = stream.toByteArray();
          if (generate) {
            Files.write(javaDir.resolve(name), reference);
          } else {
            byte[] actualBytes = Files.readAllBytes(cppDir.resolve(name));
            ByteBuffer buffer = ByteBuffer.wrap(actualBytes);
            MeasurementSchema actual = MeasurementSchema.deserializeFrom(buffer);
            check(buffer.remaining() == 0, name + " trailing bytes");
            check(expected.getMeasurementName().equals(actual.getMeasurementName()), name + " name");
            check(expected.getType() == actual.getType(), name + " type");
            check(expected.getEncodingType() == actual.getEncodingType(), name + " encoding");
            check(expected.getCompressor() == actual.getCompressor(), name + " compression");
            check(properties(variant).equals(actual.getProps() == null ? Map.of() : actual.getProps()), name + " props");
            check(Arrays.equals(reference, actualBytes), name + " byte layout");
          }
        }
      }
    }
    if (generate) Files.write(javaDir.resolve("manifest.txt"), names);
    System.out.println("schema_cases=" + names.size() + " mode=" + (generate ? "generate" : "verify_cpp") + " result=PASS");
  }

  static void verifyTable(String path, int rows, boolean withProps) throws Exception {
    try (TsFileSequenceReader reader = new TsFileSequenceReader(path)) {
      TableSchema schema = reader.getTableSchemaMap().get("audit");
      check(schema != null && schema.getColumnSchemas().size() == 16, "table schema: keys=" + reader.getTableSchemaMap().keySet() + " columns=" + (schema == null ? -1 : schema.getColumnSchemas().size()));
      for (IMeasurementSchema column : schema.getColumnSchemas()) {
        Map<String, String> props = column.getProps();
        check((withProps ? properties(1) : Map.of()).equals(props == null ? Map.of() : props), "table properties");
      }
    }
    List<String> columns = new ArrayList<>();
    for (int i = 0; i < 16; i++) columns.add("v" + i);
    try (ITsFileReader reader = new TsFileReaderBuilder().file(new File(path)).build();
         ResultSet result = reader.query("audit", columns, 0, rows)) {
      int row = 0;
      while (result.next()) {
        check(result.getLong(1) == row, "timestamp " + row);
        for (int column = 0; column < 16; column++) {
          check(result.getFloat(column + 2) == row + 1.25f, "value " + row + "/" + column);
        }
        row++;
      }
      check(row == rows, "row count " + row);
    }
    System.out.println("table_file=" + path + " rows=" + rows + " properties=" + withProps + " java_read=PASS");
  }

  static void writeTable(String path) throws Exception {
    TSFileDescriptor.getInstance().getConfig().setCompressor("UNCOMPRESSED");
    List<IMeasurementSchema> columns = new ArrayList<>();
    List<ColumnCategory> categories = new ArrayList<>();
    List<String> names = new ArrayList<>();
    List<TSDataType> types = new ArrayList<>();
    for (int i = 0; i < 16; i++) {
      names.add("v" + i); types.add(TSDataType.FLOAT); categories.add(ColumnCategory.FIELD);
      columns.add(new MeasurementSchema("v" + i, TSDataType.FLOAT, TSEncoding.PLAIN,
          CompressionType.UNCOMPRESSED, properties(1)));
    }
    TableSchema schema = new TableSchema("audit", columns, categories);
    Tablet tablet = new Tablet("audit", names, types, categories, 64);
    for (int row = 0; row < 64; row++) {
      tablet.addTimestamp(row, row);
      for (String name : names) tablet.addValue(row, name, row + 1.25f);
    }
    try (TsFileWriter writer = new TsFileWriter(new File(path))) {
      writer.setGenerateTableSchema(true); writer.registerTableSchema(schema); writer.writeTable(tablet);
    }
    verifyTable(path, 64, true);
  }

  public static void main(String[] args) throws Exception {
    switch (args[0]) {
      case "generate": matrix(Path.of(args[1]), null, true); break;
      case "verify": matrix(Path.of(args[1]), Path.of(args[2]), false); break;
      case "write-table": writeTable(args[1]); break;
      case "verify-nul": {
        Map<String, String> props = Map.of("a\u0000b", "x\u0000y");
        MeasurementSchema schema = new MeasurementSchema("temperature", TSDataType.FLOAT,
            TSEncoding.TS_2DIFF, CompressionType.UNCOMPRESSED, props);
        ByteArrayOutputStream reference = new ByteArrayOutputStream();
        schema.serializeTo(reference);
        byte[] actual = Files.readAllBytes(Path.of(args[1]));
        check(Arrays.equals(reference.toByteArray(), actual), "NUL serialization bytes");
        check(props.equals(MeasurementSchema.deserializeFrom(ByteBuffer.wrap(actual)).getProps()), "NUL Java read");
        System.out.println("cpp_nul_serialization_java_read=PASS bytes=" + actual.length);
        break;
      }
      case "verify-table": verifyTable(args[1], Integer.parseInt(args[2]), Boolean.parseBoolean(args[3])); break;
      default: throw new IllegalArgumentException(args[0]);
    }
  }
}

#!/usr/bin/env bash
set -euo pipefail
validation_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2/work/issue-01/validation
task_cmake=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2/work/wsl-tools/cmake/data/bin/cmake
"$task_cmake" --build "$validation_root/linux-coverage" --target TsFile_Test --parallel 6 > "$validation_root/linux-final-build.log" 2>&1
cd "$validation_root"
TSFILE_COMPAT_GENERATE_DIR="$validation_root/native-cpp-fixtures" \
TSFILE_COMPAT_VALIDATE_DIR="$validation_root/native-java-fixtures" \
./linux-coverage/test/lib/TsFile_Test \
  --gtest_filter='MeasurementSchemaSerializationTest.*:TableModelEncodingCompressionCompatibilityTest.*' \
  --gtest_output=xml:linux-compat-tests.xml > linux-compat-tests.log 2>&1
PYTHONPATH=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2/work/wsl-tools \
python3 -m gcovr --root /mnt/d/code/tsfile/cpp \
  --filter '/mnt/d/code/tsfile/cpp/src/common/schema.h' \
  --exclude-directory '.*third_party.*' --exclude-directory '.*googletest.*' \
  --merge-mode-functions=merge-use-line-min --json-pretty \
  --output "$validation_root/coverage-schema.json" \
  "$validation_root/linux-coverage" > "$validation_root/coverage-collection.log" 2>&1
tail -n 14 linux-compat-tests.log

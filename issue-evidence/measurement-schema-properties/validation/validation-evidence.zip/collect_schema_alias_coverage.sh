#!/usr/bin/env bash
set -euo pipefail
validation_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2/work/issue-01/validation
cmp /mnt/d/code/tsfile/cpp/src/common/schema.h "$validation_root/linux-coverage/include/common/schema.h"
cd "$validation_root"
PYTHONPATH=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2/work/wsl-tools \
python3 -m gcovr -j 6 --root /mnt --filter '.*/common/schema[.]h$' \
  --exclude-directory '.*third_party.*' --exclude-directory '.*googletest.*' \
  --merge-mode-functions=merge-use-line-min --json-pretty \
  --output "$validation_root/coverage-schema-aliases.json" \
  "$validation_root/linux-coverage" > "$validation_root/coverage-alias-collection.log" 2>&1

#!/usr/bin/env bash
set -euo pipefail
validation_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2/work/issue-01/validation
task_cmake=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2/work/wsl-tools/cmake/data/bin/cmake
CXXFLAGS=--coverage "$task_cmake" -S /mnt/d/code/tsfile/cpp -B "$validation_root/linux-coverage" \
  -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_FLAGS_DEBUG='-O0 -g --coverage' \
  -DCMAKE_C_FLAGS_DEBUG='-O0 -g --coverage' -DCMAKE_EXE_LINKER_FLAGS=--coverage \
  -DCMAKE_SHARED_LINKER_FLAGS=--coverage -DCOV_ENABLED=ON \
  -DTSFILE_BUILD_SHARED=OFF -DBUILD_TEST=ON -DBUILD_TOOLS=OFF \
  -DENABLE_ANTLR4=OFF -DENABLE_SIMD=OFF -DENABLE_THREADS=ON \
  -DENABLE_SNAPPY=ON -DENABLE_LZ4=ON -DENABLE_LZOKAY=ON \
  -DENABLE_ZLIB=ON -DENABLE_ZSTD=ON -DENABLE_LZMA2=ON \
  > "$validation_root/linux-configure.log" 2>&1
"$task_cmake" --build "$validation_root/linux-coverage" --target TsFile_Test --parallel 6 \
  > "$validation_root/linux-build.log" 2>&1
cd "$validation_root"
./linux-coverage/test/lib/TsFile_Test \
  --gtest_output=xml:linux-all-tests.xml > linux-all-tests.log 2>&1
tail -n 12 linux-all-tests.log

#include <chrono>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <vector>
#include <fcntl.h>
#include "common/schema.h"
#include "file/write_file.h"
#include "reader/tsfile_reader.h"
#include "writer/tsfile_table_writer.h"
#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#else
#define O_BINARY 0
#endif

using namespace storage;
using namespace common;

void check(bool ok, const char* message) {
    if (!ok) throw std::runtime_error(message);
}

uint64_t peak_memory() {
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS info{};
    GetProcessMemoryInfo(GetCurrentProcess(), &info, sizeof(info));
    return info.PeakWorkingSetSize;
#else
    return 0;
#endif
}

void schema_roundtrip(const std::string& input, const std::string& output) {
    std::ifstream manifest(input + "/manifest.txt");
    check(manifest.good(), "manifest");
    std::string name;
    int count = 0;
    while (std::getline(manifest, name)) {
        std::ifstream file(input + "/" + name, std::ios::binary);
        std::vector<char> bytes((std::istreambuf_iterator<char>(file)), {});
        ByteStream in;
        in.wrap_from(bytes.data(), bytes.size());
        MeasurementSchema schema;
        check(schema.deserialize_from(in) == E_OK && in.remaining_size() == 0, "read Java schema");
        ByteStream out(16, MOD_DEFAULT);
        check(schema.serialize_to(out) == E_OK, "write C++ schema");
        std::vector<char> actual(out.total_size());
        copy_bs_to_buf(out, actual.data(), actual.size());
        std::ofstream result(output + "/" + name, std::ios::binary);
        result.write(actual.data(), actual.size());
        check(result.good(), "write schema file");
        ++count;
    }
    std::cout << "schema_cases=" << count << " java_read_cpp_write=PASS\n";
}

// A valid-output reference to distinguish required property work from the
// old serializer's incomplete output. The unchanged valid workload is empty props.
int reference_serialize(MeasurementSchema& schema, ByteStream& out) {
    int ret = E_OK;
    if (RET_FAIL(SerializationUtil::write_str(schema.measurement_name_, out))) return ret;
    if (RET_FAIL(SerializationUtil::write_ui8(schema.data_type_, out))) return ret;
    if (RET_FAIL(SerializationUtil::write_ui8(schema.encoding_, out))) return ret;
    if (RET_FAIL(SerializationUtil::write_ui8(schema.compression_type_, out))) return ret;
    if (RET_FAIL(SerializationUtil::write_ui32(schema.props_.size(), out))) return ret;
    for (const auto& prop : schema.props_) {
        if (RET_FAIL(SerializationUtil::write_str(prop.first, out))) return ret;
        if (RET_FAIL(SerializationUtil::write_str(prop.second, out))) return ret;
    }
    return ret;
}

void benchmark_schema(int iterations, int property_count, bool reference) {
    MeasurementSchema schema("temperature", common::FLOAT, TS_2DIFF, UNCOMPRESSED);
    for (int i = 0; i < property_count; ++i) {
        schema.props_[property_count == 1 ? "max_point_number" : "key" + std::to_string(i)] = "0";
    }
    volatile uint64_t checksum = 0;
    uint64_t size = 0;
    for (int i = 0; i < 2000; ++i) {
        ByteStream out(1024, MOD_DEFAULT);
        check((reference ? reference_serialize(schema, out) : schema.serialize_to(out)) == E_OK, "warmup");
        checksum += out.total_size();
    }
    const auto start = std::chrono::steady_clock::now();
    for (int i = 0; i < iterations; ++i) {
        ByteStream out(1024, MOD_DEFAULT);
        check((reference ? reference_serialize(schema, out) : schema.serialize_to(out)) == E_OK, "serialize");
        size = out.total_size();
        checksum += size;
    }
    double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    std::cout << "{\"mode\":\"serialize\",\"iterations\":" << iterations
              << ",\"properties\":" << property_count << ",\"reference\":" << reference
              << ",\"seconds\":" << seconds << ",\"serialized_bytes\":" << size
              << ",\"peak_working_set_bytes\":" << peak_memory() << "}\n";
}

void verify_table(const char* path, int rows) {
    TsFileReader reader;
    check(reader.open(path) == E_OK, "open table");
    std::vector<std::string> columns;
    for (int i = 0; i < 16; ++i) columns.push_back("v" + std::to_string(i));
    ResultSet* result = nullptr;
    check(reader.query("audit", columns, 0, rows, result) == E_OK && result, "query table");
    bool has = false;
    int row = 0;
    while (true) {
        check(result->next(has) == E_OK, "next row");
        if (!has) break;
        for (int i = 0; i < 16; ++i) check(result->get_value<float>(i + 2) == row + 1.25f, "table value");
        ++row;
    }
    check(row == rows, "table row count");
    reader.destroy_query_data_set(result);
    reader.close();
}

void write_table(const char* path, int rows, bool properties) {
    g_config_value_.time_compress_type_ = UNCOMPRESSED;
    std::vector<MeasurementSchema*> columns;
    std::vector<ColumnCategory> categories(16, ColumnCategory::FIELD);
    for (int i = 0; i < 16; ++i) {
        auto* column = new MeasurementSchema("v" + std::to_string(i), common::FLOAT, PLAIN, UNCOMPRESSED);
        if (properties) column->props_["max_point_number"] = "0";
        columns.push_back(column);
    }
    TableSchema schema("audit", columns, categories);
    Tablet tablet("audit", schema.get_measurement_names(), schema.get_data_types(), categories, rows);
    for (int row = 0; row < rows; ++row) {
        tablet.add_timestamp(row, row);
        for (int col = 0; col < 16; ++col) tablet.add_value(row, "v" + std::to_string(col), row + 1.25f);
    }
    const auto start = std::chrono::steady_clock::now();
    storage::WriteFile file;
    check(file.create(path, O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0666) == E_OK, "create table");
    {
        TsFileTableWriter writer(&file, &schema);
        check(writer.write_table(tablet) == E_OK, "write table");
        check(writer.close() == E_OK, "close table");
    }
    double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    verify_table(path, rows);
    std::cout << "{\"mode\":\"table\",\"rows\":" << rows << ",\"points\":" << rows * 16
              << ",\"properties\":" << properties << ",\"seconds\":" << seconds
              << ",\"peak_working_set_bytes\":" << peak_memory() << "}\n";
}

int main(int argc, char** argv) {
    try {
        check(libtsfile_init() == E_OK, "init");
        std::string mode(argv[1]);
        if (mode == "schema") schema_roundtrip(argv[2], argv[3]);
        else if (mode == "serialize") benchmark_schema(std::stoi(argv[2]), std::stoi(argv[3]), std::stoi(argv[4]) != 0);
        else if (mode == "table") write_table(argv[2], std::stoi(argv[3]), std::stoi(argv[4]) != 0);
        else if (mode == "read-table") { verify_table(argv[2], std::stoi(argv[3])); std::cout << "cpp_table_read=PASS\n"; }
        else if (mode == "nul-schema") {
            MeasurementSchema schema("temperature", common::FLOAT, TS_2DIFF, UNCOMPRESSED);
            schema.props_[std::string("a\0b", 3)] = std::string("x\0y", 3);
            ByteStream stream(16, MOD_DEFAULT);
            check(schema.serialize_to(stream) == E_OK, "write NUL schema");
            std::vector<char> bytes(stream.total_size());
            copy_bs_to_buf(stream, bytes.data(), bytes.size());
            std::ofstream file(argv[2], std::ios::binary);
            file.write(bytes.data(), bytes.size());
            check(file.good(), "save NUL schema");
        }
        else if (mode == "nul") {
            ByteStream stream(16, MOD_DEFAULT);
            const std::string expected("a\0b", 3);
            std::string actual;
            check(SerializationUtil::write_str(expected, stream) == E_OK, "write NUL string");
            check(SerializationUtil::read_str(actual, stream) == E_OK, "read NUL string");
            std::cout << "expected_string_bytes=" << expected.size() << " actual_string_bytes=" << actual.size()
                      << " known_incompatibility=" << (expected != actual) << '\n';
        }
        else throw std::runtime_error("mode");
        libtsfile_destroy();
        return 0;
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}

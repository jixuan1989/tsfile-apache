from pathlib import Path
import json
import subprocess
from datetime import datetime

root = Path(__file__).resolve().parent
base = root.parents[2]
classpath = (base / 'work/java-classpath.txt').read_text().strip() + ';' + str(root)
fixed = root / 'msvc-drivers/Release/schema_fixed.exe'
baseline = root / 'msvc-drivers/Release/schema_baseline.exe'
run_root = root / ('interop-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
run_root.mkdir()
(run_root / 'cpp-schemas').mkdir()

report = {'schema_cases': 360, 'schema_type_count': 10, 'schema_compression_marker_count': 6,
          'schema_property_variants': 6, 'cases': []}

def run(name, args, expected=None):
    result = subprocess.run(list(map(str, args)), capture_output=True, text=True, encoding='utf-8')
    record = {'name': name, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    report['cases'].append(record)
    (root / 'compatibility.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if result.returncode or (expected is not None and expected not in result.stdout):
        raise RuntimeError(f'{name}: {result.stdout}\n{result.stderr}')
    lines = result.stdout.strip().splitlines()
    print(name + ': ' + (lines[-1] if lines else 'exit=0'), flush=True)

java = ['java', '-cp', classpath, 'SchemaCompatibility']
run('Java generates schemas', [*java, 'generate', run_root / 'java-schemas'], 'schema_cases=360')
run('C++ reads Java and writes schemas', [fixed, 'schema', run_root / 'java-schemas', run_root / 'cpp-schemas'], 'schema_cases=360')
run('Java reads C++ and checks exact bytes', [*java, 'verify', run_root / 'java-schemas', run_root / 'cpp-schemas'], 'result=PASS')
run('C++ writes and reads full table with properties', [fixed, 'table', run_root / 'cpp.tsfile', 64, 1])
run('Java validates C++ table data and properties', [*java, 'verify-table', run_root / 'cpp.tsfile', 64, 'true'], 'java_read=PASS')
run('Java writes and reads full table with properties', [*java, 'write-table', run_root / 'java.tsfile'], 'java_read=PASS')
run('C++ validates Java table data', [fixed, 'read-table', run_root / 'java.tsfile', 64], 'cpp_table_read=PASS')
run('C++ serializes embedded NUL properties', [fixed, 'nul-schema', run_root / 'nul.schema'])
run('Java validates NUL property bytes and values', [*java, 'verify-nul', run_root / 'nul.schema'], 'cpp_nul_serialization_java_read=PASS')
run('Existing NUL reader limitation, original', [baseline, 'nul'], 'expected_string_bytes=3 actual_string_bytes=1 known_incompatibility=1')
run('Existing NUL reader limitation, fixed', [fixed, 'nul'], 'expected_string_bytes=3 actual_string_bytes=1 known_incompatibility=1')
report['result'] = 'PASS within serialization scope; existing independent embedded-NUL reader limitation reproduced in both versions'
(root / 'compatibility.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

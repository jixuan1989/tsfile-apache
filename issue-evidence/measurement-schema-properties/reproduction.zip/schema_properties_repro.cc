#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>

#include "common/schema.h"
#include "reader/tsfile_reader.h"

int main(int argc, char** argv) {
    storage::libtsfile_init();
    storage::MeasurementSchema original(
        "temperature", common::FLOAT, common::TS_2DIFF,
        common::UNCOMPRESSED);
    bool with_properties = true;
    std::string read_path, write_path;
    for (int i = 1; i < argc; ++i) {
        std::string arg(argv[i]);
        if (arg == "--empty") with_properties = false;
        if (arg == "--read" && i + 1 < argc) read_path = argv[++i];
        if (arg == "--write" && i + 1 < argc) write_path = argv[++i];
    }
    if (with_properties) original.props_["max_point_number"] = "0";

    common::ByteStream bytes(1024, common::MOD_DEFAULT);
    int serialize_result = common::E_OK;
    std::vector<char> raw_bytes;
    if (read_path.empty()) {
        serialize_result = original.serialize_to(bytes);
        raw_bytes.resize(bytes.total_size());
        common::copy_bs_to_buf(bytes, raw_bytes.data(), raw_bytes.size());
        if (!write_path.empty()) {
            std::ofstream file(write_path, std::ios::binary);
            file.write(raw_bytes.data(), raw_bytes.size());
            if (!file.good()) return 2;
        }
    } else {
        std::ifstream file(read_path, std::ios::binary);
        if (!file) return 2;
        raw_bytes.assign(std::istreambuf_iterator<char>(file), {});
        bytes.wrap_from(raw_bytes.data(), raw_bytes.size());
    }
    storage::MeasurementSchema decoded;
    int deserialize_result = decoded.deserialize_from(bytes);

    std::cout << "language=C++\n"
              << "input.measurement=temperature\n"
              << "input.type=FLOAT encoding=TS_2DIFF compression=UNCOMPRESSED\n"
              << "input.properties=" << (with_properties ? "{max_point_number=0}" : "{}") << '\n';
    if (read_path.empty()) std::cout << "serialize_return=" << serialize_result << " (E_OK=0)\n";
    std::cout << "serialized_bytes=" << raw_bytes.size() << '\n'
              << "deserialize_return=" << deserialize_result << " (E_OK=0, E_PARTIAL_READ=6)\n"
              << "output.properties={";
    bool first = true;
    for (const auto& item : decoded.props_) {
        if (!first) std::cout << ", ";
        std::cout << item.first << '=' << item.second;
        first = false;
    }
    std::cout << "}\n";
    bool valid = serialize_result == common::E_OK &&
                 deserialize_result == common::E_OK &&
                 decoded.props_ == original.props_;
    std::cout << "result=" << (valid ? "PASS" : "FAIL") << '\n';
    storage::libtsfile_destroy();
    return valid ? 0 : 1;
}

# TsFile Issue 01: Java / C++ same-input reproduction

Source commit: 12e39fe9d9dace63cc0ad39664aa0fbf5e29f52f
Tested: Windows x64, MSVC 14.50, Release static C++ library, JDK 24.0.2.
Requires: JDK 17+, Maven, CMake, Visual Studio C++ build tools on PATH.

Extract, then run in PowerShell:

    .\reproduce.ps1 -TsFileSource D:\code\tsfile

Use a clean checkout at the commit above. Replace the source path with your own.
The script builds both TsFile implementations, then both reproducers. It checks:
1. Java round-trip: 47 bytes, preserves the property, exit 0.
2. Current C++ round-trip: 22 bytes, E_PARTIAL_READ, exit 1.
3. Java empty-property control: 22 bytes, success.
4. C++ empty-property control: 22 bytes, success.
5. C++ reads Java output: success and preserves the property.
6. Java reads C++ output: BufferUnderflowException, exit 1.
The script exits 0 if all six expected reproduction results are observed.
It is a bug reproduction, not a fixed implementation or a complete PR validation.

Same input: temperature / FLOAT / TS_2DIFF / UNCOMPRESSED /
properties={"max_point_number":"0"}.
Java returns a byte count; C++ returns a status code. Compare byte output/read result.
The .bin files are serialized schemas, not complete TsFile files.
The PNG is an actual browser screenshot of a viewer displaying captured program stdout.
The source HTML and raw logs are also included; the screenshot is not a terminal capture.
The bilingual draft's local image link is for Codex review; the matching PNG is included here.
The issue body also includes all four source/build files verbatim; no attachment is needed to reproduce.
No upstream issue or PR has been submitted. Production code has not been changed.

中文：用上述命令构建并运行 Java/C++ 相同输入、无属性对照和双向交叉读取。
真实日志、截图和二进制输出均已保留；失败案例用于复现问题。issue 尚未发布。

import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.write.schema.MeasurementSchema;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class SchemaPropertiesRepro {
  public static void main(String[] args) throws Exception {
    boolean withProperties = true;
    Path readPath = null;
    Path writePath = null;
    for (int i = 0; i < args.length; i++) {
      if (args[i].equals("--empty")) withProperties = false;
      else if (args[i].equals("--read")) readPath = Path.of(args[++i]);
      else if (args[i].equals("--write")) writePath = Path.of(args[++i]);
    }
    Map<String, String> properties = withProperties ? Map.of("max_point_number", "0") : Map.of();
    MeasurementSchema original = new MeasurementSchema(
        "temperature", TSDataType.FLOAT, TSEncoding.TS_2DIFF,
        CompressionType.UNCOMPRESSED, properties);
    System.out.println("language=Java");
    System.out.println("input.measurement=temperature");
    System.out.println("input.type=FLOAT encoding=TS_2DIFF compression=UNCOMPRESSED");
    System.out.println("input.properties=" + properties);
    byte[] bytes;
    if (readPath == null) {
      ByteArrayOutputStream output = new ByteArrayOutputStream();
      int written = original.serializeTo(output);
      bytes = output.toByteArray();
      System.out.println("serialize_return=" + written + " (byte count)");
      if (writePath != null) Files.write(writePath, bytes);
    } else {
      bytes = Files.readAllBytes(readPath);
    }
    System.out.println("serialized_bytes=" + bytes.length);
    try {
      MeasurementSchema decoded = MeasurementSchema.deserializeFrom(ByteBuffer.wrap(bytes));
      Map<String, String> actual = decoded.getProps() == null ? Map.of() : decoded.getProps();
      boolean valid = actual.equals(properties);
      System.out.println("deserialize=SUCCESS");
      System.out.println("output.properties=" + actual);
      System.out.println("result=" + (valid ? "PASS" : "FAIL"));
      if (!valid) System.exit(1);
    } catch (RuntimeException error) {
      System.out.println("deserialize=FAIL exception=" + error.getClass().getSimpleName());
      System.out.println("output.properties=<unavailable: deserialization failed>");
      System.out.println("result=FAIL");
      System.exit(1);
    }
  }
}

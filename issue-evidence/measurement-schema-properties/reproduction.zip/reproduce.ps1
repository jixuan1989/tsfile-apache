param(
    [Parameter(Mandatory = $true)] [string] $TsFileSource,
    [string] $BuildRoot = (Join-Path $PSScriptRoot 'build'),
    [string] $JavaClasspath = ''
)
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$sourcePath = (Resolve-Path -LiteralPath $TsFileSource).Path
$libraryBuild = Join-Path $BuildRoot 'library'
$programBuild = Join-Path $BuildRoot 'program'
$cmakeOptions = @(
    '-DTSFILE_BUILD_SHARED=OFF', '-DBUILD_TEST=OFF', '-DBUILD_TOOLS=OFF',
    '-DENABLE_ANTLR4=OFF', '-DENABLE_SNAPPY=OFF', '-DENABLE_LZ4=OFF',
    '-DENABLE_LZOKAY=OFF', '-DENABLE_ZLIB=OFF', '-DENABLE_ZSTD=OFF',
    '-DENABLE_LZMA2=OFF', '-DENABLE_SIMD=OFF', '-DENABLE_THREADS=ON'
)
& cmake -S (Join-Path $sourcePath 'cpp') -B $libraryBuild @cmakeOptions
if ($LASTEXITCODE -ne 0) { throw 'TsFile CMake configuration failed' }
& cmake --build $libraryBuild --config Release --target tsfile --parallel 6
if ($LASTEXITCODE -ne 0) { throw 'TsFile build failed' }
$staticLibrary = Join-Path $libraryBuild 'lib\Release\tsfile.lib'
if (-not (Test-Path -LiteralPath $staticLibrary)) {
    throw "Static library not found: $staticLibrary. This script uses the Windows MSVC build layout."
}
& cmake -S $PSScriptRoot -B $programBuild "-DTSFILE_SOURCE=$sourcePath" "-DTSFILE_LIBRARY=$staticLibrary"
if ($LASTEXITCODE -ne 0) { throw 'Reproducer CMake configuration failed' }
& cmake --build $programBuild --config Release --target schema_properties_repro
if ($LASTEXITCODE -ne 0) { throw 'Reproducer build failed' }
if ([string]::IsNullOrWhiteSpace($JavaClasspath)) {
    & mvn -f (Join-Path $sourcePath 'pom.xml') -P with-java -pl java/tsfile -am '-Dtest=CompatibilityTest' '-Dsurefire.failIfNoSpecifiedTests=false' '-Dspotless.skip=true' test
    if ($LASTEXITCODE -ne 0) { throw 'Java build failed' }
    $javaReport = Join-Path $sourcePath 'java\tsfile\target\surefire-reports\TEST-org.apache.tsfile.compatibility.CompatibilityTest.xml'
    [xml]$javaXml = Get-Content -LiteralPath $javaReport -Raw
    $JavaClasspath = ($javaXml.testsuite.properties.property | Where-Object { $_.name -eq 'java.class.path' }).value
    if ([string]::IsNullOrWhiteSpace($JavaClasspath)) { throw 'Java classpath was not found in the test report' }
}
$javaClasses = Join-Path $BuildRoot 'java-classes'
New-Item -ItemType Directory -Force -Path $javaClasses | Out-Null
& javac -cp $JavaClasspath -d $javaClasses (Join-Path $PSScriptRoot 'SchemaPropertiesRepro.java')
if ($LASTEXITCODE -ne 0) { throw 'Java reproducer compilation failed' }
$runtimeClasspath = $JavaClasspath + ';' + $javaClasses
$program = Join-Path $programBuild 'Release\schema_properties_repro.exe'
$javaBytes = Join-Path $BuildRoot 'java.schema.bin'
$cppBytes = Join-Path $BuildRoot 'cpp.schema.bin'
Write-Output 'JAVA: same non-empty schema input'
& java -cp $runtimeClasspath SchemaPropertiesRepro --write $javaBytes
if ($LASTEXITCODE -ne 0) { throw 'Java reference round-trip failed' }
Write-Output 'C++: same non-empty schema input'
& $program --write $cppBytes
if ($LASTEXITCODE -ne 1) { throw 'The reported C++ failure did not reproduce as expected' }
Write-Output 'JAVA CONTROL: empty properties'
& java -cp $runtimeClasspath SchemaPropertiesRepro --empty
if ($LASTEXITCODE -ne 0) { throw 'Java empty-property control failed' }
Write-Output 'C++ CONTROL: empty properties'
& $program --empty
if ($LASTEXITCODE -ne 0) { throw 'C++ empty-property control failed' }
Write-Output 'CROSS READ: C++ reads Java output'
& $program --read $javaBytes
if ($LASTEXITCODE -ne 0) { throw 'C++ could not read the Java reference schema' }
Write-Output 'CROSS READ: Java reads current C++ output'
& java -cp $runtimeClasspath SchemaPropertiesRepro --read $cppBytes
if ($LASTEXITCODE -ne 1) { throw 'The expected cross-language failure did not reproduce' }
Write-Output 'Same-input Java/C++ difference and both cross-read results reproduced.'
exit 0

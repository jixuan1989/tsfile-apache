param([Parameter(Mandatory=$true)][string]$TsFileSource,
      [string]$BuildRoot = (Join-Path $PSScriptRoot ("run-" + [guid]::NewGuid().ToString('N'))))
$ErrorActionPreference = 'Stop'
function Run($Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program exited with $LASTEXITCODE" }
}
$source = (Resolve-Path -LiteralPath $TsFileSource).Path
$head = & git -C $source rev-parse HEAD
if ($head -ne '1180b13675e11a0230708af2cc70d037e0e12623') { throw 'Use the specified upstream commit' }
New-Item -ItemType Directory -Path $BuildRoot | Out-Null
$output = (Resolve-Path -LiteralPath $BuildRoot).Path
$library = Join-Path $output 'library'
Run cmake @('-S', "$source/cpp", '-B', $library, '-DTSFILE_BUILD_SHARED=OFF',
    '-DBUILD_TEST=OFF', '-DBUILD_TOOLS=OFF', '-DENABLE_ANTLR4=OFF', '-DENABLE_SIMD=OFF',
    '-DENABLE_THREADS=ON', '-DENABLE_SNAPPY=OFF', '-DENABLE_LZ4=OFF', '-DENABLE_LZOKAY=OFF',
    '-DENABLE_ZLIB=OFF', '-DENABLE_ZSTD=OFF', '-DENABLE_LZMA2=OFF')
Run cmake @('--build', $library, '--config', 'Release', '--target', 'tsfile', '--parallel', '6')
$program = Join-Path $output 'program'
Run cmake @('-S', $PSScriptRoot, '-B', $program, "-DTSFILE_SOURCE=$source",
    "-DTSFILE_LIB_DIR=$library/lib/Release")
Run cmake @('--build', $program, '--config', 'Release')
Run mvn @('-f', "$source/pom.xml", '-P', 'with-java', '-pl', 'java/tsfile', '-am',
    '-Dtest=CompatibilityTest', '-Dsurefire.failIfNoSpecifiedTests=false', '-Dspotless.skip=true', 'test')
[xml]$report = Get-Content -Raw "$source/java/tsfile/target/surefire-reports/TEST-org.apache.tsfile.compatibility.CompatibilityTest.xml"
$cp = ($report.testsuite.properties.property | Where-Object { $_.name -eq 'java.class.path' }).value
if (-not $cp) { throw 'Missing Java classpath' }
$java = Join-Path $env:JAVA_HOME 'bin/java.exe'
$javac = Join-Path $env:JAVA_HOME 'bin/javac.exe'
$classes = Join-Path $output 'classes'
New-Item -ItemType Directory -Path $classes | Out-Null
Run $javac @('-cp', $cp, '-d', $classes, "$PSScriptRoot/FieldFilterRepro.java")
$cp = $classes + ';' + $cp
$cpp = Join-Path $program 'Release/field_filter_repro.exe'
Run $java @('-cp', $cp, 'FieldFilterRepro', 'write', "$output/java.tsfile")
Run $cpp @('write', "$output/cpp.tsfile")
foreach ($writer in @('java', 'cpp')) {
    foreach ($filter in @('none', 'true', 'false')) {
        Write-Output "file_writer=$writer reader=java"
        Run $java @('-cp', $cp, 'FieldFilterRepro', 'read', "$output/$writer.tsfile", $filter)
        Write-Output "file_writer=$writer reader=cpp"
        Run $cpp @('read', "$output/$writer.tsfile", $filter)
    }
}
Write-Output "Reproduction completed: $output"

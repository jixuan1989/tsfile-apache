from pathlib import Path
import html
import json

root=Path(__file__).resolve().parent
data=json.loads((root/'actual-outputs.json').read_text())
panels=[]
for language in ['java','cpp']:
    selected=[x for x in data if x['file_writer']=='java' and x['reader']==language]
    assert len(selected)==3 and all(x['exit_code']==0 for x in selected)
    log='\n\n'.join('filter='+x['filter']+'\n'+x['stdout'] for x in selected)
    panels.append('<section><h2>'+language.upper()+'</h2><pre>'+html.escape(log)+'</pre></section>')
page='''<!doctype html><html><meta charset="utf-8"><title>TsFile FIELD filter — actual reproduction logs</title>
<style>body{margin:32px;font:18px system-ui;background:#f4f6fa;color:#152438}h1{font-size:27px}code,pre{font:16px Consolas,monospace}main{display:flex;gap:20px}section{padding:20px;background:white;border:1px solid #ccd5e3;border-radius:12px;flex:1}pre{line-height:1.6;white-space:pre-wrap}footer{margin-top:20px;font-size:15px;color:#43536b}</style>
<h1>Aligned table query: supplied FIELD predicate is never called in C++</h1>
<p>Commit: <code>1180b13675e11a0230708af2cc70d037e0e12623</code></p>
<p>Same Java-written file · table <code>t</code> · one FIELD <code>v: INT64 / PLAIN / UNCOMPRESSED</code><br>Input row: <code>time=1, v=42</code> · both time and value pages UNCOMPRESSED</p><main>'''+''.join(panels)+'''</main><footer>Actual stdout from executed programs, rendered as a browser log preview. This is a screenshot of the preview, not a terminal screenshot. Raw source: actual-outputs.json. Both Java- and C++-written files reproduce the same difference.</footer></html>'''
(root/'log-preview.html').write_text(page,encoding='utf-8')

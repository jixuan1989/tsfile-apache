import java.io.File;
import java.util.Arrays;
import org.apache.tsfile.enums.ColumnCategory;
import org.apache.tsfile.common.conf.TSFileDescriptor;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.TableSchema;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.controller.CachedChunkLoaderImpl;
import org.apache.tsfile.read.controller.MetadataQuerierByFileImpl;
import org.apache.tsfile.read.expression.ExpressionTree;
import org.apache.tsfile.read.filter.basic.Filter;
import org.apache.tsfile.read.query.executor.TableQueryExecutor;
import org.apache.tsfile.read.reader.block.TsBlockReader;
import org.apache.tsfile.write.TsFileWriter;
import org.apache.tsfile.write.record.Tablet;
import org.apache.tsfile.write.schema.MeasurementSchema;

public class FieldFilterRepro {
  public static void main(String[] args) throws Exception {
    TSFileDescriptor.getInstance().getConfig().setCompressor("UNCOMPRESSED");
    File file = new File(args[1]);
    if (args[0].equals("write")) {
      try (TsFileWriter writer = new TsFileWriter(file)) {
        writer.registerTableSchema(new TableSchema("t", Arrays.asList(
            new MeasurementSchema("v", TSDataType.INT64, TSEncoding.PLAIN,
                CompressionType.UNCOMPRESSED)), Arrays.asList(ColumnCategory.FIELD)));
        Tablet tablet = new Tablet("t", Arrays.asList("v"), Arrays.asList(TSDataType.INT64),
            Arrays.asList(ColumnCategory.FIELD), 1);
        tablet.addTimestamp(0, 1);
        tablet.addValue("v", 0, 42L);
        tablet.setRowSize(1);
        writer.writeTable(tablet);
      }
      System.out.println("wrote: time=1 v=42");
      return;
    }
    final int[] calls = {0};
    ExpressionTree predicate = args[2].equals("none") ? null : new ExpressionTree() {
      public boolean satisfy(Object row) { calls[0]++; return Boolean.parseBoolean(args[2]); }
      public Filter toFilter() { return null; }
    };
    try (TsFileSequenceReader source = new TsFileSequenceReader(file.getPath())) {
      TableQueryExecutor executor = new TableQueryExecutor(new MetadataQuerierByFileImpl(source),
          new CachedChunkLoaderImpl(source), TableQueryExecutor.TableQueryOrdering.DEVICE);
      int rows = 0;
      try (TsBlockReader result = executor.query("t", Arrays.asList("v"), null, null, predicate)) {
        while (result.hasNext()) {
          org.apache.tsfile.read.common.block.TsBlock block = result.next();
          for (int i = 0; i < block.getPositionCount(); i++) {
            System.out.printf("row: time=%d v=%d%n", block.getTimeByIndex(i), block.getColumn(0).getLong(i));
          }
          rows += block.getPositionCount();
        }
      }
      System.out.printf("filter=%s rows=%d predicate_calls=%d%n", args[2], rows, calls[0]);
    }
  }
}

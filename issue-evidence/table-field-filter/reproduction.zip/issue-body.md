## Minimal reproduction

Create table `t` with one `INT64` FIELD `v` and one input row `time=1, v=42`. Query `v` through `TableQueryExecutor` with a predicate that always returns `false`. Java returns no rows; C++ returns the row and never calls the supplied predicate. No tag/time filter, null, floating-point precision or unprojected field is needed.

Java and C++ use different callback interfaces (`ExpressionTree` and `Filter`). The complete programs below implement the same constant predicate using each interface and print its actual invocation count. `false` is an intentionally minimal predicate, so this reproduction does not depend on designing a named-column expression API.

### What the three screenshot cases mean

The screenshot shows three runs of the same query with different final command-line arguments. They are one bug case and two controls, not three different field-comparison operators. The programs use `none` to pass a null filter; otherwise they construct the same constant-predicate class with a different Boolean value.

| Final argument | Supplied predicate | Java rows / callback calls | C++ rows / callback calls | Role |
|---|---|---|---|---|
| `none` | No filter (`null` / `nullptr`) | 1 / 0 | 1 / 0 | Unfiltered control |
| `true` | Always returns `true` | 1 / 1 | 1 / 0 | Accept-all control; C++ still never calls it |
| `false` | Always returns `false` | 0 / 1 | 1 / 0 | Bug reproduction: C++ returns a rejected row |

All three queries project the same column `v` from the same table `t`. Only the filter argument changes. The loop in `reproduce.ps1` executes `none`, `true`, and `false` for each reader and each writer's file: 2 writers × 2 readers × 3 modes = 12 runs. A row count of 1 for `true` alone would not prove correct filtering; the callback counter and rejecting `false` case expose the ignored predicate.

Actual stdout from both writers' files:

```text
file_writer=java reader=java
filter=false rows=0 predicate_calls=1
file_writer=java reader=cpp
row: time=1 v=42
filter=false rows=1 predicate_calls=0
file_writer=cpp reader=java
filter=false rows=0 predicate_calls=1
file_writer=cpp reader=cpp
row: time=1 v=42
filter=false rows=1 predicate_calls=0
```

The null-filter and always-true controls both retain the input row; their summary lines are:

```text
Java, either input file:
filter=none rows=1 predicate_calls=0
filter=true rows=1 predicate_calls=1

C++, either input file:
filter=none rows=1 predicate_calls=0
filter=true rows=1 predicate_calls=0
```

## Complete source and build/run steps

Environment tested: Windows 11, MSVC 14.50.35717 Release, CMake 4.x, Maven 3.9.14, JDK 24. Both implementations use upstream `1180b13675e11a0230708af2cc70d037e0e12623` (current `develop` when checked). Both time and value pages are UNCOMPRESSED. The standalone script builds a fresh C++ static library and Java classes, runs the upstream Java compatibility fixture tests to obtain its dependency classpath, compiles these programs, and runs all twelve own/cross-reader cases. It requires PowerShell 7, JDK 17+, Maven, CMake 3.20+ and MSVC C++ build tools. Use a fresh output directory; the script creates one automatically.

```powershell
git clone --branch develop https://github.com/apache/tsfile.git tsfile-src
git -C tsfile-src checkout 1180b13675e11a0230708af2cc70d037e0e12623
# Save the four source/build files below in the current directory.
# JAVA_HOME points to JDK 17 or newer; mvn, cmake and MSVC are available.
pwsh -File .\reproduce.ps1 -TsFileSource .\tsfile-src
```

`FieldFilterRepro.java`

```java
import java.io.File;
import java.util.Arrays;
import org.apache.tsfile.enums.ColumnCategory;
import org.apache.tsfile.common.conf.TSFileDescriptor;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.TableSchema;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.controller.CachedChunkLoaderImpl;
import org.apache.tsfile.read.controller.MetadataQuerierByFileImpl;
import org.apache.tsfile.read.expression.ExpressionTree;
import org.apache.tsfile.read.filter.basic.Filter;
import org.apache.tsfile.read.query.executor.TableQueryExecutor;
import org.apache.tsfile.read.reader.block.TsBlockReader;
import org.apache.tsfile.write.TsFileWriter;
import org.apache.tsfile.write.record.Tablet;
import org.apache.tsfile.write.schema.MeasurementSchema;

public class FieldFilterRepro {
  public static void main(String[] args) throws Exception {
    TSFileDescriptor.getInstance().getConfig().setCompressor("UNCOMPRESSED");
    File file = new File(args[1]);
    if (args[0].equals("write")) {
      try (TsFileWriter writer = new TsFileWriter(file)) {
        writer.registerTableSchema(new TableSchema("t", Arrays.asList(
            new MeasurementSchema("v", TSDataType.INT64, TSEncoding.PLAIN,
                CompressionType.UNCOMPRESSED)), Arrays.asList(ColumnCategory.FIELD)));
        Tablet tablet = new Tablet("t", Arrays.asList("v"), Arrays.asList(TSDataType.INT64),
            Arrays.asList(ColumnCategory.FIELD), 1);
        tablet.addTimestamp(0, 1);
        tablet.addValue("v", 0, 42L);
        tablet.setRowSize(1);
        writer.writeTable(tablet);
      }
      System.out.println("wrote: time=1 v=42");
      return;
    }
    final int[] calls = {0};
    ExpressionTree predicate = args[2].equals("none") ? null : new ExpressionTree() {
      public boolean satisfy(Object row) { calls[0]++; return Boolean.parseBoolean(args[2]); }
      public Filter toFilter() { return null; }
    };
    try (TsFileSequenceReader source = new TsFileSequenceReader(file.getPath())) {
      TableQueryExecutor executor = new TableQueryExecutor(new MetadataQuerierByFileImpl(source),
          new CachedChunkLoaderImpl(source), TableQueryExecutor.TableQueryOrdering.DEVICE);
      int rows = 0;
      try (TsBlockReader result = executor.query("t", Arrays.asList("v"), null, null, predicate)) {
        while (result.hasNext()) {
          org.apache.tsfile.read.common.block.TsBlock block = result.next();
          for (int i = 0; i < block.getPositionCount(); i++) {
            System.out.printf("row: time=%d v=%d%n", block.getTimeByIndex(i), block.getColumn(0).getLong(i));
          }
          rows += block.getPositionCount();
        }
      }
      System.out.printf("filter=%s rows=%d predicate_calls=%d%n", args[2], rows, calls[0]);
    }
  }
}
```

`field_filter_repro.cc`

```cpp
#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <string>
#include "common/tablet.h"
#include "file/local_random_access_read_file.h"
#include "file/write_file.h"
#include "reader/table_query_executor.h"
#include "writer/tsfile_table_writer.h"

using namespace common;
using namespace storage;
static void check(int ret) {
    if (ret != E_OK) throw std::runtime_error("error=" + std::to_string(ret));
}
struct ConstantPredicate : Filter {
    int& calls;
    bool accept;
    ConstantPredicate(int& count, bool value) : calls(count), accept(value) {}
    bool satisfy(Statistic*) override { ++calls; return accept; }
    bool satisfy(int64_t, int64_t) override { ++calls; return accept; }
    bool satisfy(int64_t, String) override { ++calls; return accept; }
    bool satisfyRow(int, std::vector<std::string*>) const override { ++calls; return accept; }
};
int main(int argc, char** argv) {
    libtsfile_init();
    if (std::string(argv[1]) == "write") {
        WriteFile file;
        int flags = O_WRONLY | O_CREAT | O_TRUNC;
#ifdef _WIN32
        flags |= O_BINARY;
#endif
        check(file.create(argv[2], flags, 0666));
        TableSchema schema("t", {new MeasurementSchema("v", INT64, PLAIN, UNCOMPRESSED)},
                           {ColumnCategory::FIELD});
        TsFileTableWriter writer(&file, &schema);
        Tablet tablet("t", std::vector<std::string>{"v"}, std::vector<TSDataType>{INT64},
                      std::vector<ColumnCategory>{ColumnCategory::FIELD}, 1);
        check(tablet.add_timestamp(0, 1));
        check(tablet.add_value(0, "v", int64_t(42)));
        check(writer.write_table(tablet));
        check(writer.close());
        std::cout << "wrote: time=1 v=42\n";
        return 0;
    }
    int calls = 0;
    LocalRandomAccessReadFile file;
    check(file.open(argv[2]));
    TableQueryExecutor executor(&file);
    const std::string mode = argv[3];
    Filter* predicate = mode == "none" ? nullptr : new ConstantPredicate(calls, mode == "true");
    ResultSet* result = nullptr;
    check(executor.query("t", {"v"}, nullptr, nullptr, predicate, result));
    bool next = false;
    int rows = 0;
    while (true) {
        check(result->next(next));
        if (!next) break;
        std::cout << "row: time=" << result->get_value<int64_t>(1)
                  << " v=" << result->get_value<int64_t>("v") << '\n';
        ++rows;
    }
    executor.destroy_query_data_set(result);
    std::cout << "filter=" << mode << " rows=" << rows << " predicate_calls=" << calls << '\n';
}
```

`CMakeLists.txt`

```cmake
cmake_minimum_required(VERSION 3.20)
project(field_filter_repro LANGUAGES CXX)
add_executable(field_filter_repro field_filter_repro.cc)
target_compile_features(field_filter_repro PRIVATE cxx_std_11)
target_compile_definitions(field_filter_repro PRIVATE TSFILE_STATIC ENABLE_MEM_STAT ENABLE_THREADS)
target_include_directories(field_filter_repro PRIVATE "${TSFILE_SOURCE}/cpp/src")
find_library(TSFILE_LIBRARY NAMES tsfile PATHS "${TSFILE_LIB_DIR}" NO_DEFAULT_PATH REQUIRED)
target_link_libraries(field_filter_repro PRIVATE "${TSFILE_LIBRARY}")
if(MSVC)
  target_compile_options(field_filter_repro PRIVATE /utf-8 /EHsc /bigobj)
endif()
```

`reproduce.ps1`

```powershell
param([Parameter(Mandatory=$true)][string]$TsFileSource,
      [string]$BuildRoot = (Join-Path $PSScriptRoot ("run-" + [guid]::NewGuid().ToString('N'))))
$ErrorActionPreference = 'Stop'
function Run($Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program exited with $LASTEXITCODE" }
}
$source = (Resolve-Path -LiteralPath $TsFileSource).Path
$head = & git -C $source rev-parse HEAD
if ($head -ne '1180b13675e11a0230708af2cc70d037e0e12623') { throw 'Use the specified upstream commit' }
New-Item -ItemType Directory -Path $BuildRoot | Out-Null
$output = (Resolve-Path -LiteralPath $BuildRoot).Path
$library = Join-Path $output 'library'
Run cmake @('-S', "$source/cpp", '-B', $library, '-DTSFILE_BUILD_SHARED=OFF',
    '-DBUILD_TEST=OFF', '-DBUILD_TOOLS=OFF', '-DENABLE_ANTLR4=OFF', '-DENABLE_SIMD=OFF',
    '-DENABLE_THREADS=ON', '-DENABLE_SNAPPY=OFF', '-DENABLE_LZ4=OFF', '-DENABLE_LZOKAY=OFF',
    '-DENABLE_ZLIB=OFF', '-DENABLE_ZSTD=OFF', '-DENABLE_LZMA2=OFF')
Run cmake @('--build', $library, '--config', 'Release', '--target', 'tsfile', '--parallel', '6')
$program = Join-Path $output 'program'
Run cmake @('-S', $PSScriptRoot, '-B', $program, "-DTSFILE_SOURCE=$source",
    "-DTSFILE_LIB_DIR=$library/lib/Release")
Run cmake @('--build', $program, '--config', 'Release')
Run mvn @('-f', "$source/pom.xml", '-P', 'with-java', '-pl', 'java/tsfile', '-am',
    '-Dtest=CompatibilityTest', '-Dsurefire.failIfNoSpecifiedTests=false', '-Dspotless.skip=true', 'test')
[xml]$report = Get-Content -Raw "$source/java/tsfile/target/surefire-reports/TEST-org.apache.tsfile.compatibility.CompatibilityTest.xml"
$cp = ($report.testsuite.properties.property | Where-Object { $_.name -eq 'java.class.path' }).value
if (-not $cp) { throw 'Missing Java classpath' }
$java = Join-Path $env:JAVA_HOME 'bin/java.exe'
$javac = Join-Path $env:JAVA_HOME 'bin/javac.exe'
$classes = Join-Path $output 'classes'
New-Item -ItemType Directory -Path $classes | Out-Null
Run $javac @('-cp', $cp, '-d', $classes, "$PSScriptRoot/FieldFilterRepro.java")
$cp = $classes + ';' + $cp
$cpp = Join-Path $program 'Release/field_filter_repro.exe'
Run $java @('-cp', $cp, 'FieldFilterRepro', 'write', "$output/java.tsfile")
Run $cpp @('write', "$output/cpp.tsfile")
foreach ($writer in @('java', 'cpp')) {
    foreach ($filter in @('none', 'true', 'false')) {
        Write-Output "file_writer=$writer reader=java"
        Run $java @('-cp', $cp, 'FieldFilterRepro', 'read', "$output/$writer.tsfile", $filter)
        Write-Output "file_writer=$writer reader=cpp"
        Run $cpp @('read', "$output/$writer.tsfile", $filter)
    }
}
Write-Output "Reproduction completed: $output"
```

## Expected behavior and source location

Rows rejected by the supplied FIELD predicate must not be returned. The null-filter and always-true cases should continue to return the single row. Invocation counts are diagnostic here, not a proposed guarantee about callback counts in optimized queries.

In `cpp/src/reader/block/single_device_tsblock_reader.cc`, `field_filter_` is stored, but `has_next_aligned()` bulk-copies aligned rows without evaluating it. The scalar `fill_measurements()` path also retains a TODO for evaluation; that path is outside this minimal aligned reproduction. In Java, `SingleDeviceTsBlockReader.fillMeasurements()` calls `measurementExpression.satisfy(this)` and advances rejected rows without appending them.

The same logical contents are verified when each implementation reads each writer's file without a filter. The difference persists on the exact same input bytes, so a byte-identical writer output is not required to demonstrate this query-semantics bug. This issue does not allege an on-disk format mismatch. Java and C++ both have a TODO for collecting unprojected filter columns; that shared limitation is excluded from the claimed Java/C++ difference.

## Screenshot and evidence

The image is an actual browser screenshot of a preview generated from recorded stdout (`actual-outputs.json`), clearly labelled as a log preview rather than a terminal capture. The supplementary reproduction archive includes the source files, fresh-build log, twelve-case output and both input files; all necessary source/build instructions are also in this body.

![Actual reproduction log preview](TsFile_Issue_03_实际日志预览截图.jpg)

---

## 中文译稿

### 最小复现

建立表 `t`，只有一个 `INT64` FIELD `v`，输入一行 `time=1, v=42`。通过 `TableQueryExecutor` 查询 `v`，传入始终返回 `false` 的谓词：Java 返回 0 行，C++ 返回原始行，且完全没有调用传入的谓词。无需 TAG/时间过滤、空值、浮点精度或未投影字段。

Java 和 C++ 使用不同回调接口（`ExpressionTree` 和 `Filter`）。下方完整程序分别通过对应接口实现相同的恒假谓词，输出真实调用次数。这里选用恒假谓词作为最简单案例，不依赖另行设计具名字段表达式接口。

### 截图中的三种情况分别是什么

截图是同一个查询使用三个不同命令行末尾参数分别运行的结果，包含一个问题复现和两个对照，并非三种不同的字段比较运算。程序遇到 `none` 时传入空过滤器；另外两种情况构造同一个恒值谓词类，只改变其中的布尔值。

| 末尾参数 | 实际传入的谓词 | Java 行数 / 回调次数 | C++ 行数 / 回调次数 | 用途 |
|---|---|---|---|---|
| `none` | 不传过滤器（`null` / `nullptr`） | 1 / 0 | 1 / 0 | 无过滤对照 |
| `true` | 始终返回 `true` | 1 / 1 | 1 / 0 | 全部放行对照；C++ 仍未调用谓词 |
| `false` | 始终返回 `false` | 0 / 1 | 1 / 0 | 问题复现：C++ 返回了应被拒绝的行 |

三次查询都读取同一张表 `t` 的同一列 `v`，只改变过滤器参数。`reproduce.ps1` 的循环针对每个 reader、每个 writer 的文件分别执行 `none`、`true`、`false`，共 2 个 writer × 2 个 reader × 3 种模式 = 12 次运行。仅看到 `true` 返回 1 行不能证明过滤器正确执行；回调计数和拒绝所有行的 `false` 案例共同暴露了谓词被忽略的问题。

分别读取两种 writer 生成的文件，实际 stdout 如下：

```text
file_writer=java reader=java
filter=false rows=0 predicate_calls=1
file_writer=java reader=cpp
row: time=1 v=42
filter=false rows=1 predicate_calls=0
file_writer=cpp reader=java
filter=false rows=0 predicate_calls=1
file_writer=cpp reader=cpp
row: time=1 v=42
filter=false rows=1 predicate_calls=0
```

空过滤器和恒真过滤器均保留原始行，对照输出的汇总行为：

```text
Java, either input file:
filter=none rows=1 predicate_calls=0
filter=true rows=1 predicate_calls=1

C++, either input file:
filter=none rows=1 predicate_calls=0
filter=true rows=1 predicate_calls=0
```

### 完整源码与构建运行步骤

已测试环境为 Windows 11、MSVC 14.50.35717 Release、CMake 4.x、Maven 3.9.14、JDK 24。两种实现使用同一上游提交 `1180b13675e11a0230708af2cc70d037e0e12623`，核对时为最新 `develop`。时间页和值页均为 UNCOMPRESSED。独立脚本从头构建 C++ 静态库和 Java 类，运行上游 Java 兼容性 fixture 测试以获得依赖 classpath，编译复现程序，再完成 12 次自身/交叉读取。需要 PowerShell 7、JDK 17+、Maven、CMake 3.20+ 和 MSVC C++ 构建工具。使用新的输出目录，脚本默认自动创建。

```powershell
git clone --branch develop https://github.com/apache/tsfile.git tsfile-src
git -C tsfile-src checkout 1180b13675e11a0230708af2cc70d037e0e12623
# Save the four source/build files below in the current directory.
# JAVA_HOME points to JDK 17 or newer; mvn, cmake and MSVC are available.
pwsh -File .\reproduce.ps1 -TsFileSource .\tsfile-src
```

`FieldFilterRepro.java`

```java
import java.io.File;
import java.util.Arrays;
import org.apache.tsfile.enums.ColumnCategory;
import org.apache.tsfile.common.conf.TSFileDescriptor;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.TableSchema;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.controller.CachedChunkLoaderImpl;
import org.apache.tsfile.read.controller.MetadataQuerierByFileImpl;
import org.apache.tsfile.read.expression.ExpressionTree;
import org.apache.tsfile.read.filter.basic.Filter;
import org.apache.tsfile.read.query.executor.TableQueryExecutor;
import org.apache.tsfile.read.reader.block.TsBlockReader;
import org.apache.tsfile.write.TsFileWriter;
import org.apache.tsfile.write.record.Tablet;
import org.apache.tsfile.write.schema.MeasurementSchema;

public class FieldFilterRepro {
  public static void main(String[] args) throws Exception {
    TSFileDescriptor.getInstance().getConfig().setCompressor("UNCOMPRESSED");
    File file = new File(args[1]);
    if (args[0].equals("write")) {
      try (TsFileWriter writer = new TsFileWriter(file)) {
        writer.registerTableSchema(new TableSchema("t", Arrays.asList(
            new MeasurementSchema("v", TSDataType.INT64, TSEncoding.PLAIN,
                CompressionType.UNCOMPRESSED)), Arrays.asList(ColumnCategory.FIELD)));
        Tablet tablet = new Tablet("t", Arrays.asList("v"), Arrays.asList(TSDataType.INT64),
            Arrays.asList(ColumnCategory.FIELD), 1);
        tablet.addTimestamp(0, 1);
        tablet.addValue("v", 0, 42L);
        tablet.setRowSize(1);
        writer.writeTable(tablet);
      }
      System.out.println("wrote: time=1 v=42");
      return;
    }
    final int[] calls = {0};
    ExpressionTree predicate = args[2].equals("none") ? null : new ExpressionTree() {
      public boolean satisfy(Object row) { calls[0]++; return Boolean.parseBoolean(args[2]); }
      public Filter toFilter() { return null; }
    };
    try (TsFileSequenceReader source = new TsFileSequenceReader(file.getPath())) {
      TableQueryExecutor executor = new TableQueryExecutor(new MetadataQuerierByFileImpl(source),
          new CachedChunkLoaderImpl(source), TableQueryExecutor.TableQueryOrdering.DEVICE);
      int rows = 0;
      try (TsBlockReader result = executor.query("t", Arrays.asList("v"), null, null, predicate)) {
        while (result.hasNext()) {
          org.apache.tsfile.read.common.block.TsBlock block = result.next();
          for (int i = 0; i < block.getPositionCount(); i++) {
            System.out.printf("row: time=%d v=%d%n", block.getTimeByIndex(i), block.getColumn(0).getLong(i));
          }
          rows += block.getPositionCount();
        }
      }
      System.out.printf("filter=%s rows=%d predicate_calls=%d%n", args[2], rows, calls[0]);
    }
  }
}
```

`field_filter_repro.cc`

```cpp
#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <string>
#include "common/tablet.h"
#include "file/local_random_access_read_file.h"
#include "file/write_file.h"
#include "reader/table_query_executor.h"
#include "writer/tsfile_table_writer.h"

using namespace common;
using namespace storage;
static void check(int ret) {
    if (ret != E_OK) throw std::runtime_error("error=" + std::to_string(ret));
}
struct ConstantPredicate : Filter {
    int& calls;
    bool accept;
    ConstantPredicate(int& count, bool value) : calls(count), accept(value) {}
    bool satisfy(Statistic*) override { ++calls; return accept; }
    bool satisfy(int64_t, int64_t) override { ++calls; return accept; }
    bool satisfy(int64_t, String) override { ++calls; return accept; }
    bool satisfyRow(int, std::vector<std::string*>) const override { ++calls; return accept; }
};
int main(int argc, char** argv) {
    libtsfile_init();
    if (std::string(argv[1]) == "write") {
        WriteFile file;
        int flags = O_WRONLY | O_CREAT | O_TRUNC;
#ifdef _WIN32
        flags |= O_BINARY;
#endif
        check(file.create(argv[2], flags, 0666));
        TableSchema schema("t", {new MeasurementSchema("v", INT64, PLAIN, UNCOMPRESSED)},
                           {ColumnCategory::FIELD});
        TsFileTableWriter writer(&file, &schema);
        Tablet tablet("t", std::vector<std::string>{"v"}, std::vector<TSDataType>{INT64},
                      std::vector<ColumnCategory>{ColumnCategory::FIELD}, 1);
        check(tablet.add_timestamp(0, 1));
        check(tablet.add_value(0, "v", int64_t(42)));
        check(writer.write_table(tablet));
        check(writer.close());
        std::cout << "wrote: time=1 v=42\n";
        return 0;
    }
    int calls = 0;
    LocalRandomAccessReadFile file;
    check(file.open(argv[2]));
    TableQueryExecutor executor(&file);
    const std::string mode = argv[3];
    Filter* predicate = mode == "none" ? nullptr : new ConstantPredicate(calls, mode == "true");
    ResultSet* result = nullptr;
    check(executor.query("t", {"v"}, nullptr, nullptr, predicate, result));
    bool next = false;
    int rows = 0;
    while (true) {
        check(result->next(next));
        if (!next) break;
        std::cout << "row: time=" << result->get_value<int64_t>(1)
                  << " v=" << result->get_value<int64_t>("v") << '\n';
        ++rows;
    }
    executor.destroy_query_data_set(result);
    std::cout << "filter=" << mode << " rows=" << rows << " predicate_calls=" << calls << '\n';
}
```

`CMakeLists.txt`

```cmake
cmake_minimum_required(VERSION 3.20)
project(field_filter_repro LANGUAGES CXX)
add_executable(field_filter_repro field_filter_repro.cc)
target_compile_features(field_filter_repro PRIVATE cxx_std_11)
target_compile_definitions(field_filter_repro PRIVATE TSFILE_STATIC ENABLE_MEM_STAT ENABLE_THREADS)
target_include_directories(field_filter_repro PRIVATE "${TSFILE_SOURCE}/cpp/src")
find_library(TSFILE_LIBRARY NAMES tsfile PATHS "${TSFILE_LIB_DIR}" NO_DEFAULT_PATH REQUIRED)
target_link_libraries(field_filter_repro PRIVATE "${TSFILE_LIBRARY}")
if(MSVC)
  target_compile_options(field_filter_repro PRIVATE /utf-8 /EHsc /bigobj)
endif()
```

`reproduce.ps1`

```powershell
param([Parameter(Mandatory=$true)][string]$TsFileSource,
      [string]$BuildRoot = (Join-Path $PSScriptRoot ("run-" + [guid]::NewGuid().ToString('N'))))
$ErrorActionPreference = 'Stop'
function Run($Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program exited with $LASTEXITCODE" }
}
$source = (Resolve-Path -LiteralPath $TsFileSource).Path
$head = & git -C $source rev-parse HEAD
if ($head -ne '1180b13675e11a0230708af2cc70d037e0e12623') { throw 'Use the specified upstream commit' }
New-Item -ItemType Directory -Path $BuildRoot | Out-Null
$output = (Resolve-Path -LiteralPath $BuildRoot).Path
$library = Join-Path $output 'library'
Run cmake @('-S', "$source/cpp", '-B', $library, '-DTSFILE_BUILD_SHARED=OFF',
    '-DBUILD_TEST=OFF', '-DBUILD_TOOLS=OFF', '-DENABLE_ANTLR4=OFF', '-DENABLE_SIMD=OFF',
    '-DENABLE_THREADS=ON', '-DENABLE_SNAPPY=OFF', '-DENABLE_LZ4=OFF', '-DENABLE_LZOKAY=OFF',
    '-DENABLE_ZLIB=OFF', '-DENABLE_ZSTD=OFF', '-DENABLE_LZMA2=OFF')
Run cmake @('--build', $library, '--config', 'Release', '--target', 'tsfile', '--parallel', '6')
$program = Join-Path $output 'program'
Run cmake @('-S', $PSScriptRoot, '-B', $program, "-DTSFILE_SOURCE=$source",
    "-DTSFILE_LIB_DIR=$library/lib/Release")
Run cmake @('--build', $program, '--config', 'Release')
Run mvn @('-f', "$source/pom.xml", '-P', 'with-java', '-pl', 'java/tsfile', '-am',
    '-Dtest=CompatibilityTest', '-Dsurefire.failIfNoSpecifiedTests=false', '-Dspotless.skip=true', 'test')
[xml]$report = Get-Content -Raw "$source/java/tsfile/target/surefire-reports/TEST-org.apache.tsfile.compatibility.CompatibilityTest.xml"
$cp = ($report.testsuite.properties.property | Where-Object { $_.name -eq 'java.class.path' }).value
if (-not $cp) { throw 'Missing Java classpath' }
$java = Join-Path $env:JAVA_HOME 'bin/java.exe'
$javac = Join-Path $env:JAVA_HOME 'bin/javac.exe'
$classes = Join-Path $output 'classes'
New-Item -ItemType Directory -Path $classes | Out-Null
Run $javac @('-cp', $cp, '-d', $classes, "$PSScriptRoot/FieldFilterRepro.java")
$cp = $classes + ';' + $cp
$cpp = Join-Path $program 'Release/field_filter_repro.exe'
Run $java @('-cp', $cp, 'FieldFilterRepro', 'write', "$output/java.tsfile")
Run $cpp @('write', "$output/cpp.tsfile")
foreach ($writer in @('java', 'cpp')) {
    foreach ($filter in @('none', 'true', 'false')) {
        Write-Output "file_writer=$writer reader=java"
        Run $java @('-cp', $cp, 'FieldFilterRepro', 'read', "$output/$writer.tsfile", $filter)
        Write-Output "file_writer=$writer reader=cpp"
        Run $cpp @('read', "$output/$writer.tsfile", $filter)
    }
}
Write-Output "Reproduction completed: $output"
```

### 预期行为与源码位置

被 FIELD 谓词拒绝的行不应返回。空过滤器和恒真过滤器仍应返回这唯一一行。调用次数用于诊断本例，并非要求优化后的查询必须具有固定调用次数。

`cpp/src/reader/block/single_device_tsblock_reader.cc` 保存了 `field_filter_`，但 `has_next_aligned()` 批量复制对齐数据时没有执行它。标量 `fill_measurements()` 路径也保留了执行过滤器的 TODO；本次最小复现仅针对对齐路径。Java 的 `SingleDeviceTsBlockReader.fillMeasurements()` 会调用 `measurementExpression.satisfy(this)`，推进被拒绝行的游标而不追加结果。

不带过滤器时，两种实现读取两种 writer 文件的逻辑内容均一致；对同一个输入文件的同一份字节仍出现差异，所以证明这个查询语义问题无需两个 writer 的输出字节完全相同。本 issue 不声称磁盘格式存在差异。两种实现都仍有收集未投影过滤字段的 TODO，因此不把这项共同限制列为已证实的 Java/C++ 差异。

### 截图与证据

截图是真实浏览器截图，展示由实际 stdout 记录（`actual-outputs.json`）生成的日志预览，明确标注其来源，没有冒充终端截图。补充复现包包含源码、全新构建日志、12 组输出及两份输入文件；正文也提供全部源码和构建运行方法。

![Actual reproduction log preview](TsFile_Issue_03_实际日志预览截图.jpg)

**AI disclosure:** This issue, including its analysis, reproduction code and description, was written by an AI coding agent (OpenAI Codex), which also performed the reported reproduction runs.

**AI 使用说明：** 本 issue 的问题分析、复现代码和正文由 AI 编程代理（OpenAI Codex）编写，文中报告的复现实验也由该 AI 代理执行。

#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <string>
#include "common/tablet.h"
#include "file/local_random_access_read_file.h"
#include "file/write_file.h"
#include "reader/table_query_executor.h"
#include "writer/tsfile_table_writer.h"

using namespace common;
using namespace storage;
static void check(int ret) {
    if (ret != E_OK) throw std::runtime_error("error=" + std::to_string(ret));
}
struct ConstantPredicate : Filter {
    int& calls;
    bool accept;
    ConstantPredicate(int& count, bool value) : calls(count), accept(value) {}
    bool satisfy(Statistic*) override { ++calls; return accept; }
    bool satisfy(int64_t, int64_t) override { ++calls; return accept; }
    bool satisfy(int64_t, String) override { ++calls; return accept; }
    bool satisfyRow(int, std::vector<std::string*>) const override { ++calls; return accept; }
};
int main(int argc, char** argv) {
    libtsfile_init();
    if (std::string(argv[1]) == "write") {
        WriteFile file;
        int flags = O_WRONLY | O_CREAT | O_TRUNC;
#ifdef _WIN32
        flags |= O_BINARY;
#endif
        check(file.create(argv[2], flags, 0666));
        TableSchema schema("t", {new MeasurementSchema("v", INT64, PLAIN, UNCOMPRESSED)},
                           {ColumnCategory::FIELD});
        TsFileTableWriter writer(&file, &schema);
        Tablet tablet("t", std::vector<std::string>{"v"}, std::vector<TSDataType>{INT64},
                      std::vector<ColumnCategory>{ColumnCategory::FIELD}, 1);
        check(tablet.add_timestamp(0, 1));
        check(tablet.add_value(0, "v", int64_t(42)));
        check(writer.write_table(tablet));
        check(writer.close());
        std::cout << "wrote: time=1 v=42\n";
        return 0;
    }
    int calls = 0;
    LocalRandomAccessReadFile file;
    check(file.open(argv[2]));
    TableQueryExecutor executor(&file);
    const std::string mode = argv[3];
    Filter* predicate = mode == "none" ? nullptr : new ConstantPredicate(calls, mode == "true");
    ResultSet* result = nullptr;
    check(executor.query("t", {"v"}, nullptr, nullptr, predicate, result));
    bool next = false;
    int rows = 0;
    while (true) {
        check(result->next(next));
        if (!next) break;
        std::cout << "row: time=" << result->get_value<int64_t>(1)
                  << " v=" << result->get_value<int64_t>("v") << '\n';
        ++rows;
    }
    executor.destroy_query_data_set(result);
    std::cout << "filter=" << mode << " rows=" << rows << " predicate_calls=" << calls << '\n';
}

public class RunNativeCompatibility {
  public static void main(String[] args) throws Exception {
    System.setProperty("tsfile.compat.validate.dir", args[0]);
    new org.apache.tsfile.compatibility.TableModelEncodingCompressionCompatibilityTest().validateFixtures();
    long count=java.nio.file.Files.lines(java.nio.file.Paths.get(args[0],"manifest.csv")).count()-1;
    System.out.println("C++ files read/validated by Java="+count+" PASS");
  }
}

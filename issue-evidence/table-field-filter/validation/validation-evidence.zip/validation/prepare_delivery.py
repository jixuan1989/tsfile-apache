from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

v = Path(__file__).resolve().parent
root = v.parents[2]
source = v.parent / 'repro-repo'
out = root / 'outputs'
state = json.loads((root / 'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
head = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'e2e9c3786f9753ec5d5c1b813fd2f1fb0d71d5b8'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip()

def read(name):
    return json.loads((v / name).read_text(encoding='utf-8'))

def tests(name, expected):
    x = ET.parse(v / (name + '.xml')).getroot()
    assert int(x.get('failures')) == int(x.get('errors')) == 0
    cases = list(x.iter('testcase'))
    skipped = sum(c.find('skipped') is not None for c in cases)
    disabled = sum(c.get('status') == 'notrun' for c in cases)
    passed = len(cases) - skipped - disabled
    assert passed == expected, (name, passed)
    return {'passed': passed, 'skipped': skipped, 'disabled': disabled, 'seconds': float(x.get('time'))}

coverage = read('coverage-summary.json')
assert coverage['changed_production']['line_percent'] >= 90
performance = read('performance-initial.json')
confirmation = read('performance-confirmation.json')
assert len(performance['cases']) == 8
assert all(len(x['measurements']) == 25 for x in performance['cases'].values())
assert confirmation['summary']['new_independent_process_pairs'] == 300
assert confirmation['summary']['bootstrap_95_percent'][0] <= 1
assert all(x['summary']['bootstrap_95_percent'][0] <= 1 for n, x in performance['cases'].items() if n != 'time_batch')
compat = read('compatibility-summary.json')
assert compat['native_callback_reads'] == 12 and compat['multi_type_cross_reads'] == 24
assert 'PASS' in (v / 'native-java-final-readback.log').read_text(encoding='utf-8')
tests('native-cpp-java-readback', 1)
assert (v / 'linux-executable-before.sha256').read_bytes() == (v / 'linux-executable-after.sha256').read_bytes()
assert not read('baseline-source-verification.json')['mismatches']
assert read('windows-generator-comparison.json')['assertion_values_identical']
assert read('manifest-line-ending-normalization.json')['tsfile_hashes_unchanged']
asan_log = (v / 'asan-regressions.log').read_text(encoding='utf-8')
assert len(re.findall(r'\[  PASSED  \]\s+50 tests\.', asan_log)) == 5
summary = {'gates_passed': True, 'base_commit': '1180b13675e11a0230708af2cc70d037e0e12623',
    'head_commit': head, 'tests': {'windows': tests('windows-all-tests', 955),
    'linux': tests('linux-all-tests', 976), 'dedicated': tests('fixed-regressions', 50),
    'asan_last_iteration': tests('asan-regressions', 50), 'asan_total_passes': 250},
    'coverage': coverage, 'performance': {'initial': performance, 'confirmation': confirmation},
    'compatibility': compat, 'native_cpp_files_read_by_java': 117, 'native_java_files_read_by_cpp': 135}
(v / 'validation-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')

perf_table = '| Scenario | Fixed / baseline latency | 95% bootstrap interval | Baseline / fixed p95 (s) |\n|---|---:|---|---|\n'
for name, item in performance['cases'].items():
    s = item['summary']; lo, hi = s['bootstrap_95_percent']
    perf_table += f"| `{name}` | {s['paired_median_latency_ratio']:.4f} | [{lo:.4f}, {hi:.4f}] | {s['baseline']['p95_seconds']:.6f} / {s['fixed']['p95_seconds']:.6f} |\n"
c = confirmation['summary']
confirm_text = f"The initial `time_batch` estimate was {c['initial_ratio']:.4f} [{c['initial_95_percent'][0]:.4f}, {c['initial_95_percent'][1]:.4f}]. It was investigated with 300 additional independent alternating process pairs, grouped into 75 blocks of four pairs: the median block ratio was {c['paired_median_block_ratio']:.4f}, 95% interval [{c['bootstrap_95_percent'][0]:.4f}, {c['bootstrap_95_percent'][1]:.4f}]. The slowdown did not reproduce consistently. Both datasets are retained; no production change was made between these measurements."
cov_table = '| Production file | Whole-file lines | Whole-file branches |\n|---|---:|---:|\n'
for name, item in coverage['per_file'].items():
    s = item['whole_file']
    cov_table += f"| `{name}` | {s['covered_lines']}/{s['executable_lines']} ({s['line_percent']:.2f}%) | {s['covered_branches']}/{s['branches']} ({s['branch_percent']:.2f}%) |\n"
footer = state['workflow']['ai_disclosure']['pr_footer']

body = '''Fixes #1025.

With a one-row aligned table (`time=1, v=42`), an always-false FIELD predicate currently returns the row without invoking the predicate. This change makes Java and C++ return zero rows and invoke their callbacks once; the null-filter and always-true controls still return the row.

### Why the current paths are wrong

`init_internal()` enables the aligned bulk path even when `field_filter` is non-null. That path copies decoded batches directly into the result and never evaluates the predicate. The scalar merge path also has an unfinished FIELD-filter condition: with a non-null filter, it neither appends nor advances the current row, so sparse selections can loop indefinitely.

### How the change preserves row semantics

* Non-null FIELD filters use individual column contexts and the existing timestamp merge path. The shared vector context exposes only its first current value through `get_current_value()`, so reusing that accessor for several FIELDs would silently bind the wrong values. The unfiltered shared-vector and bulk-copy paths stay enabled.
* Build a borrowed, typed view of the projected FIELDs at the candidate timestamp. Fields absent at that timestamp are NULL. Names are normalized and unique; their order is unspecified. The timestamp remains signed 64-bit, primitive access checks the exact type and byte length, and binary views preserve empty values and embedded NUL bytes.
* Evaluate before appending a row and before consuming OFFSET/LIMIT. Rejected rows, including the last row of a page, still advance all contexts at that timestamp. OFFSET/LIMIT therefore count matching rows across pages, chunks and devices. Accepted unfiltered rows keep their existing append/advance loop.
* Keep callback status separate from acceptance: `E_OK` plus `accepted=false` means reject; a nonzero status is an error. `RET_FAIL(expr)` assigns `ret` and tests `ret != E_OK`, so callback/read failures return their original error and the existing `TableResultSet` failure latch prevents resuming a partially consumed read as EOF.

### Predicate API and boundaries

Add `TableFieldFilter::satisfy_row(const TableFieldRow&, bool&)` without changing `Filter`'s vtable. Its views are valid only during the callback. This avoids treating FIELDs as TAG string segments: the existing `satisfyRow(int, segments)` callback is for TAGs and also narrows timestamps to 32 bits.

Ordinary `Filter` subclasses remain usable for one selected integer/Boolean or string-like FIELD through their existing value overloads. NULL does not match these legacy predicates. Legacy FLOAT/DOUBLE or multiple-FIELD shapes return `E_NOT_SUPPORT`; use the typed row callback for those shapes and NULL-aware predicates. TAG filtering remains separate. Unprojected FIELD loading, predicate pushdown/vectorization, and new C/Python wrapper APIs are outside this change.

```cpp
struct Positive : storage::TableFieldFilter {
  int satisfy_row(const storage::TableFieldRow& row,
                  bool& accepted) const override {
    const auto* field = row.find("v");
    int64_t value = 0;
    accepted = field != nullptr && field->get(value) && value > 0;
    return common::E_OK;
  }
};
// query() owns the allocated predicate through the result reader.
executor.query("t", {"v"}, nullptr, nullptr, new Positive(), result);
```

### Validation

Base: `1180b13675e11a0230708af2cc70d037e0e12623`; tested head: `{HEAD}`.

* 50 new tests: row/batch sizes 1 and 4, parallel reads on/off, true/false/NULL filters, rejected pages, duplicate projections, all-NULL fields, nullable primitives, empty/binary strings, 64-bit timestamps, combined time/TAG/FIELD filters, cross-device OFFSET/LIMIT, invalid legacy shapes and terminal callback errors.
* Windows Release: 955 passed, 3 opt-in tests skipped; Linux GCC C++11 with all six optional codecs: 976 passed, 1 external-index test skipped. Each has 10 existing disabled tests. Complete-library MSVC ASan plus the 50 dedicated tests: five repetitions, 250 passes.
* Original native Java `ExpressionTree` callback: all 12 own/cross-reader runs match. Multi-type files from both writers: 24 reader comparisons match, including NULL/binary/float values and OFFSET/LIMIT. Complex predicates use a Java application-level reference over Java-decoded rows; they do not claim a new native Java FIELD-expression API. Upstream validators also read 117 C++ files in Java and 135 Java files in C++.
* Changed/new production executable lines: **75/77 = 97.40%**; branches: **85/109 = 77.98%**. The two missed lines are defensive current-context read-error returns. Coverage includes normal compiler-reported branches without branch exclusions; identical source/copied headers are SHA-checked and merged by physical line/branch identity.

{COV_TABLE}
Windows opt-in fixture generation with optional codecs disabled also fails on the untouched baseline (identical 336 assertion values); both failure logs are retained. The passing compressed-file matrix uses Linux with all codecs enabled. A Windows-generated fixture CSV needed CRLF-to-LF normalization for the Linux test harness's literal header comparison; all 135 TsFile hashes were unchanged, and the initial failure is retained. Explicit `"time"` projection is already rejected by the table schema on the base; normal implicit timestamps and TAG-only projection are tested here.

### Performance

Same driver/options against baseline/fixed MSVC Release static libraries; 300,000 rows × 8 INT64 FIELDs, eight queries per process, every row/checksum checked, two warmups and 25 alternating pairs per scenario, CPU affinity mask 4. Timing includes open/query/scan/result destruction and excludes fixture generation. The baseline snapshot's 255 source/build files were verified against the base Git blobs.

{PERF_TABLE}
{CONFIRM_TEXT}

These comparisons cover existing valid unfiltered, time-filtered, OFFSET/LIMIT and sparse query paths. The previous FIELD-filter implementation ignored the callback or hung, so it is not an equivalent-operation performance baseline for actually evaluating that callback. Filtered queries use the scalar merge path; this PR does not claim free filtering or universal Java/C++ parity.

[Full validation report]({REPORT_URL}) · [Sources, scripts, raw logs and measurements]({EVIDENCE_URL})

'''
body = body.replace('{HEAD}', head).replace('{COV_TABLE}', cov_table).replace('{PERF_TABLE}', perf_table).replace('{CONFIRM_TEXT}', confirm_text)
(v / 'pr-body-ready.md').write_text(body + footer + '\n', encoding='utf-8')

report = f'''# TsFile PR 03 本地验证报告

Issue：https://github.com/apache/tsfile/issues/1025。独立分支 `cpp/fix-table-field-filter`，基线 `1180b13675e11a0230708af2cc70d037e0e12623`，验证提交 `{head}`。

## 修改为何正确

原对齐批路径跳过 FIELD 回调；稀疏合并路径的 TODO 在非空过滤器下既不输出也不推进。现在非空过滤器走独立列上下文的时间合并路径：先形成保留实际类型、NULL、二进制长度和 64 位时间戳的借用行视图，再调用谓词。不能复用 TAG 的字符串段回调，也不能把共享向量上下文的首列值当作所有字段的值。

谓词的返回码与匹配布尔值分离：`E_OK` 加 `false` 是正常拒绝，非零返回码才是失败。`RET_FAIL(expr)` 将返回码赋给 `ret` 并判断其是否非零，不把匹配结果当成错误码。只有接受的行才消耗 OFFSET/LIMIT；拒绝行也必须推进，跨页、chunk 和设备继续读。回调或读取失败由既有 ResultSet 错误锁存机制传播。未过滤查询保留原有共享向量和批复制路径，接受行也保留原来的填充/推进循环。

新增 TableFieldFilter 没有修改 Filter 的虚函数表。旧 Filter 支持单个整数/布尔或字符串字段，NULL 不匹配；旧接口的浮点和多字段形态返回 E_NOT_SUPPORT，应使用带类型行回调。未投影字段自动加载、谓词下推和向量化过滤不在本项范围。视图只在回调内有效。

## 正确性与兼容性

50 项新增专项全部通过；Windows 全量 955 通过、3 跳过；Linux 全量 976 通过、1 跳过。两侧各有 10 项已有 disabled 测试，未将其算作通过。完整库及专项均使用 MSVC ASan 插桩，重复 5 轮，共 250 次通过。

原 issue 的 12 次 Java/C++ 自身和交叉读取全部一致，直接验证 Java 原生 ExpressionTree 常量回调。多类型文件有 24 次逐行对照，包含两种 writer、两种 reader、NULL、二进制、浮点及过滤后的 OFFSET/LIMIT。复杂条件的 Java 答案由 Java 原生解码后的应用层谓词计算，没有冒充 Java 原生字段表达式接口。上游验证器还验证 Java 读取 117 个 C++ 文件、C++ 读取 135 个 Java 文件，Linux 启用了六种可选压缩库。

## 覆盖率

新增/修改生产行 75/77（97.40%），分支 85/109（77.98%）。两条未覆盖行是读取当前上下文时的防御性错误返回。以下同时报告整文件覆盖率，不将局部覆盖率当成整个模块的覆盖率。

{cov_table}
GCC/gcovr 原始计数使用 atomic profiling；源文件与 CMake 复制头文件先核对 SHA，再按物理行和分支标识合并。没有排除分支或忽略解析失败。覆盖率来自完整 Linux 测试的计数快照；之后又单独验证了新生成的 Java fixture。

## 性能

300,000 行 × 8 个 INT64 字段，每进程 8 次完整查询；双方每一行和校验和均校验。每场景 2 轮预热、25 对交替独立进程、CPU affinity=4。计时含打开/查询/扫描/释放结果，不含生成 fixture。基线源快照的 255 个文件已逐一核对 Git blob。

{perf_table}
{confirm_text}

首轮时间过滤批查询偏慢的结果没有删除。追加 300 对、按每 4 对形成 75 个区块后，没有复现稳定退化；两个阶段使用完全相同的源提交和测量程序。原有有效查询路径的结果不能证明所有场景永不退化；此前忽略过滤器或卡住的实现也不是实际执行过滤的等价性能基线。

## 保留的失败与限制

1. Windows 关闭可选压缩库时额外启用 fixture 生成测试会失败；未修改基线和修复版的 336 个断言值序列完全一致。已保留两个日志，不计入默认套件通过数；压缩兼容性结论使用全部压缩库开启的 Linux 结果。
2. Windows Java 生成的 CSV manifest 使用 CRLF，Linux 上游测试工具逐字比较表头而失败。只将辅助 CSV 转为 LF，135 个 TsFile 的 SHA 全部不变，保留原 CSV、失败日志和转换脚本。
3. 显式投影 time 在基线表 schema 中已经返回列不存在，本项测试隐式时间戳和 TAG-only 投影。该限制未作为本项修改内容。
4. 初次批模式测试工具错误使用了不存在的显式 time 列索引，修正为表块固定的时间列 0。ASan 工具初次链接了未插桩 GTest，出现链接注解不匹配；已改为同选项编译 GTest，最终插桩测试通过。这些是验证工具修正，没有更改生产逻辑来绕过断言。
5. WSL/NTFS 构建曾提示约 0.2 秒时间偏差；最终重建未改变已验证可执行文件的 SHA，重建日志和前后 SHA 保留。

## 可复查材料

证据包包含生产 diff、五个修改文件、独立跨语言源码、CMake/PowerShell/WSL 构建脚本、原始测试 XML 和日志、覆盖率原始 JSON/汇总、全部性能样本与确认样本、基线文件核验、manifest 转换与 TsFile SHA。机器路径保留实际执行位置。主要入口为 final-native.ps1、build-asan.ps1、build-linux.sh、final-linux-extra.sh、check_compatibility.py、benchmark.py、confirm_performance.py。

{footer}
'''
(out / 'TsFile_PR_03_本地验证报告.md').write_text(report, encoding='utf-8')

with zipfile.ZipFile(out / 'TsFile_PR_03_验证证据.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in v.iterdir():
        if p.is_file() and p.suffix.lower() in {'.py', '.cc', '.java', '.ps1', '.sh', '.json', '.xml', '.log', '.txt', '.diff', '.sha256'}:
            if p.name.startswith(('github-', 'published-', 'pr-publication')) or p.name == 'java-classpath.txt':
                continue
            z.write(p, 'validation/' + p.name)
    for folder in ['native-java-fixtures', 'native-cpp-fixtures']:
        for p in (v / folder).iterdir():
            if p.suffix == '.csv': z.write(p, 'validation/' + folder + '/' + p.name)
    changed = subprocess.check_output(['git', '-C', str(source), 'diff', '--name-only', summary['base_commit'], head], text=True).splitlines()
    for name in changed: z.write(source / name, 'source/' + name)
    z.write(out / 'TsFile_PR_03_本地验证报告.md', 'validation-report.md')
print(json.dumps({'gates_passed': True, 'head': head, 'changed_line_percent': coverage['changed_production']['line_percent'], 'evidence_bytes': (out / 'TsFile_PR_03_验证证据.zip').stat().st_size}))

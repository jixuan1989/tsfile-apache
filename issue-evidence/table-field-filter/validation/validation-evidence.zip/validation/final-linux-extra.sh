#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2
v="$task_root/work/issue-03/validation"
cmake="$task_root/work/wsl-tools/cmake/data/bin/cmake"
sha256sum "$v/linux-coverage-atomic/test/lib/TsFile_Test" > "$v/linux-executable-before.sha256"
"$cmake" --build "$v/linux-coverage-atomic" --target TsFile_Test --parallel 6 > "$v/linux-nochange-rebuild.log" 2>&1
sha256sum "$v/linux-coverage-atomic/test/lib/TsFile_Test" > "$v/linux-executable-after.sha256"
cmp "$v/linux-executable-before.sha256" "$v/linux-executable-after.sha256"
cd "$v"
TSFILE_COMPAT_VALIDATE_DIR="$v/native-java-fixtures" ./linux-coverage-atomic/test/lib/TsFile_Test --gtest_filter=TableModelEncodingCompressionCompatibilityTest.ValidateFixtures --gtest_output=xml:native-cpp-java-readback.xml > native-cpp-java-readback.log 2>&1
tail -n 7 native-cpp-java-readback.log

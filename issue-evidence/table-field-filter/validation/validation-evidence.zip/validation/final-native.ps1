$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
cmake --build "$taskRoot/../standalone-validation/library" --target TsFile_Test --config Release --parallel 6 > "$taskRoot/windows-final-build.log" 2>&1
if($LASTEXITCODE -ne 0) { throw 'library build failed' }
cmake --build "$taskRoot/program" --config Release --parallel 6 > "$taskRoot/final-driver-build.log" 2>&1
if($LASTEXITCODE -ne 0) { throw 'driver build failed' }
cmake --build "$taskRoot/../standalone-validation/program" --target field_filter_repro --config Release > "$taskRoot/repro-final-build.log" 2>&1
if($LASTEXITCODE -ne 0) { throw 'repro build failed' }
Push-Location $taskRoot
try {
  & ../standalone-validation/library/test/lib/Release/TsFile_Test.exe --gtest_output=xml:windows-all-tests.xml > windows-all-tests.log 2>&1
  if($LASTEXITCODE -ne 0) { throw 'full tests failed' }
  & ./program/Release/regressions_fixed.exe --gtest_output=xml:fixed-regressions.xml > fixed-regressions.log 2>&1
  if($LASTEXITCODE -ne 0) { throw 'regressions failed' }
  & 'C:/Users/hxd/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' check_compatibility.py > compatibility.log 2>&1
  if($LASTEXITCODE -ne 0) { throw 'compatibility failed' }
} finally { Pop-Location }
Get-Content "$taskRoot/windows-all-tests.log" -Tail 9
Get-Content "$taskRoot/compatibility.log"

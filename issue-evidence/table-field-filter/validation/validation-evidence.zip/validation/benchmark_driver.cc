#include <fcntl.h>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include "common/tablet.h"
#include "file/local_random_access_read_file.h"
#include "file/write_file.h"
#include "reader/filter/time_filter.h"
#include "reader/filter/time_operator.h"
#include "reader/table_query_executor.h"
#include "writer/tsfile_table_writer.h"
using namespace common; using namespace storage;
static void check(int r) { if(r) throw std::runtime_error("error="+std::to_string(r)); }
int main(int argc,char**argv) {
    libtsfile_init();
    const int count=300000; const int repeats=8;
    std::vector<std::string> names; std::vector<ColumnSchema> columns;
    for(int i=0;i<8;++i) { names.push_back("v"+std::to_string(i)); columns.emplace_back(names.back(),INT64,UNCOMPRESSED,PLAIN,ColumnCategory::FIELD); }
    TableSchema schema("bench",columns);
    if(std::string(argv[1])=="write") {
        WriteFile file; int flags=O_WRONLY|O_CREAT|O_TRUNC;
#ifdef _WIN32
        flags|=O_BINARY;
#endif
        check(file.create(argv[2],flags,0666));
        TsFileTableWriter writer(&file,&schema);
        Tablet tablet("bench",schema.get_measurement_names(),schema.get_data_types(),schema.get_column_categories(),count);
        for(int row=0;row<count;++row) {
            check(tablet.add_timestamp(row,row));
            for(int c=0;c<8;++c) if(argc<4 || std::string(argv[3])!="sparse" || c!=7 || row%3) check(tablet.add_value(row,c,int64_t(row*8+c)));
        }
        check(writer.write_table(tablet)); check(writer.close()); return 0;
    }
    int batch=std::atoi(argv[3]); std::string scenario=argv[4];
    uint64_t expected=0; int first=scenario=="time"?100000:scenario=="offset"?123:0;
    int last=scenario=="offset"?123+65432:count;
    for(int row=first;row<last;++row) expected+=uint64_t(row)*17+7-(scenario=="sparse" && row%3==0?uint64_t(row)*8+7:0);
    auto started=std::chrono::steady_clock::now(); uint64_t total=0;
    for(int rep=0;rep<repeats;++rep) {
        LocalRandomAccessReadFile file; check(file.open(argv[2])); TableQueryExecutor executor(&file,batch);
        ResultSet* result=nullptr; Filter* time=scenario=="time"?TimeFilter::gt_eq(100000):nullptr;
        check(executor.query("bench",names,time,nullptr,nullptr,scenario=="offset"?123:0,scenario=="offset"?65432:-1,result));
        uint64_t checksum=0; int rows=0; bool next=false;
        while(true) {
            check(result->next(next)); if(!next) break;
            if(batch<=0) {
                checksum+=result->get_value<int64_t>(1)+result->get_value<int64_t>("v0")+(result->is_null("v7")?0:result->get_value<int64_t>("v7")); ++rows;
            } else {
                TsBlock* block=nullptr; check(result->get_next_tsblock(block)); RowIterator iter(block);
                while(iter.has_next()) {
                    for(int col:{0,1,8}) {uint32_t len=0;bool null=false;int64_t val=0; char* bytes=iter.read(col,&len,&null); if(null) { if(col!=8 || scenario!="sparse") throw std::runtime_error("bad null"); } else { if(len!=8) throw std::runtime_error("bad cell"); std::memcpy(&val,bytes,8); checksum+=val; }}
                    ++rows; iter.next();
                }
            }
        }
        executor.destroy_query_data_set(result);
        if(rows!=last-first||checksum!=expected) throw std::runtime_error("bad checksum"); total+=checksum;
    }
    double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
    printf("{\"seconds\":%.9f,\"checksum\":%llu,\"rows\":%d,\"repeats\":%d}\n",seconds,(unsigned long long)total,last-first,repeats);
}

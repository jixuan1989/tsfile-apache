import json
from pathlib import Path
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[3]
path = root / 'work/tsfile-contribution-state.json'
state = json.loads(path.read_text(encoding='utf-8'))
now = datetime.now(timezone.utc).isoformat()
for item in [state['active']] + state['drafts']:
    if item.get('pr_number') in (1018, 1024):
        item['latest_remote_ci_counts'] = {'success': 38, 'neutral': 1, 'skipped': 1}
        item['last_checked_at'] = now
        item.setdefault('monitor', {})['next_action'] = 'Monitor CI/reviews; independently implement approved issue #1025.'
        if item['pr_number'] == 1024:
            audit = item['ci_reader_open_investigation']
            audit['retry_status'] = 'success'
            audit['latest_check_counts'] = item['latest_remote_ci_counts']
            audit['root_cause'] = 'Undetermined; unchanged-source CI retry passed. No local reproduction or confirmed root-cause fix.'
            item['monitor']['last_notified_event'] = 'Windows ASan retry succeeded; no new review requests'
            item['monitor']['notification_fingerprint'] = '1024:75592b89:38success:1neutral:1skipped:review-unchanged'
            item['monitor']['last_notified_at'] = now
    if item['id'] == '03':
        item['status'] = 'implementation_and_local_validation_in_progress'
        item['active_branch'] = 'cpp/fix-table-field-filter'
        item['initial_fix_reproduction_passed'] = True
        item['current_regressions'] = {'tests': 38, 'passed': 38, 'log': 'work/issue-03/validation/fixed-regressions.log'}
state['last_checked_at'] = now
path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = root / 'outputs/TsFile_PR_02_Windows_ASan读取测试排查.md'
with report.open('a', encoding='utf-8') as out:
    out.write('\n\n后续检查：同一提交的 Windows Release ASan 重跑作业 117510460217 已成功；当前 CI 为 38 success、1 neutral、1 skipped。未修改代码，根因仍未确认，不能将重跑成功描述为根因修复。\n')

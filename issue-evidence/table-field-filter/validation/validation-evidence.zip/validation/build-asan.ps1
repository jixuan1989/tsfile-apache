$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$env:PATH = 'D:/software/visualstudio2026/buildtools/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64;' + $env:PATH
cmake -S "$taskRoot/../repro-repo/cpp" -B "$taskRoot/msvc-asan" -G 'Visual Studio 18 2026' -A x64 -DBUILD_TEST=OFF -DBUILD_TOOLS=OFF -DTSFILE_BUILD_SHARED=OFF -DENABLE_ASAN=ON -DENABLE_ANTLR4=OFF -DENABLE_SIMD=OFF -DENABLE_THREADS=ON -DENABLE_SNAPPY=OFF -DENABLE_LZ4=OFF -DENABLE_LZOKAY=OFF -DENABLE_ZLIB=OFF -DENABLE_ZSTD=OFF -DENABLE_LZMA2=OFF > "$taskRoot/asan-configure.log" 2>&1
if ($LASTEXITCODE -ne 0) { throw 'configure library failed' }
cmake --build "$taskRoot/msvc-asan" --target tsfile --config Release --parallel 6 > "$taskRoot/asan-library-build.log" 2>&1
if ($LASTEXITCODE -ne 0) { throw 'build library failed' }
cmake -S $taskRoot -B "$taskRoot/program-asan" -G 'Visual Studio 18 2026' -A x64 -DASAN_LIBRARY="$taskRoot/msvc-asan/lib/Release/tsfile.lib" > "$taskRoot/asan-test-configure.log" 2>&1
if ($LASTEXITCODE -ne 0) { throw 'configure tests failed' }
cmake --build "$taskRoot/program-asan" --target regressions_asan --config Release --parallel 6 > "$taskRoot/asan-test-build.log" 2>&1
if ($LASTEXITCODE -ne 0) { throw 'build tests failed' }
Push-Location $taskRoot
try {
  & ./program-asan/Release/regressions_asan.exe --gtest_repeat=5 --gtest_output=xml:asan-regressions.xml > asan-regressions.log 2>&1
  if ($LASTEXITCODE -ne 0) { throw 'ASan tests failed' }
} finally { Pop-Location }
Get-Content "$taskRoot/asan-regressions.log" -Tail 6

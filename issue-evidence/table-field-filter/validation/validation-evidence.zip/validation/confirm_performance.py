from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import random
import statistics
import subprocess

v=Path(__file__).resolve().parent
initial=json.loads((v/'performance.json').read_text())
assert len(initial['cases'])==8
(v/'performance-initial.json').write_text(json.dumps(initial,indent=2)+'\n')
affinity=ctypes.windll.kernel32.SetProcessAffinityMask
affinity.argtypes=[wintypes.HANDLE,ctypes.c_size_t]
affinity.restype=wintypes.BOOL

def run(kind):
    p=subprocess.Popen([str(v/f'program/Release/bench_{kind}.exe'),'read',str(v/'benchmark.tsfile'),'1024','time'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    assert affinity(wintypes.HANDLE(int(p._handle)),4)
    out,err=p.communicate()
    assert p.returncode==0, (out,err)
    return json.loads(out.strip())

pairs=[]
blocks=[]
for block in range(75):
    section=[]
    for part in range(4):
        index=block*4+part
        order=['baseline','fixed'] if index%2==0 else ['fixed','baseline']
        row={kind:run(kind) for kind in order}
        assert row['baseline']['checksum']==row['fixed']['checksum']
        section.append(row);pairs.append(row)
    ratio=sum(x['fixed']['seconds'] for x in section)/sum(x['baseline']['seconds'] for x in section)
    blocks.append(ratio)
    if (block+1)%15==0: print('confirmation blocks='+str(block+1),flush=True)
rng=random.Random(1025)
boot=sorted(statistics.median(rng.choices(blocks,k=len(blocks))) for _ in range(10000))
summary={'case':'time_batch','new_independent_process_pairs':300,'blocks':75,'pairs_per_block':4,'paired_median_block_ratio':statistics.median(blocks),'bootstrap_95_percent':[boot[250],boot[9750]],'initial_ratio':initial['cases']['time_batch']['summary']['paired_median_latency_ratio'],'initial_95_percent':initial['cases']['time_batch']['summary']['bootstrap_95_percent']}
(v/'performance-confirmation.json').write_text(json.dumps({'summary':summary,'block_ratios':blocks,'measurements':pairs},indent=2)+'\n')
print(json.dumps(summary),flush=True)

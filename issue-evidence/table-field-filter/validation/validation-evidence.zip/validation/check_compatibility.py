from pathlib import Path
import hashlib
import json
import subprocess

v = Path(__file__).resolve().parent
issue = v.parent
cp = (v / 'java-classpath.txt').read_text(encoding='utf-8').strip()
java = [r'C:\Program Files\Java\jdk-24\bin\java.exe', '-cp', str(v) + ';' + cp, 'FieldFilterCompatibility']
cpp = [str(v / 'program/Release/compat_fixed.exe')]
records = []

def run(cmd):
    result = subprocess.run(list(map(str, cmd)), capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    records.append({'command': list(map(str, cmd)), 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    (v / 'compatibility-results.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    assert result.returncode == 0, records[-1]
    return result.stdout.strip()

files = {}
for writer, prefix in [('java', java), ('cpp', cpp)]:
    path = v / ('multi-' + writer + '.tsfile')
    if path.exists():
        path.unlink()
    run(prefix + ['write', path])
    files[writer] = path

for mode, offset, limit, rows in [('all',0,-1,28),('typed',0,-1,16),('typed',0,0,0),('typed',3,5,5),('typed',8,3,3),('typed',20,5,0)]:
    outputs = []
    for writer, path in files.items():
        for reader, prefix in [('java', java), ('cpp', cpp)]:
            out = run(prefix + [mode, path, offset, limit])
            assert len(out.splitlines()) == rows, (mode, writer, reader, len(out.splitlines()))
            outputs.append(out)
    assert len(set(outputs)) == 1, (mode, 'row output differs')
    print('multi-type cross-reader mode=' + mode + ' rows=' + str(rows) + ' identical=PASS', flush=True)

jrepro = [java[0], '-cp', str(issue / 'standalone-validation/classes') + ';' + cp, 'FieldFilterRepro']
crepro = [str(issue / 'standalone-validation/program/Release/field_filter_repro.exe')]
for writer in ['java', 'cpp']:
    path = issue / 'standalone-validation' / (writer + '.tsfile')
    for mode in ['none', 'true', 'false']:
        j = run(jrepro + ['read', path, mode])
        c = run(crepro + ['read', path, mode])
        assert j == c, (writer, mode, j, c)
        assert ('rows=0' if mode == 'false' else 'rows=1') in j
print('original Java native callback matrix: 12 reads identical=PASS', flush=True)
(v / 'compatibility-summary.json').write_text(json.dumps({'commands': len(records), 'native_callback_reads': 12,
    'multi_type_cross_reads': 24, 'multi_type_rows_all': 28, 'multi_type_rows_filtered': 16,
    'complex_predicate_oracle': 'Java application-level reference on native decoded typed rows; not a Java ExpressionTree field-value API',
    'file_hashes': {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in files.items()}}, indent=2) + '\n')

import java.io.File;
import java.util.Arrays;
import org.apache.tsfile.enums.ColumnCategory;
import org.apache.tsfile.common.conf.TSFileDescriptor;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.TableSchema;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.controller.CachedChunkLoaderImpl;
import org.apache.tsfile.read.controller.MetadataQuerierByFileImpl;
import org.apache.tsfile.read.expression.ExpressionTree;
import org.apache.tsfile.read.filter.basic.Filter;
import org.apache.tsfile.read.query.executor.TableQueryExecutor;
import org.apache.tsfile.read.reader.block.TsBlockReader;
import org.apache.tsfile.write.TsFileWriter;
import org.apache.tsfile.write.record.Tablet;
import org.apache.tsfile.write.schema.MeasurementSchema;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.tsfile.utils.Binary;
public class FieldFilterCompatibility {
  static String hex(byte[] bytes) {
    StringBuilder out=new StringBuilder();
    for(byte b:bytes) out.append(String.format(Locale.ROOT,"%02x",b & 255));
    return out.toString();
  }
  public static void main(String[] args) throws Exception {
    TSFileDescriptor.getInstance().getConfig().setCompressor("UNCOMPRESSED");
    TSFileDescriptor.getInstance().getConfig().setMaxNumberOfPointsInPage(3);
    File file=new File(args[1]);
    if(args[0].equals("write")) {
      try(TsFileWriter writer=new TsFileWriter(file)) {
        List<String> names=Arrays.asList("id","v","i","f","d","blob");
        List<TSDataType> types=Arrays.asList(TSDataType.STRING,TSDataType.INT64,TSDataType.INT32,TSDataType.FLOAT,TSDataType.DOUBLE,TSDataType.BLOB);
        List<ColumnCategory> categories=Arrays.asList(ColumnCategory.TAG,ColumnCategory.FIELD,ColumnCategory.FIELD,ColumnCategory.FIELD,ColumnCategory.FIELD,ColumnCategory.FIELD);
        List<org.apache.tsfile.write.schema.IMeasurementSchema> schemas=new ArrayList<>();
        for(int c=0;c<names.size();++c) schemas.add(new MeasurementSchema(names.get(c),types.get(c),TSEncoding.PLAIN,CompressionType.UNCOMPRESSED));
        writer.registerTableSchema(new TableSchema("t",schemas,categories));
        for(int chunk=0;chunk<2;++chunk) {
          Tablet tablet=new Tablet("t",names,types,categories,14);
          for(int dev=0;dev<2;++dev) for(int row=0;row<7;++row) {
            int index=dev*7+row,t=chunk*7+row;
            tablet.addTimestamp(index,1099511627776L+t);
            tablet.addValue("id",index,new Binary((dev==0?"d0":"d1").getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            tablet.addValue("v",index,(long)(dev*100+t));
            tablet.addValue("i",index,t%3==0?null:Integer.valueOf(-t));
            tablet.addValue("f",index,(float)t+0.25f);
            tablet.addValue("d",index,-(double)t-0.5);
            tablet.addValue("blob",index,new Binary(t%2==0?new byte[0]:new byte[]{97,0,98}));
          }
          tablet.setRowSize(14); writer.writeTable(tablet); writer.flush();
        }
      }
      return;
    }
    try(TsFileSequenceReader source=new TsFileSequenceReader(file.getPath())) {
      TableQueryExecutor executor=new TableQueryExecutor(new MetadataQuerierByFileImpl(source),new CachedChunkLoaderImpl(source),TableQueryExecutor.TableQueryOrdering.DEVICE);
      int rows=0, matched=0;
      int offset=args.length>2?Integer.parseInt(args[2]):0;
      int limit=args.length>3?Integer.parseInt(args[3]):-1;
      try(TsBlockReader result=executor.query("t",Arrays.asList("v","i","f","d","blob"),null,null,null)) {
        while(result.hasNext()) {
          org.apache.tsfile.read.common.block.TsBlock block=result.next();
          for(int row=0;row<block.getPositionCount();++row) {
            long v=block.getColumn(0).getLong(row);
            boolean nil=block.getColumn(1).isNull(row);
            float f=block.getColumn(2).getFloat(row);
            // Application-level Java reference predicate. The native Java
            // constant callback is tested separately by FieldFilterRepro.
            if(args[0].equals("typed") && !(nil || (v%2==0 && f>4))) continue;
            if(matched++ < offset || (limit>=0 && rows>=limit)) continue;
            System.out.printf(Locale.ROOT,"%d,%d,%s,%.2f,%.2f,%s%n",block.getTimeByIndex(row),v,nil?"null":Integer.toString(block.getColumn(1).getInt(row)),f,block.getColumn(3).getDouble(row),hex(block.getColumn(4).getBinary(row).getValues()));
            ++rows;
          }
        }
      }
      System.err.println("rows="+rows);
    }
  }
}

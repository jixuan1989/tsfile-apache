#include <fcntl.h>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include "common/tablet.h"
#include "file/local_random_access_read_file.h"
#include "file/write_file.h"
#include "reader/filter/table_field_filter.h"
#include "reader/table_query_executor.h"
#include "writer/tsfile_table_writer.h"
using namespace common;
using namespace storage;
static void check(int ret) { if(ret) throw std::runtime_error("error="+std::to_string(ret)); }
static std::string hex(const char* data, uint32_t size) {
    std::string out; const char* digits="0123456789abcdef";
    for(uint32_t i=0;i<size;++i) { unsigned char c=data[i]; out+=digits[c>>4]; out+=digits[c&15]; } return out;
}
class Select : public TableFieldFilter {
 public:
    int satisfy_row(const TableFieldRow& row, bool& ok) const override {
        int64_t v=0; float f=0;
        if(!row.find("v")->get(v) || !row.find("f")->get(f)) return E_DECODE_ERR;
        ok=row.find("i")->is_null() || (v%2==0 && f>4); return E_OK;
    }
};
int main(int argc,char** argv) {
    libtsfile_init();
    const std::string mode=argv[1];
    if(mode=="write") {
        g_config_value_.page_writer_max_point_num_=3;
        WriteFile file; int flags=O_WRONLY|O_CREAT|O_TRUNC;
#ifdef _WIN32
        flags|=O_BINARY;
#endif
        check(file.create(argv[2],flags,0666));
        std::vector<ColumnSchema> columns;
        const std::vector<std::string> names{"id","v","i","f","d","blob"};
        const std::vector<TSDataType> types{STRING,INT64,INT32,FLOAT,DOUBLE,BLOB};
        for(size_t c=0;c<names.size();++c) columns.emplace_back(names[c],types[c],UNCOMPRESSED,PLAIN,c==0?ColumnCategory::TAG:ColumnCategory::FIELD);
        TableSchema schema("t",columns); TsFileTableWriter writer(&file,&schema);
        for(int chunk=0;chunk<2;++chunk) {
            Tablet tablet("t",schema.get_measurement_names(),schema.get_data_types(),schema.get_column_categories(),14);
            for(int dev=0;dev<2;++dev) for(int row=0;row<7;++row) {
                const int index=dev*7+row,t=chunk*7+row;
                check(tablet.add_timestamp(index,INT64_C(1099511627776)+t));
                check(tablet.add_value(index,"id",dev?"d1":"d0"));
                check(tablet.add_value(index,"v",int64_t(dev*100+t)));
                if(t%3) check(tablet.add_value(index,"i",int32_t(-t)));
                check(tablet.add_value(index,"f",float(t)+0.25f));
                check(tablet.add_value(index,"d",-double(t)-0.5));
                const std::string bytes=t%2?std::string("a\0b",3):std::string();
                check(tablet.add_value(index,"blob",String(bytes.data(),bytes.size())));
            }
            check(writer.write_table(tablet)); check(writer.flush());
        }
        check(writer.close()); return 0;
    }
    LocalRandomAccessReadFile file; check(file.open(argv[2]));
    TableQueryExecutor executor(&file); ResultSet* result=nullptr;
    check(executor.query("t",{"v","i","f","d","blob"},nullptr,nullptr,mode=="typed"?new Select():nullptr,argc>3?std::atoi(argv[3]):0,argc>4?std::atoi(argv[4]):-1,result));
    bool next=false; int rows=0;
    while(true) {
        check(result->next(next)); if(!next) break;
        const auto blob=result->get_value<String*>("blob");
        printf("%lld,%lld,",(long long)result->get_value<int64_t>(1),(long long)result->get_value<int64_t>("v"));
        if(result->is_null("i")) printf("null"); else printf("%d",result->get_value<int32_t>("i"));
        printf(",%.2f,%.2f,%s\n",double(result->get_value<float>("f")),result->get_value<double>("d"),hex(blob->buf_,blob->len_).c_str());
        ++rows;
    }
    executor.destroy_query_data_set(result);
    std::cerr<<"rows="<<rows<<"\n";
    return 0;
}

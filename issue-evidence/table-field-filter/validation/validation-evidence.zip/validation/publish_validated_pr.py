from pathlib import Path
import base64
import hashlib
import json
import os
import re
import subprocess
import time
from urllib.request import urlopen

root = Path(__file__).resolve().parent
base = root.parents[2]
source = root.parent / 'repro-repo'
out = base / 'outputs'
gh = r'C:\Program Files\GitHub CLI\gh.exe'
state_path = base / 'work/tsfile-contribution-state.json'
state = json.loads(state_path.read_text(encoding='utf-8'))
item = next(x for x in state['drafts'] if x['id'] == '03')
summary = json.loads((root / 'validation-summary.json').read_text())
record_path = root / 'pr-publication.json'
record = json.loads(record_path.read_text()) if record_path.exists() else {}
fork = 'jixuan1989/tsfile-apache'
upstream = 'apache/tsfile'
branch = 'cpp/fix-table-field-filter'
evidence_branch = item['evidence_branch']
prefix = 'issue-evidence/table-field-filter/validation'
env = os.environ.copy()
env['PATH'] = str(Path(gh).parent) + os.pathsep + env['PATH']
env['GIT_TERMINAL_PROMPT'] = '0'
env['GODEBUG'] = 'http2client=0'

def save():
    record_path.write_text(json.dumps(record,indent=2)+'\n')

def run(args):
    result = subprocess.run(args,capture_output=True,text=True,encoding='utf-8',env=env)
    if result.returncode: raise RuntimeError(f'{args[:3]}: {result.stderr}')
    return result.stdout.strip()

def cli(*args): return run([gh,*args])

def api_once(endpoint,payload=None,method=None):
    args = ['api',endpoint]
    if payload is not None:
        request = root / 'github-pr-publication-request.json'
        request.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
        args += ['--method',method or 'POST','--input',str(request)]
    return json.loads(cli(*args))

def api(endpoint, payload=None, method=None):
    attempts = 4 if payload is None or endpoint.endswith('/git/blobs') else 1
    for attempt in range(attempts):
        try:
            return api_once(endpoint, payload, method)
        except Exception:
            if attempt + 1 == attempts: raise
            time.sleep(2)

assert item['approval_received'] and item['issue_url'] == 'https://github.com/apache/tsfile/issues/1025'
assert summary['gates_passed'] and state['fork'] == fork
assert api('user')['login'] == 'jixuan1989'
head = run(['git','-C',str(source),'rev-parse','HEAD'])
assert head == summary['head_commit'] != summary['base_commit']
assert run(['git','-C',str(source),'branch','--show-current']) == branch
assert run(['git','-C',str(source),'status','--porcelain']) == ''
assert api(f'repos/{upstream}/commits/develop')['sha'] == summary['base_commit']
changed = run(['git','-C',str(source),'diff','--name-only',summary['base_commit'],head]).splitlines()
assert len(changed) == 5 and all(x.startswith(('cpp/src/','cpp/test/')) for x in changed)
remotes = run(['git','-C',str(source),'remote']).splitlines()
if 'fork' not in remotes:
    run(['git','-C',str(source),'remote','add','fork',f'https://github.com/{fork}.git'])
assert run(['git','-C',str(source),'remote','get-url','fork']) == f'https://github.com/{fork}.git'
run(['git','-C',str(source),'-c','credential.helper=','-c','credential.helper=!gh auth git-credential',
     'push','--set-upstream','fork',branch])
assert api(f'repos/{fork}/git/ref/heads/{branch}')['object']['sha'] == head
record['head_commit'] = head; save()
print('Source topic branch pushed to personal fork and verified.',flush=True)

assets = {'validation-report.md':out/'TsFile_PR_03_本地验证报告.md',
          'validation-evidence.zip':out/'TsFile_PR_03_验证证据.zip'}
if not record.get('evidence_commit'):
    parent = api(f'repos/{fork}/git/ref/heads/{evidence_branch}')['object']['sha']
    original = api(f'repos/{fork}/git/commits/{parent}')
    tree_entries = []
    for name,path in assets.items():
        blob = api(f'repos/{fork}/git/blobs',{'encoding':'base64','content':base64.b64encode(path.read_bytes()).decode('ascii')})
        tree_entries.append({'path':f'{prefix}/{name}','mode':'100644','type':'blob','sha':blob['sha']})
    tree = api(f'repos/{fork}/git/trees',{'base_tree':original['tree']['sha'],'tree':tree_entries})
    commit = api(f'repos/{fork}/git/commits',{'message':'Add validated fix evidence for TsFile #1025','tree':tree['sha'],'parents':[parent]})
    record['evidence_commit'] = commit['sha']; save()
if not record.get('evidence_ref_updated'):
    current = api(f'repos/{fork}/git/ref/heads/{evidence_branch}')['object']['sha']
    if current != record['evidence_commit']:
        api(f'repos/{fork}/git/refs/heads/{evidence_branch}',{'sha':record['evidence_commit'],'force':False},'PATCH')
    record['evidence_ref_updated'] = True; save()
for name,path in assets.items():
    url = f'https://raw.githubusercontent.com/{fork}/{record["evidence_commit"]}/{prefix}/{name}'
    for attempt in range(3):
        try:
            with urlopen(url,timeout=60) as response: data = response.read()
            assert hashlib.sha256(data).digest() == hashlib.sha256(path.read_bytes()).digest()
            break
        except Exception:
            if attempt == 2: raise
            time.sleep(2)
report_url = f'https://github.com/{fork}/blob/{record["evidence_commit"]}/{prefix}/validation-report.md'
evidence_url = f'https://raw.githubusercontent.com/{fork}/{record["evidence_commit"]}/{prefix}/validation-evidence.zip'
record.update(report_url=report_url,evidence_url=evidence_url); save()
print('Public validation report/evidence uploaded and SHA-256 verified.',flush=True)

title = '[C++] Apply field predicates to aligned table query rows'
body = (root/'pr-body-ready.md').read_text(encoding='utf-8').replace('{REPORT_URL}',report_url).replace('{EVIDENCE_URL}',evidence_url)
assert not re.search(r'\{[A-Z_]+\}',body)
assert body.endswith(state['workflow']['ai_disclosure']['pr_footer']+'\n')
body_path = root/'pr-body.md'; body_path.write_text(body,encoding='utf-8')
(out/'TsFile_PR_03_说明.md').write_text('# '+title+'\n\n'+body,encoding='utf-8')
pr_url = record.get('pr_url') or item.get('pr_url')
if not pr_url:
    existing = api(f'repos/{upstream}/pulls?state=all&head=jixuan1989:{branch}&per_page=100')
    assert len(existing) <= 1
    if existing:
        pr_url = existing[0]['html_url']
    else:
        created = api(f'repos/{upstream}/pulls', {'head':f'jixuan1989:{branch}', 'base':'develop', 'title':title, 'body':body, 'maintainer_can_modify':True})
        pr_url = created['html_url']
    assert re.fullmatch(r'https://github.com/apache/tsfile/pull/\d+',pr_url)
    record['pr_url'] = pr_url; save()
number = int(pr_url.rsplit('/',1)[1])
verified = api(f'repos/{upstream}/pulls/{number}')
assert verified['head']['sha'] == head and verified['head']['repo']['full_name'] == fork
assert verified['head']['ref'] == branch and verified['base']['ref'] == 'develop'
assert verified['title'] == title and verified['user']['login'] == 'jixuan1989'
assert verified['body'].replace('\r\n','\n').strip() == body.strip()
assert verified['state'] == 'open' and not verified['draft'] and not verified['merged']
(root/'published-pr-verified.json').write_text(json.dumps(verified,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
item.update(status='pr_submitted_awaiting_ci_and_review',pr_url=pr_url,pr_number=number,head_commit=head,
    pr_body_verified=True,local_quality_gates_passed=True,
    validation_report='outputs/TsFile_PR_03_本地验证报告.md',validation_evidence='outputs/TsFile_PR_03_验证证据.zip',
    public_validation_report_url=report_url,public_validation_evidence_url=evidence_url,
    coverage=summary['coverage'],performance=summary['performance'])
item['implementation']['quality_gates'] = 'passed'
item.setdefault('ai_disclosure_verified', {})['pr'] = True
for queued in state['queue']:
    if queued['id'] == '03': queued.update(status='pr_submitted_awaiting_ci_and_review',pr=pr_url)
state_path.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
plan_path = out/'TsFile_串行贡献流程.md'
plan = plan_path.read_text(encoding='utf-8-sig').replace('下一步在独立分支实现修复并完成本地质量验证。', f'独立分支修复及质量验证已完成，已提交 [PR #{number}]({pr_url})；继续跟进 CI 与审阅。')
plan_path.write_text(plan,encoding='utf-8-sig')
print(json.dumps({'pr_url':pr_url,'head_commit':head,'verified':True}),flush=True)

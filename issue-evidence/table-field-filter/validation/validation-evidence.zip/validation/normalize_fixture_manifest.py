from pathlib import Path
import hashlib
import json

v = Path(__file__).resolve().parent
folder = v / 'native-java-fixtures'
manifest = folder / 'manifest.csv'
original = folder / 'manifest.windows.csv'
if not original.exists():
    original.write_bytes(manifest.read_bytes())
raw = original.read_bytes()
assert manifest.read_bytes() in (raw, raw.replace(b'\r\n', b'\n'))
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.tsfile')}
manifest.write_bytes(raw.replace(b'\r\n', b'\n'))
assert hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.tsfile')}
(v / 'manifest-line-ending-normalization.json').write_text(json.dumps({
    'reason': 'Linux upstream fixture-manifest harness compares a CSV header literally; Windows Java generator emits CRLF. Only auxiliary manifest line endings normalized; all 135 TsFile bytes unchanged.',
    'manifest_before_sha256': hashlib.sha256(raw).hexdigest(),
    'manifest_after_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'tsfile_hashes_unchanged': True, 'tsfile_sha256': hashes}, indent=2) + '\n')

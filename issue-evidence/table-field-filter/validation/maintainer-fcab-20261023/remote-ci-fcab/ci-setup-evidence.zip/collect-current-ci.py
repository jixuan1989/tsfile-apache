"""Read actual new-head failed jobs; never rerun CI or change workflows."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,os,time,hashlib
v=Path(__file__).resolve().parent;root=v.parents[3];out=v/'remote-ci-fcab';out.mkdir(exist_ok=True)
snapshot=json.loads((root/'work/contribution-monitor-latest.json').read_text(encoding='utf-8'))
item=next(x for x in snapshot['items'] if x['number']==1026)
assert item['head']=='fcab7437130421bed2604311461a7a7aa6e9a255'
failed=[c for c in item['check_runs'] if c['conclusion']=='failure'];assert len(failed)==7
env=os.environ.copy();env['GODEBUG']='http2client=0'
def get(endpoint):
    for i in range(3):
        args=['C:/Program Files/GitHub CLI/gh.exe','api',endpoint]
        if endpoint.endswith('/logs'):args.append('--allow-escape-sequences')
        p=subprocess.run(args,env=env,capture_output=True,timeout=90)
        if p.returncode==0:return p.stdout
        if i<2:time.sleep(2)
    raise RuntimeError(p.stderr.decode(errors='replace'))
def collect(c):
    job=int(c['html_url'].rsplit('/',1)[1]);prefix=f'repos/apache/tsfile/actions/jobs/{job}'
    for suffix,endpoint in [('json',prefix),('annotations.json',f'repos/apache/tsfile/check-runs/{c["id"]}/annotations'),('log',prefix+'/logs')]:
        p=out/f'job-{job}.{suffix}'
        if not p.exists():p.write_bytes(get(endpoint))
    text=(out/f'job-{job}.log').read_text(encoding='utf-8-sig');metadata=json.loads((out/f'job-{job}.json').read_text(encoding='utf-8'))
    assert metadata['head_sha']==item['head'] and metadata['conclusion']=='failure'
    errors=[x for x in ['update-alternatives: error: alternative path /usr/bin/clang-format-17 does not exist',"The version '3.9' with architecture 'x64' was not found for Ubuntu 26.04."] if x in text]
    assert len(errors)==1,(job,text[-2000:])
    bad=[s for s in metadata['steps'] if s['conclusion']=='failure'];assert len(bad)==1
    assert bad[0]['name'] in ['Install dependencies','Set up Python'],bad
    after=[s for s in metadata['steps'] if s['number']>bad[0]['number']]
    assert all(s['conclusion']=='skipped' or s['name'].startswith(('Post ','Complete job')) for s in after),after
    return {'job':job,'name':c['name'],'url':c['html_url'],'stage':bad[0]['name'],'error':errors[0],
            'formatter_missing':'clang-format-17' in errors[0],
            'all_following_noncleanup_steps_skipped':True,
            'artifacts':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.glob(f'job-{job}.*')}}
with ThreadPoolExecutor(max_workers=4) as pool:findings=list(pool.map(collect,failed))
diff=subprocess.check_output(['git','-C',str(root/'work/pr03-fcab-src'),'diff','11bfc35c99f8e845939a6753f004ecee38c7a2ec','fcab7437130421bed2604311461a7a7aa6e9a255','--','.github/workflows']);assert not diff
summary={'checked_at':datetime.now(timezone.utc).isoformat(),'head':item['head'],'failed_jobs':findings,
         'formatter_missing':sum(f['formatter_missing'] for f in findings),'python39_unavailable':sum(not f['formatter_missing'] for f in findings),
         'project_build_or_tests_reached':False,'workflow_diff_11b_to_fcab':'empty',
         'classification':'runner/toolchain setup; independent from scoped correctness/performance/source gates',
         'ci_rerun_requested':False,'workflow_modified':False,'source_pushed':False}
assert summary['formatter_missing']==6 and summary['python39_unavailable']==1
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['head','formatter_missing','python39_unavailable','project_build_or_tests_reached','workflow_diff_11b_to_fcab']}))

from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import random
import statistics
import subprocess

root = Path(__file__).resolve().parent
affinity = ctypes.windll.kernel32.SetProcessAffinityMask
affinity.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
affinity.restype = wintypes.BOOL

def run(kind, width, pct, batch):
    process = subprocess.Popen([str(root / f'msvc/Release/field_query_{kind}.exe'),
        'read', str(root / 'field-query.tsfile'), str(width), str(pct), str(batch)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    applied = bool(affinity(wintypes.HANDLE(int(process._handle)), 4))
    stdout, stderr = process.communicate()
    assert applied
    if process.returncode:
        raise RuntimeError(stdout + '\n' + stderr)
    result = json.loads([s for s in stdout.splitlines() if s.startswith('{')][-1])
    assert result['callback_calls'] == 160000
    assert result['returned_rows_per_query'] == 400 * pct
    result['affinity_mask'] = 4
    return result

def percentile(a, f):
    a = sorted(a); index = (len(a) - 1) * f; lo = int(index); hi = min(lo + 1, len(a) - 1)
    return a[lo] if lo == hi else a[lo] * (hi - index) + a[hi] * (index - lo)

report = {
    'baseline_commit': 'e2e9c3786f9753ec5d5c1b813fd2f1fb0d71d5b8',
    'baseline_scope': 'Prior PR implementation executes the same native FIELD callback correctly for these dense non-NULL inputs. This is not the develop baseline, whose predicate was ignored or hung.',
    'method': 'MSVC Release, static library, identical 40000-row x 8 INT64 PLAIN UNCOMPRESSED file; 2 warmups then 25 alternating independent process pairs, CPU affinity mask 4; 4 complete verified queries/process. Warm filesystem cache; fresh processes are not cold-cache evidence. Bootstrap resamples the 25 process pairs; query P50/P95 use the 100 queries/variant/case clustered in 25 processes, not 100 independent processes.',
    'metrics': 'Full time includes open, metadata/query setup, result consumption/checksum and cleanup. open_seconds is file open only; plan_seconds includes metadata/query construction. First-row time is unavailable for zero-result queries. Working set is whole-process peak, not incremental query allocation. No P99 or cold-cache claim.',
    'cases': {}}
rng = random.Random(1026)
for width in (1, 4, 8):
    for pct in (0, 1, 10, 50, 100):
        for batch in (0, 1024):
            name = f'fields{width}_accept{pct}_' + ('row' if batch == 0 else 'batch')
            print('Benchmark: ' + name, flush=True)
            for _ in range(2):
                for kind in ('before', 'after'): run(kind, width, pct, batch)
            measurements = []
            for pair in range(25):
                order = ('before', 'after') if pair % 2 == 0 else ('after', 'before')
                row = {k: run(k, width, pct, batch) for k in order}
                assert row['before']['checksum'] == row['after']['checksum']
                measurements.append(row)
            ratios = [sum(r['after']['full_seconds']) / sum(r['before']['full_seconds']) for r in measurements]
            boot = sorted(statistics.median(rng.choices(ratios, k=25)) for _ in range(10000))
            summary = {'paired_median_latency_ratio': statistics.median(ratios),
                'bootstrap_95_percent': [percentile(boot, .025), percentile(boot, .975)]}
            for kind in ('before', 'after'):
                metrics = {}
                for key in ('open_seconds', 'plan_seconds', 'first_row_seconds', 'full_seconds'):
                    values = [v for r in measurements for v in r[kind][key] if v is not None]
                    metrics[key] = {'samples': len(values), 'p50': statistics.median(values) if values else None,
                        'p95': percentile(values, .95) if values else None}
                full = [v for r in measurements for v in r[kind]['full_seconds']]
                metrics['median_input_rows_per_second'] = statistics.median(40000 / v for v in full)
                metrics['median_returned_rows_per_second'] = statistics.median(400 * pct / v for v in full)
                metrics['median_peak_process_working_set_bytes'] = statistics.median(r[kind]['peak_process_working_set_bytes'] for r in measurements)
                metrics['max_peak_process_working_set_bytes'] = max(r[kind]['peak_process_working_set_bytes'] for r in measurements)
                summary[kind] = metrics
            report['cases'][name] = {'width': width, 'selectivity_percent': pct, 'batch_size': batch,
                'summary': summary, 'measurements': measurements}
            (root / 'field-query-performance.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
            print(json.dumps({'case': name, 'ratio': summary['paired_median_latency_ratio'], 'ci': summary['bootstrap_95_percent']}), flush=True)

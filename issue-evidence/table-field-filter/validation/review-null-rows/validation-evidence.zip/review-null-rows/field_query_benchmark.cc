#include <fcntl.h>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include "common/tablet.h"
#include "file/local_random_access_read_file.h"
#include "file/write_file.h"
#include "reader/filter/table_field_filter.h"
#include "reader/table_query_executor.h"
#include "writer/tsfile_table_writer.h"
#include <windows.h>
#include <psapi.h>
using namespace common; using namespace storage;
using Clock=std::chrono::steady_clock;
void check(int r){if(r)throw std::runtime_error("error="+std::to_string(r));}
double elapsed(Clock::time_point start){return std::chrono::duration<double>(Clock::now()-start).count();}
const int N=40000,REPEATS=4;
struct Select : TableFieldFilter {
 int pct;int& calls;
 Select(int p,int& c):pct(p),calls(c){}
 int satisfy_row(const TableFieldRow& row,bool& ok)const override{
  ++calls;int64_t value=0;const auto* f=row.find("v0");
  if(!f||!f->get(value))return E_DECODE_ERR;
  ok=(value/8)%100<pct;return E_OK;
 }
};
int main(int argc,char**argv){
 libtsfile_init();std::vector<std::string> names;std::vector<ColumnSchema> cols;
 for(int c=0;c<8;++c){names.push_back("v"+std::to_string(c));cols.emplace_back(names.back(),common::INT64,UNCOMPRESSED,PLAIN,ColumnCategory::FIELD);}
 if(std::string(argv[1])=="write"){
  storage::WriteFile f;check(f.create(argv[2],O_WRONLY|O_CREAT|O_TRUNC|O_BINARY,0666));TableSchema schema("bench",cols);TsFileTableWriter w(&f,&schema);
  Tablet t("bench",schema.get_measurement_names(),schema.get_data_types(),schema.get_column_categories(),N);
  for(int r=0;r<N;++r){check(t.add_timestamp(r,r));for(int c=0;c<8;++c)check(t.add_value(r,c,int64_t(r*8+c)));}
  check(w.write_table(t));check(w.close());return 0;
 }
 int width=std::atoi(argv[3]),pct=std::atoi(argv[4]),batch=std::atoi(argv[5]);names.resize(width);
 uint64_t expected=0;int wanted=0;
 for(int r=0;r<N;++r)if(r%100<pct){++wanted;expected+=uint64_t(r)*(1+8*width)+width*(width-1)/2;}
 std::vector<double> opens,plans,firsts,fulls;int calls=0;uint64_t total_sum=0;
 for(int rep=0;rep<REPEATS;++rep){
  auto start=Clock::now();double first=-1,open=0,plan=0;int rows=0;uint64_t sum=0;
  {
   LocalRandomAccessReadFile file;check(file.open(argv[2]));open=elapsed(start);
   auto plan_start=Clock::now();TableQueryExecutor q(&file,batch);ResultSet* result=nullptr;
   check(q.query("bench",names,nullptr,nullptr,new Select(pct,calls),result));plan=elapsed(plan_start);
   bool next=false;
   while(true){check(result->next(next));if(!next)break;if(first<0)first=elapsed(start);
    if(batch<=0){for(int c=1;c<=width+1;++c){if(result->is_null(c))throw std::runtime_error("unexpected null");sum+=result->get_value<int64_t>(c);}++rows;}
    else{TsBlock* b=nullptr;check(result->get_next_tsblock(b));RowIterator it(b);while(it.has_next()){
     for(int c=0;c<=width;++c){uint32_t len=0;bool nil=false;char* ptr=it.read(c,&len,&nil);int64_t value=0;if(nil||len!=8)throw std::runtime_error("invalid cell");std::memcpy(&value,ptr,8);sum+=value;}++rows;it.next();
    }}
   }
   q.destroy_query_data_set(result);
  }
  if(rows!=wanted||sum!=expected)throw std::runtime_error("checksum/row mismatch");
  opens.push_back(open);plans.push_back(plan);firsts.push_back(first);fulls.push_back(elapsed(start));total_sum+=sum;
 }
 if(calls!=N*REPEATS)throw std::runtime_error("callback count mismatch");
 PROCESS_MEMORY_COUNTERS m{};m.cb=sizeof(m);if(!GetProcessMemoryInfo(GetCurrentProcess(),&m,sizeof(m)))throw std::runtime_error("memory query");
 auto arr=[](const std::vector<double>&a){std::cout<<"[";for(size_t i=0;i<a.size();++i){if(i)std::cout<<",";if(a[i]<0)std::cout<<"null";else std::cout<<a[i];}std::cout<<"]";};
 std::cout.precision(10);std::cout<<"{\"open_seconds\":";arr(opens);std::cout<<",\"plan_seconds\":";arr(plans);std::cout<<",\"first_row_seconds\":";arr(firsts);std::cout<<",\"full_seconds\":";arr(fulls);
 std::cout<<",\"input_rows_per_query\":"<<N<<",\"returned_rows_per_query\":"<<wanted<<",\"fields\":"<<width<<",\"selectivity_percent\":"<<pct<<",\"batch_size\":"<<batch<<",\"callback_calls\":"<<calls<<",\"checksum\":"<<total_sum<<",\"peak_process_working_set_bytes\":"<<m.PeakWorkingSetSize<<"}\n";
}

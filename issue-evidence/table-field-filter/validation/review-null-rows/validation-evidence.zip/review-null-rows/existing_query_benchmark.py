from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import os
import random
import statistics
import subprocess

root = Path(__file__).resolve().parent
validation_root = root.parent
binary = validation_root / 'program/Release'
affinity = ctypes.windll.kernel32.SetProcessAffinityMask
affinity.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
affinity.restype = wintypes.BOOL
sequence = 0

def run(kind, arguments):
    data = validation_root / ('benchmark-sparse.tsfile' if arguments[1] == 'sparse' else 'benchmark.tsfile')
    process = subprocess.Popen([str(binary / f'bench_{kind}.exe'), 'read', str(data), *map(str,arguments)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    applied = bool(affinity(wintypes.HANDLE(int(process._handle)), 4))
    stdout, stderr = process.communicate()
    assert applied, 'Could not set benchmark CPU affinity'
    if process.returncode: raise RuntimeError(stdout+'\n'+stderr)
    result = json.loads([line for line in stdout.splitlines() if line.startswith('{')][-1])
    result['affinity_mask'] = 4
    return result

def percentile(values, fraction):
    values=sorted(values); index=(len(values)-1)*fraction; lo=int(index); hi=min(lo+1,len(values)-1)
    return values[lo]*(hi-index)+values[hi]*(index-lo) if hi!=lo else values[lo]

cases = {f'{scenario}_{mode}': [batch, scenario] for scenario in ['all', 'time', 'offset', 'sparse'] for mode, batch in [('row', 0), ('batch', 1024)]}
report={'baseline_commit':'1180b13675e11a0230708af2cc70d037e0e12623',
    'platform':'Windows x64 MSVC 14.50 Release; static; threads/memstat enabled; uncompressed time/value columns',
    'method':'Identical driver and options; baseline/fixed static library; 300,000 x 8 INT64 fields; 8 full queries per process; every row/checksum validated; 2 warmups and 25 alternating process pairs; CPU affinity mask 4; timing includes file open/query/scan/result destruction, excludes fixture generation.',
    'scope':'Existing valid unfiltered aligned, time-filtered, OFFSET/LIMIT and sparse scalar paths. The old non-null field_filter was ignored or hung, so it is not an equivalent-operation baseline for the newly implemented predicate.',
    'cases':{}}
rng=random.Random(1020)
for name, arguments in cases.items():
    print('Benchmark: '+name,flush=True)
    for warmup in range(2):
        for kind in ['baseline','fixed']: run(kind,arguments)
    measurements=[]
    for pair in range(25):
        order=['baseline','fixed'] if pair%2==0 else ['fixed','baseline']
        row={kind:run(kind,arguments) for kind in order}
        measurements.append(row)
    ratios=[row['fixed']['seconds']/row['baseline']['seconds'] for row in measurements]
    bootstrap=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for repeat in range(10000))
    summary={'paired_median_latency_ratio':statistics.median(ratios),
        'bootstrap_95_percent':[percentile(bootstrap,.025),percentile(bootstrap,.975)]}
    for kind in ['baseline','fixed']:
        times=[row[kind]['seconds'] for row in measurements]
        summary[kind]={'median_seconds':statistics.median(times),'p95_seconds':percentile(times,.95),
            'median_rows_per_second':statistics.median(row[kind]['rows']*row[kind]['repeats']/row[kind]['seconds'] for row in measurements)}

    report['cases'][name]={'arguments':arguments,'summary':summary,'measurements':measurements}
    (root/'existing-query-performance.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'case':name,**summary}),flush=True)

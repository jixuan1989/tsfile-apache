#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include "common/tablet.h"
#include "file/local_random_access_read_file.h"
#include "file/write_file.h"
#include "reader/filter/table_field_filter.h"
#include "reader/filter/time_filter.h"
#include "reader/filter/time_operator.h"
#include "reader/table_query_executor.h"
#include "writer/tsfile_table_writer.h"
using namespace common; using namespace storage;
void check(int r) {if(r) throw std::runtime_error("error="+std::to_string(r));}
const int64_t base=INT64_C(1099511627776);
struct Predicate : TableFieldFilter {
    std::string name;
    Predicate(std::string n):name(n){}
    int satisfy_row(const TableFieldRow& row,bool& ok)const override{
        const auto* f=row.find(name); if(!f) return E_DECODE_ERR;
        ok=name=="nullable_flag" || f->is_null(); return E_OK;
    }
};
int main(int argc,char**argv){
 libtsfile_init();
 if(std::string(argv[1])=="write"){
  g_config_value_.page_writer_max_point_num_=3;
  WriteFile file;int flags=O_WRONLY|O_CREAT|O_TRUNC;
#ifdef _WIN32
  flags|=O_BINARY;
#endif
  check(file.create(argv[2],flags,0666));
  std::vector<ColumnSchema> cols;
  const std::vector<std::string> names{"id","v","tail_null","nullable_flag","empty"};
  const std::vector<TSDataType> types{STRING,INT64,INT64,BOOLEAN,INT64};
  for(size_t c=0;c<names.size();++c)cols.emplace_back(names[c],types[c],UNCOMPRESSED,PLAIN,c?ColumnCategory::FIELD:ColumnCategory::TAG);
  TableSchema schema("t",cols);TsFileTableWriter writer(&file,&schema);
  for(int chunk=0;chunk<2;++chunk){
   Tablet tab("t",schema.get_measurement_names(),schema.get_data_types(),schema.get_column_categories(),14);
   for(int dev=0;dev<2;++dev)for(int row=0;row<7;++row){int t=chunk*7+row,i=dev*7+row;
    check(tab.add_timestamp(i,base+t));check(tab.add_value(i,"id",dev?"d1":"d0"));check(tab.add_value(i,"v",int64_t(t)));
    if(t%3==0)check(tab.add_value(i,"tail_null",int64_t(t)));
    if(t%3!=0)check(tab.add_value(i,"nullable_flag",bool(t%2)));
   }
   check(writer.write_table(tab));check(writer.flush());
  }
  check(writer.close());return 0;
 }
 std::string mode=argv[3], name=mode=="tail"?"tail_null":mode=="bool"?"nullable_flag":"empty";
 Filter* time= mode=="tail"||mode=="bool"||mode=="empty-slice" ?TimeFilter::between(base+1,base+2,false):mode=="empty-outside"?TimeFilter::between(base+20,base+21,false):nullptr;
 LocalRandomAccessReadFile file;check(file.open(argv[2]));TableQueryExecutor q(&file);ResultSet* r=nullptr;
 check(q.query("t",{name},time,nullptr,new Predicate(name),mode=="empty-slice"?1:0,mode=="empty-slice"?2:-1,r));
 bool next=false;int rows=0;
 while(true){check(r->next(next));if(!next)break;
  std::cout<<r->get_value<int64_t>(1)<<",";
  if(r->is_null(name))std::cout<<"null";else if(name=="nullable_flag")std::cout<<(r->get_value<bool>(name)?"true":"false");else std::cout<<r->get_value<int64_t>(name);
  std::cout<<"\n";++rows;
 }
 q.destroy_query_data_set(r);std::cerr<<"rows="<<rows<<"\n";
}

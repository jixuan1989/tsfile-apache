from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import time
from urllib.request import urlopen

root=Path(__file__).resolve().parent
base=root.parents[3]
source=root.parent.parent/'repro-repo'
state_path=base/'work/tsfile-contribution-state.json'
state=json.loads(state_path.read_text(encoding='utf-8'))
summary=json.loads((root/'review-validation-summary.json').read_text(encoding='utf-8'))
assert summary['publication_gate_passed'] is True
head=summary['head']
gh=r'C:\Program Files\GitHub CLI\gh.exe'
fork='jixuan1989/tsfile-apache'
upstream='apache/tsfile'
branch='cpp/fix-table-field-filter'
evidence_branch='issue-evidence/table-field-filter'
prefix='issue-evidence/table-field-filter/validation/review-null-rows'
record_path=root/'review-publication.json'
record=json.loads(record_path.read_text(encoding='utf-8')) if record_path.exists() else {'head':head}
assert record['head']==head
env=os.environ.copy();env['PATH']=str(Path(gh).parent)+os.pathsep+env['PATH']
env['GODEBUG']='http2client=0';env['GIT_TERMINAL_PROMPT']='0'

def save(): record_path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(args):
    p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',env=env)
    if p.returncode: raise RuntimeError(f'{args[:3]}: {p.stderr}')
    return p.stdout.strip()
def api_once(endpoint,payload=None,method=None):
    args=[gh,'api',endpoint]
    if payload is not None:
        req=root/'github-review-request.json';req.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
        args+=['--method',method or 'POST','--input',str(req)]
    return json.loads(run(args))
def api(endpoint,payload=None,method=None):
    attempts=4 if payload is None or endpoint.endswith('/git/blobs') else 1
    for i in range(attempts):
        try:return api_once(endpoint,payload,method)
        except Exception:
            if i+1==attempts:raise
            time.sleep(2)

assert api('user')['login']=='jixuan1989'
assert run(['git','-C',str(source),'rev-parse','HEAD'])==head
assert run(['git','-C',str(source),'status','--porcelain'])==''
assert run(['git','-C',str(source),'branch','--show-current'])==branch
assert run(['git','-C',str(source),'remote','get-url','fork'])==f'https://github.com/{fork}.git'
if not record.get('source_pushed'):
    try:
        run(['git','-C',str(source),'-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','fork',branch])
    except Exception:
        if api(f'repos/{fork}/git/ref/heads/{branch}')['object']['sha']!=head:raise
    assert api(f'repos/{fork}/git/ref/heads/{branch}')['object']['sha']==head
    record['source_pushed']=True;save()
    print('Source revision pushed and verified.',flush=True)

assets={'validation-report.md':base/'outputs/TsFile_PR_03_审阅修订验证报告.md',
        'validation-evidence.zip':base/'outputs/TsFile_PR_03_审阅修订验证证据.zip'}
if not record.get('evidence_commit'):
    parent=api(f'repos/{fork}/git/ref/heads/{evidence_branch}')['object']['sha']
    old=api(f'repos/{fork}/git/commits/{parent}')
    entries=[]
    for name,p in assets.items():
        blob=api(f'repos/{fork}/git/blobs',{'encoding':'base64','content':base64.b64encode(p.read_bytes()).decode('ascii')})
        entries.append({'path':f'{prefix}/{name}','mode':'100644','type':'blob','sha':blob['sha']})
    tree=api(f'repos/{fork}/git/trees',{'base_tree':old['tree']['sha'],'tree':entries})
    commit=api(f'repos/{fork}/git/commits',{'message':'Record PR 1026 NULL review fixes and query performance evidence','tree':tree['sha'],'parents':[parent]})
    record['evidence_commit']=commit['sha'];save()
if not record.get('evidence_ref_updated'):
    if api(f'repos/{fork}/git/ref/heads/{evidence_branch}')['object']['sha']!=record['evidence_commit']:
        api(f'repos/{fork}/git/refs/heads/{evidence_branch}',{'sha':record['evidence_commit'],'force':False},'PATCH')
    record['evidence_ref_updated']=True;save()
if not record.get('evidence_verified'):
    for name,p in assets.items():
        url=f'https://raw.githubusercontent.com/{fork}/{record["evidence_commit"]}/{prefix}/{name}'
        for i in range(3):
            try:
                with urlopen(url,timeout=60) as r:data=r.read()
                assert hashlib.sha256(data).digest()==hashlib.sha256(p.read_bytes()).digest()
                break
            except Exception:
                if i==2:raise
                time.sleep(2)
    record['evidence_verified']=True;save()
record['report_url']=f'https://github.com/{fork}/blob/{record["evidence_commit"]}/{prefix}/validation-report.md'
record['evidence_url']=f'https://raw.githubusercontent.com/{fork}/{record["evidence_commit"]}/{prefix}/validation-evidence.zip'
body=(root/'pr-body-ready.md').read_text(encoding='utf-8').replace('{REPORT_URL}',record['report_url']).replace('{EVIDENCE_URL}',record['evidence_url'])
assert body.endswith(state['workflow']['ai_disclosure']['pr_footer']+'\n')
current=api(f'repos/{upstream}/pulls/1026')
assert current['head']['sha']==head and current['state']=='open' and not current['merged']
if current['body']!=body:
    try:api(f'repos/{upstream}/pulls/1026',{'body':body},'PATCH')
    except Exception:
        if api(f'repos/{upstream}/pulls/1026')['body']!=body:raise
assert api(f'repos/{upstream}/pulls/1026')['body']==body
record['pr_body_verified']=True;save()
(root/'pr-body.md').write_text(body,encoding='utf-8')
(base/'outputs/TsFile_PR_03_说明.md').write_text('# [C++] Apply field predicates to aligned table query rows\n\n'+body,encoding='utf-8')
print('Revision evidence hash-verified and PR body updated.',flush=True)

messages={
4305097605: '''Confirmed. The aligned value page's time statistics exclude NULL entries, so they cannot rule out candidate timestamps in the shared time page. I reproduced this with `(t0,42),(t1,NULL),(t2,NULL)` and a time window `[t1,t2]`: the prior PR returned 0 rows, while Java and the corrected C++ return 4 across two devices, on either writer's file. Commit {head} uses only shared time-page statistics for this conservative page check. Missing time statistics keep the page. The new test runs with row/batch-1/batch-4 and parallel on/off.

The revision also fixes the test-only TAG predicate leak behind the two Linux ASan CI failures: the query borrows this predicate, so it now has stack ownership. The old test reproduced 480 leaked bytes in six allocations; the revised Linux ASan/UBSan full suite passes with leak detection enabled.''',
4305097623: '''Confirmed. The BOOLEAN NULL scalar branch skipped the timestamp predicate and could emit an out-of-window NULL before FIELD evaluation and OFFSET/LIMIT. Commit {head} checks that timestamp, backs off the provisional row, and continues without consuming a value for a NULL. The two-device reproduction previously returned 6 rows for the window; revised C++ and Java return the same 4, with both Java-written and C++-written inputs. The test also verifies callback timestamps and OFFSET/LIMIT in all six row/batch/parallel configurations.''',
4305097635: '''Confirmed. A sole all-NULL aligned FIELD has a zero-count value index and no value context, but still has shared timestamps that must reach a NULL-aware predicate. Commit {head} uses the existing time-only context specifically for that aligned, zero-value-count, non-null-FIELD-filter case. The empty-result shortcut remains for non-aligned or other time-filtered-out value queries. Before the revision the reproduction returned 0 rows; revised C++ and Java return 28, or the same 2 after a time window and OFFSET/LIMIT, on both writers' files. Always-false, legacy-NULL rejection, and wholly outside-window controls are covered too.'''
}
footer='\n\nAI disclosure: This analysis, implementation, validation and reply were produced by OpenAI Codex.\n\nAI 使用说明：本分析、修改、验证和回复由 OpenAI Codex 完成。'
common='''

Validation for {head}: all 24 added regression configurations fail on the old PR head and pass after the fix; 74 focused, 979 Windows Release, 1000 all-codec Linux, and 999 Linux ASan/UBSan full-suite tests pass. Twenty added NULL-boundary Java/C++ own/cross-reader results match. Whole-PR changed executable lines: 87/89 (97.75%); review-only: 12/12 (100%). Query evidence retains the original eight cases and adds 30 native FIELD selectivity/projection cases with verified full results, open/metadata/first-row/full timing and process peak memory; comparison boundaries and unmeasured scope are documented.

[Revision report]({report}) · [Source, raw test and performance evidence]({evidence})'''
record.setdefault('review_replies',{})
for cid,text in messages.items():
    reply=(text+common).format(head=head,report=record['report_url'],evidence=record['evidence_url'])+footer
    # Read all comments before POST; exact body recovers an uncertain prior submission.
    comments=api(f'repos/{upstream}/pulls/1026/comments?per_page=100')
    matches=[c for c in comments if c.get('in_reply_to_id')==cid and c.get('body')==reply]
    assert len(matches)<=1
    if not matches:
        try:
            created=api(f'repos/{upstream}/pulls/1026/comments/{cid}/replies',{'body':reply})
            matches=[created]
        except Exception:
            comments=api(f'repos/{upstream}/pulls/1026/comments?per_page=100')
            matches=[c for c in comments if c.get('in_reply_to_id')==cid and c.get('body')==reply]
            if not matches:raise
    assert len(matches)==1 and matches[0]['body']==reply
    record['review_replies'][str(cid)]={'id':matches[0]['id'],'url':matches[0]['html_url'],'body_verified':True}
    save();print(f'Review thread {cid} replied and verified.',flush=True)
print(json.dumps(record,ensure_ascii=True,indent=2))

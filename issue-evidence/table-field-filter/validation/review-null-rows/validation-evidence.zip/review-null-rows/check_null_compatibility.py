from pathlib import Path
import hashlib
import json
import subprocess

v = Path(__file__).resolve().parent
cp = (v.parent / 'java-classpath.txt').read_text(encoding='utf-8').strip()
java = [r'C:\Program Files\Java\jdk-24\bin\java.exe', '-cp', str(v) + ';' + cp, 'NullRowsCompatibility']
cpp = [str(v / 'msvc/Release/null_compat_after.exe')]
old = [str(v / 'msvc/Release/null_compat_before.exe')]
records = []

def run(cmd):
    p = subprocess.run(list(map(str, cmd)), capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    records.append({'command': list(map(str, cmd)), 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
    (v / 'null-compatibility.json').write_text(json.dumps(records, indent=2) + '\n')
    assert p.returncode == 0, records[-1]
    return p.stdout.strip()

base = 1099511627776
expected = {
    'tail': '\n'.join(f'{base+t},null' for _ in range(2) for t in [1,2]),
    'bool': '\n'.join(f'{base+t},{str(t==1).lower()}' for _ in range(2) for t in [1,2]),
    'empty': '\n'.join(f'{base+t},null' for _ in range(2) for t in range(14)),
    'empty-slice': f'{base+2},null\n{base+1},null', 'empty-outside': ''}
differences = []
files = {}
for writer, prefix in [('java', java), ('cpp', cpp)]:
    file = v / (writer + '-nulls.tsfile')
    if file.exists(): file.unlink()
    run(prefix + ['write', file])
    files[writer] = file
    for mode, want in expected.items():
        before = run(old + ['read', file, mode])
        fixed = run(cpp + ['read', file, mode])
        reference = run(java + ['read', file, mode])
        assert fixed == reference == want, (writer, mode, fixed, reference, want)
        if before != want: differences.append({'writer': writer, 'case': mode, 'before_rows': len(before.splitlines()), 'fixed_rows': len(fixed.splitlines())})
        print(json.dumps({'writer': writer, 'case': mode, 'before_rows': len(before.splitlines()), 'fixed_rows': len(fixed.splitlines()), 'java_rows': len(reference.splitlines()), 'result': 'PASS'}), flush=True)
(v / 'null-compatibility-summary.json').write_text(json.dumps({'fixed_java_cross_reads': 20, 'prior_pr_reads': 10, 'before_differences': differences, 'input_file_hashes': {k: hashlib.sha256(p.read_bytes()).hexdigest() for k,p in files.items()}, 'oracle': 'Native Java time-filtered query and projected typed/null cells; Java application applies IS NULL and OFFSET/LIMIT. C++ uses native FIELD callback and OFFSET/LIMIT.'}, indent=2) + '\n')

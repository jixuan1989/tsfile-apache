#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2
v="$task_root/work/issue-03/validation/review-null-rows"
build=/tmp/tsfile-pr03-review-asan
"$task_root/work/wsl-tools/cmake/data/bin/cmake" --build "$build" --target TsFile_Test --parallel 6 > "$v/asan-after-build.log" 2>&1
cd /tmp/tsfile-pr03-review-asan-run
ASAN_OPTIONS=detect_leaks=1 "$build/test/lib/TsFile_Test" --gtest_filter='*TableFieldFilter*' --gtest_output=xml:"$v/asan-after-focused.xml" > "$v/asan-after-focused.log" 2>&1
ASAN_OPTIONS=detect_leaks=1 TSFILE_COMPAT_VALIDATE_DIR="$task_root/work/issue-03/validation/native-java-fixtures" "$build/test/lib/TsFile_Test" --gtest_output=xml:"$v/asan-after-full.xml" > "$v/asan-after-full.log" 2>&1
tail -n 10 "$v/asan-after-full.log"

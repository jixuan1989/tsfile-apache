import java.io.File;
import java.util.Arrays;
import org.apache.tsfile.enums.ColumnCategory;
import org.apache.tsfile.common.conf.TSFileDescriptor;
import org.apache.tsfile.enums.TSDataType;
import org.apache.tsfile.file.metadata.TableSchema;
import org.apache.tsfile.file.metadata.enums.CompressionType;
import org.apache.tsfile.file.metadata.enums.TSEncoding;
import org.apache.tsfile.read.TsFileSequenceReader;
import org.apache.tsfile.read.controller.CachedChunkLoaderImpl;
import org.apache.tsfile.read.controller.MetadataQuerierByFileImpl;
import org.apache.tsfile.read.expression.ExpressionTree;
import org.apache.tsfile.read.filter.basic.Filter;
import org.apache.tsfile.read.query.executor.TableQueryExecutor;
import org.apache.tsfile.read.reader.block.TsBlockReader;
import org.apache.tsfile.write.TsFileWriter;
import org.apache.tsfile.write.record.Tablet;
import org.apache.tsfile.write.schema.MeasurementSchema;

public class NullRowsCompatibility {
 static final long BASE=1099511627776L;
 public static void main(String[]args)throws Exception{
  TSFileDescriptor.getInstance().getConfig().setCompressor("UNCOMPRESSED");
  TSFileDescriptor.getInstance().getConfig().setMaxNumberOfPointsInPage(3);
  File file=new File(args[1]);
  if(args[0].equals("write")){
   java.util.List<String> names=Arrays.asList("id","v","tail_null","nullable_flag","empty");
   java.util.List<TSDataType> types=Arrays.asList(TSDataType.STRING,TSDataType.INT64,TSDataType.INT64,TSDataType.BOOLEAN,TSDataType.INT64);
   java.util.List<ColumnCategory> cats=Arrays.asList(ColumnCategory.TAG,ColumnCategory.FIELD,ColumnCategory.FIELD,ColumnCategory.FIELD,ColumnCategory.FIELD);
   java.util.List<org.apache.tsfile.write.schema.IMeasurementSchema> schemas=new java.util.ArrayList<>();
   for(int c=0;c<names.size();++c)schemas.add(new MeasurementSchema(names.get(c),types.get(c),TSEncoding.PLAIN,CompressionType.UNCOMPRESSED));
   try(TsFileWriter writer=new TsFileWriter(file)){
    writer.registerTableSchema(new TableSchema("t",schemas,cats));
    for(int chunk=0;chunk<2;++chunk){
     Tablet tab=new Tablet("t",names,types,cats,14);
     for(int dev=0;dev<2;++dev)for(int row=0;row<7;++row){int t=chunk*7+row,i=dev*7+row;
      tab.addTimestamp(i,BASE+t);tab.addValue("id",i,new org.apache.tsfile.utils.Binary((dev==0?"d0":"d1").getBytes(java.nio.charset.StandardCharsets.UTF_8)));
      tab.addValue("v",i,(long)t);tab.addValue("tail_null",i,t%3==0?Long.valueOf(t):null);
      tab.addValue("nullable_flag",i,t%3==0?null:Boolean.valueOf(t%2!=0));tab.addValue("empty",i,null);
     }
     tab.setRowSize(14);writer.writeTable(tab);writer.flush();
    }
   }return;
  }
  String mode=args[2],name=mode.equals("tail")?"tail_null":mode.equals("bool")?"nullable_flag":"empty";
  final long from=mode.equals("empty-outside")?BASE+20:BASE+1,to=mode.equals("empty-outside")?BASE+21:BASE+2;
  ExpressionTree time=mode.equals("empty")?null:new ExpressionTree(){
   public boolean satisfy(Object row){return true;}
   public Filter toFilter(){return org.apache.tsfile.read.filter.factory.TimeFilterApi.between(from,to);}
  };
  try(TsFileSequenceReader source=new TsFileSequenceReader(file.getPath())){
   TableQueryExecutor q=new TableQueryExecutor(new MetadataQuerierByFileImpl(source),new CachedChunkLoaderImpl(source),TableQueryExecutor.TableQueryOrdering.DEVICE);
   int rows=0,matched=0;
   try(TsBlockReader r=q.query("t",Arrays.asList(name),time,null,null)){
    while(r.hasNext()){
     org.apache.tsfile.read.common.block.TsBlock b=r.next();
     for(int i=0;i<b.getPositionCount();++i){boolean nil=b.getColumn(0).isNull(i);
      if(!name.equals("nullable_flag")&&!nil)continue;
      if(mode.equals("empty-slice")&&(matched++<1||rows>=2))continue;
      System.out.println(b.getTimeByIndex(i)+","+(nil?"null":Boolean.toString(b.getColumn(0).getBoolean(i))));++rows;
     }
    }
   }System.err.println("rows="+rows);
  }
 }
}

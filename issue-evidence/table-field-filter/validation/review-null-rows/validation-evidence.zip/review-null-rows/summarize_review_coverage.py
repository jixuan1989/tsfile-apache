from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(__file__).resolve().parent.parent
source = root.parent / 'repro-repo'
raw = json.loads((root / 'coverage-raw.json').read_text())
diff = subprocess.check_output(['git', '-C', str(source), 'diff', '--unified=0', 'e2e9c3786f9753ec5d5c1b813fd2f1fb0d71d5b8', '--', 'cpp/src'], text=True)
(root / 'review-null-rows/review-production.diff').write_text(diff, encoding='utf-8')
changed = {}
path = None
for line in diff.splitlines():
    if line.startswith('+++ b/'):
        path = line[6:]
        changed[path] = set()
    elif line.startswith('@@'):
        match = re.search(r'\+(\d+)(?:,(\d+))? @@', line)
        start = int(match[1]); count = int(match[2] or 1)
        changed[path].update(range(start, start + count))

merged = {}
aliases = {}
for file in raw['files']:
    original = file['file']
    if '/repro-repo/cpp/src/' in original:
        relative = original.split('/repro-repo/cpp/src/', 1)[1]
        disk = source / 'cpp/src' / relative
    elif '/linux-coverage-atomic/include/' in original:
        relative = original.split('/linux-coverage-atomic/include/', 1)[1]
        disk = root / 'linux-coverage-atomic/include' / relative
    else:
        raise AssertionError(original)
    key = 'cpp/src/' + relative
    assert disk.read_bytes() == (source / key).read_bytes(), original
    aliases.setdefault(key, []).append({'path': original, 'sha256': hashlib.sha256(disk.read_bytes()).hexdigest()})
    lines = merged.setdefault(key, {})
    for line in file['lines']:
        number = line['line_number']
        target = lines.setdefault(number, {'count': 0, 'branches': {}, 'functions': set()})
        assert line['count'] >= 0
        target['count'] += line['count']
        target['functions'].add(line.get('function_name', ''))
        for branch in line.get('branches', []):
            assert branch['count'] >= 0
            # Same physical header, compiler and branch identity; union coverage.
            identity = (branch.get('source_block_id'), branch['branchno'])
            target['branches'][identity] = target['branches'].get(identity, 0) + branch['count']

def summarize(lines):
    lines = list(lines)
    covered = sum(x['count'] > 0 for x in lines)
    branches = [count for x in lines for count in x['branches'].values()]
    return {'covered_lines': covered, 'executable_lines': len(lines),
            'line_percent': 100 * covered / len(lines) if lines else None,
            'covered_branches': sum(x > 0 for x in branches), 'branches': len(branches),
            'branch_percent': 100 * sum(x > 0 for x in branches) / len(branches) if branches else None}

per_file = {}
changed_lines = []
for path, lines in merged.items():
    selected = {n: line for n, line in lines.items() if n in changed.get(path, set())}
    changed_lines.extend(selected.values())
    per_file[path] = {'whole_file': summarize(lines.values()), 'changed': summarize(selected.values()),
                      'uncovered_changed_lines': [n for n, x in selected.items() if x['count'] == 0]}
result = {'method': 'GCC/gcovr; fresh atomic profiling build; identical source/copied headers merged by physical line and source-block/branch identity; no branch exclusions or ignored parse errors',
          'changed_production': summarize(changed_lines), 'per_file': per_file, 'aliases': aliases}
(root / 'review-null-rows/review-only-coverage-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

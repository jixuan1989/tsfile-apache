from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parent
validation = root.parent
base = validation.parents[2]
source = validation.parent / 'repro-repo'
out = base / 'outputs'
state = json.loads((base / 'work/tsfile-contribution-state.json').read_text(encoding='utf-8'))
head = subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert head == '249b0d51a6bfe202185aa21b794ff21ccdfafcf3'
assert subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip() == ''

def xml_result(name):
    xml = ET.parse(root / name).getroot()
    cases = list(xml.iter('testcase'))
    return {'passed':sum(c.get('status') != 'notrun' and c.find('skipped') is None and c.find('failure') is None for c in cases),
        'failed':int(xml.get('failures')), 'errors':int(xml.get('errors')),
        'skipped':sum(c.find('skipped') is not None for c in cases), 'disabled':int(xml.get('disabled'))}

tests={name:xml_result(name) for name in ['before.xml','after.xml','windows-all-tests.xml','linux-all-tests.xml','asan-after-focused.xml','asan-after-full.xml']}
assert tests['before.xml']['failed'] == 24
for name,result in tests.items():
    if name != 'before.xml': assert result['failed'] == result['errors'] == 0
assert tests['after.xml']['passed'] == 74
assert tests['windows-all-tests.xml']['passed'] == 979
assert tests['linux-all-tests.xml']['passed'] == 1000
assert tests['asan-after-full.xml']['passed'] == 999
assert (root/'asan-before-exit.txt').read_text().strip() == '1'
assert '480 byte(s) leaked in 6 allocation(s)' in (root/'asan-before.log').read_text(encoding='utf-8')
assert not re.search(r'ERROR:|SUMMARY:|runtime error:', (root/'asan-after-full.log').read_text(encoding='utf-8'))
assert 'C++ files read/validated by Java=117 PASS' in (root/'java-native-validation.log').read_text(encoding='utf-8')
coverage=json.loads((root/'coverage-summary.json').read_text(encoding='utf-8'))
review_coverage=json.loads((root/'review-only-coverage-summary.json').read_text(encoding='utf-8'))
compat=json.loads((root/'null-compatibility-summary.json').read_text(encoding='utf-8'))
assert compat['fixed_java_cross_reads'] == 20
field=json.loads((root/'field-query-performance.json').read_text(encoding='utf-8'))
existing=json.loads((root/'existing-query-performance.json').read_text(encoding='utf-8'))
assert len(field['cases']) == 30 and len(existing['cases']) == 8
for data in [field,existing]:
    assert all(len(v['measurements']) == 25 for v in data['cases'].values())
assert not any(v['summary']['bootstrap_95_percent'][0] > 1 for data in [field,existing] for v in data['cases'].values())

def pct(a,b): return f'{a}/{b} ({100*a/b:.2f}%)'
def coverage_table():
    rows=['| Production file | Whole-file lines | Whole-file branches |','|---|---:|---:|']
    for path,data in coverage['per_file'].items():
        c=data['whole_file'];rows.append(f'| `{path}` | {pct(c["covered_lines"],c["executable_lines"])} | {pct(c["covered_branches"],c["branches"])} |')
    return '\n'.join(rows)
def performance_table(data, field_mode=False):
    rows=['| Case | After / baseline median paired latency | 95% bootstrap interval | Baseline / after p95 (s) |','|---|---:|---|---|']
    for name,case in data['cases'].items():
        c=case['summary'];lo,hi=c['bootstrap_95_percent']
        if field_mode:
            before=c['before']['full_seconds']['p95'];after=c['after']['full_seconds']['p95']
        else:
            before=c['baseline']['p95_seconds'];after=c['fixed']['p95_seconds']
        rows.append(f'| `{name}` | {c["paired_median_latency_ratio"]:.4f} | [{lo:.4f}, {hi:.4f}] | {before:.6f} / {after:.6f} |')
    return '\n'.join(rows)

c=coverage['changed_production']; rc=review_coverage['changed_production']
review_explanation='''### Review revision: aligned NULLs and time predicates

All three Copilot findings were reproduced against prior PR head `e2e9c3786f9753ec5d5c1b813fd2f1fb0d71d5b8`. Four new cases × six row/batch/parallel configurations failed before the revision (24/24) and pass afterward.

* An aligned value page's statistics cover non-NULL values only. Its last value timestamp can precede NULL timestamps still present in the shared time page. Page rejection now uses the shared time-page statistics only; an absent statistic conservatively keeps the page. For `(t0,42),(t1,NULL),(t2,NULL)`, a query restricted to `[t1,t2]` must still present both NULL rows to a NULL-aware FIELD predicate.
* The scalar BOOLEAN decoder previously appended a NULL before applying the time predicate. It now tests the decoded timestamp and backs off the provisional row before continuing when the time does not match. No value decoder advances for a NULL. This prevents an out-of-window NULL from reaching FIELD evaluation or consuming OFFSET/LIMIT.
* A sole all-NULL selected aligned FIELD has no value context. For a non-null FIELD predicate and an aligned value index with count zero, the reader now uses the existing time-only context to supply candidate timestamps and typed NULL values. Other empty-value queries retain the existing empty-result shortcut, including non-aligned sources and nonzero-value series eliminated by the time filter. Unfiltered behavior is unchanged.
* The Linux ASan CI failures were a separate test ownership error: TAG predicates are borrowed, so the combined-filter test now passes a stack-owned TAG predicate instead of leaking an allocation. The old test reproduced 480 leaked bytes in six allocations locally. Linux ASan/UBSan with leak detection enabled now passes the focused 74 tests and the full suite, with no suppressed sanitizer diagnostics.

The before/after C++ results on **both Java-written and C++-written files** are:

| Query | Prior PR C++ rows | Revised C++ rows | Java reference rows |
|---|---:|---:|---:|
| trailing NULLs, time window, `IS NULL` | 0 | 4 | 4 |
| nullable BOOLEAN, time window, accept-all | 6 | 4 | 4 |
| sole all-NULL FIELD, `IS NULL` | 0 | 28 | 28 |
| sole all-NULL FIELD, time/OFFSET/LIMIT | 0 | 2 | 2 |
| outside time window | 0 | 0 | 0 |

Twenty revised C++/Java own/cross-reader results match exactly. Ten prior-PR C++ reads are retained, including eight mismatches. Java performs native time filtering and projected reads, followed by application-level `IS NULL` and OFFSET/LIMIT; this is a result oracle, not a native Java FIELD callback performance baseline. Full source and actual row outputs are in the revision evidence.
'''
validation_text=f'''### Validation after review

Base: `1180b13675e11a0230708af2cc70d037e0e12623`; previous PR head: `e2e9c3786f9753ec5d5c1b813fd2f1fb0d71d5b8`; revised head: `{head}`.

* 74 focused tests pass: row/batch sizes 1 and 4, parallel on/off, typed/legacy predicates, NULL/binary/primitive boundaries, timestamp width, combined time/TAG/FIELD filtering, page/chunk/device transitions, OFFSET/LIMIT and terminal errors. The 24 new review regressions fail before and pass after.
* Windows Release: **979 passed**, 3 opt-in skipped; Linux GCC C++11 with all six optional codecs: **1000 passed**, 1 external-index skipped. Both have 10 pre-existing disabled tests.
* Linux Debug ASan/UBSan with leak detection: **74 focused and 999 full-suite tests passed**, 2 opt-in skipped and 10 pre-existing disabled. The full run validates the 135 fresh Java fixtures; C++ fixture generation is opt-in and disabled for this sanitizer run. No runtime-error or sanitizer diagnostics in the full log.
* Original 12 Java native callback own/cross-reads and 24 multi-type comparisons still match. Added 20 NULL-boundary comparisons match. With all six codecs enabled, C++ validates 135 Java fixtures and Java validates 117 C++ fixtures generated by this revision.
* Whole-PR changed/new executable lines: **{pct(c['covered_lines'],c['executable_lines'])}**; branches **{pct(c['covered_branches'],c['branches'])}**. Review-only changed lines: **{pct(rc['covered_lines'],rc['executable_lines'])}**; branches **{pct(rc['covered_branches'],rc['branches'])}**. Two whole-PR uncovered lines are defensive current-context error returns. GCC attributes generated decoder macro bodies to their expansion/physical lines; this is executable-line coverage, not a claim to cover every generated instruction. Source/copied-header hashes match; normal compiler branches are included without exclusions.

{coverage_table()}

Windows optional-codec fixture generation still has the documented untouched-baseline failure (336 matching assertion values), so compressed-file compatibility is validated by the all-codec Linux build. The earlier CRLF fixture-manifest normalization and unchanged 135 TsFile hashes remain documented in the original report. Explicit `"time"` projection remains an existing table-schema limitation; ordinary implicit timestamps and TAG-only projection are tested.
'''
performance_text=f'''### Query performance after review

Query and write scope are reported separately. This revision changes reader paths and test ownership only; no writer, encoder, Java source or on-disk format changed. Existing write results are retained, and writing was not retimed for this reader revision.

**Existing eight query cases: develop base versus revised head.** Same verified 300,000-row × 8 INT64 PLAIN/UNCOMPRESSED files, same MSVC Release static configuration, eight fully consumed/checksummed queries per process, two warmups then 25 alternating process pairs, CPU affinity mask 4. The p95 below is **process time for eight queries**, not individual-request p95. Timing includes open/setup/read/checksum/cleanup; no cold-cache claim. The original initial and 300-pair confirmation measurements remain linked and preserved.

{performance_table(existing)}

**FIELD selectivity and projection: prior PR head versus revised head.** Thirty cases cover 1/4/8 projected FIELDs, 0/1/10/50/100% accepted rows and row/batch-1024 APIs. The identical dense file has 40,000 rows × 8 INT64 PLAIN/UNCOMPRESSED fields. Prior PR head correctly executes the same native callback on these non-NULL inputs, so it is a valid baseline for this revision's filtering cost. The upstream ignored/hanging implementation is not used as an equivalent filtering baseline.

Two warmups and 25 alternating process pairs per case, four queries/process, CPU affinity mask 4; every cell, returned row count, checksum and 160,000 callbacks/process are checked. Raw per-query arrays provide file-open time, metadata/query-plan time, first-row time (unavailable at 0% results), complete query latency and throughput; peak working set is the **whole process**, not incremental query memory. Per-query p50/p95 use 100 queries per variant/case clustered in 25 processes; bootstrap ratios resample the 25 process pairs. No P99 or controlled cold-cache result is claimed.

{performance_table(field,True)}

Full metrics and every initial sample, including outliers, are retained in `field-query-performance.json` and `existing-query-performance.json`. NULL/page/chunk/device and parallel boundaries are covered by correctness tests; the new FIELD timing matrix is dense, one-device, single-reader, uncompressed. It does not measure a TAG selectivity matrix, FIELD-filtered sparse/NULL latency, non-aligned FIELD performance, compressed-query performance, or parallel scaling. Those scopes remain explicitly unmeasured. Original and revised query comparisons do not prove universal Java/C++ performance equivalence.

No case in either new dataset has its paired-median 95% interval wholly above 1. The measured scope shows no statistically clear slowdown; this does not establish an absolute absence of regressions or a p95 non-inferiority guarantee. Individual higher p95 samples and outliers are preserved in the tables and raw data.
'''

original=(validation/'pr-body.md').read_text(encoding='utf-8')
intro=original.split('### Validation')[0]
body=intro+review_explanation+'\n'+validation_text+'\n'+performance_text+'''
[Review revision validation report]({REPORT_URL}) · [Revision sources, scripts, raw logs and measurements]({EVIDENCE_URL})

[Original validation report](https://github.com/jixuan1989/tsfile-apache/blob/f93a65a0bab8cd0fda3f255fb7f8b95f74beb3d9/issue-evidence/table-field-filter/validation/validation-report.md) · [Original evidence, including all initial and confirmation performance samples](https://raw.githubusercontent.com/jixuan1989/tsfile-apache/f93a65a0bab8cd0fda3f255fb7f8b95f74beb3d9/issue-evidence/table-field-filter/validation/validation-evidence.zip)

'''+state['workflow']['ai_disclosure']['pr_footer']+'\n'
(root/'pr-body-ready.md').write_text(body,encoding='utf-8')
report='''# TsFile PR #1026：NULL 审阅修订与查询性能补测

三条审阅意见均有效，已逐条复现并修复。NULL 的时间过滤必须先于 FIELD 回调及 OFFSET/LIMIT；全 NULL 对齐列仍需借助共享时间列生成候选行。测试中 TAG 过滤器的借用生命周期也已修复。以下保留英文实现说明、实际计数和完整性能数据，方便上游直接核对。

'''+review_explanation+'\n'+validation_text+'\n'+performance_text+'\n'+state['workflow']['ai_disclosure']['pr_footer']+'\n'
report_path=out/'TsFile_PR_03_审阅修订验证报告.md'
report_path.write_text(report,encoding='utf-8')
summary={'head':head,'publication_gate_passed':True,'tests':tests,'coverage':coverage,'review_only_coverage':review_coverage,
    'compatibility':compat,'field_cases':30,'existing_query_cases':8,
    'performance_cases_with_lower_ci_above_one':{group:[n for n,v in d['cases'].items() if v['summary']['bootstrap_95_percent'][0]>1] for group,d in [('field',field),('existing',existing)]},
    'performance_interpretation':'Assess preserved intervals and repeatable regressions before publication; no automatic pass on noisy samples.'}
(root/'review-validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
assets={}
for p in root.iterdir():
    if p.is_file() and p.suffix in {'.cc','.h','.java','.py','.ps1','.sh','.json','.xml','.log','.txt','.diff','.md','.tsfile'}:
        if p.name.startswith('github-') or p.name in {'pr-body-ready.md','evidence-manifest.json','review-publication.json'}: continue
        assets['review-null-rows/'+p.name]=p
for name in ['aligned_chunk_reader.cc','block/single_device_tsblock_reader.cc','filter/table_field_filter.h','filter/table_field_filter.cc','block/single_device_tsblock_reader.h']:
    assets['source/cpp/src/reader/'+name]=source/'cpp/src/reader'/name
assets['source/cpp/test/reader/table_field_filter_test.cc']=source/'cpp/test/reader/table_field_filter_test.cc'
for name in ['final-native.ps1','check_compatibility.py','normalize_fixture_manifest.py','summarize_coverage.py','benchmark.cc','CMakeLists.txt']:
    if (validation/name).exists(): assets['original-validation/'+name]=validation/name
assets['validation-report.md']=report_path
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in assets.items()}
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(out/'TsFile_PR_03_审阅修订验证证据.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,p in assets.items(): z.write(p,name)
    z.write(root/'evidence-manifest.json','evidence-manifest.json')
print(json.dumps({'head':head,'tests':tests,'changed_lines':c,'review_changed_lines':rc,
    'performance_investigation':summary['performance_cases_with_lower_ci_above_one']},ensure_ascii=True,indent=2))

#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/c/Users/hxd/Documents/Codex/2026-10-17/new-chat-2
v="$task_root/work/issue-03/validation/review-null-rows"
build=/tmp/tsfile-pr03-review-asan
cmake="$task_root/work/wsl-tools/cmake/data/bin/cmake"
"$cmake" -S "$task_root/work/issue-03/repro-repo/cpp" -B "$build" -DCMAKE_BUILD_TYPE=Debug -DENABLE_ASAN=ON -DTSFILE_BUILD_SHARED=OFF -DBUILD_TEST=ON -DBUILD_TOOLS=OFF -DENABLE_ANTLR4=OFF -DENABLE_SIMD=OFF -DENABLE_THREADS=ON -DENABLE_SNAPPY=ON -DENABLE_LZ4=ON -DENABLE_LZOKAY=ON -DENABLE_ZLIB=ON -DENABLE_ZSTD=ON -DENABLE_LZMA2=ON -DTSFILE_DEPENDENCY_CACHE="$task_root/work/issue-01/validation/linux-coverage/dependency-cache" > "$v/asan-before-configure.log" 2>&1
"$cmake" --build "$build" --target TsFile_Test --parallel 6 > "$v/asan-before-build.log" 2>&1
mkdir -p /tmp/tsfile-pr03-review-asan-run
cd /tmp/tsfile-pr03-review-asan-run
set +e
ASAN_OPTIONS=detect_leaks=1 "$build/test/lib/TsFile_Test" --gtest_filter='*TimeAndTagFiltersComposeWithFieldFilter*' --gtest_output=xml:"$v/asan-before.xml" > "$v/asan-before.log" 2>&1
ret=$?
set -e
printf '%s\n' "$ret" > "$v/asan-before-exit.txt"
test "$ret" -ne 0
grep -A4 'LeakSanitizer' "$v/asan-before.log"
